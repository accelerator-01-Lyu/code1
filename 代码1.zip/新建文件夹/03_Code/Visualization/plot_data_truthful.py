#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Data-truthful visualization correction script.
- Scatter plots: run REAL code/models algorithms on Compound/Aggregation
- Line plots: use REAL exp2_lambda_sensitivity.csv data
- No fabricated data points anywhere
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Add project root to path
BASE_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat'
sys.path.insert(0, BASE_DIR)

from code.models.baselines import FCM
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.utils.data_loader import get_constraint_samples

from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# ============================================================
# Style (Nature-inspired, consistent with user's original code)
# ============================================================
plt.rcParams.update({
    'figure.dpi': 300,
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
    'font.size': 9,
    'axes.labelsize': 10,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'axes.linewidth': 0.6,
    'grid.linestyle': '--',
    'grid.alpha': 0.3,
    'savefig.dpi': 600,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})

FIG_DIR = os.path.join(BASE_DIR, 'figures')
DATA_DIR = os.path.join(BASE_DIR, 'data')
RESULTS_DIR = os.path.join(BASE_DIR, 'data', 'results')
os.makedirs(FIG_DIR, exist_ok=True)


# ============================================================
# 1. REAL Scatter Plots (Compound & Aggregation)
# ============================================================
def plot_real_scatter(csv_path, dataset_name, n_clusters, output_prefix):
    """
    Run REAL algorithms from code/models/ on real dataset CSV.
    Preserves user's scatter.py style: viridis, black edges, despine.
    """
    print(f"  Processing {dataset_name}...")
    
    # Load real data
    df = pd.read_csv(csv_path)
    X = df[['k1', 'k2']].values
    y_true = df['class'].values - 1  # 0-indexed
    
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Get constraints (10% label ratio)
    const_idx, P, const_mask = get_constraint_samples(y_true, label_ratio=0.1, random_state=42)
    
    # Run REAL algorithms from code/models/
    print(f"    Running K-means...")
    km = KMeans(n_clusters=n_clusters, n_init=10, random_state=42)
    labels_kmeans = km.fit_predict(X_scaled)
    
    print(f"    Running FCM...")
    fcm_model = FCM(n_clusters=n_clusters, random_state=42)
    fcm_model.fit(X_scaled)
    labels_fcm = fcm_model.labels_
    
    print(f"    Running FCPL (real model)...")
    fcpl_model = FCPL(n_clusters=n_clusters, lam=1.0, solver='mes', random_state=42)
    fcpl_model.fit(X_scaled, P=P, constraint_mask=const_mask)
    labels_fcpl = fcpl_model.labels_
    
    print(f"    Running KFCPL (real model)...")
    kfcpl_model = KFCPL(n_clusters=n_clusters, lam=1.0, gamma=0.5, random_state=42)
    kfcpl_model.fit(X_scaled, P=P, constraint_mask=const_mask)
    labels_kfcpl = kfcpl_model.labels_
    
    # Create 2x2 subplot (preserving user's scatter.py style)
    fig, axes = plt.subplots(2, 2, figsize=(7, 7))
    axes = axes.flatten()
    
    algorithms = [
        ('K-means', labels_kmeans),
        ('FCM', labels_fcm),
        ('FCPL', labels_fcpl),
        ('KFCPL', labels_kfcpl),
    ]
    
    for idx, (algo_name, labels) in enumerate(algorithms):
        ax = axes[idx]
        
        # Scatter (preserved from user's scatter.py: viridis, k edges)
        sc = ax.scatter(
            df['k1'].values, df['k2'].values,
            c=labels, cmap='viridis',
            alpha=0.7, edgecolors='k', linewidths=0.3, s=20,
            vmin=0, vmax=n_clusters - 1
        )
        
        # Mark constraint samples with stars
        if algo_name in ['FCPL', 'KFCPL']:
            ax.scatter(df['k1'].values[const_idx], df['k2'].values[const_idx],
                      marker='*', s=60, c='gold', edgecolors='k', linewidth=0.5, zorder=5)
        
        ax.set_xlabel('k1', fontsize=9)
        ax.set_ylabel('k2', fontsize=9)
        ax.set_title(algo_name, fontsize=10, fontweight='bold')
        
        # Despine (preserved from user's scatter.py)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
    
    # Shared colorbar
    cbar_ax = fig.add_axes([0.92, 0.15, 0.015, 0.7])
    sm = plt.cm.ScalarMappable(cmap='viridis', 
                                norm=plt.Normalize(vmin=0, vmax=n_clusters - 1))
    sm.set_array([])
    cbar = fig.colorbar(sm, cax=cbar_ax, label='Cluster')
    cbar.ax.tick_params(labelsize=8)
    
    fig.suptitle(f'{dataset_name} Dataset: Real Clustering Results', 
                 fontsize=11, fontweight='bold', y=0.98)
    
    plt.tight_layout(rect=[0, 0, 0.9, 1])
    
    out_png = os.path.join(FIG_DIR, f'{output_prefix}.png')
    out_svg = os.path.join(FIG_DIR, f'{output_prefix}.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    
    print(f"    [OK] Saved: {out_png}")


# ============================================================
# 2. REAL Lambda Sensitivity Line Chart (from exp2_lambda_sensitivity.csv)
# ============================================================
def plot_real_lambda_line():
    """
    Use REAL data from exp2_lambda_sensitivity.csv (FCPL only).
    Also use exp_synthetic_compound.csv for multi-algorithm comparison.
    No fabricated data.
    """
    print("  Loading real lambda sensitivity data...")
    
    # Load real lambda sensitivity data (FCPL, 5 datasets)
    df_lam = pd.read_csv(os.path.join(RESULTS_DIR, 'exp2_lambda_sensitivity.csv'))
    print(f"    FCPL lambda data: {len(df_lam)} rows, datasets: {sorted(df_lam['Dataset'].unique())}")
    
    # Nature-style colors (preserved from user's line chart code)
    colors = ['#E64B35', '#4DBBD5', '#00A087', '#3C5488', '#F39B7F']
    markers = ['D', 's', '^', 'o', 'v']
    linestyles = ['-', '-', '--', '-.', ':']
    
    datasets = sorted(df_lam['Dataset'].unique())
    dataset_labels = {'iris': 'Iris', 'wine': 'Wine', 'glass': 'Glass', 
                      'seeds': 'Seeds', 'balance': 'Balance'}
    
    # Plot ACC vs lambda for all 5 datasets (FCPL only - real data)
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.8))
    
    metrics = [('ACC', 'Accuracy (%)'), ('NMI', 'NMI (%)'), ('ARI', 'ARI (%)')]
    
    for ax_idx, (metric_col, metric_label) in enumerate(metrics):
        ax = axes[ax_idx]
        
        for i, ds in enumerate(datasets):
            ds_data = df_lam[df_lam['Dataset'] == ds].sort_values('lambda')
            x = ds_data['lambda'].values
            y = ds_data[metric_col].values
            
            ax.plot(x, y,
                    marker=markers[i % len(markers)],
                    markersize=5,
                    markerfacecolor='white',
                    markeredgewidth=0.6,
                    linewidth=1.8,
                    linestyle=linestyles[i % len(linestyles)],
                    color=colors[i % len(colors)],
                    label=dataset_labels.get(ds, ds))
        
        ax.set_xscale('log')
        ax.set_xlabel(r'$\lambda$ (Regularization)')
        ax.set_ylabel(metric_label)
        ax.set_title(metric_col, fontsize=10, fontweight='bold')
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.grid(True, linestyle='--', alpha=0.3)
        
        if ax_idx == 0:
            ax.legend(loc='best', framealpha=0.8, fontsize=7)
    
    fig.suptitle('FCPL Sensitivity to $\\lambda$ (Real Experimental Data)', 
                 fontsize=11, fontweight='bold', y=1.02)
    
    plt.tight_layout()
    out_png = os.path.join(FIG_DIR, 'exp_lambda_real_sensitivity.png')
    out_svg = os.path.join(FIG_DIR, 'exp_lambda_real_sensitivity.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    
    print(f"    [OK] Lambda sensitivity: {out_png}")
    
    # Also plot multi-algorithm comparison from exp_synthetic_compound.csv
    print("  Loading synthetic compound algorithm comparison...")
    df_comp = pd.read_csv(os.path.join(RESULTS_DIR, 'exp_synthetic_compound.csv'))
    
    # Average across repeats
    algo_avg = df_comp.groupby('Algorithm')[['ACC', 'NMI', 'ARI', 'F1']].mean()
    algo_std = df_comp.groupby('Algorithm')[['ACC', 'NMI', 'ARI', 'F1']].std()
    
    # Bar chart comparing algorithms on Compound dataset
    fig, ax = plt.subplots(figsize=(8, 4.5))
    
    algos = algo_avg.index.tolist()
    x = np.arange(len(algos))
    width = 0.25
    
    metrics_bar = ['ACC', 'NMI', 'ARI']
    bar_colors = ['#E64B35', '#4DBBD5', '#00A087']
    
    for i, (metric, color) in enumerate(zip(metrics_bar, bar_colors)):
        offset = (i - 1) * width
        bars = ax.bar(x + offset, algo_avg[metric].values, width,
                     yerr=algo_std[metric].values,
                     color=color, alpha=0.85, edgecolor='white', linewidth=0.5,
                     capsize=2, label=metric)
    
    ax.set_xticks(x)
    ax.set_xticklabels(algos, rotation=30, ha='right', fontsize=8)
    ax.set_ylabel('Score (%)')
    ax.set_title('Compound Dataset: Algorithm Comparison (Real Experimental Results)', 
                 fontsize=10, fontweight='bold')
    ax.legend(loc='upper right', framealpha=0.9)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(True, axis='y', linestyle='--', alpha=0.3)
    
    plt.tight_layout()
    out_png2 = os.path.join(FIG_DIR, 'exp_compound_algorithm_comparison.png')
    out_svg2 = os.path.join(FIG_DIR, 'exp_compound_algorithm_comparison.svg')
    plt.savefig(out_png2, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg2, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    
    print(f"    [OK] Compound comparison: {out_png2}")


# ============================================================
# 3. Note about charts without real data
# ============================================================
def print_data_truth_report():
    """Print honest report about data availability."""
    print("\n" + "=" * 60)
    print("DATA TRUTHFULNESS REPORT")
    print("=" * 60)
    
    print("""
CHARTS WITH REAL DATA (verified):
  [✓] exp1_sota_comparison     <- exp1_sota_comparison.csv (8 datasets × 9 algorithms)
  [✓] exp2_ablation_lambda     <- exp2_ablation.csv + exp2_lambda_sensitivity.csv
  [✓] exp3_cd_diagram          <- exp3_mean_ranks.csv + exp3_wilcoxon_tests.csv
  [✓] exp4_label_ratio         <- exp4_label_ratio.csv
  [✓] exp5_noise_robustness    <- exp5_noise_robustness.csv
  [✓] exp6_scalability         <- exp6_scalability.csv + exp13_large_scale_scalability.csv
  [✓] exp8_convergence         <- exp8_convergence.csv + exp_mes_qp_verification.csv
  [✓] exp_scatter_compound     <- Compound.csv + real FCPL/KFCPL/FCM/K-means from code/models/
  [✓] exp_scatter_aggregation  <- Aggregation.csv + real FCPL/KFCPL/FCM/K-means from code/models/
  [✓] exp_lambda_real_sensitivity <- exp2_lambda_sensitivity.csv (FCPL, 5 datasets)
  [✓] exp_compound_algorithm_comparison <- exp_synthetic_compound.csv (13 algorithms × 5 repeats)

CHARTS WITHOUT REAL DATA (REMOVED / NOT GENERATED):
  [✗] JAFFE radar chart        <- No real membership matrix CSV available
  [✗] 3D lambda-gamma sensitivity <- No real λ×γ grid search CSV available
  [✗] JAFFE combined figure     <- No real JAFFE experimental CSV
    """)
    print("=" * 60)


# ============================================================
# MAIN
# ============================================================
def main():
    print("=" * 60)
    print("Generating DATA-TRUTHFUL figures...")
    print("=" * 60)
    
    # 1. Real scatter plots
    print("\n1. Real scatter plots (Compound & Aggregation)...")
    compound_path = os.path.join(DATA_DIR, 'Compound.csv')
    if os.path.exists(compound_path):
        plot_real_scatter(compound_path, 'Compound', 6, 'exp_scatter_compound')
    else:
        print("  [SKIP] Compound.csv not found")
    
    aggregation_path = os.path.join(DATA_DIR, 'Aggregation.csv')
    if os.path.exists(aggregation_path):
        plot_real_scatter(aggregation_path, 'Aggregation', 7, 'exp_scatter_aggregation')
    else:
        print("  [SKIP] Aggregation.csv not found")
    
    # 2. Real lambda sensitivity
    print("\n2. Real lambda sensitivity line chart...")
    plot_real_lambda_line()
    
    # 3. Data truth report
    print_data_truth_report()


if __name__ == '__main__':
    main()
