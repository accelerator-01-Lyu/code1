#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
v5 Complete Chart Regeneration - All remaining charts
Nature-style colors from v5_style.py
"""

import os
import sys
import ast
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import linear_sum_assignment

BASE_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat'
sys.path.insert(0, BASE_DIR)
sys.path.insert(0, os.path.join(BASE_DIR, 'code', 'figures'))

from v5_style import (
    apply_nature_style, ALGO_COLORS, ALGO_MARKERS,
    BLUE_GREEN_CMAP, get_algo_style
)
apply_nature_style()

from code.models.baselines import FCM
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.utils.data_loader import get_constraint_samples
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

DATA_DIR = os.path.join(BASE_DIR, 'data', 'results')
FIG_DIR = os.path.join(BASE_DIR, 'figures')
DATA_RAW = os.path.join(BASE_DIR, 'data')

DATASET_NAMES = {
    'iris': 'Iris', 'wine': 'Wine', 'breast_cancer': 'Breast',
    'glass': 'Glass', 'seeds': 'Seeds', 'balance': 'Balance',
    'vehicle': 'Vehicle', 'segment': 'Segment',
    'ionosphere': 'Ionosphere', 'sonar': 'Sonar',
    'ecoli': 'Ecoli', 'diabetes': 'Diabetes', 'heart': 'Heart',
    'optdigits': 'Optdigits', 'yeast': 'Yeast',
}

REPR_ALGOS = ['K-means', 'FCM', 'SFCM', 'SSFCM', 'FCPL', 'KFCPL']


def despine(ax):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)


def add_panel_label(ax, label, x=-0.12, y=1.05):
    ax.text(x, y, f'({label})', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top', ha='right')


def compute_acc(y_true, y_pred):
    labels_true = np.unique(y_true)
    labels_pred = np.unique(y_pred)
    n = max(len(labels_true), len(labels_pred))
    cost = np.zeros((n, n))
    for i, lt in enumerate(labels_true):
        for j, lp in enumerate(labels_pred):
            cost[i, j] = -np.sum((y_true == lt) & (y_pred == lp))
    row_ind, col_ind = linear_sum_assignment(cost)
    return -cost[row_ind, col_ind].sum() / len(y_true) * 100


# ============================================================
# Fig6: Scatter Plots (Compound & Aggregation)
# ============================================================
def fig6_scatter():
    from code.models.baselines import FCM as FCMModel
    
    datasets = [
        ('Compound.csv', 'Compound', 6, 'v5_fig6_scatter_compound',
         {'lam': 1.0, 'm': 1.5, 'label_ratio': 0.8, 'preprocess': True},
         {'lam': 0.1, 'm': 1.2, 'gamma': 0.5, 'label_ratio': 0.4, 'preprocess': False}),
        ('Aggregation.csv', 'Aggregation', 7, 'v5_fig6_scatter_aggregation',
         {'lam': 200.0, 'm': 2.5, 'label_ratio': 0.4, 'preprocess': False},
         {'lam': 2.0, 'm': 2.0, 'gamma': 0.5, 'label_ratio': 0.4, 'preprocess': False}),
    ]
    
    for csv_name, ds_name, n_clust, out_prefix, fcpl_p, kfcpl_p in datasets:
        print(f"  Processing {ds_name}...")
        df = pd.read_csv(os.path.join(DATA_RAW, csv_name))
        X_raw = df[['k1', 'k2']].values
        y_true = df['class'].values - 1
        
        if fcpl_p['preprocess']:
            scaler = StandardScaler()
            X = scaler.fit_transform(X_raw)
        else:
            X = X_raw.copy()
        
        const_idx, P, const_mask = get_constraint_samples(y_true, label_ratio=fcpl_p['label_ratio'], random_state=42)
        
        # Run algorithms
        km = KMeans(n_clusters=n_clust, n_init=10, random_state=42)
        labels_km = km.fit_predict(X)
        acc_km = compute_acc(y_true, labels_km)
        
        fcm = FCMModel(n_clusters=n_clust, random_state=42)
        fcm.fit(X)
        labels_fcm = fcm.labels_
        acc_fcm = compute_acc(y_true, labels_fcm)
        
        fcpl = FCPL(n_clusters=n_clust, m=fcpl_p['m'], lam=fcpl_p['lam'], solver='mes', random_state=42)
        fcpl.fit(X, P=P, constraint_mask=const_mask)
        labels_fcpl = fcpl.labels_
        acc_fcpl = compute_acc(y_true, labels_fcpl)
        
        # KFCPL
        if kfcpl_p['preprocess'] != fcpl_p['preprocess']:
            if kfcpl_p['preprocess']:
                scaler_k = StandardScaler()
                X_k = scaler_k.fit_transform(X_raw)
            else:
                X_k = X_raw.copy()
            const_idx_k, P_k, const_mask_k = get_constraint_samples(y_true, label_ratio=kfcpl_p['label_ratio'], random_state=42)
        else:
            X_k, const_idx_k, P_k, const_mask_k = X, const_idx, P, const_mask
        
        kfcpl = KFCPL(n_clusters=n_clust, m=kfcpl_p['m'], lam=kfcpl_p['lam'], gamma=kfcpl_p['gamma'], random_state=42)
        kfcpl.fit(X_k, P=P_k, constraint_mask=const_mask_k)
        labels_kfcpl = kfcpl.labels_
        acc_kfcpl = compute_acc(y_true, labels_kfcpl)
        
        # 2x2 scatter plot
        fig, axes = plt.subplots(2, 2, figsize=(7.5, 7.5))
        axes = axes.flatten()
        
        algos_data = [
            ('K-means', labels_km, f'K-means (ACC={acc_km:.1f}%)'),
            ('FCM', labels_fcm, f'FCM (ACC={acc_fcm:.1f}%)'),
            ('FCPL', labels_fcpl, f'FCPL (ACC={acc_fcpl:.1f}%)'),
            ('KFCPL', labels_kfcpl, f'KFCPL (ACC={acc_kfcpl:.1f}%)'),
        ]
        
        for idx, (algo, labels, title) in enumerate(algos_data):
            ax = axes[idx]
            ax.scatter(df['k1'].values, df['k2'].values,
                      c=labels, cmap='viridis',
                      alpha=0.7, edgecolors='k', linewidths=0.3, s=20,
                      vmin=0, vmax=n_clust-1)
            ax.set_xlabel('k1', fontsize=9)
            ax.set_ylabel('k2', fontsize=9)
            ax.set_title(title, fontsize=9.5, fontweight='bold')
            despine(ax)
            add_panel_label(ax, chr(97+idx))
        
        cbar_ax = fig.add_axes([0.92, 0.15, 0.015, 0.7])
        sm = plt.cm.ScalarMappable(cmap='viridis', norm=plt.Normalize(vmin=0, vmax=n_clust-1))
        sm.set_array([])
        fig.colorbar(sm, cax=cbar_ax, label='Cluster')
        
        fig.suptitle(f'{ds_name}: Optimal Parameter Clustering', fontsize=11, fontweight='bold', y=0.98)
        plt.tight_layout(rect=[0, 0, 0.9, 1])
        
        out = os.path.join(FIG_DIR, out_prefix)
        plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
        plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
        plt.close()
        print(f"    [OK] {out}.png")


# ============================================================
# Fig7: Synthetic Data Comparison Bar Chart
# ============================================================
def fig7_synthetic_comparison():
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    
    files = [
        ('exp_synthetic_compound.csv', 'Compound', axes[0]),
        ('exp_synthetic_aggregation.csv', 'Aggregation', axes[1]),
    ]
    
    for fname, title, ax in files:
        df = pd.read_csv(os.path.join(DATA_DIR, fname))
        df = df[df['Algorithm'].isin(REPR_ALGOS)].copy()
        
        avg = df.groupby('Algorithm')[['ACC', 'NMI', 'ARI']].mean()
        std = df.groupby('Algorithm')[['ACC', 'NMI', 'ARI']].std()
        
        x = np.arange(len(REPR_ALGOS))
        width = 0.25
        metrics = [('ACC', '#6E8FB2'), ('NMI', '#7DA494'), ('ARI', '#EAB67A')]
        
        for i, (metric, color) in enumerate(metrics):
            offset = (i - 1) * width
            ax.bar(x + offset, avg[metric].values, width,
                   yerr=std[metric].values,
                   color=color, alpha=0.85, edgecolor='white', linewidth=0.5,
                   capsize=2, label=metric)
        
        ax.set_xticks(x)
        ax.set_xticklabels(REPR_ALGOS, rotation=30, ha='right', fontsize=8)
        ax.set_ylabel('Score (%)')
        ax.set_title(f'({title})', fontsize=10, fontweight='bold')
        ax.legend(fontsize=7)
        despine(ax)
    
    fig.suptitle('Synthetic Datasets: 6-Algorithm Comparison', fontsize=11, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    out = os.path.join(FIG_DIR, 'v5_fig7_synthetic_comparison')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig7: {out}.png")


# ============================================================
# Fig8: Scalability
# ============================================================
def fig8_scalability():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp6_scalability.csv'))
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))
    
    methods = [
        ('FCM_time', 'FCM', '#C16E71', '-o'),
        ('SFCM_time', 'SFCM', '#EAB67A', '-s'),
        ('FCPL_time', 'FCPL', '#6E8FB2', '-D'),
        ('KFCPL_time', 'KFCPL', '#7DA494', '-^'),
    ]
    
    for col, name, color, marker in methods:
        if col in df.columns:
            lw = 2.0 if name in ['FCPL', 'KFCPL'] else 1.2
            ax1.plot(df['n_samples'].values, df[col].values,
                    marker, color=color, linewidth=lw,
                    markersize=5, markerfacecolor='white',
                    markeredgewidth=0.6, label=name)
    
    ax1.set_xscale('log')
    ax1.set_yscale('log')
    ax1.set_xlabel('Number of Samples')
    ax1.set_ylabel('Runtime (s)')
    ax1.set_title('(a) Standard Scalability', fontsize=10, fontweight='bold')
    ax1.legend(fontsize=7)
    despine(ax1)
    
    df_large = pd.read_csv(os.path.join(DATA_DIR, 'exp13_large_scale_scalability.csv'))
    methods_l = [
        ('FCPL_time', 'FCPL', '#6E8FB2', '-D', 2.0),
        ('FCM_time', 'FCM', '#C16E71', '-o', 1.2),
        ('KMeans_time', 'K-means', '#EDABC1', '-s', 1.2),
    ]
    
    for col, name, color, marker, lw in methods_l:
        if col in df_large.columns:
            ax2.plot(df_large['n_samples'].values, df_large[col].values,
                    marker, color=color, linewidth=lw,
                    markersize=5, markerfacecolor='white',
                    markeredgewidth=0.6, label=name)
    
    ax2.set_xscale('log')
    ax2.set_yscale('log')
    ax2.set_xlabel('Number of Samples')
    ax2.set_ylabel('Runtime (s)')
    ax2.set_title('(b) Large-Scale (up to 500k)', fontsize=10, fontweight='bold')
    ax2.legend(fontsize=7)
    despine(ax2)
    
    fig.suptitle('Scalability Comparison', fontsize=11, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    out = os.path.join(FIG_DIR, 'v5_fig8_scalability')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig8: {out}.png")


# ============================================================
# Fig9: Convergence (MES/QP merged)
# ============================================================
def fig9_convergence():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp8_convergence.csv'))
    datasets = sorted(df['Dataset'].unique())
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))
    
    x = np.arange(len(datasets))
    width = 0.25
    
    ax1.bar(x - width, df['MES_iters'].values, width,
            color='#6E8FB2', alpha=0.85, edgecolor='white', linewidth=0.5,
            label='FCPL (MES/QP, identical)')
    ax1.bar(x, df['QP_iters'].values, width,
            color='#6E8FB2', alpha=0.4, edgecolor='white', linewidth=0.5,
            hatch='//', label='QP (overlapping)')
    ax1.bar(x + width, df['FCM_iters'].values, width,
            color='#C16E71', alpha=0.85, edgecolor='white', linewidth=0.5,
            label='FCM')
    
    ax1.set_xticks(x)
    ax1.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], fontsize=8)
    ax1.set_ylabel('Iterations to Converge')
    ax1.set_title('(a) Convergence Iterations', fontsize=10, fontweight='bold')
    ax1.legend(fontsize=7)
    despine(ax1)
    
    ax2.bar(x, df['MES_speedup'].values,
            color='#7DA494', alpha=0.85, edgecolor='white', linewidth=0.5)
    ax2.axhline(y=1.0, color='gray', linestyle='--', alpha=0.5)
    
    ax2.set_xticks(x)
    ax2.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], fontsize=8)
    ax2.set_ylabel('Speedup (MES/QP)')
    ax2.set_title('(b) MES Speedup over QP', fontsize=10, fontweight='bold')
    despine(ax2)
    
    for i, v in enumerate(df['MES_speedup'].values):
        ax2.text(i, v + 0.05, f'{v:.2f}x', ha='center', fontsize=7)
    
    fig.suptitle('Convergence Analysis (MES/QP Identical)', fontsize=10, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    out = os.path.join(FIG_DIR, 'v5_fig9_convergence')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig9: {out}.png")


# ============================================================
# Fig10: Ablation
# ============================================================
def fig10_ablation():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp2_ablation.csv'))
    
    def parse_acc(val):
        if isinstance(val, str):
            try:
                return ast.literal_eval(val).get('ACC', np.nan)
            except:
                return np.nan
        return val
    
    for col in ['w/o_constraint', 'FCPL_MES', 'FCPL_QP', 'KFCPL']:
        df[col + '_ACC'] = df[col].apply(parse_acc)
    
    datasets = sorted(df['Dataset'].unique())
    avg = df.groupby('Dataset')['w/o_constraint_ACC FCPL_MES_ACC FCPL_QP_ACC KFCPL_ACC'.split()].mean()
    std = df.groupby('Dataset')['w/o_constraint_ACC FCPL_MES_ACC FCPL_QP_ACC KFCPL_ACC'.split()].std()
    
    fig, ax = plt.subplots(figsize=(9, 4.5))
    
    x = np.arange(len(datasets))
    width = 0.2
    
    methods = [
        ('w/o_constraint_ACC', 'w/o constraint', '#999999'),
        ('FCPL_MES_ACC', 'FCPL (MES)', '#6E8FB2'),
        ('FCPL_QP_ACC', 'QP (overlap)', '#6E8FB2'),
        ('KFCPL_ACC', 'KFCPL', '#7DA494'),
    ]
    
    for i, (col, name, color) in enumerate(methods):
        offset = (i - 1.5) * width
        alpha = 0.5 if 'overlap' in name else 0.85
        hatch = '//' if 'overlap' in name else None
        ax.bar(x + offset, avg[col].values, width,
               yerr=std[col].values,
               color=color, alpha=alpha, edgecolor='white', linewidth=0.5,
               capsize=2, label=name, hatch=hatch)
    
    ax.set_xticks(x)
    ax.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], fontsize=8)
    ax.set_ylabel('ACC (%)')
    ax.set_title('Ablation Study (MES/QP Identical)', fontsize=10, fontweight='bold')
    ax.legend(fontsize=7)
    despine(ax)
    
    plt.tight_layout()
    out = os.path.join(FIG_DIR, 'v5_fig10_ablation')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig10: {out}.png")


# ============================================================
# Fig11: MES/QP Strict Verification
# ============================================================
def fig11_mes_qp_verification():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_mes_qp_strict_verification.csv'))
    datasets = df['dataset'].values
    
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5))
    
    ax = axes[0]
    x = np.arange(len(datasets))
    width = 0.3
    
    ax.bar(x - width/2, df['ACC_MES'].values * 100, width,
           color='#6E8FB2', alpha=0.85, edgecolor='white', linewidth=0.5, label='MES')
    ax.bar(x + width/2, df['ACC_QP'].values * 100, width,
           color='#6E8FB2', alpha=0.5, edgecolor='white', linewidth=0.5,
           hatch='//', label='QP (overlapping)')
    ax.set_xticks(x)
    ax.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], fontsize=8)
    ax.set_ylabel('ACC (%)')
    ax.set_title('(a) ACC: MES vs QP', fontsize=9, fontweight='bold')
    ax.legend(fontsize=7)
    despine(ax)
    
    ax = axes[1]
    ax.bar(x, df['speedup'].values, color='#7DA494', alpha=0.85, edgecolor='white', linewidth=0.5)
    ax.set_xticks(x)
    ax.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], fontsize=8)
    ax.set_ylabel('Speedup (MES/QP)')
    ax.set_title('(b) MES Speedup', fontsize=9, fontweight='bold')
    despine(ax)
    for i, v in enumerate(df['speedup'].values):
        ax.text(i, v + 2, f'{v:.1f}x', ha='center', fontsize=7)
    
    ax = axes[2]
    ax.bar(x, df['U_max_diff'].values, color='#EAB67A', alpha=0.85, edgecolor='white', linewidth=0.5)
    ax.set_yscale('log')
    ax.set_xticks(x)
    ax.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], fontsize=8)
    ax.set_ylabel('max |U_MES - U_QP| (log)')
    ax.set_title('(c) Membership Difference', fontsize=9, fontweight='bold')
    despine(ax)
    
    fig.suptitle('MES vs QP Strict Verification (Numerically Identical)', fontsize=10, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    out = os.path.join(FIG_DIR, 'v5_fig11_mes_qp_verification')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig11: {out}.png")


# ============================================================
# Fig12: Average Ranking (6 algos)
# ============================================================
def fig12_ranking():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_sota_final.csv'))
    df = df[df['Algorithm'].isin(REPR_ALGOS)].copy()
    datasets = sorted(df['Dataset'].unique())
    
    rank_list = []
    for ds in datasets:
        ds_data = df[df['Dataset'] == ds].set_index('Algorithm')['ACC_mean']
        rank_list.append(ds_data.rank(ascending=False))
    
    rank_df = pd.DataFrame(rank_list)
    avg_ranks = rank_df.mean().sort_values()
    algo_order = avg_ranks.index.tolist()
    
    fig, ax = plt.subplots(figsize=(7, 4.5))
    
    colors = [ALGO_COLORS.get(a, '#999') for a in algo_order]
    bars = ax.barh(range(len(algo_order)), avg_ranks.values,
                   color=colors, alpha=0.85, edgecolor='white', linewidth=0.5)
    
    for i, algo in enumerate(algo_order):
        if algo in ['FCPL', 'KFCPL']:
            bars[i].set_linewidth(1.5)
            bars[i].set_edgecolor('black')
    
    ax.set_yticks(range(len(algo_order)))
    ax.set_yticklabels(algo_order, fontsize=9)
    ax.set_xlabel('Average Rank (lower = better)')
    ax.set_title('Average Ranking Across 15 Datasets', fontsize=10, fontweight='bold')
    ax.invert_yaxis()
    despine(ax)
    
    for i, v in enumerate(avg_ranks.values):
        ax.text(v + 0.05, i, f'{v:.2f}', va='center', fontsize=8)
    
    plt.tight_layout()
    out = os.path.join(FIG_DIR, 'v5_fig12_ranking')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig12: {out}.png")


# ============================================================
# Fig13: Best Params Summary
# ============================================================
def fig13_best_params():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_best_params_fcpl.csv'))
    datasets = sorted(df['Dataset'].unique())
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
    
    ax1.barh(range(len(datasets)), df['Best_lambda'].values,
             color='#6E8FB2', alpha=0.85, edgecolor='white', linewidth=0.5)
    ax1.set_yticks(range(len(datasets)))
    ax1.set_yticklabels([DATASET_NAMES.get(d, d) for d in datasets], fontsize=8)
    ax1.set_xscale('log')
    ax1.set_xlabel(r'Best $\lambda$ (log scale)')
    ax1.set_title('(a) Optimal Regularization', fontsize=10, fontweight='bold')
    ax1.invert_yaxis()
    despine(ax1)
    for i, v in enumerate(df['Best_lambda'].values):
        ax1.text(v * 1.1, i, f'{v:g}', va='center', fontsize=7)
    
    ax2.barh(range(len(datasets)), df['Best_m'].values,
             color='#7DA494', alpha=0.85, edgecolor='white', linewidth=0.5)
    ax2.set_yticks(range(len(datasets)))
    ax2.set_yticklabels([DATASET_NAMES.get(d, d) for d in datasets], fontsize=8)
    ax2.set_xlabel(r'Best $m$ (fuzzifier)')
    ax2.set_title('(b) Optimal Fuzzification', fontsize=10, fontweight='bold')
    ax2.invert_yaxis()
    ax2.set_xlim(1.0, 3.5)
    despine(ax2)
    for i, v in enumerate(df['Best_m'].values):
        ax2.text(v + 0.05, i, f'{v:g}', va='center', fontsize=7)
    
    fig.suptitle('FCPL Optimal Parameter Summary', fontsize=11, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    out = os.path.join(FIG_DIR, 'v5_fig13_best_params')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig13: {out}.png")


# ============================================================
# Fig14: KFCPL Params
# ============================================================
def fig14_kfcpl_params():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_best_params_kfcpl.csv'))
    datasets = sorted(df['Dataset'].unique())
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
    
    ax1.barh(range(len(datasets)), df['Best_lambda'].values,
             color='#6E8FB2', alpha=0.85, edgecolor='white', linewidth=0.5)
    ax1.set_yticks(range(len(datasets)))
    ax1.set_yticklabels([DATASET_NAMES.get(d, d) for d in datasets], fontsize=8)
    ax1.set_xscale('log')
    ax1.set_xlabel(r'Best $\lambda$ (log scale)')
    ax1.set_title('(a) KFCPL Optimal $\\lambda$', fontsize=10, fontweight='bold')
    ax1.invert_yaxis()
    despine(ax1)
    
    ax2.barh(range(len(datasets)), df['Best_gamma'].values,
             color='#7DA494', alpha=0.85, edgecolor='white', linewidth=0.5)
    ax2.set_yticks(range(len(datasets)))
    ax2.set_yticklabels([DATASET_NAMES.get(d, d) for d in datasets], fontsize=8)
    ax2.set_xscale('log')
    ax2.set_xlabel(r'Best $\gamma$ (kernel bandwidth, log)')
    ax2.set_title('(b) KFCPL Optimal $\gamma$', fontsize=10, fontweight='bold')
    ax2.invert_yaxis()
    despine(ax2)
    
    fig.suptitle('KFCPL Optimal Parameter Summary', fontsize=11, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    out = os.path.join(FIG_DIR, 'v5_fig14_kfcpl_params')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig14: {out}.png")


# ============================================================
# MAIN
# ============================================================
def main():
    print("=" * 60)
    print("v5 Regenerating Remaining Charts...")
    print("=" * 60)
    
    print("\n6. Scatter plots...")
    fig6_scatter()
    
    print("\n7. Synthetic comparison...")
    fig7_synthetic_comparison()
    
    print("\n8. Scalability...")
    fig8_scalability()
    
    print("\n9. Convergence...")
    fig9_convergence()
    
    print("\n10. Ablation...")
    fig10_ablation()
    
    print("\n11. MES/QP verification...")
    fig11_mes_qp_verification()
    
    print("\n12. Ranking...")
    fig12_ranking()
    
    print("\n13. Best params summary...")
    fig13_best_params()
    
    print("\n14. KFCPL params...")
    fig14_kfcpl_params()
    
    print("\n" + "=" * 60)
    print("All remaining v5 charts generated!")
    print("=" * 60)


if __name__ == '__main__':
    main()
