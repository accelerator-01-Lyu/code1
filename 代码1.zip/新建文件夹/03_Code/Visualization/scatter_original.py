import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 设置图片清晰度
plt.rcParams['figure.dpi'] = 300

# 读取你上传的 CSV 文件
df_real = pd.read_csv('C:/Users/FJZ/Desktop/Compound.csv')

# 读取你上传的 Excel 文件
excel_file = pd.ExcelFile('C:/Users/FJZ/Desktop/2.xlsx')
df_pred = excel_file.parse('Sheet1')

# 提取第 2 到 8 列数据
membership_cols = df_pred.columns[1:8]

# 计算预测标签，即每行中第 2 到 8 列最大值所在的列索引
df_pred['pred_label'] = df_pred[membership_cols].idxmax(axis=1)

# 将列索引转换为数值标签（从 1 开始）
df_pred['pred_label'] = pd.to_numeric(df_pred['pred_label'].str.extract('(\d+)')[0]) + 1

# 检查调整后的标签（应包含正确的标签范围）
print("=== 调整后标签检查 ===")
unique_labels = sorted(df_pred['pred_label'].unique())
print(f"预测标签的唯一值：{unique_labels}")
print(f"标签数量：{len(unique_labels)}")

# 使用 df_real 的索引和 df_pred 中的 OriginalID 列进行合并
df_merged = pd.merge(df_real.reset_index(names='OriginalID'), df_pred, on='OriginalID', how='left')

# 设置格式配置，将字体替换为 WenQuanYi Zen Hei
plt.rcParams.update({
    'font.family': 'WenQuanYi Zen Hei',
    'font.size': 8,
    'axes.labelsize': 8,
    'xtick.labelsize': 7,
    'ytick.labelsize': 7,
    'axes.linewidth': 0.5,
    'xtick.major.width': 0.5,
    'ytick.major.width': 0.5,
    'xtick.major.size': 3,
    'ytick.major.size': 3,
})

# 颜色范围根据实际标签确定
min_val = int(df_merged['pred_label'].min())
max_val = int(df_merged['pred_label'].max())

# 绘制图形
fig, ax = plt.subplots(1, 1, figsize=(3.5, 3.5))

sc = ax.scatter(
    df_merged['k1'],
    df_merged['k2'],
    c=df_merged['pred_label'],
    cmap='viridis',
    alpha=0.7,
    edgecolors='k',
    linewidths=0.3,
    s=20,
    vmin=min_val,
    vmax=max_val
)

ax.set_xlabel('k1')
ax.set_ylabel('k2')

# 色阶条设置
cbar = plt.colorbar(sc, ax=ax, label='Cluster', shrink=0.85)
cbar.set_ticks(range(min_val, max_val + 1))
cbar.ax.tick_params(width=0.5)

# 移除顶部和右侧边框
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()

# 保存图片
save_path = 'C:/Users/FJZ/Desktop//nature_right_plot.png'
plt.savefig(save_path, dpi=600, bbox_inches='tight', pad_inches=0.05)
plt.close()