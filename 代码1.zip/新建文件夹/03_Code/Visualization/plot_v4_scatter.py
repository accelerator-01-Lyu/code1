#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
v4 Synthetic Dataset Scatter Plots
Run FCPL/KFCPL with optimal parameters from exp_synthetic_final.csv
Compare with K-means and FCM baselines.
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, normalized_mutual_info_score, adjusted_rand_score
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

BASE_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat'
sys.path.insert(0, BASE_DIR)

from code.models.baselines import FCM
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.utils.data_loader import get_constraint_samples

# ============================================================
# Style (preserved from user's scatter.py)
# ============================================================
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
    'font.size': 9,
    'axes.labelsize': 10,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'axes.linewidth': 0.6,
    'savefig.dpi': 600,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})

FIG_DIR = os.path.join(BASE_DIR, 'figures')


def compute_accuracy(y_true, y_pred):
    """Compute clustering accuracy using Hungarian-like best match."""
    from scipy.optimize import linear_sum_assignment
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    
    # Build cost matrix
    labels_true = np.unique(y_true)
    labels_pred = np.unique(y_pred)
    
    n_true = len(labels_true)
    n_pred = len(labels_pred)
    n = max(n_true, n_pred)
    
    cost = np.zeros((n, n))
    for i, lt in enumerate(labels_true):
        for j, lp in enumerate(labels_pred):
            cost[i, j] = -np.sum((y_true == lt) & (y_pred == lp))
    
    row_ind, col_ind = linear_sum_assignment(cost)
    total_correct = -cost[row_ind, col_ind].sum()
    return total_correct / len(y_true) * 100


def plot_scatter_2x2(csv_path, dataset_name, n_clusters,
                     fcpl_params, kfcpl_params, output_prefix):
    """
    Generate 2x2 scatter plot: K-means, FCM, FCPL, KFCPL.
    """
    print(f"  Processing {dataset_name}...")
    
    # Load data
    df = pd.read_csv(csv_path)
    X_raw = df[['k1', 'k2']].values
    y_true = df['class'].values - 1  # 0-indexed
    
    # Preprocess according to parameters
    preprocess = fcpl_params.get('preprocess', True)
    if preprocess:
        scaler = StandardScaler()
        X = scaler.fit_transform(X_raw)
        print(f"    Preprocessed (StandardScaler)")
    else:
        X = X_raw.copy()
        print(f"    No preprocessing")
    
    # Get constraint samples
    label_ratio = fcpl_params.get('label_ratio', 0.1)
    const_idx, P, const_mask = get_constraint_samples(y_true, label_ratio=label_ratio, random_state=42)
    
    # Run K-means
    print(f"    Running K-means...")
    km = KMeans(n_clusters=n_clusters, n_init=10, random_state=42)
    labels_km = km.fit_predict(X)
    acc_km = compute_accuracy(y_true, labels_km)
    
    # Run FCM
    print(f"    Running FCM...")
    fcm = FCM(n_clusters=n_clusters, random_state=42)
    fcm.fit(X)
    labels_fcm = fcm.labels_
    acc_fcm = compute_accuracy(y_true, labels_fcm)
    
    # Run FCPL with optimal parameters
    print(f"    Running FCPL (λ={fcpl_params['lam']}, m={fcpl_params['m']})...")
    fcpl = FCPL(n_clusters=n_clusters, 
                m=fcpl_params['m'], 
                lam=fcpl_params['lam'],
                solver='mes', random_state=42)
    fcpl.fit(X, P=P, constraint_mask=const_mask)
    labels_fcpl = fcpl.labels_
    acc_fcpl = compute_accuracy(y_true, labels_fcpl)
    
    # Run KFCPL with optimal parameters
    kfcpl_label_ratio = kfcpl_params.get('label_ratio', label_ratio)
    kfcpl_preprocess = kfcpl_params.get('preprocess', preprocess)
    
    if kfcpl_preprocess != preprocess:
        if kfcpl_preprocess:
            scaler_k = StandardScaler()
            X_k = scaler_k.fit_transform(X_raw)
        else:
            X_k = X_raw.copy()
        const_idx_k, P_k, const_mask_k = get_constraint_samples(y_true, label_ratio=kfcpl_label_ratio, random_state=42)
    else:
        X_k = X
        const_idx_k, P_k, const_mask_k = const_idx, P, const_mask
    
    print(f"    Running KFCPL (λ={kfcpl_params['lam']}, m={kfcpl_params['m']}, γ={kfcpl_params['gamma']})...")
    kfcpl = KFCPL(n_clusters=n_clusters,
                  m=kfcpl_params['m'],
                  lam=kfcpl_params['lam'],
                  gamma=kfcpl_params['gamma'],
                  random_state=42)
    kfcpl.fit(X_k, P=P_k, constraint_mask=const_mask_k)
    labels_kfcpl = kfcpl.labels_
    acc_kfcpl = compute_accuracy(y_true, labels_kfcpl)
    
    print(f"    Accuracies: K-means={acc_km:.1f}%, FCM={acc_fcm:.1f}%, FCPL={acc_fcpl:.1f}%, KFCPL={acc_kfcpl:.1f}%")
    
    # Create 2x2 subplot
    fig, axes = plt.subplots(2, 2, figsize=(7.5, 7.5))
    axes = axes.flatten()
    
    algorithms = [
        ('K-means', labels_km, f'K-means (ACC={acc_km:.1f}%)'),
        ('FCM', labels_fcm, f'FCM (ACC={acc_fcm:.1f}%)'),
        ('FCPL', labels_fcpl, f'FCPL (ACC={acc_fcpl:.1f}%)'),
        ('KFCPL', labels_kfcpl, f'KFCPL (ACC={acc_kfcpl:.1f}%)'),
    ]
    
    panel_labels = ['a', 'b', 'c', 'd']
    
    for idx, (algo_name, labels, title) in enumerate(algorithms):
        ax = axes[idx]
        
        # Scatter (preserved from user's scatter.py: viridis, k edges)
        sc = ax.scatter(
            df['k1'].values, df['k2'].values,
            c=labels, cmap='viridis',
            alpha=0.7, edgecolors='k', linewidths=0.3, s=20,
            vmin=0, vmax=n_clusters - 1
        )
        
        ax.set_xlabel('k1', fontsize=9)
        ax.set_ylabel('k2', fontsize=9)
        ax.set_title(title, fontsize=9.5, fontweight='bold')
        
        # Despine (preserved from user's scatter.py)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        
        # Panel label
        ax.text(-0.12, 1.05, f'({panel_labels[idx]})', transform=ax.transAxes,
                fontsize=10, fontweight='bold', va='top', ha='right')
    
    # Shared colorbar
    cbar_ax = fig.add_axes([0.92, 0.15, 0.015, 0.7])
    sm = plt.cm.ScalarMappable(cmap='viridis', 
                                norm=plt.Normalize(vmin=0, vmax=n_clusters - 1))
    sm.set_array([])
    cbar = fig.colorbar(sm, cax=cbar_ax, label='Cluster')
    cbar.ax.tick_params(labelsize=8)
    
    fig.suptitle(f'{dataset_name} Dataset: Optimal Parameter Clustering Results',
                 fontsize=11, fontweight='bold', y=0.98)
    
    plt.tight_layout(rect=[0, 0, 0.9, 1])
    
    out_png = os.path.join(FIG_DIR, f'{output_prefix}.png')
    out_svg = os.path.join(FIG_DIR, f'{output_prefix}.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"    [OK] Saved: {out_png}")
    
    return {
        'dataset': dataset_name,
        'K-means': acc_km,
        'FCM': acc_fcm,
        'FCPL': acc_fcpl,
        'KFCPL': acc_kfcpl,
    }


# ============================================================
# MAIN
# ============================================================
def main():
    print("=" * 60)
    print("v4 Synthetic Dataset Scatter Plots (Optimal Params)")
    print("=" * 60)
    
    results = []
    
    # Compound dataset
    print("\n1. Compound Dataset (399 samples, 6 clusters)...")
    compound_csv = os.path.join(BASE_DIR, 'data', 'Compound.csv')
    compound_fcpl_params = {
        'lam': 1.0,
        'm': 1.5,
        'label_ratio': 0.8,
        'preprocess': True,
    }
    compound_kfcpl_params = {
        'lam': 0.1,
        'm': 1.2,
        'gamma': 0.5,
        'label_ratio': 0.4,
        'preprocess': False,
    }
    
    r1 = plot_scatter_2x2(
        compound_csv, 'Compound', 6,
        compound_fcpl_params, compound_kfcpl_params,
        'exp_v4_scatter_compound'
    )
    results.append(r1)
    
    # Aggregation dataset
    print("\n2. Aggregation Dataset (788 samples, 7 clusters)...")
    aggregation_csv = os.path.join(BASE_DIR, 'data', 'Aggregation.csv')
    aggregation_fcpl_params = {
        'lam': 200.0,
        'm': 2.5,
        'label_ratio': 0.4,
        'preprocess': False,
    }
    aggregation_kfcpl_params = {
        'lam': 2.0,
        'm': 2.0,
        'gamma': 0.5,
        'label_ratio': 0.4,
        'preprocess': False,
    }
    
    r2 = plot_scatter_2x2(
        aggregation_csv, 'Aggregation', 7,
        aggregation_fcpl_params, aggregation_kfcpl_params,
        'exp_v4_scatter_aggregation'
    )
    results.append(r2)
    
    # Summary
    print("\n" + "=" * 60)
    print("RESULTS SUMMARY")
    print("=" * 60)
    for r in results:
        print(f"\n{r['dataset']}:")
        for k in ['K-means', 'FCM', 'FCPL', 'KFCPL']:
            print(f"  {k:10s}: {r[k]:.1f}%")
    
    print("\n" + "=" * 60)
    print("All scatter plots generated!")
    print("=" * 60)


if __name__ == '__main__':
    main()
