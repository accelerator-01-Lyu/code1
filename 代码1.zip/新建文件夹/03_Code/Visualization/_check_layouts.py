"""Check all figure layouts for symmetry issues."""
import os

fig_dir = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\figures'

# List all exp*.png files
files = sorted([f for f in os.listdir(fig_dir) if f.startswith('exp') and f.endswith('.png')])

print("=== Current Figure Files ===")
for f in files:
    path = os.path.join(fig_dir, f)
    size = os.path.getsize(path) / 1024
    print(f"  {f:45s} {size:8.1f} KB")

print("\n=== Layout Issues to Fix ===")
print("""
Current non-symmetric layouts:
  [✗] exp4_label_ratio.png     - 5 datasets in 2x3 grid (last cell empty) → FIX to 2x3 with summary panel
  [✗] exp5_noise_robustness.png - 5 datasets in 2x3 grid (last cell empty) → FIX to 2x3 with summary panel
  [✗] exp7_visualization.png   - 3 rows x 4 cols but only 3 datasets → verify symmetry

Verified symmetric:
  [✓] exp1_sota_comparison.png  - 1x2
  [✓] exp2_ablation_lambda.png - 1x2
  [✓] exp3_cd_diagram.png       - single
  [✓] exp6_scalability.png      - 1x2
  [✓] exp8_convergence.png     - 1x2
  [✓] exp_scatter_compound.png  - 2x2
  [✓] exp_scatter_aggregation.png - 2x2
  [✓] exp_lambda_real_sensitivity.png - 1x3
  [✓] exp_compound_algorithm_comparison.png - single
""")
