import numpy as np
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.ticker import FixedLocator

# 基础设置
mpl.rcParams.update({
    'font.family': 'Arial',
    'font.size': 12,
    'axes.labelsize': 14,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'lines.linewidth': 0.5,
    'axes.linewidth': 0.7,
    'figure.dpi': 600,
    'savefig.dpi': 600,
})

# 输出目录设置
OUTPUT_DIR = Path('C:/Users/FJZ/Desktop')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# 固定7个刻度值
CUSTOM_TICKS = [0.001, 0.01, 0.1, 1, 10, 100, 1000]
# 刻度对应的线性位置（视觉均等）
LINEAR_POS = np.arange(len(CUSTOM_TICKS))  # [0, 1, 2, 3, 4, 5, 6]

# 指标映射关系
METRICS = [
    ('ACC_Train', 'ACC'),
    ('Precision_Train', 'Precision'),
    ('Recall_Train', 'Recall'),
    ('F1_Train', 'F1'),
    ('NMI_Train', 'NMI'),
    ('ARI_Train', 'ARI')
]


def format_tick_label(value):
    """自定义刻度显示格式"""
    if value == 0.001:
        return "0.001"
    elif value == 0.01:
        return "0.01"
    elif value == 0.1:
        return "0.1"
    else:  # 1,10,100,1000等整数
        return f"{int(value)}"


def load_data(file_path):
    """加载Excel数据"""
    try:
        df = pd.read_excel(file_path)
        print(f"成功加载数据，共 {len(df)} 行")
        return df
    except Exception as e:
        print(f"数据加载失败: {e}")
        raise


def create_3d_bar_plot(df, metric_col, metric_name, global_norm, cmap, output_dir):
    """创建单个指标的3D柱状图（使用全局统一色阶）"""
    fig = plt.figure(figsize=(9, 9), dpi=600)
    ax = fig.add_subplot(111, projection='3d')
    
    # 留白设置
    plt.subplots_adjust(
        left=0.2,
        right=0.8,
        bottom=0.2,
        top=0.8,
        wspace=0.3,
        hspace=0.3
    )

    # 选择模型
    model = 'MES_QP'
    model_df = df[df['Model'] == model].copy()
    
    if model_df.empty:
        print(f"警告：无 {model} 数据")
        return None

    # 准备数据
    xs, ys, dz_list = [], [], []
    for i, gamma in enumerate(CUSTOM_TICKS):
        for j, lam in enumerate(CUSTOM_TICKS):
            match = model_df[(model_df['Lambda'] == lam) & (model_df['Gamma'] == gamma)]
            if not match.empty:
                xs.append(LINEAR_POS[j])  # 线性位置确保视觉均匀
                ys.append(LINEAR_POS[i])
                dz_list.append(match[metric_col].values[0])

    if not dz_list:
        print(f"警告：{metric_name} 无匹配数据，跳过绘图")
        return None

    # 颜色映射（使用全局norm）
    colors = cmap(global_norm(dz_list))

    # 柱子宽度（紧密排列）
    dx = 0.8
    dy = 0.8

    # 绘制3D柱状图
    ax.bar3d(
        xs, ys, np.zeros_like(dz_list),
        dx, dy, dz_list,
        color=colors, alpha=0.9, edgecolor='w', linewidth=0.2
    )

    # 坐标轴配置
    ax.set_xlabel("λ", labelpad=15, fontsize=14)
    ax.set_ylabel("γ", labelpad=15, fontsize=14)
    ax.set_zlabel(metric_name, labelpad=12, fontsize=14, rotation=90)
    
    # 设置刻度位置和标签
    ax.xaxis.set_major_locator(FixedLocator(LINEAR_POS))
    ax.yaxis.set_major_locator(FixedLocator(LINEAR_POS))
    ax.set_xticklabels([format_tick_label(x) for x in CUSTOM_TICKS])
    ax.set_yticklabels([format_tick_label(y) for y in CUSTOM_TICKS])
    
    # 调整刻度标签角度
    plt.setp(ax.get_xticklabels(), rotation=0, ha='left')
    plt.setp(ax.get_yticklabels(), rotation=0, ha='right')
    
    ax.zaxis.set_rotate_label(True)
    ax.zaxis.set_label_coords(0.5, -0.05)

    # 视角调整
    ax.view_init(elev=25, azim=-30)

    # 刻度优化
    ax.xaxis._axinfo["tick"]["inward_factor"] = 0.0
    ax.yaxis._axinfo["tick"]["inward_factor"] = 0.0
    ax.zaxis._axinfo["tick"]["inward_factor"] = 0.0
    ax.tick_params(axis='both', direction='out', pad=8, labelsize=10)

    # 保存图片
    output_path = output_dir / f"3D_{metric_name}_Unified_Color.tif"
    plt.savefig(
        output_path,
        format='tif',
        dpi=600,
        bbox_inches='tight',
        pad_inches=0.5
    )
    print(f"{metric_name} 3D柱状图已保存：{output_path}")
    plt.close()
    return dz_list  # 返回当前指标的dz数据，用于全局色阶计算


def create_unified_colorbar(cmap, global_norm, all_dz, output_dir, width=9):
    """创建全局统一的色阶条（所有指标共用）"""
    fig = plt.figure(figsize=(width, 1.5), dpi=600)
    
    plt.subplots_adjust(
        left=0.2,
        right=0.8,
        bottom=0.3,
        top=0.7
    )
    
    ax = fig.add_axes([0.15, 0.4, 0.7, 0.2])  # 色阶条位置
    
    sm = mpl.cm.ScalarMappable(cmap=cmap, norm=global_norm)
    sm.set_array(all_dz)  # 关联所有数据范围
    cbar = fig.colorbar(sm, cax=ax, orientation='horizontal')
    cbar.ax.set_xlabel("Metric value", fontsize=12, labelpad=10)  # 统一标题
    cbar.ax.tick_params(labelsize=10, pad=8)
    
    output_path = output_dir / "Unified_Colorbar_All_Metrics.tif"
    plt.savefig(
        output_path,
        format='tif',
        dpi=600,
        bbox_inches='tight',
        pad_inches=0.5
    )
    plt.close()
    print(f"全局统一色阶条已保存：{output_path}")


def generate_all_metrics_with_unified_colorbar(df, output_dir):
    """批量生成所有指标的图表，并使用统一色阶条"""
    # 第一步：收集所有指标的数值数据，计算全局范围
    all_dz = []  # 存储所有指标的数值，用于计算全局最大/最小值
    cmap = plt.get_cmap('plasma')  # 统一使用plasma色图
    
    # 先遍历所有指标，收集数据
    print("正在收集所有指标数据，计算全局色阶范围...")
    for metric_col, metric_name in METRICS:
        print(f"收集 {metric_name} 数据...")
        # 临时生成当前指标的数据（仅为了获取dz_list）
        model = 'MES_QP'
        model_df = df[df['Model'] == model].copy()
        if model_df.empty:
            print(f"警告：{metric_name} 无数据，跳过")
            continue
        
        dz_list = []
        for i, gamma in enumerate(CUSTOM_TICKS):
            for j, lam in enumerate(CUSTOM_TICKS):
                match = model_df[(model_df['Lambda'] == lam) & (model_df['Gamma'] == gamma)]
                if not match.empty:
                    dz_list.append(match[metric_col].values[0])
        
        if dz_list:
            all_dz.extend(dz_list)  # 汇总到全局列表
    
    if not all_dz:
        print("错误：无任何有效数据，无法生成图表")
        return
    
    # 计算全局统一的归一化范围
    global_vmin = np.min(all_dz)
    global_vmax = np.max(all_dz)
    global_norm = mpl.colors.Normalize(vmin=global_vmin, vmax=global_vmax)
    print(f"全局色阶范围：{global_vmin:.4f} ~ {global_vmax:.4f}")
    
    # 第二步：使用全局色阶生成所有指标的3D图
    print("\n开始生成所有指标的3D柱状图（统一色阶）...")
    for metric_col, metric_name in METRICS:
        print(f"\n----- 生成 {metric_name} 图表 -----")
        create_3d_bar_plot(
            df, metric_col, metric_name, 
            global_norm=global_norm,  # 使用全局归一化
            cmap=cmap, 
            output_dir=output_dir
        )
    
    # 第三步：生成全局统一的色阶条
    print("\n生成全局统一色阶条...")
    create_unified_colorbar(
        cmap=cmap,
        global_norm=global_norm,
        all_dz=all_dz,
        output_dir=output_dir
    )


if __name__ == "__main__":
    excel_path = Path('C:/Users/FJZ/Desktop/4.xlsx')  # 数据文件路径
    data_df = load_data(excel_path)
    generate_all_metrics_with_unified_colorbar(data_df, OUTPUT_DIR)