#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
v4 Redraw all charts:
- Bar charts: only 6 representative algorithms (not 15 crowded)
- Line charts: only semi-supervised algorithms + unsupervised baselines as dashed lines
- Merged overlapping curves (MES/QP)
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ============================================================
# Style
# ============================================================
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
    'font.size': 9,
    'axes.labelsize': 10,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'legend.fontsize': 7.5,
    'axes.linewidth': 0.6,
    'grid.linestyle': '--',
    'grid.alpha': 0.3,
    'savefig.dpi': 600,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})

DATA_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\data\results'
FIG_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\figures'

# ============================================================
# 6 Representative Algorithms
# ============================================================
REPR_ALGOS = ['K-means', 'FCM', 'SFCM', 'SSFCM', 'FCPL', 'KFCPL']

REPR_COLORS = {
    'K-means': '#F39B7F',   # salmon - unsupervised baseline
    'FCM':     '#3C5488',   # dark blue - unsupervised baseline
    'SFCM':    '#00A087',   # teal - classic semi-supervised
    'SSFCM':   '#3CBB75',   # green - recent semi-supervised
    'FCPL':    '#E64B35',   # red - paper method (highlighted)
    'KFCPL':   '#4DBBD5',   # cyan - paper method kernel (highlighted)
}

DATASET_NAMES = {
    'iris': 'Iris', 'wine': 'Wine', 'breast_cancer': 'Breast',
    'glass': 'Glass', 'seeds': 'Seeds', 'balance': 'Balance',
    'vehicle': 'Vehicle', 'segment': 'Segment',
    'ionosphere': 'Ionosphere', 'sonar': 'Sonar',
    'ecoli': 'Ecoli', 'diabetes': 'Diabetes', 'heart': 'Heart',
    'optdigits': 'Optdigits', 'yeast': 'Yeast',
}


def despine(ax):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)


def add_panel_label(ax, label, x=-0.12, y=1.05):
    ax.text(x, y, f'({label})', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top', ha='right')


# ============================================================
# Fig1: SOTA Comparison Bar Chart (6 representative algos)
# ============================================================
def plot_sota_6algos():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_sota_final.csv'))
    
    datasets = sorted(df['Dataset'].unique())
    
    # Filter to 6 representative algorithms
    df_repr = df[df['Algorithm'].isin(REPR_ALGOS)].copy()
    
    # Pivot
    pivot_mean = df_repr.pivot(index='Dataset', columns='Algorithm', values='ACC_mean')
    pivot_std = df_repr.pivot(index='Dataset', columns='Algorithm', values='ACC_std')
    
    # 3 metrics side by side
    metrics = [
        ('ACC', 'ACC_mean', 'ACC_std'),
        ('NMI', 'NMI_mean', 'NMI_std'),
        ('ARI', 'ARI_mean', 'ARI_std'),
    ]
    
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    
    for ax_idx, (metric_name, mean_col, std_col) in enumerate(metrics):
        ax = axes[ax_idx]
        
        pm = df_repr.pivot(index='Dataset', columns='Algorithm', values=mean_col)
        ps = df_repr.pivot(index='Dataset', columns='Algorithm', values=std_col)
        
        x = np.arange(len(datasets))
        width = 0.13
        
        for i, algo in enumerate(REPR_ALGOS):
            if algo not in pm.columns:
                continue
            offset = (i - len(REPR_ALGOS)/2 + 0.5) * width
            color = REPR_COLORS[algo]
            lw = 2.0 if algo in ['FCPL', 'KFCPL'] else 0.8
            alpha = 1.0 if algo in ['FCPL', 'KFCPL'] else 0.85
            
            ax.bar(x + offset, pm[algo].values, width,
                   yerr=ps[algo].values,
                   color=color, alpha=alpha, 
                   edgecolor='white', linewidth=0.5,
                   capsize=2, error_kw={'linewidth': 0.7})
        
        ax.set_xticks(x)
        ax.set_xticklabels([DATASET_NAMES.get(d, d)[:7] for d in datasets], 
                          rotation=45, ha='right', fontsize=7)
        ax.set_ylabel(f'{metric_name} (%)')
        ax.set_title(metric_name, fontsize=10, fontweight='bold')
        despine(ax)
    
    # Shared legend
    handles = []
    labels = []
    for algo in REPR_ALGOS:
        h = plt.Rectangle((0,0), 1, 1, color=REPR_COLORS[algo], 
                          ec='white', lw=0.5)
        handles.append(h)
        labels.append(algo)
    
    fig.legend(handles, labels, loc='lower center', ncol=6,
               framealpha=0.9, fontsize=8, bbox_to_anchor=(0.5, -0.06))
    
    fig.suptitle('SOTA Comparison: 6 Representative Algorithms × 15 Datasets',
                 fontsize=11, fontweight='bold', y=1.02)
    
    plt.tight_layout()
    out_png = os.path.join(FIG_DIR, 'exp_v4_sota_6algos.png')
    out_svg = os.path.join(FIG_DIR, 'exp_v4_sota_6algos.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] SOTA 6-algo comparison: {out_png}")


# ============================================================
# Fig2: Synthetic Dataset Comparison (6 algos)
# ============================================================
def plot_synthetic_6algos():
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    
    datasets_files = [
        ('exp_synthetic_compound.csv', 'Compound', axes[0]),
        ('exp_synthetic_aggregation.csv', 'Aggregation', axes[1]),
    ]
    
    for fname, title, ax in datasets_files:
        df = pd.read_csv(os.path.join(DATA_DIR, fname))
        df_repr = df[df['Algorithm'].isin(REPR_ALGOS)].copy()
        
        algo_avg = df_repr.groupby('Algorithm')[['ACC', 'NMI', 'ARI']].mean()
        algo_std = df_repr.groupby('Algorithm')[['ACC', 'NMI', 'ARI']].std()
        
        x = np.arange(len(REPR_ALGOS))
        width = 0.25
        
        metrics = [('ACC', '#E64B35'), ('NMI', '#4DBBD5'), ('ARI', '#00A087')]
        
        for i, (metric, color) in enumerate(metrics):
            offset = (i - 1) * width
            ax.bar(x + offset, algo_avg[metric].values, width,
                   yerr=algo_std[metric].values,
                   color=color, alpha=0.85, edgecolor='white', linewidth=0.5,
                   capsize=2, label=metric)
        
        ax.set_xticks(x)
        ax.set_xticklabels(REPR_ALGOS, rotation=30, ha='right', fontsize=8)
        ax.set_ylabel('Score (%)')
        ax.set_title(f'({title})', fontsize=10, fontweight='bold')
        ax.legend(loc='upper right', framealpha=0.9, fontsize=7)
        despine(ax)
    
    fig.suptitle('Synthetic Datasets: 6 Representative Algorithm Comparison',
                 fontsize=11, fontweight='bold', y=1.02)
    
    plt.tight_layout()
    out_png = os.path.join(FIG_DIR, 'exp_v4_synthetic_6algos.png')
    out_svg = os.path.join(FIG_DIR, 'exp_v4_synthetic_6algos.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Synthetic 6-algo comparison: {out_png}")


# ============================================================
# Fig3: Average Ranking (6 algos)
# ============================================================
def plot_ranking_6algos():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_sota_final.csv'))
    df_repr = df[df['Algorithm'].isin(REPR_ALGOS)].copy()
    
    datasets = sorted(df_repr['Dataset'].unique())
    
    rank_list = []
    for ds in datasets:
        ds_data = df_repr[df_repr['Dataset'] == ds].set_index('Algorithm')['ACC_mean']
        ranks = ds_data.rank(ascending=False)
        rank_list.append(ranks)
    
    rank_df = pd.DataFrame(rank_list)
    avg_ranks = rank_df.mean().sort_values()
    
    algo_order = avg_ranks.index.tolist()
    
    fig, ax = plt.subplots(figsize=(7, 4.5))
    
    colors = [REPR_COLORS.get(a, '#999') for a in algo_order]
    
    bars = ax.barh(range(len(algo_order)), avg_ranks.values,
                   color=colors, alpha=0.85, edgecolor='white', linewidth=0.5)
    
    # Highlight FCPL/KFCPL
    for i, algo in enumerate(algo_order):
        if algo in ['FCPL', 'KFCPL']:
            bars[i].set_linewidth(1.5)
            bars[i].set_edgecolor('black')
    
    ax.set_yticks(range(len(algo_order)))
    ax.set_yticklabels(algo_order, fontsize=9)
    ax.set_xlabel('Average Rank (lower = better)')
    ax.set_title('Average Ranking Across 15 Datasets',
                 fontsize=10, fontweight='bold')
    ax.invert_yaxis()
    despine(ax)
    
    for i, v in enumerate(avg_ranks.values):
        ax.text(v + 0.05, i, f'{v:.2f}', va='center', fontsize=8)
    
    plt.tight_layout()
    out_png = os.path.join(FIG_DIR, 'exp_v4_ranking_6algos.png')
    out_svg = os.path.join(FIG_DIR, 'exp_v4_ranking_6algos.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] 6-algo ranking: {out_png}")


# ============================================================
# Fig4: Scalability (6 algos, 2 panels)
# ============================================================
def plot_scalability_6algos():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp6_scalability.csv'))
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))
    
    # (a) Time vs n_samples (log-log)
    methods = [
        ('FCM_time', 'FCM', '#3C5488', '-o'),
        ('SFCM_time', 'SFCM', '#00A087', '-s'),
        ('FCPL_time', 'FCPL', '#E64B35', '-D'),
        ('KFCPL_time', 'KFCPL', '#4DBBD5', '-^'),
    ]
    
    for col, name, color, marker in methods:
        if col in df.columns:
            lw = 2.0 if name in ['FCPL', 'KFCPL'] else 1.2
            ax1.plot(df['n_samples'].values, df[col].values,
                    marker, color=color, linewidth=lw,
                    markersize=5, markerfacecolor='white',
                    markeredgewidth=0.6, label=name)
    
    ax1.set_xscale('log')
    ax1.set_yscale('log')
    ax1.set_xlabel('Number of Samples')
    ax1.set_ylabel('Runtime (s)')
    ax1.set_title('(a) Scalability: Runtime vs Dataset Size', fontsize=10, fontweight='bold')
    ax1.legend(loc='upper left', framealpha=0.9)
    despine(ax1)
    
    # (b) Large scale scalability
    df_large = pd.read_csv(os.path.join(DATA_DIR, 'exp13_large_scale_scalability.csv'))
    
    methods_large = [
        ('FCPL_time', 'FCPL', '#E64B35', '-D'),
        ('FCM_time', 'FCM', '#3C5488', '-o'),
        ('KMeans_time', 'K-means', '#F39B7F', '-s'),
    ]
    
    for col, name, color, marker in methods_large:
        if col in df_large.columns:
            lw = 2.0 if name == 'FCPL' else 1.2
            ax2.plot(df_large['n_samples'].values, df_large[col].values,
                    marker, color=color, linewidth=lw,
                    markersize=5, markerfacecolor='white',
                    markeredgewidth=0.6, label=name)
    
    ax2.set_xscale('log')
    ax2.set_yscale('log')
    ax2.set_xlabel('Number of Samples')
    ax2.set_ylabel('Runtime (s)')
    ax2.set_title('(b) Large-Scale Scalability (up to 500k)', fontsize=10, fontweight='bold')
    ax2.legend(loc='upper left', framealpha=0.9)
    despine(ax2)
    
    fig.suptitle('Scalability Comparison', fontsize=11, fontweight='bold', y=1.02)
    
    plt.tight_layout()
    out_png = os.path.join(FIG_DIR, 'exp_v4_scalability.png')
    out_svg = os.path.join(FIG_DIR, 'exp_v4_scalability.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Scalability: {out_png}")


# ============================================================
# Fig5: Convergence (MES/QP merged)
# ============================================================
def plot_convergence_merged():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp8_convergence.csv'))
    
    datasets = sorted(df['Dataset'].unique())
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))
    
    # (a) Iterations bar chart
    x = np.arange(len(datasets))
    width = 0.25
    
    # MES/QP merged (identical results)
    ax1.bar(x - width, df['MES_iters'].values, width,
            color='#E64B35', alpha=0.85, edgecolor='white', linewidth=0.5,
            label='FCPL (MES/QP, identical)')
    ax1.bar(x, df['QP_iters'].values, width,
            color='#E64B35', alpha=0.5, edgecolor='white', linewidth=0.5,
            hatch='//', label='QP (overlapping)')
    ax1.bar(x + width, df['FCM_iters'].values, width,
            color='#3C5488', alpha=0.85, edgecolor='white', linewidth=0.5,
            label='FCM')
    
    ax1.set_xticks(x)
    ax1.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], 
                       rotation=30, ha='right', fontsize=8)
    ax1.set_ylabel('Iterations to Converge')
    ax1.set_title('(a) Convergence Iterations', fontsize=10, fontweight='bold')
    ax1.legend(fontsize=7, loc='upper right')
    despine(ax1)
    
    # (b) Speedup
    ax2.bar(x, df['MES_speedup'].values,
            color='#4DBBD5', alpha=0.85, edgecolor='white', linewidth=0.5)
    
    ax2.set_xticks(x)
    ax2.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets],
                       rotation=30, ha='right', fontsize=8)
    ax2.set_ylabel('Speedup (MES / QP)')
    ax2.set_title('(b) MES Speedup over QP', fontsize=10, fontweight='bold')
    ax2.axhline(y=1.0, color='gray', linestyle='--', alpha=0.5)
    despine(ax2)
    
    for i, v in enumerate(df['MES_speedup'].values):
        ax2.text(i, v + 0.05, f'{v:.2f}x', ha='center', fontsize=7)
    
    fig.suptitle('Convergence Analysis (MES/QP Results Identical, Merged)',
                 fontsize=10, fontweight='bold', y=1.02)
    
    plt.tight_layout()
    out_png = os.path.join(FIG_DIR, 'exp_v4_convergence.png')
    out_svg = os.path.join(FIG_DIR, 'exp_v4_convergence.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Convergence (MES/QP merged): {out_png}")


# ============================================================
# MAIN
# ============================================================
def main():
    print("=" * 60)
    print("Generating v4 charts (6 representative algos)...")
    print("=" * 60)
    
    print("\n1. SOTA comparison (6 representative algos)...")
    plot_sota_6algos()
    
    print("\n2. Synthetic dataset comparison (6 algos)...")
    plot_synthetic_6algos()
    
    print("\n3. Average ranking (6 algos)...")
    plot_ranking_6algos()
    
    print("\n4. Scalability...")
    plot_scalability_6algos()
    
    print("\n5. Convergence (MES/QP merged)...")
    plot_convergence_merged()
    
    print("\n" + "=" * 60)
    print("v4 chart generation complete!")
    print("=" * 60)
    print("""
Representative algorithms selected (6 total):
  - K-means:  classic unsupervised baseline
  - FCM:      classic fuzzy unsupervised baseline
  - SFCM:     classic semi-supervised fuzzy
  - SSFCM:    recent semi-supervised method
  - FCPL:     paper method (highlighted, 2.5pt)
  - KFCPL:    paper method kernel (highlighted, 2.5pt)

Overlap handling:
  - MES/QP: numerically identical → merged in convergence chart
  - Legend: "FCPL (MES/QP, identical)"
""")


if __name__ == '__main__':
    main()
