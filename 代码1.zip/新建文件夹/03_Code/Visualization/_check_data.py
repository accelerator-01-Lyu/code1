import pandas as pd
import os

data_dir = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\data\results'

# exp1 full data
df1 = pd.read_csv(os.path.join(data_dir, 'exp1_sota_comparison.csv'))
print('=== exp1_sota_comparison.csv ===')
print(f'Shape: {df1.shape}')
print(f'Datasets: {sorted(df1["Dataset"].unique())}')
print(f'Algorithms: {sorted(df1["Algorithm"].unique())}')
print()
print('Full data:')
print(df1.to_string())
print()

# Wilcoxon tests
df3 = pd.read_csv(os.path.join(data_dir, 'exp3_wilcoxon_tests.csv'))
print('=== exp3_wilcoxon_tests.csv ===')
print(df3.to_string())
print()

# acc matrix
df_acc = pd.read_csv(os.path.join(data_dir, 'exp3_acc_matrix.csv'))
print('=== exp3_acc_matrix.csv ===')
print(df_acc.to_string())
