#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
v5 Chart Regeneration with New Nature Color Scheme
All charts use pastel palette + blue-green gradient.
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Add parent dir
BASE_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat'
sys.path.insert(0, BASE_DIR)
sys.path.insert(0, os.path.join(BASE_DIR, 'code', 'figures'))

from v5_style import (
    apply_nature_style, ALGO_COLORS, ALGO_MARKERS, ALGO_LINESTYLES,
    BLUE_GREEN_CMAP, BLUE_GREEN_GRADIENT, get_algo_style
)

apply_nature_style()

DATA_DIR = os.path.join(BASE_DIR, 'data', 'results')
FIG_DIR = os.path.join(BASE_DIR, 'figures')

DATASET_NAMES = {
    'iris': 'Iris', 'wine': 'Wine', 'breast_cancer': 'Breast',
    'glass': 'Glass', 'seeds': 'Seeds', 'balance': 'Balance',
    'vehicle': 'Vehicle', 'segment': 'Segment',
    'ionosphere': 'Ionosphere', 'sonar': 'Sonar',
    'ecoli': 'Ecoli', 'diabetes': 'Diabetes', 'heart': 'Heart',
    'optdigits': 'Optdigits', 'yeast': 'Yeast',
}

REPR_ALGOS = ['K-means', 'FCM', 'SFCM', 'SSFCM', 'FCPL', 'KFCPL']


def despine(ax):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)


def add_panel_label(ax, label, x=-0.12, y=1.05):
    ax.text(x, y, f'({label})', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top', ha='right')


# ============================================================
# Fig1: SOTA Comparison Bar Chart (6 algos, new colors)
# ============================================================
def fig1_sota_comparison():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_sota_final.csv'))
    df = df[df['Algorithm'].isin(REPR_ALGOS)].copy()
    datasets = sorted(df['Dataset'].unique())
    
    metrics = [('ACC', 'ACC_mean', 'ACC_std'), 
               ('NMI', 'NMI_mean', 'NMI_std'),
               ('ARI', 'ARI_mean', 'ARI_std')]
    
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    
    for ax_idx, (mname, mcol, scol) in enumerate(metrics):
        ax = axes[ax_idx]
        pm = df.pivot(index='Dataset', columns='Algorithm', values=mcol)
        ps = df.pivot(index='Dataset', columns='Algorithm', values=scol)
        
        x = np.arange(len(datasets))
        width = 0.13
        
        for i, algo in enumerate(REPR_ALGOS):
            if algo not in pm.columns:
                continue
            offset = (i - len(REPR_ALGOS)/2 + 0.5) * width
            color = ALGO_COLORS.get(algo, '#999')
            alpha = 1.0 if algo in ['FCPL', 'KFCPL'] else 0.85
            
            ax.bar(x + offset, pm[algo].values, width,
                   yerr=ps[algo].values,
                   color=color, alpha=alpha,
                   edgecolor='white', linewidth=0.5,
                   capsize=2, error_kw={'linewidth': 0.7})
        
        ax.set_xticks(x)
        ax.set_xticklabels([DATASET_NAMES.get(d, d)[:7] for d in datasets],
                          rotation=45, ha='right', fontsize=7)
        ax.set_ylabel(f'{mname} (%)')
        ax.set_title(mname, fontsize=10, fontweight='bold')
        despine(ax)
    
    # Shared legend
    handles = [plt.Rectangle((0,0),1,1, color=ALGO_COLORS.get(a,'#999'), ec='white', lw=0.5)
               for a in REPR_ALGOS]
    fig.legend(handles, REPR_ALGOS, loc='lower center', ncol=6,
               framealpha=0.9, fontsize=8, bbox_to_anchor=(0.5, -0.06))
    
    fig.suptitle('SOTA Comparison: 6 Representative Algorithms × 15 UCI Datasets',
                 fontsize=11, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    out = os.path.join(FIG_DIR, 'v5_fig1_sota_comparison')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig1: {out}.png")


# ============================================================
# Fig2: Lambda Sensitivity Line Chart (new colors)
# ============================================================
def fig2_lambda_sensitivity():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_param_sensitivity_semisupervised.csv'))
    baseline = pd.read_csv(os.path.join(DATA_DIR, 'exp_unsupervised_baseline.csv'))
    
    datasets = sorted(df['dataset'].unique())
    lambdas = sorted(df['lambda'].unique())
    
    var_methods = ['FCPL', 'KFCPL']
    flat_methods = ['SFCM', 'SSFCM', 'CEFCM', 'GRFCM']
    unsup_methods = ['FCM', 'K-means']
    
    fig, axes = plt.subplots(2, 3, figsize=(13, 7.5))
    axes = axes.flatten()
    
    panel_labels = ['a', 'b', 'c', 'd', 'e', 'f']
    
    for idx, ds in enumerate(datasets):
        ax = axes[idx]
        ds_data = df[df['dataset'] == ds]
        
        # Varying methods (FCPL, KFCPL)
        for method in var_methods:
            m_data = ds_data[ds_data['algorithm'] == method].sort_values('lambda')
            x = m_data['lambda'].values
            y = m_data['ACC_mean'].values
            ci = m_data['ACC_ci95'].values
            
            style = get_algo_style(method)
            ax.plot(x, y, color=style['color'], linewidth=style['lw'],
                    marker=style['marker'], markersize=6,
                    markerfacecolor='white', markeredgewidth=0.7,
                    label=method, zorder=4)
            ax.fill_between(x, y - ci, y + ci,
                           color=style['color'], alpha=0.2, zorder=3)
        
        # Flat semi-supervised methods
        for method in flat_methods:
            m_data = ds_data[ds_data['algorithm'] == method]
            if len(m_data) > 0:
                y_val = m_data['ACC_mean'].values[0]
                color = ALGO_COLORS.get(method, '#999')
                ax.axhline(y=y_val, color=color, linestyle='--',
                          linewidth=1.0, alpha=0.7, zorder=2)
                ax.text(lambdas[-1] * 1.2, y_val, f'{method}\n({y_val:.1f})',
                       va='center', fontsize=6, color=color, alpha=0.8)
        
        # Unsupervised baselines
        for method in unsup_methods:
            b_data = baseline[(baseline['dataset'] == ds) & (baseline['algorithm'] == method)]
            if len(b_data) > 0:
                y_val = b_data['ACC_mean'].values[0]
                color = ALGO_COLORS.get(method, '#888')
                ax.axhline(y=y_val, color=color, linestyle=':',
                          linewidth=1.0, alpha=0.6, zorder=1)
                ax.text(lambdas[-1] * 1.2, y_val, f'{method}\n({y_val:.1f})',
                       va='center', fontsize=6, color=color, alpha=0.8)
        
        ax.set_xscale('log')
        ax.set_xlabel(r'$\lambda$ (Regularization)', fontsize=9)
        ax.set_ylabel('ACC (%)', fontsize=9)
        ax.set_title(DATASET_NAMES.get(ds, ds), fontsize=9, fontweight='bold')
        despine(ax)
        add_panel_label(ax, panel_labels[idx])
        
        if idx == 0:
            ax.legend(loc='lower right', framealpha=0.9, fontsize=7)
    
    # 6th panel: Average
    ax_sum = axes[5]
    
    for method in var_methods:
        means = [df[(df['lambda']==lam) & (df['algorithm']==method)]['ACC_mean'].mean() for lam in lambdas]
        cis = [df[(df['lambda']==lam) & (df['algorithm']==method)]['ACC_mean'].std() for lam in lambdas]
        
        style = get_algo_style(method)
        ax_sum.plot(lambdas, means, color=style['color'], linewidth=style['lw'],
                   marker=style['marker'], markersize=6,
                   markerfacecolor='white', markeredgewidth=0.7,
                   label=method)
        ax_sum.fill_between(lambdas, np.array(means)-np.array(cis), 
                           np.array(means)+np.array(cis),
                           color=style['color'], alpha=0.2)
    
    ax_sum.set_xscale('log')
    ax_sum.set_xlabel(r'$\lambda$ (Regularization)', fontsize=9)
    ax_sum.set_ylabel('ACC (%)', fontsize=9)
    ax_sum.set_title('Average (5 datasets)', fontsize=9, fontweight='bold')
    despine(ax_sum)
    add_panel_label(ax_sum, 'f')
    ax_sum.legend(loc='lower right', framealpha=0.9, fontsize=7)
    
    fig.suptitle('Sensitivity to $\\lambda$: ACC (Semi-Supervised Methods)',
                 fontsize=11, fontweight='bold', y=0.995)
    plt.tight_layout(w_pad=2.5, h_pad=2.5)
    
    out = os.path.join(FIG_DIR, 'v5_fig2_lambda_sensitivity')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig2: {out}.png")


# ============================================================
# Fig3: Label Ratio (new colors)
# ============================================================
def fig3_label_ratio():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp4_label_ratio.csv'))
    datasets = sorted(df['Dataset'].unique())
    
    methods = [
        ('FCPL_ACC_mean', 'FCPL_ACC_std', 'FCPL'),
        ('KFCPL_ACC_mean', 'KFCPL_ACC_std', 'KFCPL'),
        ('SFCM_ACC_mean', 'SFCM_ACC_std', 'SFCM'),
    ]
    
    fig, axes = plt.subplots(2, 3, figsize=(12, 7))
    axes = axes.flatten()
    
    for idx, ds in enumerate(datasets):
        ax = axes[idx]
        ds_data = df[df['Dataset'] == ds].sort_values('LabelRatio')
        x_vals = ds_data['LabelRatio'].values * 100
        
        for mean_col, std_col, algo in methods:
            mean = ds_data[mean_col].values
            std = ds_data[std_col].values
            style = get_algo_style(algo)
            
            ax.plot(x_vals, mean, color=style['color'], linewidth=style['lw'],
                    marker=style['marker'], markersize=5.5,
                    markerfacecolor='white', markeredgewidth=0.6,
                    label=algo, zorder=3)
            ax.fill_between(x_vals, mean - std, mean + std,
                            color=style['color'], alpha=0.2, zorder=2)
        
        ax.set_title(DATASET_NAMES.get(ds, ds), fontsize=9, fontweight='bold')
        ax.set_xlabel('Label Ratio (%)', fontsize=8)
        ax.set_ylabel('ACC (%)', fontsize=8)
        ax.set_xticks([5, 10, 20, 30, 50])
        despine(ax)
        add_panel_label(ax, chr(97+idx))
        
        if idx == 0:
            ax.legend(loc='lower right', framealpha=0.9, fontsize=7)
    
    # 6th panel: summary
    ax_sum = axes[5]
    ratios = sorted(df['LabelRatio'].unique())
    
    for mean_col, std_col, algo in methods:
        means = [df[df['LabelRatio']==r][mean_col].mean() for r in ratios]
        stds = [df[df['LabelRatio']==r][mean_col].std() for r in ratios]
        style = get_algo_style(algo)
        x_vals = np.array(ratios) * 100
        
        ax_sum.plot(x_vals, means, color=style['color'], linewidth=style['lw'],
                   marker=style['marker'], markersize=5.5,
                   markerfacecolor='white', markeredgewidth=0.6,
                   label=algo)
        ax_sum.fill_between(x_vals, np.array(means)-np.array(stds),
                           np.array(means)+np.array(stds),
                           color=style['color'], alpha=0.2)
    
    ax_sum.set_title('Average (5 datasets)', fontsize=9, fontweight='bold')
    ax_sum.set_xlabel('Label Ratio (%)', fontsize=8)
    ax_sum.set_ylabel('ACC (%)', fontsize=8)
    ax_sum.set_xticks([5, 10, 20, 30, 50])
    despine(ax_sum)
    add_panel_label(ax_sum, 'f')
    
    fig.suptitle('Sensitivity to Label Ratio (New Nature Colors)',
                 fontsize=11, fontweight='bold', y=0.995)
    plt.tight_layout(w_pad=2.5, h_pad=2.5)
    
    out = os.path.join(FIG_DIR, 'v5_fig3_label_ratio')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig3: {out}.png")


# ============================================================
# Fig4: Noise Robustness (new colors)
# ============================================================
def fig4_noise_robustness():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp5_noise_robustness.csv'))
    datasets = sorted(df['Dataset'].unique())
    
    methods = [
        ('FCPL_ACC_mean', 'FCPL_ACC_std', 'FCPL'),
        ('KFCPL_ACC_mean', 'KFCPL_ACC_std', 'KFCPL'),
        ('SFCM_ACC_mean', 'SFCM_ACC_std', 'SFCM'),
    ]
    
    fig, axes = plt.subplots(2, 3, figsize=(12, 7))
    axes = axes.flatten()
    
    for idx, ds in enumerate(datasets):
        ax = axes[idx]
        ds_data = df[df['Dataset'] == ds].sort_values('NoiseLevel')
        x_vals = ds_data['NoiseLevel'].values * 100
        
        for mean_col, std_col, algo in methods:
            mean = ds_data[mean_col].values
            std = ds_data[std_col].values
            style = get_algo_style(algo)
            
            ax.plot(x_vals, mean, color=style['color'], linewidth=style['lw'],
                    marker=style['marker'], markersize=5.5,
                    markerfacecolor='white', markeredgewidth=0.6,
                    label=algo, zorder=3)
            ax.fill_between(x_vals, mean - std, mean + std,
                            color=style['color'], alpha=0.2, zorder=2)
        
        ax.set_title(DATASET_NAMES.get(ds, ds), fontsize=9, fontweight='bold')
        ax.set_xlabel('Noise Rate (%)', fontsize=8)
        ax.set_ylabel('ACC (%)', fontsize=8)
        ax.set_xticks([0, 10, 20, 30, 40])
        despine(ax)
        add_panel_label(ax, chr(97+idx))
        
        if idx == 0:
            ax.legend(loc='lower left', framealpha=0.9, fontsize=7)
    
    # 6th panel: summary
    ax_sum = axes[5]
    noise_levels = sorted(df['NoiseLevel'].unique())
    
    for mean_col, std_col, algo in methods:
        means = [df[df['NoiseLevel']==nl][mean_col].mean() for nl in noise_levels]
        stds = [df[df['NoiseLevel']==nl][mean_col].std() for nl in noise_levels]
        style = get_algo_style(algo)
        x_vals = np.array(noise_levels) * 100
        
        ax_sum.plot(x_vals, means, color=style['color'], linewidth=style['lw'],
                   marker=style['marker'], markersize=5.5,
                   markerfacecolor='white', markeredgewidth=0.6,
                   label=algo)
        ax_sum.fill_between(x_vals, np.array(means)-np.array(stds),
                           np.array(means)+np.array(stds),
                           color=style['color'], alpha=0.2)
    
    ax_sum.set_title('Average (5 datasets)', fontsize=9, fontweight='bold')
    ax_sum.set_xlabel('Noise Rate (%)', fontsize=8)
    ax_sum.set_ylabel('ACC (%)', fontsize=8)
    ax_sum.set_xticks([0, 10, 20, 30, 40])
    despine(ax_sum)
    add_panel_label(ax_sum, 'f')
    
    fig.suptitle('Robustness to Label Noise (New Nature Colors)',
                 fontsize=11, fontweight='bold', y=0.995)
    plt.tight_layout(w_pad=2.5, h_pad=2.5)
    
    out = os.path.join(FIG_DIR, 'v5_fig4_noise_robustness')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig4: {out}.png")


# ============================================================
# Fig5: Grid Search Heatmap (blue-green cmap)
# ============================================================
def fig5_grid_search_heatmap():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_param_search_fcpl.csv'))
    best_df = pd.read_csv(os.path.join(DATA_DIR, 'exp_best_params_fcpl.csv'))
    
    datasets = sorted(df['Dataset'].unique())
    lambdas = sorted(df['lambda'].unique())
    ms = sorted(df['m'].unique())
    
    n_rows, n_cols = 2, 4
    
    all_acc = df['ACC_mean'].values
    vmin, vmax = all_acc.min(), all_acc.max()
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(14, 6.5))
    axes = axes.flatten()
    
    for idx, ds in enumerate(datasets):
        ax = axes[idx]
        ds_data = df[df['Dataset'] == ds]
        
        heatmap = np.zeros((len(ms), len(lambdas)))
        for i, m_val in enumerate(ms):
            for j, lam in enumerate(lambdas):
                val = ds_data[(ds_data['lambda'] == lam) & (ds_data['m'] == m_val)]['ACC_mean'].values
                if len(val) > 0:
                    heatmap[i, j] = val[0]
        
        im = ax.imshow(heatmap, aspect='auto', cmap=BLUE_GREEN_CMAP,
                       vmin=vmin, vmax=vmax, origin='lower')
        
        ax.set_xticks(range(len(lambdas)))
        ax.set_xticklabels([f'{l:g}' for l in lambdas], rotation=45, ha='right', fontsize=7)
        ax.set_yticks(range(len(ms)))
        ax.set_yticklabels([f'{m:g}' for m in ms], fontsize=7)
        
        # Mark best
        best_row = best_df[best_df['Dataset'] == ds]
        if len(best_row) > 0:
            best_lam = best_row['Best_lambda'].values[0]
            best_m = best_row['Best_m'].values[0]
            if best_lam in lambdas and best_m in ms:
                j_best = lambdas.index(best_lam)
                i_best = ms.index(best_m)
                ax.scatter(j_best, i_best, marker='*', s=120, c='white',
                          edgecolors='black', linewidths=1.0, zorder=5)
        
        ax.set_title(DATASET_NAMES.get(ds, ds), fontsize=9, fontweight='bold')
        add_panel_label(ax, chr(97+idx))
    
    # 8th cell: summary
    ax_sum = axes[7]
    ds_names = [DATASET_NAMES.get(d, d) for d in datasets]
    best_accs = [best_df[best_df['Dataset']==d]['Best_ACC'].values[0] 
                 if len(best_df[best_df['Dataset']==d]) > 0 else 0 
                 for d in datasets]
    
    bars = ax_sum.barh(range(len(ds_names)), best_accs, 
                       color='#6E8FB2', alpha=0.85, edgecolor='white', linewidth=0.5)
    ax_sum.set_yticks(range(len(ds_names)))
    ax_sum.set_yticklabels(ds_names, fontsize=7)
    ax_sum.set_xlabel('Best ACC (%)')
    ax_sum.set_title('Best ACC per Dataset', fontsize=9, fontweight='bold')
    ax_sum.invert_yaxis()
    despine(ax_sum)
    add_panel_label(ax_sum, 'h')
    
    for i, v in enumerate(best_accs):
        ax_sum.text(v + 0.5, i, f'{v:.1f}', va='center', fontsize=7)
    
    cbar_ax = fig.add_axes([0.92, 0.15, 0.015, 0.7])
    sm = plt.cm.ScalarMappable(cmap=BLUE_GREEN_CMAP, 
                                norm=plt.Normalize(vmin=vmin, vmax=vmax))
    sm.set_array([])
    cbar = fig.colorbar(sm, cax=cbar_ax)
    cbar.set_label('ACC (%)', fontsize=9)
    cbar.ax.tick_params(labelsize=8)
    
    fig.suptitle('FCPL Parameter Grid Search ($\\lambda \\times m$) - Blue-Green Theme',
                 fontsize=12, fontweight='bold', y=0.995)
    
    plt.tight_layout(rect=[0, 0, 0.9, 1], w_pad=2.0, h_pad=2.5)
    
    out = os.path.join(FIG_DIR, 'v5_fig5_grid_search')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig5: {out}.png")


# ============================================================
# MAIN
# ============================================================
def main():
    print("=" * 60)
    print("v5 Regenerating Charts with New Nature Colors...")
    print("=" * 60)
    
    print("\n1. SOTA comparison...")
    fig1_sota_comparison()
    
    print("\n2. Lambda sensitivity...")
    fig2_lambda_sensitivity()
    
    print("\n3. Label ratio...")
    fig3_label_ratio()
    
    print("\n4. Noise robustness...")
    fig4_noise_robustness()
    
    print("\n5. Grid search heatmap...")
    fig5_grid_search_heatmap()
    
    print("\n" + "=" * 60)
    print("v5 Data visualization complete!")
    print("=" * 60)


if __name__ == '__main__':
    main()
