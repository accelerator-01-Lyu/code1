#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
v5 Unified Nature-style Color Scheme
Based on user's 4 reference images.
Low-saturation pastel palette + blue-green gradient.
"""

import matplotlib.pyplot as plt
import matplotlib as mpl

# ============================================================
# 8-Color Pastel Palette (from user's specification + reference images)
# ============================================================
ALGO_COLORS = {
    'FCPL':       '#6E8FB2',  # 雾霾蓝 (main method, primary)
    'KFCPL':      '#7DA494',  # 灰豆绿 (kernel extension)
    'SFCM':       '#EAB67A',  # 暖杏黄
    'SSFCM':      '#E5A179',  # 珊瑚橙
    'CEFCM':      '#E5A179',  # 珊瑚橙 (same family as SSFCM)
    'FCM':        '#C16E71',  # 豆沙红
    'KFCM':       '#ABC5E5',  # 浅天蓝
    'K-means':    '#EDABC1',  # 藕荷粉
    'PCAKM':      '#9FB0D8',  # 灰紫蓝
    'GRFCM':      '#9FB0D8',  # 灰紫蓝
    'GK':         '#9FB0D8',  # 灰紫蓝
    'PCM':        '#9FB0D8',  # 灰紫蓝
    'CDRSC':      '#9FB0D8',  # 灰紫蓝
    'ContraClust': '#9FB0D8', # 灰紫蓝
}

# ============================================================
# Blue-Green Gradient (for heatmaps, CI fills)
# From Nature Science Cell reference
# ============================================================
BLUE_GREEN_GRADIENT = [
    '#D5E8F1',  # lightest blue
    '#ABD7DF',  # light cyan
    '#CAEBE7',  # light mint
    '#A9D9BB',  # light green
    '#90B4CF',  # medium blue
    '#337BAC',  # dark blue (primary)
    '#4FB1B2',  # dark cyan
]

# Create custom colormap
from matplotlib.colors import LinearSegmentedColormap
BLUE_GREEN_CMAP = LinearSegmentedColormap.from_list(
    'blue_green', 
    ['#D5E8F1', '#ABD7DF', '#CAEBE7', '#A9D9BB', '#90B4CF', '#337BAC', '#4FB1B2'],
    N=256
)

# ============================================================
# Flowchart Module Colors (macaron pastel style)
# ============================================================
FLOWCHART = {
    'input':       {'face': '#DBEEF3', 'edge': '#337BAC', 'lw': 1.5},  # light blue fill, dark blue border
    'processing':  {'face': '#F5DECA', 'edge': '#E5A179', 'lw': 1.5},  # light orange fill, orange border
    'constraint':  {'face': '#F4F8EE', 'edge': '#7DA494', 'lw': 1.5},  # light green fill, green border
    'output':      {'face': '#E7E1EC', 'edge': '#9FB0D8', 'lw': 1.5},  # light purple fill, purple border
    'highlight':   {'face': '#FFCCCC', 'edge': '#C16E71', 'lw': 2.0},  # light red fill, red border (FCPL highlight)
    'shared':      {'face': '#E8F0E8', 'edge': '#5A9E6F', 'lw': 1.5},  # shared module
}

# ============================================================
# Marker Shapes for Algorithms
# ============================================================
ALGO_MARKERS = {
    'FCPL':       'D',   # diamond
    'KFCPL':      's',   # square
    'SFCM':       '^',   # triangle up
    'SSFCM':      'v',   # triangle down
    'FCM':        'o',   # circle
    'KFCM':       'p',   # pentagon
    'K-means':    'h',   # hexagon
    'PCAKM':      '*',   # star
}

# ============================================================
# Line Styles
# ============================================================
ALGO_LINESTYLES = {
    'FCPL':       '-',   # solid
    'KFCPL':      '-',   # solid
    'SFCM':       '--',  # dashed
    'SSFCM':      '-.',  # dash-dot
    'FCM':        ':',   # dotted
    'K-means':    '--',  # dashed
}


def apply_nature_style():
    """Apply unified Nature-style rcParams."""
    plt.rcParams.update({
        'font.family': 'serif',
        'font.serif': ['Arial', 'Times New Roman', 'DejaVu Serif', 'serif'],
        'font.size': 9,
        'axes.labelsize': 10,
        'xtick.labelsize': 8,
        'ytick.labelsize': 8,
        'legend.fontsize': 7.5,
        'axes.linewidth': 0.6,
        'grid.linestyle': '--',
        'grid.alpha': 0.3,
        'grid.color': '#cccccc',
        'axes.axisbelow': True,
        'savefig.dpi': 600,
        'savefig.bbox': 'tight',
        'savefig.pad_inches': 0.05,
        'figure.dpi': 300,
    })


def get_algo_style(algo_name):
    """Get color, marker, linestyle for an algorithm."""
    color = ALGO_COLORS.get(algo_name, '#999999')
    marker = ALGO_MARKERS.get(algo_name, 'o')
    ls = ALGO_LINESTYLES.get(algo_name, '-')
    lw = 2.0 if algo_name in ['FCPL', 'KFCPL'] else 1.2
    return {'color': color, 'marker': marker, 'ls': ls, 'lw': lw}


if __name__ == '__main__':
    # Demo: show color palette
    apply_nature_style()
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    
    # Algorithm colors
    ax = axes[0]
    algos = list(ALGO_COLORS.keys())
    for i, algo in enumerate(algos):
        ax.barh(i, 1, color=ALGO_COLORS[algo], edgecolor='white', linewidth=0.5)
        ax.text(0.5, i, algo, va='center', ha='center', fontsize=8, fontweight='bold')
    ax.set_yticks(range(len(algos)))
    ax.set_yticklabels(algos, fontsize=7)
    ax.set_title('Algorithm Color Palette', fontsize=10, fontweight='bold')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    
    # Blue-green gradient
    ax = axes[1]
    for i, c in enumerate(BLUE_GREEN_GRADIENT):
        ax.barh(i, 1, color=c, edgecolor='white', linewidth=0.5)
        ax.text(0.5, i, c, va='center', ha='center', fontsize=8)
    ax.set_yticks(range(len(BLUE_GREEN_GRADIENT)))
    ax.set_yticklabels(BLUE_GREEN_GRADIENT, fontsize=7)
    ax.set_title('Blue-Green Gradient (Heatmaps/CI)', fontsize=10, fontweight='bold')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    
    plt.tight_layout()
    plt.savefig(r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\figures\v5_color_palette.png', 
                dpi=600, bbox_inches='tight')
    print("Color palette demo saved.")
