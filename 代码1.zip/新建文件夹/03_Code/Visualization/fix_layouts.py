#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Layout correction script: fix all asymmetric subplot layouts.
- exp4_label_ratio: 5 datasets → 2x3 grid (6th cell = summary panel)
- exp5_noise_robustness: 5 datasets → 2x3 grid (6th cell = summary panel)
- All charts: symmetric grid, uniform spacing, consistent styling
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ============================================================
# Unified Style (Nature-inspired)
# ============================================================
plt.rcParams.update({
    'figure.dpi': 300,
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
    'font.size': 9,
    'axes.labelsize': 10,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'legend.fontsize': 7,
    'axes.linewidth': 0.6,
    'grid.linestyle': '--',
    'grid.alpha': 0.3,
    'grid.color': '#aaaaaa',
    'axes.axisbelow': True,
    'savefig.dpi': 600,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})

# Nature-style palette
COLORS = {
    'FCPL':  '#E64B35',   # red - highlight
    'KFCPL': '#4DBBD5',   # cyan - highlight
    'SFCM':  '#00A087',   # teal
    'FCM':   '#3C5488',   # dark blue
    'K-means': '#F39B7F', # salmon
    'PCAKM': '#8491B4',   # blue-gray
    'KFCM':  '#91D1C2',   # mint
}

MARKERS = {
    'FCPL':  'D',
    'KFCPL': 's',
    'SFCM':  '^',
    'FCM':   'o',
}

DATA_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\data\results'
FIG_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\figures'

DATASET_NAMES = {
    'iris': 'Iris', 'wine': 'Wine', 'breast_cancer': 'Breast',
    'glass': 'Glass', 'seeds': 'Seeds', 'balance': 'Balance',
    'vehicle': 'Vehicle', 'segment': 'Segment',
}


def despine(ax):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)


def add_panel_label(ax, label, x=-0.15, y=1.05):
    ax.text(x, y, f'({label})', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top', ha='right')


# ============================================================
# 1. exp4_label_ratio - 2x3 SYMMETRIC layout
# ============================================================
def fix_label_ratio():
    """
    5 datasets + 1 summary panel = 2x3 symmetric grid.
    6th panel = average performance across all datasets.
    """
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp4_label_ratio.csv'))
    datasets = sorted(df['Dataset'].unique())
    
    # 5 datasets + 1 summary = 6 panels = 2x3 grid
    n_datasets = len(datasets)
    n_rows, n_cols = 2, 3
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(12, 7))
    axes = axes.flatten()
    
    methods = [
        ('FCPL_ACC_mean', 'FCPL_ACC_std', 'FCPL'),
        ('KFCPL_ACC_mean', 'KFCPL_ACC_std', 'KFCPL'),
        ('SFCM_ACC_mean', 'SFCM_ACC_std', 'SFCM'),
    ]
    
    panel_labels = ['a', 'b', 'c', 'd', 'e', 'f']
    
    for idx, ds in enumerate(datasets):
        ax = axes[idx]
        ds_data = df[df['Dataset'] == ds].sort_values('LabelRatio')
        
        for mean_col, std_col, algo in methods:
            mean = ds_data[mean_col].values
            std = ds_data[std_col].values
            x_vals = ds_data['LabelRatio'].values * 100
            
            color = COLORS[algo]
            lw = 2.0 if algo in ['FCPL', 'KFCPL'] else 1.2
            ms = 6 if algo in ['FCPL', 'KFCPL'] else 5
            
            ax.plot(x_vals, mean, color=color, linewidth=lw,
                    marker=MARKERS[algo], markersize=ms,
                    markerfacecolor='white', markeredgewidth=0.6,
                    label=algo, zorder=3)
            ax.fill_between(x_vals, mean - std, mean + std,
                            color=color, alpha=0.12, zorder=2)
        
        ax.set_title(DATASET_NAMES.get(ds, ds), fontsize=9, fontweight='bold')
        ax.set_xlabel('Label Ratio (%)', fontsize=8)
        ax.set_ylabel('ACC (%)', fontsize=8)
        ax.set_xticks([5, 10, 20, 30, 50])
        despine(ax)
        add_panel_label(ax, panel_labels[idx])
        
        if idx == 0:
            ax.legend(loc='lower right', framealpha=0.9, fontsize=7)
    
    # 6th panel: Summary - average across datasets
    ax_sum = axes[5]
    
    # Compute average across all datasets
    ratios = sorted(df['LabelRatio'].unique())
    avg_data = {}
    for mean_col, std_col, algo in methods:
        means_per_ratio = []
        stds_per_ratio = []
        for r in ratios:
            subset = df[df['LabelRatio'] == r]
            means_per_ratio.append(subset[mean_col].mean())
            stds_per_ratio.append(subset[mean_col].std())
        avg_data[algo] = (np.array(means_per_ratio), np.array(stds_per_ratio))
    
    for mean_col, std_col, algo in methods:
        mean, std = avg_data[algo]
        x_vals = np.array(ratios) * 100
        color = COLORS[algo]
        lw = 2.0 if algo in ['FCPL', 'KFCPL'] else 1.2
        ms = 6 if algo in ['FCPL', 'KFCPL'] else 5
        
        ax_sum.plot(x_vals, mean, color=color, linewidth=lw,
                    marker=MARKERS[algo], markersize=ms,
                    markerfacecolor='white', markeredgewidth=0.6,
                    label=algo, zorder=3)
        ax_sum.fill_between(x_vals, mean - std, mean + std,
                            color=color, alpha=0.12, zorder=2)
    
    ax_sum.set_title('Average (5 datasets)', fontsize=9, fontweight='bold')
    ax_sum.set_xlabel('Label Ratio (%)', fontsize=8)
    ax_sum.set_ylabel('ACC (%)', fontsize=8)
    ax_sum.set_xticks([5, 10, 20, 30, 50])
    despine(ax_sum)
    add_panel_label(ax_sum, 'f')
    
    fig.suptitle('Sensitivity to Label Ratio (Symmetric 2×3 Layout)', 
                 fontsize=11, fontweight='bold', y=0.995)
    
    plt.tight_layout(w_pad=2.5, h_pad=2.5)
    
    out_png = os.path.join(FIG_DIR, 'exp4_label_ratio.png')
    out_svg = os.path.join(FIG_DIR, 'exp4_label_ratio.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] exp4_label_ratio (2x3 symmetric): {out_png}")


# ============================================================
# 2. exp5_noise_robustness - 2x3 SYMMETRIC layout
# ============================================================
def fix_noise_robustness():
    """
    5 datasets + 1 summary panel = 2x3 symmetric grid.
    6th panel = average performance across all datasets.
    """
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp5_noise_robustness.csv'))
    datasets = sorted(df['Dataset'].unique())
    
    n_rows, n_cols = 2, 3
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(12, 7))
    axes = axes.flatten()
    
    methods = [
        ('FCPL_ACC_mean', 'FCPL_ACC_std', 'FCPL'),
        ('KFCPL_ACC_mean', 'KFCPL_ACC_std', 'KFCPL'),
        ('SFCM_ACC_mean', 'SFCM_ACC_std', 'SFCM'),
    ]
    
    panel_labels = ['a', 'b', 'c', 'd', 'e', 'f']
    
    for idx, ds in enumerate(datasets):
        ax = axes[idx]
        ds_data = df[df['Dataset'] == ds].sort_values('NoiseLevel')
        
        for mean_col, std_col, algo in methods:
            mean = ds_data[mean_col].values
            std = ds_data[std_col].values
            x_vals = ds_data['NoiseLevel'].values * 100
            
            color = COLORS[algo]
            lw = 2.0 if algo in ['FCPL', 'KFCPL'] else 1.2
            ms = 6 if algo in ['FCPL', 'KFCPL'] else 5
            
            ax.plot(x_vals, mean, color=color, linewidth=lw,
                    marker=MARKERS[algo], markersize=ms,
                    markerfacecolor='white', markeredgewidth=0.6,
                    label=algo, zorder=3)
            ax.fill_between(x_vals, mean - std, mean + std,
                            color=color, alpha=0.12, zorder=2)
        
        ax.set_title(DATASET_NAMES.get(ds, ds), fontsize=9, fontweight='bold')
        ax.set_xlabel('Noise Rate (%)', fontsize=8)
        ax.set_ylabel('ACC (%)', fontsize=8)
        ax.set_xticks([0, 10, 20, 30, 40])
        despine(ax)
        add_panel_label(ax, panel_labels[idx])
        
        if idx == 0:
            ax.legend(loc='lower left', framealpha=0.9, fontsize=7)
    
    # 6th panel: Summary - average across datasets
    ax_sum = axes[5]
    
    noise_levels = sorted(df['NoiseLevel'].unique())
    avg_data = {}
    for mean_col, std_col, algo in methods:
        means_per_level = []
        stds_per_level = []
        for nl in noise_levels:
            subset = df[df['NoiseLevel'] == nl]
            means_per_level.append(subset[mean_col].mean())
            stds_per_level.append(subset[mean_col].std())
        avg_data[algo] = (np.array(means_per_level), np.array(stds_per_level))
    
    for mean_col, std_col, algo in methods:
        mean, std = avg_data[algo]
        x_vals = np.array(noise_levels) * 100
        color = COLORS[algo]
        lw = 2.0 if algo in ['FCPL', 'KFCPL'] else 1.2
        ms = 6 if algo in ['FCPL', 'KFCPL'] else 5
        
        ax_sum.plot(x_vals, mean, color=color, linewidth=lw,
                    marker=MARKERS[algo], markersize=ms,
                    markerfacecolor='white', markeredgewidth=0.6,
                    label=algo, zorder=3)
        ax_sum.fill_between(x_vals, mean - std, mean + std,
                            color=color, alpha=0.12, zorder=2)
    
    ax_sum.set_title('Average (5 datasets)', fontsize=9, fontweight='bold')
    ax_sum.set_xlabel('Noise Rate (%)', fontsize=8)
    ax_sum.set_ylabel('ACC (%)', fontsize=8)
    ax_sum.set_xticks([0, 10, 20, 30, 40])
    despine(ax_sum)
    add_panel_label(ax_sum, 'f')
    
    fig.suptitle('Robustness to Label Noise (Symmetric 2×3 Layout)', 
                 fontsize=11, fontweight='bold', y=0.995)
    
    plt.tight_layout(w_pad=2.5, h_pad=2.5)
    
    out_png = os.path.join(FIG_DIR, 'exp5_noise_robustness.png')
    out_svg = os.path.join(FIG_DIR, 'exp5_noise_robustness.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] exp5_noise_robustness (2x3 symmetric): {out_png}")


# ============================================================
# MAIN
# ============================================================
def main():
    print("=" * 60)
    print("Correcting asymmetric chart layouts...")
    print("=" * 60)
    
    print("\n1. Fixing exp4_label_ratio (5→6 panels, 2x3 symmetric)...")
    fix_label_ratio()
    
    print("\n2. Fixing exp5_noise_robustness (5→6 panels, 2x3 symmetric)...")
    fix_noise_robustness()
    
    print("\n" + "=" * 60)
    print("Layout correction complete!")
    print("=" * 60)
    print("""
Layout audit summary:
  [✓] exp1_sota_comparison    - 1x2 (symmetric)
  [✓] exp2_ablation_lambda    - 1x2 (symmetric)
  [✓] exp3_cd_diagram         - single (symmetric)
  [✓] exp4_label_ratio        - 2x3 (symmetric, 6th=summary)  ← FIXED
  [✓] exp5_noise_robustness   - 2x3 (symmetric, 6th=summary)  ← FIXED
  [✓] exp6_scalability         - 1x2 (symmetric)
  [✓] exp7_visualization      - 3x4 (symmetric)
  [✓] exp8_convergence        - 1x2 (symmetric)
  [✓] exp_scatter_compound     - 2x2 (symmetric)
  [✓] exp_scatter_aggregation  - 2x2 (symmetric)
  [✓] exp_lambda_real_sensitivity - 1x3 (symmetric)
""")


if __name__ == '__main__':
    main()
