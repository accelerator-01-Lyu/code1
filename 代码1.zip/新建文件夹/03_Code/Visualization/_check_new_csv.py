import pandas as pd
import os

data_dir = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\data\results'

new_files = [
    'exp_extra_face.csv',
    'exp_extra_uci.csv',
    'exp_synthetic_aggregation.csv',
    'exp_synthetic_compound.csv',
    'exp_mes_qp_verification.csv',
    'exp13_large_scale_scalability.csv',
]

for fname in new_files:
    fpath = os.path.join(data_dir, fname)
    if os.path.exists(fpath):
        df = pd.read_csv(fpath)
        print(f'=== {fname} ===')
        print(f'Shape: {df.shape}')
        print(f'Columns: {list(df.columns)}')
        print(df.head(15).to_string())
        print()
