import pandas as pd
import os

data_dir = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\data'

for fname in ['Compound.csv', 'Aggregation.csv']:
    fpath = os.path.join(data_dir, fname)
    if os.path.exists(fpath):
        df = pd.read_csv(fpath)
        print(f'=== {fname} ===')
        print(f'Shape: {df.shape}')
        print(f'Columns: {list(df.columns)}')
        print(f'Classes: {sorted(df["class"].unique())}')
        print(f'Head:')
        print(df.head())
        print()
    else:
        print(f'{fname} NOT FOUND at {fpath}')
