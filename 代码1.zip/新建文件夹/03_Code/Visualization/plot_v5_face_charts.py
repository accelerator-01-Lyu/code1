#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
v5 Face Experiment Charts - Framework (waiting for data)
Will be activated when exp_face_redone.csv and membership data are ready.
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat'
FIG_DIR = os.path.join(BASE_DIR, 'figures')
DATA_DIR = os.path.join(BASE_DIR, 'data', 'results')

plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
    'font.size': 9,
    'axes.labelsize': 10,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'legend.fontsize': 7.5,
    'axes.linewidth': 0.6,
    'grid.linestyle': '--',
    'grid.alpha': 0.3,
    'savefig.dpi': 600,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})

# Nature colors
COLORS = {
    'FCPL': '#6E8FB2',
    'KFCPL': '#7DA494',
    'SFCM': '#EAB67A',
    'FCM': '#C16E71',
}


def despine(ax):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)


def add_panel_label(ax, label, x=-0.12, y=1.05):
    ax.text(x, y, f'({label})', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top', ha='right')


# ============================================================
# Fig16: Face Membership Distribution Heatmap
# Rows: algorithms (FCM/SFCM/FCPL)
# Columns: 6 emotions
# Select 3-4 representative samples, each as a subplot
# ============================================================
def fig16_face_membership_heatmap(membership_data):
    """
    Parameters:
        membership_data: dict with keys:
            'FCM': array (n_samples, n_clusters)
            'SFCM': array (n_samples, n_clusters)
            'FCPL': array (n_samples, n_clusters)
            'sample_labels': list of emotion names
    """
    fig, axes = plt.subplots(1, 3, figsize=(12, 4.5))
    algorithms = ['FCM', 'SFCM', 'FCPL']
    
    for ax_idx, algo in enumerate(algorithms):
        ax = axes[ax_idx]
        data = membership_data[algo]
        
        im = ax.imshow(data, aspect='auto', cmap='YlOrRd',
                       vmin=0, vmax=1, origin='lower')
        
        ax.set_xticks(range(data.shape[1]))
        ax.set_xticklabels(membership_data['sample_labels'], fontsize=8, rotation=45, ha='right')
        ax.set_ylabel('Samples', fontsize=9)
        ax.set_title(f'{algo}', fontsize=10, fontweight='bold')
        despine(ax)
        add_panel_label(ax, chr(97+ax_idx))
    
    cbar_ax = fig.add_axes([0.92, 0.15, 0.015, 0.7])
    sm = plt.cm.ScalarMappable(cmap='YlOrRd', norm=plt.Normalize(vmin=0, vmax=1))
    sm.set_array([])
    fig.colorbar(sm, cax=cbar_ax, label='Membership')
    
    fig.suptitle('Fuzzy Membership Distribution: Face Emotion Recognition',
                 fontsize=11, fontweight='bold', y=1.02)
    
    plt.tight_layout(rect=[0, 0, 0.9, 1])
    out = os.path.join(FIG_DIR, 'v5_fig16_face_membership_heatmap')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig16: {out}.png")


# ============================================================
# Fig17: Face Entropy Distribution Boxplot
# ============================================================
def fig17_face_entropy_boxplot(entropy_data):
    """
    Parameters:
        entropy_data: dict with keys:
            'FCM': array of entropy values
            'SFCM': array of entropy values
            'FCPL': array of entropy values
    """
    fig, ax = plt.subplots(figsize=(7, 5))
    
    algorithms = ['FCM', 'SFCM', 'FCPL']
    box_data = [entropy_data[a] for a in algorithms]
    colors = [COLORS[a] for a in algorithms]
    
    bp = ax.boxplot(box_data, patch_artist=True, labels=algos,
                    medianprops={'color': 'black', 'linewidth': 1.5},
                    whiskerprops={'linewidth': 0.8},
                    capprops={'linewidth': 0.8})
    
    for patch, color in zip(bp['boxes'], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)
        patch.set_edgecolor('white')
        patch.set_linewidth(0.5)
    
    # Add jittered points
    for i, data in enumerate(box_data):
        x = np.random.normal(i + 1, 0.04, size=len(data))
        ax.scatter(x, data, s=10, alpha=0.5, color=colors[i], zorder=2)
    
    ax.set_ylabel('Membership Entropy (bits)', fontsize=9)
    ax.set_title('Fuzzy Membership Entropy Distribution', fontsize=10, fontweight='bold')
    despine(ax)
    
    plt.tight_layout()
    out = os.path.join(FIG_DIR, 'v5_fig17_face_entropy_boxplot')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig17: {out}.png")


# ============================================================
# Check if data is available
# ============================================================
def check_and_run():
    face_file = os.path.join(DATA_DIR, 'exp_face_redone.csv')
    
    if not os.path.exists(face_file):
        print("[WAITING] exp_face_redone.csv not found yet.")
        print("         Face charts will be generated when data is available.")
        return
    
    print("[DATA FOUND] Generating face charts...")
    
    # Read face data
    df = pd.read_csv(face_file)
    print(f"  Data shape: {df.shape}")
    print(f"  Algorithms: {sorted(df['algorithm'].unique())}")
    
    # TODO: Generate actual charts when membership data is available
    print("  Note: Membership matrices needed for heatmap.")
    print("        Waiting for exp_face_membership_*.csv files.")


if __name__ == '__main__':
    check_and_run()
