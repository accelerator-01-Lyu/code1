#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
v4 Lambda Sensitivity Line Chart
- FCPL/KFCPL: lines with 95% CI (vary with lambda)
- SFCM/CEFCM/GRFCM/SSFCM: horizontal dashed reference lines
- FCM/K-means: unsupervised baseline dashed lines
- 2x3 symmetric layout (5 datasets + 1 average)
- Based on user's line chart.py style (Nature colors, white-filled markers)
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ============================================================
# Style (based on user's line chart.py)
# ============================================================
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
    'font.size': 9,
    'axes.labelsize': 10,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'legend.fontsize': 7,
    'axes.linewidth': 0.6,
    'grid.linestyle': '--',
    'grid.alpha': 0.3,
    'savefig.dpi': 600,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})

DATA_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\data\results'
FIG_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\figures'

# Nature-inspired colors (from user's line chart.py)
COLORS = {
    'FCPL':    '#E64B35',   # red - main paper method
    'KFCPL':   '#4DBBD5',   # cyan - paper method kernel
    'SFCM':    '#00A087',   # teal - classic semi-supervised
    'SSFCM':   '#3C5488',   # dark blue - recent semi-supervised
    'CEFCM':   '#F39B7F',   # salmon
    'GRFCM':   '#8491B4',   # blue-gray
    'FCM':     '#91D1C2',   # mint - unsupervised baseline
    'K-means': '#B09C85',   # brown - unsupervised baseline
}

DATASET_NAMES = {
    'iris': 'Iris', 'wine': 'Wine', 'seeds': 'Seeds',
    'balance': 'Balance', 'glass': 'Glass',
}


def despine(ax):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)


def add_panel_label(ax, label, x=-0.12, y=1.05):
    ax.text(x, y, f'({label})', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top', ha='right')


def plot_lambda_sensitivity(metric_name, mean_col, ci_col, ylabel, output_prefix):
    """
    Generate lambda sensitivity line chart for given metric.
    """
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_param_sensitivity_semisupervised.csv'))
    baseline = pd.read_csv(os.path.join(DATA_DIR, 'exp_unsupervised_baseline.csv'))
    
    datasets = sorted(df['dataset'].unique())
    lambdas = sorted(df['lambda'].unique())
    
    # Methods that vary with lambda (FCPL, KFCPL)
    var_methods = ['FCPL', 'KFCPL']
    # Methods that are flat (SFCM, CEFCM, GRFCM, SSFCM)
    flat_methods = ['SFCM', 'SSFCM', 'CEFCM', 'GRFCM']
    # Unsupervised baselines (from separate CSV)
    unsup_methods = ['FCM', 'K-means']
    
    fig, axes = plt.subplots(2, 3, figsize=(13, 7.5))
    axes = axes.flatten()
    
    panel_labels = ['a', 'b', 'c', 'd', 'e', 'f']
    
    for idx, ds in enumerate(datasets):
        ax = axes[idx]
        ds_data = df[df['dataset'] == ds]
        
        # Plot varying methods (FCPL, KFCPL) as lines with CI
        for method in var_methods:
            m_data = ds_data[ds_data['algorithm'] == method].sort_values('lambda')
            x = m_data['lambda'].values
            y = m_data[mean_col].values
            ci = m_data[ci_col].values
            
            color = COLORS[method]
            lw = 2.5 if method in ['FCPL', 'KFCPL'] else 1.5
            marker = 'D' if method == 'FCPL' else 's'
            
            ax.plot(x, y, color=color, linewidth=lw,
                    marker=marker, markersize=6,
                    markerfacecolor='white', markeredgewidth=0.7,
                    label=method, zorder=4)
            ax.fill_between(x, y - ci, y + ci,
                           color=color, alpha=0.15, zorder=3)
        
        # Plot flat semi-supervised methods as horizontal dashed lines
        for method in flat_methods:
            m_data = ds_data[ds_data['algorithm'] == method]
            if len(m_data) > 0:
                y_val = m_data[mean_col].values[0]
                ci_val = m_data[ci_col].values[0] if ci_col in m_data.columns else 0
                
                color = COLORS.get(method, '#999')
                ax.axhline(y=y_val, color=color, linestyle='--', 
                          linewidth=1.0, alpha=0.7, zorder=2)
                # Label at right side
                ax.text(lambdas[-1] * 1.15, y_val, f'{method}\n({y_val:.1f})',
                       va='center', fontsize=6, color=color, alpha=0.8)
        
        # Plot unsupervised baselines as horizontal gray dashed lines
        for method in unsup_methods:
            b_data = baseline[(baseline['dataset'] == ds) & (baseline['algorithm'] == method)]
            if len(b_data) > 0:
                y_val = b_data[mean_col.replace('_mean', '')].values[0] if mean_col.replace('_mean', '') in b_data.columns else b_data[mean_col].values[0]
                
                # Try different column names
                if mean_col == 'ACC_mean':
                    y_val = b_data['ACC_mean'].values[0]
                elif mean_col == 'NMI_mean':
                    y_val = b_data['NMI_mean'].values[0]
                elif mean_col == 'ARI_mean':
                    y_val = b_data['ARI_mean'].values[0]
                
                color = '#888888'
                ax.axhline(y=y_val, color=color, linestyle=':', 
                          linewidth=1.0, alpha=0.6, zorder=1)
                ax.text(lambdas[-1] * 1.15, y_val, f'{method}\n({y_val:.1f})',
                       va='center', fontsize=6, color=color, alpha=0.8)
        
        ax.set_xscale('log')
        ax.set_xlabel(r'$\lambda$ (Regularization)', fontsize=9)
        ax.set_ylabel(ylabel, fontsize=9)
        ax.set_title(DATASET_NAMES.get(ds, ds), fontsize=9, fontweight='bold')
        despine(ax)
        add_panel_label(ax, panel_labels[idx])
        
        if idx == 0:
            ax.legend(loc='lower right', framealpha=0.9, fontsize=7)
    
    # 6th panel: Average across datasets
    ax_sum = axes[5]
    
    # Compute average for varying methods
    for method in var_methods:
        all_means = []
        all_cis = []
        for lam in lambdas:
            subset = df[(df['lambda'] == lam) & (df['algorithm'] == method)]
            all_means.append(subset[mean_col].mean())
            all_cis.append(subset[mean_col].std())
        
        x = np.array(lambdas)
        y = np.array(all_means)
        ci = np.array(all_cis)
        
        color = COLORS[method]
        lw = 2.5
        marker = 'D' if method == 'FCPL' else 's'
        
        ax_sum.plot(x, y, color=color, linewidth=lw,
                   marker=marker, markersize=6,
                   markerfacecolor='white', markeredgewidth=0.7,
                   label=method, zorder=4)
        ax_sum.fill_between(x, y - ci, y + ci,
                           color=color, alpha=0.15, zorder=3)
    
    # Flat methods average
    for method in flat_methods:
        subset = df[df['algorithm'] == method]
        y_val = subset[mean_col].mean()
        color = COLORS.get(method, '#999')
        ax_sum.axhline(y=y_val, color=color, linestyle='--',
                      linewidth=1.0, alpha=0.7, zorder=2)
    
    # Unsupervised baselines average
    for method in unsup_methods:
        subset = baseline[baseline['algorithm'] == method]
        if mean_col == 'ACC_mean':
            y_val = subset['ACC_mean'].mean()
        elif mean_col == 'NMI_mean':
            y_val = subset['NMI_mean'].mean()
        elif mean_col == 'ARI_mean':
            y_val = subset['ARI_mean'].mean()
        ax_sum.axhline(y=y_val, color='#888888', linestyle=':',
                      linewidth=1.0, alpha=0.6, zorder=1)
    
    ax_sum.set_xscale('log')
    ax_sum.set_xlabel(r'$\lambda$ (Regularization)', fontsize=9)
    ax_sum.set_ylabel(ylabel, fontsize=9)
    ax_sum.set_title('Average (5 datasets)', fontsize=9, fontweight='bold')
    despine(ax_sum)
    add_panel_label(ax_sum, 'f')
    ax_sum.legend(loc='lower right', framealpha=0.9, fontsize=7)
    
    fig.suptitle(f'Sensitivity to $\\lambda$: {metric_name} (Semi-Supervised Methods)',
                 fontsize=11, fontweight='bold', y=0.995)
    
    plt.tight_layout(w_pad=2.5, h_pad=2.5)
    
    out_png = os.path.join(FIG_DIR, f'{output_prefix}.png')
    out_svg = os.path.join(FIG_DIR, f'{output_prefix}.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] {metric_name}: {out_png}")


# ============================================================
# MAIN
# ============================================================
def main():
    print("=" * 60)
    print("Generating v4 Lambda Sensitivity Charts...")
    print("=" * 60)
    
    print("\n1. ACC sensitivity...")
    plot_lambda_sensitivity(
        'ACC', 'ACC_mean', 'ACC_ci95', 'Accuracy (%)',
        'exp_v4_lambda_sensitivity'
    )
    
    print("\n2. NMI sensitivity...")
    plot_lambda_sensitivity(
        'NMI', 'NMI_mean', 'NMI_ci95', 'NMI (%)',
        'exp_v4_lambda_sensitivity_NMI'
    )
    
    print("\n3. ARI sensitivity...")
    plot_lambda_sensitivity(
        'ARI', 'ARI_mean', 'ARI_ci95', 'ARI (%)',
        'exp_v4_lambda_sensitivity_ARI'
    )
    
    print("\n" + "=" * 60)
    print("All lambda sensitivity charts generated!")
    print("=" * 60)
    print("""
Chart structure:
  - FCPL/KFCPL: solid lines with 95% CI fill (vary with lambda)
  - SFCM/SSFCM/CEFCM/GRFCM: horizontal dashed lines (fixed lambda-independent)
  - FCM/K-means: horizontal dotted gray lines (unsupervised baselines)
  - Layout: 2x3 symmetric (5 datasets + 1 average)
  - Colors: Nature-inspired (#E64B35 red, #4DBBD5 cyan, etc.)
""")


if __name__ == '__main__':
    main()
