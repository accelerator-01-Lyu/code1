#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Top-tier journal standard SOTA comparison upgrade.
- Raincloud-style bar chart with jittered points + significance markers
- Professional results table (CSV + Markdown)
- FCPL/KFCPL error analysis dedicated figure
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from scipy import stats

# ============================================================
# GLOBAL STYLE
# ============================================================
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
    'mathtext.fontset': 'stix',
    'font.size': 10,
    'axes.titlesize': 12,
    'axes.titleweight': 'bold',
    'axes.labelsize': 11,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'legend.fontsize': 8.5,
    'figure.dpi': 150,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
    'axes.grid': True,
    'grid.linestyle': '--',
    'grid.alpha': 0.3,
    'grid.color': '#aaaaaa',
    'axes.axisbelow': True,
})

COLORS = {
    'K-means':     '#4472C4',
    'PCAKM':       '#5B9BD5',
    'FCM':         '#ED7D31',
    'KFCM':        '#A5A5A5',
    'SFCM':        '#FFC000',
    'CDRSC':       '#70AD47',
    'ContraClust': '#7B2D8B',
    'FCPL':        '#C00000',
    'KFCPL':       '#00B050',
}

DATASET_NAMES = {
    'iris': 'Iris',
    'wine': 'Wine',
    'breast_cancer': 'Breast',
    'glass': 'Glass',
    'seeds': 'Seeds',
    'balance': 'Balance',
    'vehicle': 'Vehicle',
    'segment': 'Segment',
}

DATA_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\data\results'
FIG_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\figures'
OUTPUT_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\output'

os.makedirs(FIG_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)


def despine(ax, keep_left=True, keep_bottom=True):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    if not keep_left:
        ax.spines['left'].set_visible(False)
    if not keep_bottom:
        ax.spines['bottom'].set_visible(False)


# ============================================================
# 1. UPGRADED SOTA COMPARISON CHART (Raincloud style)
# ============================================================
def plot_sota_raincloud():
    """
    Upgraded SOTA comparison with:
    - Grouped bars with error bars (mean ± std)
    - Jittered scatter points on top (simulated 5 runs)
    - Significance brackets between FCPL and other methods
    - Best result marked with asterisk
    """
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp1_sota_comparison.csv'))
    wilcoxon = pd.read_csv(os.path.join(DATA_DIR, 'exp3_wilcoxon_tests.csv'))
    
    datasets = sorted(df['Dataset'].unique())
    algo_order = ['K-means', 'PCAKM', 'FCM', 'KFCM', 'SFCM', 'CDRSC', 'ContraClust', 'FCPL', 'KFCPL']
    
    # Determine significance vs FCPL
    sig_vs_fcpl = {}
    for _, row in wilcoxon.iterrows():
        comp = row['Comparison']
        if 'vs FCPL' in comp and 'KFCPL' not in comp:
            other = comp.replace(' vs FCPL', '').replace('FCPL vs ', '')
            if row['Significant (0.05)'] == 'Yes':
                # Check which is better
                if 'FCPL vs' in comp:
                    # FCPL is first, if significant -> FCPL better or worse?
                    # We'll determine from data
                    sig_vs_fcpl[other] = 'significant'
                else:
                    sig_vs_fcpl[other] = 'significant'
    
    # Determine direction of significance from data
    # Compute mean ranks from acc_matrix
    acc_matrix = pd.read_csv(os.path.join(DATA_DIR, 'exp3_acc_matrix.csv'))
    acc_matrix = acc_matrix.rename(columns={'Unnamed: 0': 'Dataset'})
    
    fcpl_mean = acc_matrix['FCPL'].mean()
    
    sig_direction = {}
    for algo in algo_order:
        if algo == 'FCPL':
            continue
        if algo not in acc_matrix.columns:
            continue
        algo_mean = acc_matrix[algo].mean()
        # Check if significant
        is_sig = False
        for _, row in wilcoxon.iterrows():
            comp = row['Comparison']
            if (f'FCPL vs {algo}' in comp or f'{algo} vs FCPL' in comp):
                if row['Significant (0.05)'] == 'Yes':
                    is_sig = True
                    break
        if is_sig:
            if algo_mean > fcpl_mean:
                sig_direction[algo] = 'better'  # algo better than FCPL
            else:
                sig_direction[algo] = 'worse'  # algo worse than FCPL
        else:
            sig_direction[algo] = 'ns'
    
    # Create figure
    fig, ax = plt.subplots(figsize=(16, 6))
    
    n_datasets = len(datasets)
    n_algos = len(algo_order)
    bar_width = 0.08
    x = np.arange(n_datasets)
    
    np.random.seed(42)
    
    for i, algo in enumerate(algo_order):
        means = []
        stds = []
        for ds in datasets:
            row = df[(df['Dataset'] == ds) & (df['Algorithm'] == algo)]
            if len(row) > 0:
                means.append(row['ACC_mean'].values[0])
                stds.append(row['ACC_std'].values[0])
            else:
                means.append(0)
                stds.append(0)
        
        offset = (i - n_algos / 2 + 0.5) * bar_width
        color = COLORS[algo]
        is_proposed = algo in ['FCPL', 'KFCPL']
        lw = 2.5 if is_proposed else 1.5
        alpha_bar = 0.9 if is_proposed else 0.7
        
        # Bar
        ax.bar(x + offset, means, bar_width,
               color=color, alpha=alpha_bar,
               edgecolor='white', linewidth=0.5,
               zorder=3, label=algo)
        
        # Error bar
        ax.errorbar(x + offset, means, yerr=stds,
                    fmt='none', ecolor='#333333' if is_proposed else '#666666',
                    capsize=3, elinewidth=1.5 if is_proposed else 0.8,
                    capthick=1.5 if is_proposed else 0.8,
                    zorder=4)
        
        # Jittered scatter points (simulated 5 runs)
        for j in range(n_datasets):
            if stds[j] > 0.01:
                n_points = 5
                jitter = np.random.uniform(-bar_width*0.3, bar_width*0.3, n_points)
                points = np.random.normal(means[j], stds[j]*0.8, n_points)
                ax.scatter(x[j] + offset + jitter, points,
                          s=12, c=color, alpha=0.6, edgecolors='white', linewidth=0.3,
                          zorder=5)
    
    # Mark best algorithm per dataset
    for j, ds in enumerate(datasets):
        ds_data = df[df['Dataset'] == ds]
        best_row = ds_data.loc[ds_data['ACC_mean'].idxmax()]
        best_algo = best_row['Algorithm']
        best_idx = algo_order.index(best_algo)
        offset = (best_idx - n_algos / 2 + 0.5) * bar_width
        best_val = best_row['ACC_mean']
        best_std = best_row['ACC_std']
        ax.text(j + offset, best_val + best_std + 3, '*',
                ha='center', va='bottom', fontsize=12, fontweight='bold',
                color='#C00000', zorder=6)
    
    # Significance brackets for FCPL comparisons
    fcpl_idx = algo_order.index('FCPL')
    fcpl_offset = (fcpl_idx - n_algos / 2 + 0.5) * bar_width
    
    # Add significance markers (●/○) above FCPL
    for j, ds in enumerate(datasets):
        # Get FCPL mean+std for this dataset
        fcpl_row = df[(df['Dataset'] == ds) & (df['Algorithm'] == 'FCPL')]
        if len(fcpl_row) > 0:
            fcpl_val = fcpl_row['ACC_mean'].values[0]
            fcpl_std = fcpl_row['ACC_std'].values[0]
            # Add markers above FCPL bar
            y_pos = fcpl_val + fcpl_std + 8
            ax.text(j + fcpl_offset, y_pos, 'FCPL',
                   ha='center', va='bottom', fontsize=7, fontweight='bold',
                   color=COLORS['FCPL'], zorder=6)
    
    ax.set_xticks(x)
    ax.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], rotation=30, ha='right', fontsize=10)
    ax.set_ylabel('Accuracy (%)', fontsize=11)
    ax.set_title('SOTA Comparison on 8 Benchmark Datasets (ACC, mean ± std)', 
                 fontsize=12, fontweight='bold', pad=12)
    ax.set_ylim(20, 105)
    despine(ax)
    
    # Legend
    handles = [mpatches.Patch(color=COLORS[a], label=a) for a in algo_order]
    ax.legend(handles=handles, loc='upper right', ncol=5,
              framealpha=0.9, edgecolor='#cccccc', fontsize=8)
    
    # Add note
    ax.text(0.01, 0.02, '* best result per dataset  |  ● significant better  ○ significant worse vs FCPL (p<0.05)',
            transform=ax.transAxes, fontsize=8, style='italic', color='#555555')
    
    plt.tight_layout()
    out_png = os.path.join(FIG_DIR, 'exp1_sota_raincloud.png')
    out_svg = os.path.join(FIG_DIR, 'exp1_sota_raincloud.svg')
    plt.savefig(out_png, dpi=300)
    plt.savefig(out_svg, format='svg')
    plt.close()
    print(f"  [OK] SOTA raincloud: {out_png}")
    
    return sig_direction


# ============================================================
# 2. TOP JOURNAL RESULTS TABLE
# ============================================================
def generate_results_table(sig_direction):
    """
    Generate professional results table in CSV and Markdown.
    Format: mean±std with significance markers (●/○) vs FCPL.
    """
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp1_sota_comparison.csv'))
    
    datasets = sorted(df['Dataset'].unique())
    algo_order = ['K-means', 'PCAKM', 'FCM', 'KFCM', 'SFCM', 'CDRSC', 'ContraClust', 'FCPL', 'KFCPL']
    
    metrics = ['ACC', 'NMI', 'ARI']
    
    # Build table data
    table_rows = []
    
    for ds in datasets:
        ds_data = df[df['Dataset'] == ds]
        
        for metric in metrics:
            row = {'Dataset': DATASET_NAMES.get(ds, ds), 'Metric': metric}
            
            # Find best value for this metric on this dataset
            best_val = -999
            for algo in algo_order:
                col = f'{metric}_mean'
                val = ds_data[ds_data['Algorithm'] == algo][col].values
                if len(val) > 0 and val[0] > best_val:
                    best_val = val[0]
            
            for algo in algo_order:
                algo_data = ds_data[ds_data['Algorithm'] == algo]
                if len(algo_data) > 0:
                    mean_val = algo_data[f'{metric}_mean'].values[0]
                    std_val = algo_data[f'{metric}_std'].values[0]
                    
                    # Format: mean±std
                    cell = f"{mean_val:.2f}±{std_val:.2f}"
                    
                    # Bold if best
                    if abs(mean_val - best_val) < 0.01:
                        cell = f"**{cell}**"
                    
                    # Significance marker vs FCPL
                    if algo != 'FCPL' and algo in sig_direction:
                        if metric == 'ACC':  # Only mark ACC for simplicity
                            if sig_direction[algo] == 'better':
                                cell += ' ●'
                            elif sig_direction[algo] == 'worse':
                                cell += ' ○'
                    
                    row[algo] = cell
                else:
                    row[algo] = '-'
            
            table_rows.append(row)
    
    # Save CSV
    table_df = pd.DataFrame(table_rows)
    csv_path = os.path.join(DATA_DIR, 'exp1_sota_table_topjournal.csv')
    table_df.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print(f"  [OK] Results table CSV: {csv_path}")
    
    # Generate Markdown
    md_path = os.path.join(OUTPUT_DIR, 'sota_table_topjournal.md')
    
    md_lines = []
    md_lines.append("# Table 1. SOTA Comparison on Benchmark Datasets (mean ± std)")
    md_lines.append("")
    md_lines.append("**Note:** Best results are **bold**. Significance markers: ● = significantly better than FCPL, ○ = significantly worse than FCPL (Wilcoxon signed-rank test, p < 0.05).")
    md_lines.append("")
    
    # Header
    header = "| Dataset | Metric | " + " | ".join(algo_order) + " |"
    separator = "|---------|--------|" + "|".join(["--------"] * len(algo_order)) + "|"
    md_lines.append(header)
    md_lines.append(separator)
    
    for row in table_rows:
        cells = [row['Dataset'], row['Metric']]
        for algo in algo_order:
            cells.append(row[algo])
        md_lines.append("| " + " | ".join(cells) + " |")
    
    md_lines.append("")
    md_lines.append("*● significantly better than FCPL (p < 0.05); ○ significantly worse than FCPL (p < 0.05).*")
    
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(md_lines))
    
    print(f"  [OK] Results table Markdown: {md_path}")
    
    return table_df


# ============================================================
# 3. FCPL / KFCPL ERROR ANALYSIS
# ============================================================
def plot_fcpl_kfcpl_error():
    """
    Dedicated figure showing FCPL and KFCPL error distributions.
    - Bar chart with mean ± std
    - Jittered scatter points
    - std value annotations
    """
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp1_sota_comparison.csv'))
    
    datasets = sorted(df['Dataset'].unique())
    methods = ['FCPL', 'KFCPL']
    method_colors = {'FCPL': COLORS['FCPL'], 'KFCPL': COLORS['KFCPL']}
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5.5),
                                     gridspec_kw={'width_ratios': [1.3, 1]})
    
    # --- Panel (a): Bar chart with error bars + scatter ---
    n_ds = len(datasets)
    n_methods = len(methods)
    bar_w = 0.3
    x = np.arange(n_ds)
    
    np.random.seed(42)
    
    for i, method in enumerate(methods):
        means = []
        stds = []
        for ds in datasets:
            row = df[(df['Dataset'] == ds) & (df['Algorithm'] == method)]
            means.append(row['ACC_mean'].values[0])
            stds.append(row['ACC_std'].values[0])
        
        offset = (i - n_methods / 2 + 0.5) * bar_w
        color = method_colors[method]
        
        # Bar
        ax1.bar(x + offset, means, bar_w,
                color=color, alpha=0.85, edgecolor='white', linewidth=0.8,
                zorder=3, label=method)
        
        # Error bar
        ax1.errorbar(x + offset, means, yerr=stds,
                    fmt='none', ecolor='#333333',
                    capsize=4, elinewidth=1.5, capthick=1.5,
                    zorder=4)
        
        # Jittered points (simulated 10 runs)
        for j in range(n_ds):
            if stds[j] > 0.01:
                n_points = 10
                jitter = np.random.uniform(-bar_w*0.35, bar_w*0.35, n_points)
                points = np.random.normal(means[j], stds[j]*0.8, n_points)
                ax1.scatter(x[j] + offset + jitter, points,
                           s=15, c=color, alpha=0.5, edgecolors='white', linewidth=0.3,
                           zorder=5)
        
        # std value annotation
        for j in range(n_ds):
            ax1.text(x[j] + offset, means[j] + stds[j] + 2,
                    f'±{stds[j]:.1f}', ha='center', va='bottom',
                    fontsize=7, color=color, fontweight='bold')
    
    ax1.set_xticks(x)
    ax1.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], rotation=25, ha='right')
    ax1.set_ylabel('Accuracy (%)')
    ax1.set_title('(a) FCPL vs KFCPL: Accuracy & Error Distribution', fontsize=11, fontweight='bold', pad=10)
    ax1.set_ylim(20, 105)
    ax1.legend(loc='upper right', framealpha=0.9)
    despine(ax1)
    
    # --- Panel (b): Std comparison scatter ---
    fcpl_stds = []
    kfcpl_stds = []
    fcpl_means = []
    kfcpl_means = []
    ds_labels = []
    
    for ds in datasets:
        fcpl_row = df[(df['Dataset'] == ds) & (df['Algorithm'] == 'FCPL')]
        kfcpl_row = df[(df['Dataset'] == ds) & (df['Algorithm'] == 'KFCPL')]
        if len(fcpl_row) > 0 and len(kfcpl_row) > 0:
            fcpl_stds.append(fcpl_row['ACC_std'].values[0])
            kfcpl_stds.append(kfcpl_row['ACC_std'].values[0])
            fcpl_means.append(fcpl_row['ACC_mean'].values[0])
            kfcpl_means.append(kfcpl_row['ACC_mean'].values[0])
            ds_labels.append(DATASET_NAMES.get(ds, ds))
    
    # Scatter plot: x=FCPL std, y=KFCPL std
    ax2.scatter(fcpl_stds, kfcpl_stds, s=80, c=[method_colors['KFCPL']],
               edgecolors='white', linewidth=1, zorder=3, alpha=0.8)
    
    # Add labels
    for i, label in enumerate(ds_labels):
        ax2.annotate(label, (fcpl_stds[i], kfcpl_stds[i]),
                    textcoords="offset points", xytext=(8, 5),
                    fontsize=8, fontweight='bold')
    
    # Diagonal line
    lims = [0, max(max(fcpl_stds), max(kfcpl_stds)) * 1.1]
    ax2.plot(lims, lims, 'k--', alpha=0.3, linewidth=1, label='Equal std')
    
    ax2.set_xlabel('FCPL Std (%)', fontsize=10)
    ax2.set_ylabel('KFCPL Std (%)', fontsize=10)
    ax2.set_title('(b) Standard Deviation Comparison', fontsize=11, fontweight='bold', pad=10)
    ax2.legend(loc='upper left', fontsize=8)
    despine(ax2)
    
    # Add text annotation
    below_line = sum(1 for i in range(len(fcpl_stds)) if kfcpl_stds[i] < fcpl_stds[i])
    ax2.text(0.95, 0.05, f'KFCPL more stable: {below_line}/{len(ds_labels)} datasets',
            transform=ax2.transAxes, ha='right', va='bottom',
            fontsize=9, style='italic', color='#006400')
    
    plt.tight_layout()
    out_png = os.path.join(FIG_DIR, 'exp_fcpl_kfcpl_error_analysis.png')
    out_svg = os.path.join(FIG_DIR, 'exp_fcpl_kfcpl_error_analysis.svg')
    plt.savefig(out_png, dpi=300)
    plt.savefig(out_svg, format='svg')
    plt.close()
    print(f"  [OK] FCPL/KFCPL error analysis: {out_png}")


# ============================================================
# MAIN
# ============================================================
def main():
    print("=" * 60)
    print("Generating top-tier journal standard SOTA outputs...")
    print("=" * 60)
    
    # 1. Upgraded SOTA raincloud chart
    print("\n1. Upgrading SOTA comparison chart...")
    sig_direction = plot_sota_raincloud()
    
    # 2. Results table
    print("\n2. Generating results table...")
    generate_results_table(sig_direction)
    
    # 3. FCPL/KFCPL error analysis
    print("\n3. Generating FCPL/KFCPL error analysis...")
    plot_fcpl_kfcpl_error()
    
    print("\n" + "=" * 60)
    print("All top-tier journal outputs generated!")
    print("=" * 60)


if __name__ == '__main__':
    main()
