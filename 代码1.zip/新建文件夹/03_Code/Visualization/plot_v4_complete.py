#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
v4 Complete Chart Generation Script
All charts based on latest real CSV data, 6 representative algorithms,
symmetric layouts, Nature colors, 600DPI PNG+SVG.
"""

import os
import ast
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ============================================================
# Global Style
# ============================================================
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
    'font.size': 9,
    'axes.labelsize': 10,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'legend.fontsize': 7.5,
    'axes.linewidth': 0.6,
    'grid.linestyle': '--',
    'grid.alpha': 0.3,
    'grid.color': '#aaaaaa',
    'axes.axisbelow': True,
    'savefig.dpi': 600,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})

DATA_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\data\results'
FIG_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\figures'

# 6 Representative Algorithms
REPR_ALGOS = ['K-means', 'FCM', 'SFCM', 'SSFCM', 'FCPL', 'KFCPL']
REPR_COLORS = {
    'K-means': '#F39B7F',
    'FCM':     '#3C5488',
    'SFCM':    '#00A087',
    'SSFCM':   '#3CBB75',
    'FCPL':    '#E64B35',
    'KFCPL':   '#4DBBD5',
}

DATASET_NAMES = {
    'iris': 'Iris', 'wine': 'Wine', 'breast_cancer': 'Breast',
    'glass': 'Glass', 'seeds': 'Seeds', 'balance': 'Balance',
    'vehicle': 'Vehicle', 'segment': 'Segment',
    'ionosphere': 'Ionosphere', 'sonar': 'Sonar',
    'ecoli': 'Ecoli', 'diabetes': 'Diabetes', 'heart': 'Heart',
    'optdigits': 'Optdigits', 'yeast': 'Yeast',
}


def despine(ax):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)


def add_panel_label(ax, label, x=-0.12, y=1.05):
    ax.text(x, y, f'({label})', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top', ha='right')


# ============================================================
# 1. UCI SOTA Comparison (6 algos × 15 datasets)
# ============================================================
def fig1_sota_comparison():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_sota_final.csv'))
    df = df[df['Algorithm'].isin(REPR_ALGOS)].copy()
    datasets = sorted(df['Dataset'].unique())
    
    metrics = [('ACC', 'ACC_mean', 'ACC_std'), 
               ('NMI', 'NMI_mean', 'NMI_std'),
               ('ARI', 'ARI_mean', 'ARI_std')]
    
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    
    for ax_idx, (mname, mcol, scol) in enumerate(metrics):
        ax = axes[ax_idx]
        pm = df.pivot(index='Dataset', columns='Algorithm', values=mcol)
        ps = df.pivot(index='Dataset', columns='Algorithm', values=scol)
        
        x = np.arange(len(datasets))
        width = 0.13
        
        for i, algo in enumerate(REPR_ALGOS):
            if algo not in pm.columns:
                continue
            offset = (i - len(REPR_ALGOS)/2 + 0.5) * width
            color = REPR_COLORS[algo]
            alpha = 1.0 if algo in ['FCPL', 'KFCPL'] else 0.85
            
            ax.bar(x + offset, pm[algo].values, width,
                   yerr=ps[algo].values,
                   color=color, alpha=alpha,
                   edgecolor='white', linewidth=0.5,
                   capsize=2, error_kw={'linewidth': 0.7})
        
        ax.set_xticks(x)
        ax.set_xticklabels([DATASET_NAMES.get(d, d)[:7] for d in datasets],
                          rotation=45, ha='right', fontsize=7)
        ax.set_ylabel(f'{mname} (%)')
        ax.set_title(mname, fontsize=10, fontweight='bold')
        despine(ax)
    
    # Shared legend
    handles = [plt.Rectangle((0,0),1,1, color=REPR_COLORS[a], ec='white', lw=0.5)
               for a in REPR_ALGOS]
    fig.legend(handles, REPR_ALGOS, loc='lower center', ncol=6,
               framealpha=0.9, fontsize=8, bbox_to_anchor=(0.5, -0.06))
    
    fig.suptitle('SOTA Comparison: 6 Representative Algorithms × 15 UCI Datasets',
                 fontsize=11, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    out = os.path.join(FIG_DIR, 'v4_fig1_sota_comparison')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig1: {out}.png")


# ============================================================
# 2. Ablation Study
# ============================================================
def fig2_ablation():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp2_ablation.csv'))
    
    # Parse dictionary columns
    def parse_acc(val):
        if isinstance(val, str):
            try:
                d = ast.literal_eval(val)
                return d.get('ACC', np.nan)
            except:
                return np.nan
        return val
    
    for col in ['w/o_constraint', 'FCPL_MES', 'FCPL_QP', 'KFCPL']:
        df[col + '_ACC'] = df[col].apply(parse_acc)
    
    datasets = sorted(df['Dataset'].unique())
    
    # Average across repeats
    avg = df.groupby('Dataset')[['w/o_constraint_ACC', 'FCPL_MES_ACC', 
                                'FCPL_QP_ACC', 'KFCPL_ACC']].mean()
    std = df.groupby('Dataset')[['w/o_constraint_ACC', 'FCPL_MES_ACC',
                                 'FCPL_QP_ACC', 'KFCPL_ACC']].std()
    
    fig, ax = plt.subplots(figsize=(9, 4.5))
    
    x = np.arange(len(datasets))
    width = 0.2
    
    methods = [
        ('w/o_constraint_ACC', 'w/o constraint', '#999999'),
        ('FCPL_MES_ACC', 'FCPL (MES/QP)', '#E64B35'),
        ('FCPL_QP_ACC', 'QP (overlapping)', '#E64B35'),
        ('KFCPL_ACC', 'KFCPL', '#4DBBD5'),
    ]
    
    for i, (col, name, color) in enumerate(methods):
        offset = (i - 1.5) * width
        alpha = 0.5 if 'overlapping' in name else 0.85
        hatch = '//' if 'overlapping' in name else None
        
        ax.bar(x + offset, avg[col].values, width,
               yerr=std[col].values,
               color=color, alpha=alpha, edgecolor='white', linewidth=0.5,
               capsize=2, label=name, hatch=hatch)
    
    ax.set_xticks(x)
    ax.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], fontsize=8)
    ax.set_ylabel('ACC (%)')
    ax.set_title('Ablation Study: Constraint Contribution (MES/QP Identical)',
                 fontsize=10, fontweight='bold')
    ax.legend(fontsize=7, loc='upper right')
    despine(ax)
    
    plt.tight_layout()
    out = os.path.join(FIG_DIR, 'v4_fig2_ablation')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig2: {out}.png")


# ============================================================
# 3. Label Ratio Sensitivity (semi-supervised only)
# ============================================================
def fig3_label_ratio():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp4_label_ratio.csv'))
    datasets = sorted(df['Dataset'].unique())
    
    # Semi-supervised methods only: FCPL, KFCPL, SFCM
    methods = [
        ('FCPL_ACC_mean', 'FCPL_ACC_std', 'FCPL', '#E64B35', 'D', 2.0),
        ('KFCPL_ACC_mean', 'KFCPL_ACC_std', 'KFCPL', '#4DBBD5', 's', 2.0),
        ('SFCM_ACC_mean', 'SFCM_ACC_std', 'SFCM', '#00A087', '^', 1.2),
    ]
    
    fig, axes = plt.subplots(2, 3, figsize=(12, 7))
    axes = axes.flatten()
    
    for idx, ds in enumerate(datasets):
        ax = axes[idx]
        ds_data = df[df['Dataset'] == ds].sort_values('LabelRatio')
        x_vals = ds_data['LabelRatio'].values * 100
        
        for mean_col, std_col, algo, color, marker, lw in methods:
            mean = ds_data[mean_col].values
            std = ds_data[std_col].values
            
            ax.plot(x_vals, mean, color=color, linewidth=lw,
                    marker=marker, markersize=5.5,
                    markerfacecolor='white', markeredgewidth=0.6,
                    label=algo, zorder=3)
            ax.fill_between(x_vals, mean - std, mean + std,
                            color=color, alpha=0.12, zorder=2)
        
        ax.set_title(DATASET_NAMES.get(ds, ds), fontsize=9, fontweight='bold')
        ax.set_xlabel('Label Ratio (%)', fontsize=8)
        ax.set_ylabel('ACC (%)', fontsize=8)
        ax.set_xticks([5, 10, 20, 30, 50])
        despine(ax)
        add_panel_label(ax, chr(97+idx))
        
        if idx == 0:
            ax.legend(loc='lower right', framealpha=0.9, fontsize=7)
    
    # 6th panel: summary average
    ax_sum = axes[5]
    ratios = sorted(df['LabelRatio'].unique())
    
    for mean_col, std_col, algo, color, marker, lw in methods:
        means = [df[df['LabelRatio'] == r][mean_col].mean() for r in ratios]
        stds = [df[df['LabelRatio'] == r][mean_col].std() for r in ratios]
        x_vals = np.array(ratios) * 100
        
        ax_sum.plot(x_vals, means, color=color, linewidth=lw,
                   marker=marker, markersize=5.5,
                   markerfacecolor='white', markeredgewidth=0.6,
                   label=algo)
        ax_sum.fill_between(x_vals, np.array(means) - np.array(stds),
                           np.array(means) + np.array(stds),
                           color=color, alpha=0.12)
    
    ax_sum.set_title('Average (5 datasets)', fontsize=9, fontweight='bold')
    ax_sum.set_xlabel('Label Ratio (%)', fontsize=8)
    ax_sum.set_ylabel('ACC (%)', fontsize=8)
    ax_sum.set_xticks([5, 10, 20, 30, 50])
    despine(ax_sum)
    add_panel_label(ax_sum, 'f')
    
    fig.suptitle('Sensitivity to Label Ratio (Semi-Supervised Methods Only)',
                 fontsize=11, fontweight='bold', y=0.995)
    plt.tight_layout(w_pad=2.5, h_pad=2.5)
    
    out = os.path.join(FIG_DIR, 'v4_fig3_label_ratio')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig3: {out}.png")


# ============================================================
# 4. Noise Robustness (semi-supervised only)
# ============================================================
def fig4_noise_robustness():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp5_noise_robustness.csv'))
    datasets = sorted(df['Dataset'].unique())
    
    methods = [
        ('FCPL_ACC_mean', 'FCPL_ACC_std', 'FCPL', '#E64B35', 'D', 2.0),
        ('KFCPL_ACC_mean', 'KFCPL_ACC_std', 'KFCPL', '#4DBBD5', 's', 2.0),
        ('SFCM_ACC_mean', 'SFCM_ACC_std', 'SFCM', '#00A087', '^', 1.2),
    ]
    
    fig, axes = plt.subplots(2, 3, figsize=(12, 7))
    axes = axes.flatten()
    
    for idx, ds in enumerate(datasets):
        ax = axes[idx]
        ds_data = df[df['Dataset'] == ds].sort_values('NoiseLevel')
        x_vals = ds_data['NoiseLevel'].values * 100
        
        for mean_col, std_col, algo, color, marker, lw in methods:
            mean = ds_data[mean_col].values
            std = ds_data[std_col].values
            
            ax.plot(x_vals, mean, color=color, linewidth=lw,
                    marker=marker, markersize=5.5,
                    markerfacecolor='white', markeredgewidth=0.6,
                    label=algo, zorder=3)
            ax.fill_between(x_vals, mean - std, mean + std,
                            color=color, alpha=0.12, zorder=2)
        
        ax.set_title(DATASET_NAMES.get(ds, ds), fontsize=9, fontweight='bold')
        ax.set_xlabel('Noise Rate (%)', fontsize=8)
        ax.set_ylabel('ACC (%)', fontsize=8)
        ax.set_xticks([0, 10, 20, 30, 40])
        despine(ax)
        add_panel_label(ax, chr(97+idx))
        
        if idx == 0:
            ax.legend(loc='lower left', framealpha=0.9, fontsize=7)
    
    # 6th panel: summary
    ax_sum = axes[5]
    noise_levels = sorted(df['NoiseLevel'].unique())
    
    for mean_col, std_col, algo, color, marker, lw in methods:
        means = [df[df['NoiseLevel'] == nl][mean_col].mean() for nl in noise_levels]
        stds = [df[df['NoiseLevel'] == nl][mean_col].std() for nl in noise_levels]
        x_vals = np.array(noise_levels) * 100
        
        ax_sum.plot(x_vals, means, color=color, linewidth=lw,
                   marker=marker, markersize=5.5,
                   markerfacecolor='white', markeredgewidth=0.6,
                   label=algo)
        ax_sum.fill_between(x_vals, np.array(means) - np.array(stds),
                           np.array(means) + np.array(stds),
                           color=color, alpha=0.12)
    
    ax_sum.set_title('Average (5 datasets)', fontsize=9, fontweight='bold')
    ax_sum.set_xlabel('Noise Rate (%)', fontsize=8)
    ax_sum.set_ylabel('ACC (%)', fontsize=8)
    ax_sum.set_xticks([0, 10, 20, 30, 40])
    despine(ax_sum)
    add_panel_label(ax_sum, 'f')
    
    fig.suptitle('Robustness to Label Noise (Semi-Supervised Methods Only)',
                 fontsize=11, fontweight='bold', y=0.995)
    plt.tight_layout(w_pad=2.5, h_pad=2.5)
    
    out = os.path.join(FIG_DIR, 'v4_fig4_noise_robustness')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig4: {out}.png")


# ============================================================
# 5. MES vs QP Strict Verification
# ============================================================
def fig5_mes_qp_verification():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_mes_qp_strict_verification.csv'))
    
    datasets = df['dataset'].values
    
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5))
    
    # (a) ACC comparison (should be identical)
    ax = axes[0]
    x = np.arange(len(datasets))
    width = 0.3
    
    ax.bar(x - width/2, df['ACC_MES'].values * 100, width,
           color='#E64B35', alpha=0.85, edgecolor='white', linewidth=0.5,
           label='MES')
    ax.bar(x + width/2, df['ACC_QP'].values * 100, width,
           color='#E64B35', alpha=0.5, edgecolor='white', linewidth=0.5,
           hatch='//', label='QP (overlapping)')
    
    ax.set_xticks(x)
    ax.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], fontsize=8)
    ax.set_ylabel('ACC (%)')
    ax.set_title('(a) ACC: MES vs QP (Identical)', fontsize=9, fontweight='bold')
    ax.legend(fontsize=7)
    despine(ax)
    
    # (b) Speedup
    ax = axes[1]
    bars = ax.bar(x, df['speedup'].values,
                  color='#4DBBD5', alpha=0.85, edgecolor='white', linewidth=0.5)
    
    ax.set_xticks(x)
    ax.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], fontsize=8)
    ax.set_ylabel('Speedup (MES/QP)')
    ax.set_title('(b) MES Speedup over QP', fontsize=9, fontweight='bold')
    despine(ax)
    
    for i, v in enumerate(df['speedup'].values):
        ax.text(i, v + 2, f'{v:.1f}x', ha='center', fontsize=7)
    
    # (c) U difference (log scale)
    ax = axes[2]
    u_diff = df['U_max_diff'].values
    
    ax.bar(x, u_diff,
           color='#3C5488', alpha=0.85, edgecolor='white', linewidth=0.5)
    ax.set_yscale('log')
    ax.set_xticks(x)
    ax.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], fontsize=8)
    ax.set_ylabel('max |U_MES - U_QP| (log scale)')
    ax.set_title('(c) Membership Matrix Difference', fontsize=9, fontweight='bold')
    despine(ax)
    
    fig.suptitle('MES vs QP Strict Verification (Numerically Identical)',
                 fontsize=10, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    out = os.path.join(FIG_DIR, 'v4_fig5_mes_qp_verification')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig5: {out}.png")


# ============================================================
# 6. Scalability
# ============================================================
def fig6_scalability():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp6_scalability.csv'))
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))
    
    # (a) Standard scalability
    methods = [
        ('FCM_time', 'FCM', '#3C5488', '-o', 1.2),
        ('SFCM_time', 'SFCM', '#00A087', '-s', 1.2),
        ('FCPL_time', 'FCPL', '#E64B35', '-D', 2.0),
        ('KFCPL_time', 'KFCPL', '#4DBBD5', '-^', 2.0),
    ]
    
    for col, name, color, marker, lw in methods:
        if col in df.columns:
            ax1.plot(df['n_samples'].values, df[col].values,
                    marker, color=color, linewidth=lw,
                    markersize=5, markerfacecolor='white',
                    markeredgewidth=0.6, label=name)
    
    ax1.set_xscale('log')
    ax1.set_yscale('log')
    ax1.set_xlabel('Number of Samples')
    ax1.set_ylabel('Runtime (s)')
    ax1.set_title('(a) Standard Scalability', fontsize=10, fontweight='bold')
    ax1.legend(loc='upper left', framealpha=0.9)
    despine(ax1)
    
    # (b) Large scale
    df_large = pd.read_csv(os.path.join(DATA_DIR, 'exp13_large_scale_scalability.csv'))
    
    methods_l = [
        ('FCPL_time', 'FCPL', '#E64B35', '-D', 2.0),
        ('FCM_time', 'FCM', '#3C5488', '-o', 1.2),
        ('KMeans_time', 'K-means', '#F39B7F', '-s', 1.2),
    ]
    
    for col, name, color, marker, lw in methods_l:
        if col in df_large.columns:
            ax2.plot(df_large['n_samples'].values, df_large[col].values,
                    marker, color=color, linewidth=lw,
                    markersize=5, markerfacecolor='white',
                    markeredgewidth=0.6, label=name)
    
    ax2.set_xscale('log')
    ax2.set_yscale('log')
    ax2.set_xlabel('Number of Samples')
    ax2.set_ylabel('Runtime (s)')
    ax2.set_title('(b) Large-Scale (up to 500k)', fontsize=10, fontweight='bold')
    ax2.legend(loc='upper left', framealpha=0.9)
    despine(ax2)
    
    fig.suptitle('Scalability Comparison', fontsize=11, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    out = os.path.join(FIG_DIR, 'v4_fig6_scalability')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig6: {out}.png")


# ============================================================
# 7. Face Experiment (exp_face_redone.csv)
# ============================================================
def fig7_face_experiment():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_face_redone.csv'))
    
    algorithms = sorted(df['algorithm'].unique())
    label_ratios = sorted(df['label_ratio'].unique())
    
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5))
    
    metrics = [
        ('ACC_mean', 'ACC_ci95', 'ACC (%)'),
        ('NMI_mean', 'NMI_ci95', 'NMI (%)'),
        ('ARI_mean', 'ARI_ci95', 'ARI (%)'),
    ]
    
    for ax_idx, (mean_col, ci_col, ylabel) in enumerate(metrics):
        ax = axes[ax_idx]
        
        for algo in algorithms:
            algo_data = df[df['algorithm'] == algo].sort_values('label_ratio')
            x = algo_data['label_ratio'].values * 100
            y = algo_data[mean_col].values
            ci = algo_data[ci_col].values
            
            color = REPR_COLORS.get(algo, '#999999')
            lw = 2.0 if algo in ['FCPL', 'KFCPL'] else 1.2
            
            ax.plot(x, y, color=color, linewidth=lw,
                   marker='o', markersize=5,
                   markerfacecolor='white', markeredgewidth=0.6,
                   label=algo)
            ax.fill_between(x, y - ci, y + ci, color=color, alpha=0.1)
        
        ax.set_xlabel('Label Ratio (%)')
        ax.set_ylabel(ylabel)
        ax.set_title(ylabel.split(' ')[0], fontsize=10, fontweight='bold')
        despine(ax)
        
        if ax_idx == 0:
            ax.legend(fontsize=6.5, ncol=2, loc='lower right')
    
    fig.suptitle('Face Expression Recognition: Algorithm Comparison',
                 fontsize=11, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    out = os.path.join(FIG_DIR, 'v4_fig7_face_experiment')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig7: {out}.png")


# ============================================================
# 8. Large-Scale Industrial Dataset
# ============================================================
def fig8_large_scale():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_large_scale_summary.csv'))
    
    # Filter out OOM and convert numeric
    df = df[df['ACC_mean'] != 'OOM'].copy()
    df['ACC_mean'] = pd.to_numeric(df['ACC_mean'], errors='coerce')
    df['time_mean'] = pd.to_numeric(df['time_mean'], errors='coerce')
    df = df.dropna(subset=['ACC_mean', 'time_mean'])
    
    datasets = sorted(df['dataset'].unique())
    algorithms = sorted(df['algorithm'].unique())
    
    # Filter to representative algorithms
    repr_in_data = [a for a in REPR_ALGOS if a in algorithms]
    
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    
    # (a) ACC comparison
    ax = axes[0]
    x = np.arange(len(datasets))
    width = 0.13
    
    for i, algo in enumerate(repr_in_data):
        algo_data = df[df['algorithm'] == algo].set_index('dataset')
        offset = (i - len(repr_in_data)/2 + 0.5) * width
        color = REPR_COLORS.get(algo, '#999')
        alpha = 1.0 if algo in ['FCPL', 'KFCPL'] else 0.85
        
        vals = [algo_data['ACC_mean'].get(d, 0) for d in datasets]
        ax.bar(x + offset, vals, width,
               color=color, alpha=alpha, edgecolor='white', linewidth=0.5,
               label=algo)
    
    ax.set_xticks(x)
    ax.set_xticklabels([d[:12] for d in datasets], rotation=30, ha='right', fontsize=7)
    ax.set_ylabel('ACC (%)')
    ax.set_title('(a) Large-Scale ACC Comparison', fontsize=10, fontweight='bold')
    ax.legend(fontsize=7)
    despine(ax)
    
    # (b) Runtime comparison
    ax = axes[1]
    for i, algo in enumerate(repr_in_data):
        algo_data = df[df['algorithm'] == algo].set_index('dataset')
        vals = [algo_data['time_mean'].get(d, 0) for d in datasets]
        ax.bar(x + i * width, vals, width,
               color=REPR_COLORS.get(algo, '#999'), alpha=0.85,
               edgecolor='white', linewidth=0.5)
    
    ax.set_xticks(x + width*len(repr_in_data)/2 - width/2)
    ax.set_xticklabels([d[:12] for d in datasets], rotation=30, ha='right', fontsize=7)
    ax.set_ylabel('Runtime (s)')
    ax.set_title('(b) Runtime Comparison', fontsize=10, fontweight='bold')
    despine(ax)
    
    fig.suptitle('Large-Scale Industrial Datasets', fontsize=11, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    out = os.path.join(FIG_DIR, 'v4_fig8_large_scale')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig8: {out}.png")


# ============================================================
# MAIN
# ============================================================
def main():
    print("=" * 60)
    print("v4 Complete Chart Generation")
    print("=" * 60)
    
    print("\n1. UCI SOTA comparison...")
    fig1_sota_comparison()
    
    print("\n2. Ablation study...")
    fig2_ablation()
    
    print("\n3. Label ratio sensitivity...")
    fig3_label_ratio()
    
    print("\n4. Noise robustness...")
    fig4_noise_robustness()
    
    print("\n5. MES vs QP verification...")
    fig5_mes_qp_verification()
    
    print("\n6. Scalability...")
    fig6_scalability()
    
    print("\n7. Face experiment...")
    fig7_face_experiment()
    
    print("\n8. Large-scale industrial...")
    fig8_large_scale()
    
    print("\n" + "=" * 60)
    print("All v4 charts generated!")
    print("=" * 60)


if __name__ == '__main__':
    main()
