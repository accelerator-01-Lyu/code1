"""Check all CSV files for algorithm lists and data structures."""
import pandas as pd
import os

data_dir = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\data\results'

csv_files = [f for f in os.listdir(data_dir) if f.endswith('.csv')]

print("=" * 70)
print("ALGORITHM INVENTORY ACROSS ALL CSV FILES")
print("=" * 70)

all_algos = set()

for fname in sorted(csv_files):
    fpath = os.path.join(data_dir, fname)
    try:
        df = pd.read_csv(fpath)
        print(f"\n--- {fname} ---")
        print(f"  Shape: {df.shape}")
        print(f"  Columns: {list(df.columns)[:15]}")
        
        # Check for Algorithm column
        if 'Algorithm' in df.columns:
            algos = sorted(df['Algorithm'].unique())
            print(f"  Algorithms ({len(algos)}): {algos}")
            all_algos.update(algos)
        else:
            # Check for method columns like FCPL_ACC_mean, etc.
            algo_cols = [c for c in df.columns if '_ACC_mean' in c or '_ACC_std' in c]
            if algo_cols:
                algo_names = sorted(set([c.replace('_ACC_mean', '').replace('_ACC_std', '') for c in algo_cols]))
                print(f"  Methods (from columns): {algo_names}")
                all_algos.update(algo_names)
    except Exception as e:
        print(f"  Error: {e}")

print("\n" + "=" * 70)
print(f"UNION OF ALL ALGORITHMS: {len(all_algos)}")
print("=" * 70)
for a in sorted(all_algos):
    print(f"  - {a}")
