# -*- coding: utf-8 -*-
"""
draw_figures.py
IEEE-style vector figures for:
  "Semi-supervised Fuzzy Clustering with Partition-level Constraints
   and an Efficient Matrix-Based Solver (FCPL / MES / KFCPL)"

Outputs (SVG vector + PNG @300dpi):
  Fig 1: clustering paradigm comparison (Hard / FCM / FCPL)
  Fig 2: FCPL + KFCPL algorithm flowchart with MES detail box
  Fig 3: MES mathematical-principle schematic
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import (FancyBboxPatch, FancyArrowPatch, Polygon,
                                Rectangle)

HERE = os.path.dirname(os.path.abspath(__file__))
FIG_DIR = os.path.normpath(os.path.join(HERE, "..", "..", "figures"))
os.makedirs(FIG_DIR, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Nimbus Roman", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 9.5,
    "axes.linewidth": 0.9,
    "figure.dpi": 150,
    "savefig.dpi": 300,
    "svg.fonttype": "none",
    "pdf.fonttype": 42,
})

C1 = np.array([0.173, 0.424, 0.722])    # blue   (A)
C2 = np.array([0.851, 0.376, 0.071])    # orange (B)
C3 = np.array([0.106, 0.620, 0.467])    # teal   (C)
CLR = [C1, C2, C3]
INK = "#1a1a1a"
rng = np.random.default_rng(20260916)


def save(fig, name):
    svg = os.path.join(FIG_DIR, name + ".svg")
    png = os.path.join(FIG_DIR, name + ".png")
    fig.savefig(svg, bbox_inches="tight")
    fig.savefig(png, bbox_inches="tight", dpi=300)
    plt.close(fig)
    print("saved:", png)


# ======================================================================
# Fig 1
# ======================================================================
def make_data():
    m1 = np.array([0.0, 0.0]);  c1 = np.array([[0.55, 0.10], [0.10, 0.55]])
    m2 = np.array([2.3, 1.1]);  c2 = np.array([[0.55, -0.08], [-0.08, 0.55]])
    m3 = np.array([1.0, 2.9]);  c3 = np.array([[0.45, 0.05], [0.05, 0.45]])
    X = np.vstack([rng.multivariate_normal(m1, c1, 55),
                   rng.multivariate_normal(m2, c2, 55),
                   rng.multivariate_normal(m3, c3, 45)])
    y = np.array([0]*55 + [1]*55 + [2]*45)
    return X, y, [m1, m2, m3]


def fcm_membership(X, centers, m=2.0):
    d = np.stack([np.sum((X - c) ** 2, axis=1) for c in centers], axis=1)
    d = np.clip(d, 1e-8, None)
    u = np.zeros_like(d)
    for k in range(d.shape[1]):
        u[:, k] = 1.0 / np.sum((d[:, k:k+1] / d) ** (1.0 / (m - 1.0)), axis=1)
    return u


def fig1():
    X, y, centers = make_data()
    U = fcm_membership(X, centers, m=2.0)
    rgb = U @ np.array(CLR)

    fig, axes = plt.subplots(1, 3, figsize=(13.2, 4.7))
    titles = ["(a) Traditional Hard Clustering",
              "(b) Unsupervised Fuzzy Clustering",
              "(c) Partition-level Constrained Fuzzy Clustering (Ours)"]

    gx = np.linspace(X[:, 0].min()-0.6, X[:, 0].max()+0.6, 220)
    gy = np.linspace(X[:, 1].min()-0.6, X[:, 1].max()+0.6, 220)
    GX, GY = np.meshgrid(gx, gy)
    GPTS = np.c_[GX.ravel(), GY.ravel()]
    gd = np.stack([np.sum((GPTS - c) ** 2, axis=1) for c in centers], axis=1)
    glab = np.argmin(gd, axis=1).reshape(GX.shape)
    # fuzzy grid colours
    Ug = np.zeros_like(gd)
    for j in range(3):
        Ug[:, j] = 1.0 / np.sum((gd[:, j:j+1] / gd), axis=1)
    rgbf = (Ug @ np.array(CLR)).reshape(GX.shape[0], GX.shape[1], 3)

    # (a) hard
    ax = axes[0]
    for k in range(3):
        ax.scatter(X[y == k, 0], X[y == k, 1], s=22, color=CLR[k],
                   edgecolor="white", linewidth=0.4, zorder=3)
    for k in range(3):
        ax.contourf(GX, GY, glab, levels=[k-0.5, k+0.5],
                    colors=[CLR[k]], alpha=0.10, zorder=1)
    ax.contour(GX, GY, glab, levels=[0.5, 1.5], colors=INK,
               linewidths=1.1, zorder=2)
    ax.set_title(titles[0])
    ax.text(0.5, -0.13, r"Hard assignment: $u_{ik}\in\{0,1\}$",
            transform=ax.transAxes, ha="center", fontsize=9)

    # (b) fuzzy
    ax = axes[1]
    ax.pcolormesh(GX, GY, rgbf, shading="auto", alpha=0.18, zorder=1)
    ax.scatter(X[:, 0], X[:, 1], s=22, c=rgb, edgecolor="white",
               linewidth=0.4, zorder=3)
    ax.set_title(titles[1])
    ax.text(0.5, -0.13,
            r"Soft assignment: $u_{ik}\in[0,1],\ \sum_k u_{ik}=1$",
            transform=ax.transAxes, ha="center", fontsize=9)

    # (c) FCPL
    ax = axes[2]
    ax.scatter(X[:, 0], X[:, 1], s=22, c=rgb, edgecolor="white",
               linewidth=0.4, zorder=3)
    labeled_idx = []
    for k in range(3):
        idx = np.where(y == k)[0]
        dd = np.sum((X[idx] - centers[k]) ** 2, axis=1)
        labeled_idx.append(idx[np.argmin(dd)])
    bnd = int(np.argmin(np.abs(U.max(axis=1) - 0.5)))
    labeled_idx.append(bnd)
    labeled_idx = np.unique(labeled_idx)
    for li in labeled_idx:
        ax.scatter(X[li, 0], X[li, 1], marker="*", s=170,
                   facecolor="#111111", edgecolor="white", linewidth=0.8, zorder=5)
    callout = [labeled_idx[0], labeled_idx[-1]]
    prior_txt = [r"$\mathbf{p}_i=(0.92,0.05,0.03)$",
                 r"$\mathbf{p}_i=(0.08,0.85,0.07)$"]
    for li, tx in zip(callout, prior_txt):
        ax.annotate(tx, xy=(X[li, 0], X[li, 1]),
                    xytext=(X[li, 0]+0.55, X[li, 1]+0.55), fontsize=8,
                    arrowprops=dict(arrowstyle="->", lw=0.8, color="#444444"),
                    zorder=6)
    ax.set_title(titles[2])
    ax.text(0.5, -0.13,
            r"Partition-level constraints: $\mathbf{u}_i\approx\mathbf{p}_i$ for labeled samples",
            transform=ax.transAxes, ha="center", fontsize=9)
    ax.scatter([], [], marker="*", s=130, facecolor="#111111",
               edgecolor="white", label="labeled sample (partition prior)")
    ax.legend(loc="upper left", framealpha=0.9, handletextpad=0.1)

    for ax in axes:
        ax.set_xticks([]); ax.set_yticks([])
        for s in ax.spines.values():
            s.set_color("#888888")
        ax.set_aspect("equal")

    fig.text(0.5, 0.005,
             r"Evolution:  hard one-to-one assignment  $\longrightarrow$  "
             r"fuzzy soft membership  $\longrightarrow$  "
             r"+ global partition-level prior $\mathbf{P}$",
             ha="center", va="bottom", fontsize=9, style="italic", color="#333333")
    fig.tight_layout(rect=[0, 0.07, 1, 1])
    save(fig, "fig1_paradigm_comparison")



# ======================================================================
# Fig 2 : modern panel-style algorithm framework
# ======================================================================
MAGENTA = "#E91E63"
INKBLUE = "#1F4E79"


def rbox(ax, cx, cy, w, h, fc, ec="#546E7A", lw=1.2, ls="solid",
         rad=0.9, zorder=2):
    x, y = cx - w/2, cy - h/2
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h,
        boxstyle=f"round,pad=0.02,rounding_size={rad}",
        facecolor=fc, edgecolor=ec, lw=lw, linestyle=ls, zorder=zorder))


def panel(ax, x0, y0, x1, y1, fc, ec="#90A4AE"):
    ax.add_patch(FancyBboxPatch(
        (x0, y0), x1-x0, y1-y0,
        boxstyle="round,pad=0.3,rounding_size=1.4",
        facecolor=fc, edgecolor=ec, lw=1.1, zorder=0))


def varrow(ax, x, y0, y1, color=MAGENTA, lw=3.0):
    ax.add_patch(FancyArrowPatch((x, y0), (x, y1), arrowstyle="-|>",
                                 mutation_scale=18, lw=lw, color=color,
                                 zorder=4))


def parrow(ax, p0, p1, color="#37474F", lw=1.3, ls="solid"):
    ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle="-|>", mutation_scale=11,
                                 lw=lw, color=color, linestyle=ls, zorder=3))


# ---- tiny inset icons (drawn in data coords) ----
def icon_scatter(ax, cx, cy, s=1.3):
    pts = [(cx-1.6, cy-0.8), (cx-0.9, cy-1.4), (cx-0.4, cy-0.2),
           (cx+0.3, cy-1.0), (cx+0.9, cy-0.4), (cx+1.5, cy-1.1),
           (cx-1.2, cy+0.9), (cx-0.3, cy+1.3), (cx+0.4, cy+0.6),
           (cx+1.2, cy+1.2), (cx+0.0, cy+0.0)]
    cols = [C1, C1, C2, C2, C2, C3, C1, C3, C2, C3, C3]
    for (px, py), c in zip(pts, cols):
        ax.scatter([px], [py], s=26, color=c, edgecolor="white",
                   linewidth=0.4, zorder=5)


def icon_heatmap(ax, cx, cy, n=5, cell=0.62, labeled=None):
    rng2 = np.random.default_rng(7)
    M = rng2.random((n, n)) * 0.55 + 0.15
    if labeled is not None:
        M[labeled, :] = [0.95, 0.1, 0.1] + list(rng2.random(n-3)*0.2)
    for i in range(n):
        for j in range(n):
            v = M[i, j]
            col = (0.1 + 0.7*v, 0.25 + 0.5*v, 0.55 + 0.35*v)
            ax.add_patch(Rectangle((cx - n*cell/2 + j*cell - cell/2,
                                    cy - n*cell/2 + i*cell - cell/2),
                                   cell*0.92, cell*0.92,
                                   facecolor=col, edgecolor="white",
                                   linewidth=0.3, zorder=5))


def icon_kernel(ax, cx, cy):
    t = np.linspace(-2.0, 2.0, 60)
    y = np.exp(-(t**2)/1.2)
    ax.plot(cx + t*1.1, cy + y*1.3, color="#E91E63", lw=1.6, zorder=5)
    ax.plot([cx-2.3, cx+2.3], [cy-1.4, cy-1.4], color="#90A4AE",
            lw=0.8, zorder=5)


def icon_conv(ax, cx, cy):
    t = np.linspace(0, 1, 40)
    y = 0.1 + 0.9*np.exp(-4.5*t)
    ax.plot(cx - 1.6 + t*3.2, cy - 1.2 + y*2.0, color="#2E7D32",
            lw=1.6, zorder=5)
    ax.plot([cx-1.6, cx+1.6], [cy-1.2, cy-1.2], color="#90A4AE",
            lw=0.8, zorder=5)


def vstage_label(ax, x, y, text, color):
    ax.add_patch(FancyBboxPatch((x-1.6, y-3.2), 3.2, 6.4,
                 boxstyle="round,pad=0.1,rounding_size=0.8",
                 facecolor=color, edgecolor="none", zorder=3))
    ax.text(x, y, text, rotation=90, ha="center", va="center",
            color="white", fontsize=9.5, fontweight="bold", zorder=4)


def fig2():
    fig = plt.figure(figsize=(16, 12))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off")

    # ---------- three horizontal panels ----------
    panel(ax, 9, 81, 98, 96, "#E3F2FD")     # Input
    panel(ax, 9, 30, 98, 78, "#E8F5E9")     # Optimization
    panel(ax, 9, 10, 98, 26, "#FFF3E0")     # Output

    vstage_label(ax, 4.5, 88.5, "INPUT", "#42A5F5")
    vstage_label(ax, 4.5, 54.0, "OPTIMIZATION", "#66BB6A")
    vstage_label(ax, 4.5, 18.0, "OUTPUT", "#FFA726")

    # ================= PANEL 1 : INPUT =================
    rbox(ax, 26, 88.5, 20, 9.5, "#FFFFFF", ec="#42A5F5")
    icon_scatter(ax, 21, 90.5)
    ax.text(29.5, 89.8, "Dataset  $X$", ha="center", va="center",
            fontsize=9.5, fontweight="bold", color=INKBLUE)
    ax.text(29.5, 86.8, r"$n$ samples, $d$ features", ha="center",
            va="center", fontsize=8, color="#555")

    rbox(ax, 53, 88.5, 20, 9.5, "#FFFFFF", ec="#42A5F5")
    icon_heatmap(ax, 48.5, 89.5, labeled=1)
    ax.text(57.5, 89.8, "Partition-level prior $P$", ha="center",
            va="center", fontsize=9.0, fontweight="bold", color=INKBLUE)
    ax.text(57.5, 86.8, r"prior membership, $10\%$ labeled", ha="center",
            va="center", fontsize=8, color="#555")

    rbox(ax, 82, 88.5, 22, 9.5, "#FFFFFF", ec="#42A5F5")
    ax.text(82, 90.8, "Hyperparameters", ha="center", va="center",
            fontsize=9.5, fontweight="bold", color=INKBLUE)
    ax.text(82, 88.2, r"$k$, $\lambda$, $m$", ha="center", va="center",
            fontsize=8.6)
    ax.text(82, 86.2, r"$\gamma$ (KFCPL only)", ha="center", va="center",
            fontsize=8, color="#555")

    # converging input arrows
    varrow(ax, 26, 81.2, 78.4)
    varrow(ax, 53, 81.2, 78.4)
    varrow(ax, 82, 81.2, 78.4)

    # ================= PANEL 2 : OPTIMIZATION =================
    ax.text(53.5, 76.2, "Alternating Optimization", ha="center", va="center",
            fontsize=11, fontweight="bold", color="#2E7D32")
    # vertical divider
    ax.plot([54.5, 54.5], [31.5, 74.5], color="#90A4AE", lw=1.0,
            ls=(0, (4, 3)), zorder=1)
    ax.text(31.5, 73.8, "FCPL  (Euclidean Space)", ha="center",
            fontsize=9.5, fontweight="bold", color=INKBLUE)
    ax.text(76.5, 73.8, "KFCPL  (RKHS / Gaussian Kernel)", ha="center",
            fontsize=9.5, fontweight="bold", color="#BF360C")

    # ---- FCPL column ----
    # E-step
    rbox(ax, 31.5, 70.5, 36, 5.2, "#FFFFFF", ec="#66BB6A", lw=1.3)
    ax.text(31.5, 71.6, "E-step: update centers", ha="center", va="center",
            fontsize=8.8, fontweight="bold", color="#2E7D32")
    ax.text(31.5, 69.4, r"$c_k=\frac{\sum_i u_{ik}^{m}x_i}{\sum_i u_{ik}^{m}}$",
            ha="center", va="center", fontsize=8.6)

    # M-step header
    rbox(ax, 31.5, 64.5, 36, 4.0, "#E8F5E9", ec="#66BB6A", lw=1.2)
    ax.text(31.5, 64.5, "M-step: update fuzzy membership  $U$",
            ha="center", va="center", fontsize=8.8, fontweight="bold")

    # two sub-branches
    rbox(ax, 21.5, 58.5, 18, 6.2, "#FFFFFF", ec="#90A4AE")
    ax.text(21.5, 59.6, r"$i\notin S$", ha="center", va="center",
            fontsize=8.6, fontweight="bold")
    ax.text(21.5, 57.6, "FCM closed form", ha="center", va="center",
            fontsize=8)
    ax.text(21.5, 56.4, r"$u_{ik}=1/\sum_j(d_{ik}/d_{ij})^{2/(m-1)}$",
            ha="center", va="center", fontsize=6.8, color="#444")

    rbox(ax, 41.5, 58.5, 18, 6.2, "#FFF8E1", ec="#FB8C00", lw=1.6)
    ax.text(41.5, 59.6, r"$i\in S$", ha="center", va="center",
            fontsize=8.6, fontweight="bold", color="#E65100")
    ax.text(41.5, 57.6, "MES Solver", ha="center", va="center",
            fontsize=8.2, fontweight="bold", color="#E65100")

    # MES detail dashed grouping
    rbox(ax, 41.5, 49.0, 20, 7.6, "#FFFDE7", ec="#FB8C00", lw=1.1,
         ls=(0, (3, 2)), rad=0.6)
    ax.text(41.5, 51.8, "Lagrangian", ha="center", va="center",
            fontsize=7.6, color="#E65100")
    ax.text(41.5, 50.2, "→ Block linear system", ha="center", va="center",
            fontsize=7.6, color="#E65100")
    ax.text(41.5, 48.6, "→ Active-set truncation", ha="center", va="center",
            fontsize=7.6, color="#E65100")

    # decision
    rbox(ax, 31.5, 40.5, 26, 5.6, "#FFFFFF", ec="#66BB6A", lw=1.3)
    ax.text(31.5, 41.2, "Convergence?", ha="center", va="center",
            fontsize=8.8, fontweight="bold", color="#2E7D32")
    ax.text(31.5, 39.6, r"$\|U_{new}-U_{old}\|_\infty<10^{-5}$",
            ha="center", va="center", fontsize=8.2)

    # FCPL internal arrows
    parrow(ax, (31.5, 67.8), (31.5, 66.6))
    parrow(ax, (26, 62.4), (22, 61.6))
    parrow(ax, (37, 62.4), (41, 61.6))
    parrow(ax, (41.5, 55.3), (41.5, 52.9))
    parrow(ax, (21.5, 55.3), (27, 43.6))
    parrow(ax, (41.5, 45.1), (36, 43.4))
    # loop back (magenta)
    parrow(ax, (18.5, 40.5), (13.5, 40.5), color=MAGENTA, lw=2.2)
    parrow(ax, (13.5, 40.5), (13.5, 70.5), color=MAGENTA, lw=2.2)
    parrow(ax, (13.5, 70.5), (18.5, 70.5), color=MAGENTA, lw=2.2)
    ax.text(12.0, 55.5, "no", rotation=90, ha="center", va="center",
            fontsize=8.5, color=MAGENTA, fontweight="bold")

    # ---- KFCPL column ----
    rbox(ax, 76.5, 70.5, 36, 5.2, "#FFFFFF", ec="#FF8A65", lw=1.3)
    icon_kernel(ax, 64.5, 70.5)
    ax.text(80.5, 71.6, "Kernel map  $\\phi:X\\to\\mathcal{H}$",
            ha="center", va="center", fontsize=8.8, fontweight="bold",
            color="#BF360C")
    ax.text(80.5, 69.4, r"$K(x,y)=\exp(-\gamma\|x-y\|^2)$",
            ha="center", va="center", fontsize=8.6)

    rbox(ax, 76.5, 64.5, 36, 4.0, "#FBE9E7", ec="#FF8A65", lw=1.2)
    ax.text(76.5, 64.5, "E-step: kernel centers (weighted $\\phi(x_i)$)",
            ha="center", va="center", fontsize=8.6, fontweight="bold")

    rbox(ax, 66.5, 58.5, 18, 6.2, "#FFFFFF", ec="#90A4AE")
    ax.text(66.5, 59.6, r"$i\notin S$", ha="center", va="center",
            fontsize=8.6, fontweight="bold")
    ax.text(66.5, 57.6, "kernel-distance", ha="center", va="center",
            fontsize=8)
    ax.text(66.5, 56.4, "FCM update", ha="center", va="center", fontsize=8)

    rbox(ax, 86.5, 58.5, 18, 6.2, "#FFF8E1", ec="#FB8C00", lw=1.6)
    ax.text(86.5, 59.6, r"$i\in S$", ha="center", va="center",
            fontsize=8.6, fontweight="bold", color="#E65100")
    ax.text(86.5, 57.6, "MES Solver", ha="center", va="center",
            fontsize=8.2, fontweight="bold", color="#E65100")

    rbox(ax, 86.5, 49.0, 20, 7.6, "#FFFDE7", ec="#FB8C00", lw=1.1,
         ls=(0, (3, 2)), rad=0.6)
    ax.text(86.5, 51.8, "Lagrangian", ha="center", va="center",
            fontsize=7.6, color="#E65100")
    ax.text(86.5, 50.2, "→ Block linear system", ha="center", va="center",
            fontsize=7.6, color="#E65100")
    ax.text(86.5, 48.6, "→ Active-set truncation", ha="center", va="center",
            fontsize=7.6, color="#E65100")

    rbox(ax, 76.5, 40.5, 26, 5.6, "#FFFFFF", ec="#FF8A65", lw=1.3)
    ax.text(76.5, 41.2, "Convergence?", ha="center", va="center",
            fontsize=8.8, fontweight="bold", color="#BF360C")
    ax.text(76.5, 39.6, r"$\|U_{new}-U_{old}\|_\infty<10^{-5}$",
            ha="center", va="center", fontsize=8.2)

    parrow(ax, (76.5, 67.8), (76.5, 66.6))
    parrow(ax, (71, 62.4), (67, 61.6))
    parrow(ax, (82, 62.4), (86, 61.6))
    parrow(ax, (86.5, 55.3), (86.5, 52.9))
    parrow(ax, (66.5, 55.3), (72, 43.6))
    parrow(ax, (86.5, 45.1), (82, 43.4))
    # loop back right side (magenta)
    parrow(ax, (89.5, 40.5), (94.5, 40.5), color=MAGENTA, lw=2.2)
    parrow(ax, (94.5, 40.5), (94.5, 70.5), color=MAGENTA, lw=2.2)
    parrow(ax, (94.5, 70.5), (90.5, 70.5), color=MAGENTA, lw=2.2)
    ax.text(96.0, 55.5, "no", rotation=90, ha="center", va="center",
            fontsize=8.5, color=MAGENTA, fontweight="bold")

    # panel1 -> panel2 magenta already vertical; decision yes -> output
    varrow(ax, 31.5, 37.6, 26.4)
    varrow(ax, 76.5, 37.6, 26.4)
    ax.text(33.5, 32.0, "yes", fontsize=8.5, color=MAGENTA,
            fontweight="bold")
    ax.text(78.5, 32.0, "yes", fontsize=8.5, color=MAGENTA,
            fontweight="bold")

    # ================= PANEL 3 : OUTPUT =================
    rbox(ax, 26, 18, 20, 9, "#FFFFFF", ec="#FFA726")
    icon_heatmap(ax, 21.5, 19.5)
    ax.text(29.5, 20.5, "Fuzzy membership $U$", ha="center", va="center",
            fontsize=8.8, fontweight="bold", color="#E65100")
    ax.text(29.5, 16.8, "$n\\times k$ matrix", ha="center", va="center",
            fontsize=8, color="#555")

    rbox(ax, 53, 18, 20, 9, "#FFFFFF", ec="#FFA726")
    ax.text(53, 19.8, "Cluster centers", ha="center", va="center",
            fontsize=8.8, fontweight="bold", color="#E65100")
    ax.text(53, 17.6, "$C$  (FCPL) / $z_k$  (KFCPL)", ha="center",
            va="center", fontsize=8)

    rbox(ax, 82, 18, 22, 9, "#FFFFFF", ec="#FFA726")
    icon_conv(ax, 76.5, 19.5)
    ax.text(85.5, 20.5, "Convergence", ha="center", va="center",
            fontsize=8.8, fontweight="bold", color="#E65100")
    ax.text(85.5, 16.8, "monotonic objective", ha="center", va="center",
            fontsize=8, color="#555")

    ax.text(53.5, 11.5, "Clustering results  +  fuzzy interpretability",
            ha="center", va="center", fontsize=9.5, fontweight="bold",
            color="#BF360C")

    save(fig, "fig2_algorithm_flowchart")

# ======================================================================
# Fig 3
# ======================================================================
def fig3():
    fig, axes = plt.subplots(1, 3, figsize=(13.4, 4.6))
    v = np.array([[0.0, 0.0], [1.0, 0.0], [0.5, np.sqrt(3)/2]])

    # (a) simplex
    ax = axes[0]
    ax.add_patch(Polygon(v, closed=True, facecolor="#eaf0f8",
                         edgecolor="#2c3e50", lw=1.3, zorder=1))
    ctr = np.array([0.45, 0.35, 0.20])
    grid = np.linspace(0, 1, 110)
    AA, BB = np.meshgrid(grid, grid)
    CC = 1 - AA - BB
    Q = np.zeros_like(AA)
    mask = CC >= 0
    Q[mask] = np.sum((np.c_[AA[mask], BB[mask], CC[mask]] - ctr) ** 2, axis=1)
    Qm = np.ma.masked_where(~mask, Q)
    xx = AA*v[0, 0] + BB*v[1, 0] + CC*v[2, 0]
    yy = AA*v[0, 1] + BB*v[1, 1] + CC*v[2, 1]
    ax.contourf(xx, yy, Qm, levels=12, cmap="Blues", alpha=0.55, zorder=2)
    pc = ctr[0]*v[0] + ctr[1]*v[1] + ctr[2]*v[2]
    ax.scatter([pc[0]], [pc[1]], marker="*", s=220, color="#b23a3a",
               edgecolor="white", zorder=5)
    ax.text(pc[0], pc[1]+0.06, "constrained\noptimum", ha="center",
            fontsize=8, color="#b23a3a")
    ax.text(v[0, 0]-0.03, v[0, 1]-0.05, r"$u_1=1$", fontsize=8.5, ha="right")
    ax.text(v[1, 0]+0.03, v[1, 1]-0.05, r"$u_2=1$", fontsize=8.5, ha="left")
    ax.text(v[2, 0], v[2, 1]+0.04, r"$u_3=1$", fontsize=8.5, ha="center")
    ax.text(0.5, -0.18, "(a) Feasible region: simplex\n" +
            r"$\mathbf{1}^{\top}u=1,\ u\geq0$",
            transform=ax.transAxes, ha="center", fontsize=8.8)
    ax.set_xlim(-0.15, 1.15); ax.set_ylim(-0.15, 1.05)
    ax.set_aspect("equal"); ax.axis("off")

    # (b) Lagrangian relaxation
    ax = axes[1]
    t = np.linspace(-0.3, 1.3, 10)
    ax.plot(t, 1-t, color="#2c3e50", lw=1.6, zorder=2,
            label=r"equality $\mathbf{1}^{\top}u=1$")
    cx, cy = 0.55, 0.55
    gx = np.linspace(-0.3, 1.3, 200); gy = np.linspace(-0.3, 1.3, 200)
    GX, GY = np.meshgrid(gx, gy)
    ax.contour(GX, GY, (GX-cx)**2 + (GY-cy)**2, levels=10,
               cmap="Oranges", alpha=0.7, zorder=1)
    ax.scatter([cx], [cy], marker="o", s=80, facecolor="white",
               edgecolor="#b23a3a", zorder=5)
    ax.annotate(r"unconstrained $u^{\star}$", xy=(cx, cy),
                xytext=(cx+0.13, cy+0.13), fontsize=8.5, color="#b23a3a",
                arrowprops=dict(arrowstyle="->", lw=0.8))
    ax.text(0.5, -0.18,
            "(b) Lagrangian relaxation\n" +
            r"non-negativity dropped $\Rightarrow$ affine line",
            transform=ax.transAxes, ha="center", fontsize=8.8)
    ax.set_xlim(-0.3, 1.3); ax.set_ylim(-0.3, 1.3)
    ax.set_aspect("equal"); ax.axis("off")
    ax.legend(loc="upper right", fontsize=7.8, framealpha=0.9)

    # (c) block matrix
    ax = axes[2]
    k = 6
    M = np.zeros((k+1, k+1))
    M[:k, :k] = np.diag([4.2, 3.8, 5.1, 3.5, 4.6, 3.9])
    M[:k, k] = 1.0; M[k, :k] = 1.0
    ax.imshow(M, cmap="Blues", aspect="equal", vmin=0, vmax=6, zorder=1)
    ax.add_patch(Rectangle((-0.5, -0.5), k, k, fill=False,
                           edgecolor="#1f4e79", lw=1.6))
    ax.add_patch(Rectangle((k-0.5, -0.5), 1, k, fill=False,
                           edgecolor="#b23a3a", lw=1.6))
    ax.add_patch(Rectangle((-0.5, k-0.5), k, 1, fill=False,
                           edgecolor="#b23a3a", lw=1.6))
    ax.text(k/2-0.5, k/2-0.5, r"$D+\lambda I$", ha="center",
            va="center", fontsize=11, color="#1f4e79")
    ax.text(k, k/2-0.5, r"$\mathbf{1}$", ha="center",
            va="center", fontsize=11, color="#b23a3a")
    ax.text(k/2-0.5, k, r"$\mathbf{1}^{\top}$", ha="center",
            va="center", fontsize=11, color="#b23a3a")
    ax.text(k, k, "0", ha="center", va="center", fontsize=10, color="#555")
    ax.set_xticks([]); ax.set_yticks([])
    ax.set_title("block-matrix inversion", fontsize=9.5, pad=8)
    ax.text(0.5, -0.20,
            "(c) Block linear system" + "\n" +
            r"$(D+\lambda I)u_i+\mathbf{1}\,\nu=\lambda p_i,\quad \mathbf{1}^{\top}u_i=1$",
            transform=ax.transAxes, ha="center", fontsize=8.2)

    fig.suptitle("MES:  constrained QP  $\\to$  Lagrangian relaxation  "
                 "$\\to$  solvable linear system",
                 fontsize=10.5, y=1.02)
    fig.tight_layout()
    save(fig, "fig3_mes_principle")


if __name__ == "__main__":
    fig1()
    fig2()
    fig3()
    print("ALL DONE ->", FIG_DIR)
