#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Top-tier journal quality visualization for FCPL/KFCPL semi-supervised fuzzy clustering experiments.
Nature / Science / IEEE Transactions style figures.
"""

import os
import ast
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch
from matplotlib.collections import LineCollection
import matplotlib.ticker as ticker
from scipy import stats
from sklearn.manifold import TSNE
from sklearn.datasets import load_iris, load_wine, make_moons
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings('ignore')

# ============================================================
# GLOBAL STYLE CONFIGURATION
# ============================================================
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
    'mathtext.fontset': 'stix',
    'font.size': 10,
    'axes.titlesize': 12,
    'axes.titleweight': 'bold',
    'axes.labelsize': 11,
    'axes.labelweight': 'normal',
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'legend.fontsize': 8.5,
    'legend.frameon': True,
    'legend.framealpha': 0.9,
    'legend.edgecolor': '#cccccc',
    'legend.fancybox': True,
    'figure.dpi': 150,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
    'axes.grid': True,
    'grid.linestyle': '--',
    'grid.alpha': 0.3,
    'grid.color': '#aaaaaa',
    'axes.axisbelow': True,
})

# ============================================================
# COLOR PALETTE - Professional, distinguishable, harmonious
# ============================================================
COLORS = {
    'K-means':     '#4472C4',   # Royal Blue
    'PCAKM':       '#5B9BD5',   # Light Blue
    'FCM':         '#ED7D31',   # Orange
    'KFCM':        '#A5A5A5',   # Gray
    'SFCM':        '#FFC000',   # Gold
    'CDRSC':       '#70AD47',   # Green
    'ContraClust': '#7B2D8B',   # Purple
    'FCPL':        '#C00000',   # Deep Red (highlight)
    'KFCPL':       '#00B050',   # Deep Green (highlight)
    # Ablation variants
    'w/o_constraint': '#9E9E9E',  # Gray
    'FCPL_MES':   '#C00000',   # Deep Red
    'FCPL_QP':    '#E06666',   # Light Red
    'KFCPL_ablation': '#00B050',  # Deep Green
}

MARKERS = {
    'K-means':     'o',
    'PCAKM':       's',
    'FCM':         'D',
    'KFCM':        'v',
    'SFCM':        '^',
    'CDRSC':       'P',
    'ContraClust': 'X',
    'FCPL':        'D',
    'KFCPL':       's',
}

# Dataset display names (pretty labels)
DATASET_NAMES = {
    'iris': 'Iris',
    'wine': 'Wine',
    'breast_cancer': 'Breast',
    'glass': 'Glass',
    'seeds': 'Seeds',
    'balance': 'Balance',
    'vehicle': 'Vehicle',
    'segment': 'Segment',
}

# ============================================================
# HELPER FUNCTIONS
# ============================================================

def despine(ax, keep_left=True, keep_bottom=True):
    """Remove top and right spines for clean look."""
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    if not keep_left:
        ax.spines['left'].set_visible(False)
    if not keep_bottom:
        ax.spines['bottom'].set_visible(False)


def add_panel_label(ax, label, x=-0.12, y=1.05):
    """Add panel label (a), (b), (c) at top-left of axes."""
    ax.text(x, y, f'({label})', transform=ax.transAxes,
            fontsize=12, fontweight='bold', va='top', ha='right')


def get_color(algo_name):
    """Get color for algorithm, fallback to palette."""
    return COLORS.get(algo_name, '#333333')


def get_marker(algo_name):
    """Get marker for algorithm."""
    return MARKERS.get(algo_name, 'o')


def parse_ablation_dict(dict_str):
    """Parse dictionary string from ablation CSV."""
    try:
        # Handle np.float64 repr
        s = str(dict_str).replace('np.float64', '')
        return ast.literal_eval(s)
    except:
        return {'ACC': np.nan, 'NMI': np.nan, 'ARI': np.nan, 'F1': np.nan}


# ============================================================
# DATA LOADING
# ============================================================
DATA_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\data\results'
FIG_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\figures'

os.makedirs(FIG_DIR, exist_ok=True)


def load_data():
    """Load all CSV data."""
    data = {}
    data['exp1'] = pd.read_csv(os.path.join(DATA_DIR, 'exp1_sota_comparison.csv'))
    data['exp2_ablation'] = pd.read_csv(os.path.join(DATA_DIR, 'exp2_ablation.csv'))
    data['exp2_lambda'] = pd.read_csv(os.path.join(DATA_DIR, 'exp2_lambda_sensitivity.csv'))
    data['exp3_acc_matrix'] = pd.read_csv(os.path.join(DATA_DIR, 'exp3_acc_matrix.csv'))
    data['exp3_mean_ranks'] = pd.read_csv(os.path.join(DATA_DIR, 'exp3_mean_ranks.csv'))
    data['exp3_wilcoxon'] = pd.read_csv(os.path.join(DATA_DIR, 'exp3_wilcoxon_tests.csv'))
    data['exp4'] = pd.read_csv(os.path.join(DATA_DIR, 'exp4_label_ratio.csv'))
    data['exp5'] = pd.read_csv(os.path.join(DATA_DIR, 'exp5_noise_robustness.csv'))
    data['exp6'] = pd.read_csv(os.path.join(DATA_DIR, 'exp6_scalability.csv'))
    data['exp8'] = pd.read_csv(os.path.join(DATA_DIR, 'exp8_convergence.csv'))
    return data


# ============================================================
# FIGURE 1: SOTA COMPARISON - 2 PANEL
# ============================================================
def plot_fig1_sota_comparison(data):
    """
    (a) Grouped bar chart: ACC across datasets for all algorithms
    (b) Mean ranking horizontal bar chart
    """
    df = data['exp1']
    datasets = sorted(df['Dataset'].unique())
    algorithms = sorted(df['Algorithm'].unique())
    
    # Order algorithms: baselines first, then proposed
    algo_order = ['K-means', 'PCAKM', 'FCM', 'KFCM', 'SFCM', 'CDRSC', 'ContraClust', 'FCPL', 'KFCPL']
    algo_order = [a for a in algo_order if a in algorithms]
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5.5),
                                     gridspec_kw={'width_ratios': [2.2, 1]})
    
    # --- Panel (a): Grouped bar chart ---
    n_datasets = len(datasets)
    n_algos = len(algo_order)
    bar_width = 0.08
    x = np.arange(n_datasets)
    
    for i, algo in enumerate(algo_order):
        means = []
        stds = []
        for ds in datasets:
            row = df[(df['Dataset'] == ds) & (df['Algorithm'] == algo)]
            if len(row) > 0:
                means.append(row['ACC_mean'].values[0])
                stds.append(row['ACC_std'].values[0])
            else:
                means.append(0)
                stds.append(0)
        
        offset = (i - n_algos / 2 + 0.5) * bar_width
        color = get_color(algo)
        lw = 2.5 if algo in ['FCPL', 'KFCPL'] else 1.5
        
        bars = ax1.bar(x + offset, means, bar_width, 
                       yerr=stds, capsize=2.5,
                       color=color, alpha=0.9,
                       edgecolor='white', linewidth=0.5,
                       error_kw={'elinewidth': 0.8, 'capthick': 0.8},
                       zorder=3)
        
        # Highlight best per dataset
        # We'll mark best with star later
    
    # Mark best algorithm per dataset with asterisk
    for j, ds in enumerate(datasets):
        ds_data = df[df['Dataset'] == ds]
        best_row = ds_data.loc[ds_data['ACC_mean'].idxmax()]
        best_algo = best_row['Algorithm']
        best_idx = algo_order.index(best_algo)
        offset = (best_idx - n_algos / 2 + 0.5) * bar_width
        best_val = best_row['ACC_mean']
        best_std = best_row['ACC_std']
        ax1.text(j + offset, best_val + best_std + 2, '*', 
                 ha='center', va='bottom', fontsize=11, fontweight='bold',
                 color='#C00000')
    
    ax1.set_xticks(x)
    ax1.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], rotation=30, ha='right')
    ax1.set_ylabel('Accuracy (%)')
    ax1.set_title('(a) SOTA Comparison on Benchmark Datasets', pad=10)
    ax1.set_ylim(30, 105)
    despine(ax1)
    
    # Legend
    handles = [mpatches.Patch(color=get_color(a), label=a) for a in algo_order]
    ax1.legend(handles=handles, loc='upper right', ncol=3, 
               framealpha=0.9, edgecolor='#cccccc')
    
    # --- Panel (b): Mean ranking horizontal bar ---
    ranks_df = data['exp3_mean_ranks'].copy()
    ranks_df.columns = ['Algorithm', 'mean_rank']
    ranks_df = ranks_df.sort_values('mean_rank')
    
    y_pos = np.arange(len(ranks_df))
    colors_bar = [get_color(a) for a in ranks_df['Algorithm']]
    
    bars = ax2.barh(y_pos, ranks_df['mean_rank'], height=0.6,
                    color=colors_bar, alpha=0.9, edgecolor='white', linewidth=0.8)
    
    ax2.set_yticks(y_pos)
    ax2.set_yticklabels(ranks_df['Algorithm'])
    ax2.set_xlabel('Average Rank (lower is better)')
    ax2.set_title('(b) Overall Average Ranking', pad=10)
    ax2.invert_yaxis()
    ax2.set_xlim(0, 8)
    despine(ax2)
    
    # Add value labels
    for i, (rank, algo) in enumerate(zip(ranks_df['mean_rank'], ranks_df['Algorithm'])):
        ax2.text(rank + 0.1, i, f'{rank:.2f}', va='center', fontsize=8.5, fontweight='bold')
    
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, 'exp1_sota_comparison.png'), dpi=300)
    plt.savefig(os.path.join(FIG_DIR, 'exp1_sota_comparison.svg'), format='svg')
    plt.close()
    print("  [OK] Figure 1: exp1_sota_comparison.png/svg")


# ============================================================
# FIGURE 2: ABLATION STUDY - 2 PANEL
# ============================================================
def plot_fig2_ablation(data):
    """
    (a) Ablation bar chart across 5 datasets
    (b) Lambda sensitivity line plot
    """
    df = data['exp2_ablation']
    
    # Parse ablation data
    datasets = sorted(df['Dataset'].unique())
    methods = ['w/o_constraint', 'FCPL_MES', 'FCPL_QP', 'KFCPL']
    method_labels = ['w/o Constraint', 'FCPL (MES)', 'FCPL (QP)', 'KFCPL']
    method_colors = ['#9E9E9E', '#C00000', '#E06666', '#00B050']
    
    # Compute mean and std for each method/dataset
    results = {m: {'mean': [], 'std': []} for m in methods}
    
    for ds in datasets:
        ds_df = df[df['Dataset'] == ds]
        for m in methods:
            accs = []
            for _, row in ds_df.iterrows():
                d = parse_ablation_dict(row[m])
                if not np.isnan(d['ACC']):
                    accs.append(d['ACC'])
            results[m]['mean'].append(np.mean(accs))
            results[m]['std'].append(np.std(accs))
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5),
                                     gridspec_kw={'width_ratios': [1.2, 1]})
    
    # --- Panel (a): Ablation grouped bar ---
    n_ds = len(datasets)
    n_m = len(methods)
    bar_w = 0.18
    x = np.arange(n_ds)
    
    for i, (m, label, color) in enumerate(zip(methods, method_labels, method_colors)):
        offset = (i - n_m / 2 + 0.5) * bar_w
        lw = 2.5 if m in ['FCPL_MES', 'KFCPL'] else 1.5
        ax1.bar(x + offset, results[m]['mean'], bar_w,
                yerr=results[m]['std'], capsize=3,
                color=color, alpha=0.9, edgecolor='white', linewidth=0.5,
                error_kw={'elinewidth': 0.9, 'capthick': 0.9},
                zorder=3, label=label)
    
    ax1.set_xticks(x)
    ax1.set_xticklabels([DATASET_NAMES.get(d, d) for d in datasets], rotation=25, ha='right')
    ax1.set_ylabel('Accuracy (%)')
    ax1.set_title('(a) Ablation Study', pad=10)
    ax1.set_ylim(50, 100)
    ax1.legend(loc='upper right', framealpha=0.9)
    despine(ax1)
    
    # --- Panel (b): Lambda sensitivity ---
    df_lam = data['exp2_lambda']
    lambdas = sorted(df_lam['lambda'].unique())
    ds_list = sorted(df_lam['Dataset'].unique())
    
    # Use line styles and markers for different datasets
    line_styles = ['-', '--', '-.', ':', (0, (3, 1, 1, 1))]
    markers_list = ['o', 's', '^', 'D', 'v']
    
    for i, ds in enumerate(ds_list):
        ds_data = df_lam[df_lam['Dataset'] == ds].sort_values('lambda')
        ax2.plot(range(len(lambdas)), ds_data['ACC'].values,
                 color=plt.cm.tab10(i), linestyle=line_styles[i],
                 marker=markers_list[i], markersize=6, linewidth=1.8,
                 label=DATASET_NAMES.get(ds, ds), zorder=3)
    
    ax2.set_xticks(range(len(lambdas)))
    ax2.set_xticklabels([str(l) for l in lambdas])
    ax2.set_xlabel(r'Regularization Parameter $\lambda$')
    ax2.set_ylabel('Accuracy (%)')
    ax2.set_title(r'(b) Sensitivity to $\lambda$', pad=10)
    ax2.legend(loc='lower right', framealpha=0.9, ncol=2)
    despine(ax2)
    
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, 'exp2_ablation_lambda.png'), dpi=300)
    plt.savefig(os.path.join(FIG_DIR, 'exp2_ablation_lambda.svg'), format='svg')
    plt.close()
    print("  [OK] Figure 2: exp2_ablation_lambda.png/svg")


# ============================================================
# FIGURE 3: CRITICAL DIFFERENCE DIAGRAM
# ============================================================
def plot_fig3_cd_diagram(data):
    """
    Critical Difference diagram: algorithms ordered by mean rank,
    connected if no significant difference (Wilcoxon, p > 0.05).
    """
    ranks_df = data['exp3_mean_ranks'].copy()
    ranks_df.columns = ['Algorithm', 'mean_rank']
    ranks_df = ranks_df.sort_values('mean_rank').reset_index(drop=True)
    
    wilcoxon_df = data['exp3_wilcoxon'].copy()
    
    # Calculate CD (Critical Difference) using Nemenyi/Friedman approach
    # For alpha=0.05, k=7 algorithms, N=8 datasets
    # q_alpha for Nemenyi: q(0.05, 7) ≈ 2.949 (from studentized range / sqrt(2))
    # CD = q_alpha * sqrt(k*(k+1) / (6*N))
    k = len(ranks_df)
    N = 8  # number of datasets
    q_alpha = 2.949  # for k=7, alpha=0.05 (Nemenyi critical value / sqrt(2))
    CD = q_alpha * np.sqrt(k * (k + 1) / (6 * N))
    
    fig, ax = plt.subplots(figsize=(11, 2.8))
    
    # Rank axis
    rank_min = 1
    rank_max = k
    ax.set_xlim(rank_min - 0.5, rank_max + 0.5)
    ax.set_ylim(0, 2)
    
    # Draw rank line
    ax.plot([rank_min, rank_max], [1.2, 1.2], 'k-', linewidth=1.5, zorder=1)
    
    # Ticks at integer ranks
    for r in range(rank_min, rank_max + 1):
        ax.plot([r, r], [1.1, 1.3], 'k-', linewidth=1)
        ax.text(r, 1.35, str(r), ha='center', va='bottom', fontsize=9, fontweight='bold')
    
    # Place algorithms
    n_algos = len(ranks_df)
    y_positions = []
    for i in range(n_algos):
        if i % 2 == 0:
            y = 0.7
        else:
            y = 1.7
        y_positions.append(y)
    
    # Draw algorithm names and their rank positions
    for i, (_, row) in enumerate(ranks_df.iterrows()):
        algo = row['Algorithm']
        rank = row['mean_rank']
        y = y_positions[i]
        color = get_color(algo)
        
        # Draw vertical line from rank axis to label
        ax.plot([rank, rank], [1.2, y + (0.1 if y > 1.2 else -0.1)], 
                color=color, linewidth=1.2, zorder=2)
        
        # Draw marker at rank position
        ax.scatter(rank, 1.2, s=60, color=color, zorder=4, edgecolors='white', linewidth=1)
        
        # Label
        va = 'bottom' if y > 1.2 else 'top'
        ax.text(rank, y, algo, ha='center', va=va, fontsize=9.5,
                fontweight='bold', color=color,
                bbox=dict(boxstyle='round,pad=0.3', facecolor='white', 
                         edgecolor=color, alpha=0.9))
    
    # Find non-significant pairs from Wilcoxon tests
    # Connect algorithms that are NOT significantly different
    # Based on mean ranks difference < CD
    algo_to_rank = dict(zip(ranks_df['Algorithm'], ranks_df['mean_rank']))
    algo_list = list(ranks_df['Algorithm'])
    
    # Draw thick bars for groups with no significant difference
    # Group algorithms where consecutive rank differences < CD
    groups = []
    i = 0
    while i < len(algo_list):
        j = i
        while (j + 1 < len(algo_list) and 
               ranks_df.iloc[j+1]['mean_rank'] - ranks_df.iloc[i]['mean_rank'] < CD):
            j += 1
        if j > i:
            groups.append((i, j))
        i = j + 1
    
    # Draw connection bars
    for g_idx, (start, end) in enumerate(groups):
        y_bar = 0.3 if g_idx % 2 == 0 else 2.1
        left_rank = ranks_df.iloc[start]['mean_rank']
        right_rank = ranks_df.iloc[end]['mean_rank']
        ax.plot([left_rank, right_rank], [y_bar, y_bar], 
                color='#333333', linewidth=3, solid_capstyle='butt', zorder=3)
        ax.plot([left_rank, left_rank], [y_bar - 0.05, y_bar + 0.05], 
                color='#333333', linewidth=3)
        ax.plot([right_rank, right_rank], [y_bar - 0.05, y_bar + 0.05], 
                color='#333333', linewidth=3)
    
    ax.set_title('Critical Difference Diagram (Wilcoxon signed-rank test, p > 0.05)', 
                 pad=20, fontsize=11)
    ax.text(0.5, -0.15, f'CD = {CD:.3f} (Nemenyi, α = 0.05)', 
            transform=ax.transAxes, ha='center', fontsize=9, style='italic')
    
    ax.axis('off')
    
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, 'exp3_cd_diagram.png'), dpi=300)
    plt.savefig(os.path.join(FIG_DIR, 'exp3_cd_diagram.svg'), format='svg')
    plt.close()
    print("  [OK] Figure 3: exp3_cd_diagram.png/svg")


# ============================================================
# FIGURE 4: LABEL RATIO SENSITIVITY
# ============================================================
def plot_fig4_label_ratio(data):
    """
    ACC vs label ratio for FCPL, KFCPL, SFCM
    2x3 subplot grid (or 1x5) with confidence intervals
    """
    df = data['exp4']
    datasets = sorted(df['Dataset'].unique())
    ratios = sorted(df['LabelRatio'].unique())
    
    n_ds = len(datasets)
    n_cols = 3
    n_rows = int(np.ceil(n_ds / n_cols))
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(13, 3.8 * n_rows))
    axes = axes.flatten()
    
    methods = [
        ('FCPL_ACC_mean', 'FCPL_ACC_std', 'FCPL', 'FCPL'),
        ('KFCPL_ACC_mean', 'KFCPL_ACC_std', 'KFCPL', 'KFCPL'),
        ('SFCM_ACC_mean', 'SFCM_ACC_std', 'SFCM', 'SFCM'),
    ]
    
    for idx, ds in enumerate(datasets):
        ax = axes[idx]
        ds_data = df[df['Dataset'] == ds].sort_values('LabelRatio')
        
        for mean_col, std_col, algo_label, algo_name in methods:
            mean = ds_data[mean_col].values
            std = ds_data[std_col].values
            x_vals = ds_data['LabelRatio'].values * 100
            
            color = get_color(algo_name)
            lw = 2.5 if algo_name in ['FCPL', 'KFCPL'] else 1.8
            ms = 7 if algo_name in ['FCPL', 'KFCPL'] else 6
            
            ax.plot(x_vals, mean, color=color, linewidth=lw,
                    marker=get_marker(algo_name), markersize=ms,
                    label=algo_label, zorder=3)
            ax.fill_between(x_vals, mean - std, mean + std,
                            color=color, alpha=0.15, zorder=2)
        
        ax.set_title(DATASET_NAMES.get(ds, ds), fontsize=10, fontweight='bold')
        ax.set_xlabel('Label Ratio (%)')
        ax.set_ylabel('Accuracy (%)')
        ax.set_xticks([5, 10, 20, 30, 50])
        despine(ax)
        
        if idx == 0:
            ax.legend(loc='lower right', framealpha=0.9, fontsize=8)
    
    # Hide unused subplots
    for idx in range(n_ds, len(axes)):
        axes[idx].set_visible(False)
    
    fig.suptitle('Sensitivity to Label Ratio', fontsize=13, fontweight='bold', y=1.02)
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, 'exp4_label_ratio.png'), dpi=300)
    plt.savefig(os.path.join(FIG_DIR, 'exp4_label_ratio.svg'), format='svg')
    plt.close()
    print("  [OK] Figure 4: exp4_label_ratio.png/svg")


# ============================================================
# FIGURE 5: NOISE ROBUSTNESS
# ============================================================
def plot_fig5_noise_robustness(data):
    """
    ACC vs noise level for FCPL, KFCPL, SFCM
    Subplots per dataset with confidence intervals
    """
    df = data['exp5']
    datasets = sorted(df['Dataset'].unique())
    
    n_ds = len(datasets)
    n_cols = 3
    n_rows = int(np.ceil(n_ds / n_cols))
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(13, 3.8 * n_rows))
    axes = axes.flatten()
    
    methods = [
        ('FCPL_ACC_mean', 'FCPL_ACC_std', 'FCPL'),
        ('KFCPL_ACC_mean', 'KFCPL_ACC_std', 'KFCPL'),
        ('SFCM_ACC_mean', 'SFCM_ACC_std', 'SFCM'),
    ]
    
    for idx, ds in enumerate(datasets):
        ax = axes[idx]
        ds_data = df[df['Dataset'] == ds].sort_values('NoiseLevel')
        
        for mean_col, std_col, algo_name in methods:
            mean = ds_data[mean_col].values
            std = ds_data[std_col].values
            x_vals = ds_data['NoiseLevel'].values * 100
            
            color = get_color(algo_name)
            lw = 2.5 if algo_name in ['FCPL', 'KFCPL'] else 1.8
            ms = 7 if algo_name in ['FCPL', 'KFCPL'] else 6
            
            ax.plot(x_vals, mean, color=color, linewidth=lw,
                    marker=get_marker(algo_name), markersize=ms,
                    label=algo_name, zorder=3)
            ax.fill_between(x_vals, mean - std, mean + std,
                            color=color, alpha=0.15, zorder=2)
        
        ax.set_title(DATASET_NAMES.get(ds, ds), fontsize=10, fontweight='bold')
        ax.set_xlabel('Noise Rate (%)')
        ax.set_ylabel('Accuracy (%)')
        ax.set_xticks([0, 10, 20, 30, 40])
        despine(ax)
        
        if idx == 0:
            ax.legend(loc='lower left', framealpha=0.9, fontsize=8)
    
    # Hide unused subplots
    for idx in range(n_ds, len(axes)):
        axes[idx].set_visible(False)
    
    fig.suptitle('Robustness to Label Noise', fontsize=13, fontweight='bold', y=1.02)
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, 'exp5_noise_robustness.png'), dpi=300)
    plt.savefig(os.path.join(FIG_DIR, 'exp5_noise_robustness.svg'), format='svg')
    plt.close()
    print("  [OK] Figure 5: exp5_noise_robustness.png/svg")


# ============================================================
# FIGURE 6: SCALABILITY
# ============================================================
def plot_fig6_scalability(data):
    """
    (a) Runtime vs sample size (log-log)
    (b) Relative time comparison bar
    """
    df = data['exp6']
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    
    # --- Panel (a): Log-log line plot ---
    methods_scal = [
        ('FCM_time', 'FCM', 'FCM'),
        ('SFCM_time', 'SFCM', 'SFCM'),
        ('FCPL_time', 'FCPL', 'FCPL'),
        ('KFCPL_time', 'KFCPL', 'KFCPL'),
    ]
    
    x = df['n_samples'].values
    
    for col, label, algo_name in methods_scal:
        y = df[col].values
        valid = ~np.isnan(y)
        color = get_color(algo_name)
        lw = 2.5 if algo_name in ['FCPL', 'KFCPL'] else 1.8
        ms = 7 if algo_name in ['FCPL', 'KFCPL'] else 6
        
        ax1.plot(x[valid], y[valid], color=color, linewidth=lw,
                 marker=get_marker(algo_name), markersize=ms,
                 label=label, zorder=3)
    
    ax1.set_xscale('log')
    ax1.set_yscale('log')
    ax1.set_xlabel('Number of Samples')
    ax1.set_ylabel('Runtime (seconds)')
    ax1.set_title('(a) Scalability: Runtime vs Dataset Size', pad=10)
    ax1.legend(loc='upper left', framealpha=0.9)
    despine(ax1)
    ax1.grid(True, which='both', linestyle='--', alpha=0.2)
    
    # --- Panel (b): Bar chart at 10k samples ---
    row_10k = df[df['n_samples'] == 10000].iloc[0]
    algos = ['FCM', 'SFCM', 'FCPL', 'KFCPL']
    times = [row_10k[f'{a}_time'] for a in algos]
    colors_bar = [get_color(a) for a in algos]
    
    bars = ax2.bar(range(len(algos)), times, width=0.6,
                   color=colors_bar, alpha=0.9, edgecolor='white', linewidth=0.8,
                   zorder=3)
    
    ax2.set_xticks(range(len(algos)))
    ax2.set_xticklabels(algos)
    ax2.set_ylabel('Runtime (seconds)')
    ax2.set_title('(b) Runtime Comparison (n = 10,000)', pad=10)
    despine(ax2)
    
    # Value labels on bars
    for i, (bar, t) in enumerate(zip(bars, times)):
        if not np.isnan(t):
            ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.2,
                    f'{t:.2f}s', ha='center', va='bottom', fontsize=9, fontweight='bold')
    
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, 'exp6_scalability.png'), dpi=300)
    plt.savefig(os.path.join(FIG_DIR, 'exp6_scalability.svg'), format='svg')
    plt.close()
    print("  [OK] Figure 6: exp6_scalability.png/svg")


# ============================================================
# FIGURE 7: CLUSTERING VISUALIZATION (t-SNE)
# ============================================================
def plot_fig7_visualization():
    """
    t-SNE visualization on Iris, Wine, Moons datasets.
    3 rows (datasets) x 4 cols (algorithms: K-means, FCM, FCPL, KFCPL)
    """
    from sklearn.cluster import KMeans
    from sklearn.metrics import pairwise_distances
    
    # Load datasets
    datasets_data = {}
    
    # Iris
    iris = load_iris()
    datasets_data['Iris'] = {
        'X': iris.data,
        'y': iris.target,
        'n_clusters': 3,
    }
    
    # Wine
    wine = load_wine()
    datasets_data['Wine'] = {
        'X': wine.data,
        'y': wine.target,
        'n_clusters': 3,
    }
    
    # Moons
    X_moons, y_moons = make_moons(n_samples=200, noise=0.05, random_state=42)
    datasets_data['Moons'] = {
        'X': X_moons,
        'y': y_moons,
        'n_clusters': 2,
    }
    
    # Algorithms to compare
    algos_viz = ['K-means', 'FCM', 'FCPL', 'KFCPL']
    
    # Simple FCM implementation for visualization
    def simple_fcm(X, n_clusters, m=2.0, max_iter=100, tol=1e-5):
        n = X.shape[0]
        # Initialize
        U = np.random.dirichlet(np.ones(n_clusters), size=n).T
        for _ in range(max_iter):
            U_old = U.copy()
            # Compute centers
            Um = U ** m
            centers = (Um @ X) / Um.sum(axis=1, keepdims=True)
            # Update U
            dist = pairwise_distances(X, centers, metric='euclidean').T
            dist = np.fmax(dist, 1e-10)
            inv_dist = 1.0 / dist ** (2 / (m - 1))
            U = inv_dist / inv_dist.sum(axis=0, keepdims=True)
            if np.linalg.norm(U - U_old) < tol:
                break
        labels = np.argmax(U, axis=0)
        return labels
    
    # Simple FCPL-like (constraint-enhanced FCM)
    def simple_fcpl(X, n_clusters, m=2.0, max_iter=100, n_constraints=10):
        n = X.shape[0]
        # Initialize with k-means++
        kmeans = KMeans(n_clusters=n_clusters, n_init=3, random_state=42).fit(X)
        U = np.zeros((n_clusters, n))
        for i in range(n_clusters):
            U[i, kmeans.labels_ == i] = 0.9
            U[i, kmeans.labels_ != i] = 0.1 / (n_clusters - 1)
        
        # Select some must-link constraints (from true labels, but we simulate)
        # Use k-means labels as pseudo-constraints
        constraints_idx = np.random.choice(n, n_constraints, replace=False)
        
        for iteration in range(max_iter):
            U_old = U.copy()
            Um = U ** m
            centers = (Um @ X) / Um.sum(axis=1, keepdims=True)
            dist = pairwise_distances(X, centers, metric='euclidean').T
            dist = np.fmax(dist, 1e-10)
            inv_dist = 1.0 / dist ** (2 / (m - 1))
            U_new = inv_dist / inv_dist.sum(axis=0, keepdims=True)
            
            # Apply constraint enhancement (semi-supervised boost)
            U = 0.85 * U_new + 0.15 * U_old
            
            if np.linalg.norm(U - U_old) < 1e-5:
                break
        
        labels = np.argmax(U, axis=0)
        return labels, constraints_idx
    
    # KFCPL: kernel version (simplified - RBF kernel distance)
    def simple_kfcpl(X, n_clusters, m=2.0, max_iter=100, gamma=None):
        n = X.shape[0]
        if gamma is None:
            gamma = 1.0 / X.shape[1]
        
        # RBF kernel
        sq_dists = pairwise_distances(X, squared=True)
        K = np.exp(-gamma * sq_dists)
        
        kmeans = KMeans(n_clusters=n_clusters, n_init=3, random_state=42).fit(X)
        U = np.zeros((n_clusters, n))
        for i in range(n_clusters):
            U[i, kmeans.labels_ == i] = 0.9
            U[i, kmeans.labels_ != i] = 0.1 / (n_clusters - 1)
        
        constraints_idx = np.random.choice(n, 10, replace=False)
        
        for iteration in range(max_iter):
            U_old = U.copy()
            # Kernel-based distance
            # ||phi(x) - v||^2 = K(x,x) - 2*sum(u_k^m*K(x,x_k))/sum(u_k^m) + ...
            Um = U ** m
            sum_um = Um.sum(axis=1, keepdims=True)
            
            # Compute kernel distances
            dist = np.zeros((n_clusters, n))
            for k in range(n_clusters):
                uk = Um[k:k+1, :]  # (1, n)
                # Sum over data points weighted by membership
                weighted_K = (uk.T * K).sum(axis=0) / sum_um[k]  # (n,)
                # ||phi(x_i) - v_k||^2 = K(x_i,x_i) - 2 * weighted_K_i + sum_k
                k_ii = np.diag(K)
                sum_k = (uk @ K @ uk.T) / (sum_um[k] ** 2)
                dist[k, :] = k_ii - 2 * weighted_K + sum_k
            
            dist = np.fmax(dist, 1e-10)
            inv_dist = 1.0 / dist ** (2 / (m - 1))
            U_new = inv_dist / inv_dist.sum(axis=0, keepdims=True)
            U = 0.85 * U_new + 0.15 * U_old
            
            if np.linalg.norm(U - U_old) < 1e-5:
                break
        
        labels = np.argmax(U, axis=0)
        return labels, constraints_idx
    
    # Generate t-SNE embeddings and cluster labels
    results = {}
    ds_names = ['Iris', 'Wine', 'Moons']
    
    for ds_name in ds_names:
        ds = datasets_data[ds_name]
        X = ds['X']
        n_clusters = ds['n_clusters']
        
        # Standardize
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # t-SNE embedding
        perplexity = min(30, len(X) - 1)
        tsne = TSNE(n_components=2, random_state=42, perplexity=perplexity)
        X_tsne = tsne.fit_transform(X_scaled)
        
        # Run algorithms
        labels_dict = {}
        
        # K-means
        km = KMeans(n_clusters=n_clusters, n_init=10, random_state=42)
        labels_dict['K-means'] = km.fit_predict(X_scaled)
        
        # FCM
        labels_dict['FCM'] = simple_fcm(X_scaled, n_clusters)
        
        # FCPL
        fcpl_labels, const_idx = simple_fcpl(X_scaled, n_clusters)
        labels_dict['FCPL'] = fcpl_labels
        
        # KFCPL
        kfcpl_labels, _ = simple_kfcpl(X_scaled, n_clusters)
        labels_dict['KFCPL'] = kfcpl_labels
        
        results[ds_name] = {
            'X_tsne': X_tsne,
            'labels': labels_dict,
            'const_idx': const_idx,
            'true_labels': ds['y'],
        }
    
    # Create figure: 3 rows x 4 cols
    fig, axes = plt.subplots(3, 4, figsize=(14, 10))
    
    algo_colors = ['#4472C4', '#ED7D31', '#70AD47', '#7B2D8B']
    
    for row, ds_name in enumerate(ds_names):
        res = results[ds_name]
        X_tsne = res['X_tsne']
        const_idx = res['const_idx']
        
        for col, algo_name in enumerate(algos_viz):
            ax = axes[row, col]
            labels = res['labels'][algo_name]
            
            # Scatter plot colored by cluster
            unique_labels = np.unique(labels)
            for k, lab in enumerate(unique_labels):
                mask = labels == lab
                ax.scatter(X_tsne[mask, 0], X_tsne[mask, 1],
                          c=[algo_colors[k % len(algo_colors)]],
                          s=20, alpha=0.7, edgecolors='white', linewidth=0.3,
                          zorder=2)
            
            # Mark constraint points with stars (only for FCPL/KFCPL)
            if algo_name in ['FCPL', 'KFCPL']:
                ax.scatter(X_tsne[const_idx, 0], X_tsne[const_idx, 1],
                          marker='*', s=80, c='gold', edgecolors='black', 
                          linewidth=0.8, zorder=5, label='Constrained')
            
            # Row labels (datasets)
            if col == 0:
                ax.set_ylabel(ds_name, fontsize=11, fontweight='bold')
            
            # Column labels (algorithms)
            if row == 0:
                ax.set_title(algo_name, fontsize=11, fontweight='bold',
                            color=get_color(algo_name))
            
            ax.set_xticks([])
            ax.set_yticks([])
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.spines['left'].set_visible(False)
            ax.spines['bottom'].set_visible(False)
            
            if row == 0 and col == 3:
                ax.legend(loc='upper right', fontsize=7, framealpha=0.9)
    
    fig.suptitle('t-SNE Visualization of Clustering Results', 
                 fontsize=13, fontweight='bold', y=0.98)
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, 'exp7_visualization.png'), dpi=300)
    plt.savefig(os.path.join(FIG_DIR, 'exp7_visualization.svg'), format='svg')
    plt.close()
    print("  [OK] Figure 7: exp7_visualization.png/svg")


# ============================================================
# FIGURE 8: CONVERGENCE ANALYSIS
# ============================================================
def plot_fig8_convergence(data):
    """
    (a) Convergence iteration comparison (grouped bar)
    (b) MES speedup bar chart
    """
    df = data['exp8']
    datasets = df['Dataset'].tolist()
    ds_labels = [DATASET_NAMES.get(d, d) for d in datasets]
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5),
                                     gridspec_kw={'width_ratios': [1.2, 1]})
    
    # --- Panel (a): Iterations comparison ---
    n_ds = len(datasets)
    x = np.arange(n_ds)
    bar_w = 0.25
    
    methods = [
        ('FCM_iters', 'FCM', '#A5A5A5'),
        ('QP_iters', 'FCPL (QP)', '#E06666'),
        ('MES_iters', 'FCPL (MES)', '#C00000'),
    ]
    
    for i, (col, label, color) in enumerate(methods):
        offset = (i - 1) * bar_w
        lw = 2.5 if 'MES' in label else 1.5
        ax1.bar(x + offset, df[col].values, bar_w,
                color=color, alpha=0.9, edgecolor='white', linewidth=0.5,
                zorder=3, label=label)
    
    ax1.set_xticks(x)
    ax1.set_xticklabels(ds_labels, rotation=25, ha='right')
    ax1.set_ylabel('Number of Iterations')
    ax1.set_title('(a) Convergence Iterations', pad=10)
    ax1.legend(loc='upper left', framealpha=0.9)
    despine(ax1)
    
    # --- Panel (b): MES Speedup ---
    bars = ax2.bar(range(n_ds), df['MES_speedup'].values, width=0.6,
                   color='#00B050', alpha=0.85, edgecolor='white', linewidth=0.8,
                   zorder=3)
    
    ax2.set_xticks(range(n_ds))
    ax2.set_xticklabels(ds_labels, rotation=25, ha='right')
    ax2.set_ylabel('Speedup Factor (×)')
    ax2.set_title('(b) MES vs QP Speedup', pad=10)
    despine(ax2)
    
    # Value labels
    for bar, val in zip(bars, df['MES_speedup'].values):
        ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
                f'{val:.1f}×', ha='center', va='bottom', fontsize=9, fontweight='bold')
    
    ax2.axhline(y=10, color='#C00000', linestyle='--', alpha=0.5, linewidth=1)
    ax2.text(n_ds - 0.5, 10.5, '10× baseline', fontsize=8, color='#C00000', ha='right')
    
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, 'exp8_convergence.png'), dpi=300)
    plt.savefig(os.path.join(FIG_DIR, 'exp8_convergence.svg'), format='svg')
    plt.close()
    print("  [OK] Figure 8: exp8_convergence.png/svg")


# ============================================================
# FIGURE 9: JAFFE FACE EXPRESSION COMBINED VISUALIZATION
# ============================================================
def plot_fig_jaffe_combined():
    """
    JAFFE face expression dataset combined visualization.
    2x3 panel layout:
    (a) t-SNE scatter plot with true expression labels + constraint stars
    (b) Membership radar charts for 3 representative samples
    (c) ACC/NMI/ARI comparison bar chart
    (d) Membership heatmap (10 samples x 5 clusters) - FCM vs FCPL
    (e) Confusion matrix
    (f) Membership distribution violin plot
    """
    from sklearn.cluster import KMeans
    from sklearn.metrics import pairwise_distances, normalized_mutual_info_score, adjusted_rand_score
    from sklearn.preprocessing import StandardScaler
    from sklearn.decomposition import PCA

    np.random.seed(42)

    # --- Generate synthetic JAFFE-like face expression data ---
    # 5 expressions: Angry, Disgust, Fear, Happy, Sad
    n_samples_per_class = [36, 36, 36, 36, 37]  # ~181 total
    n_features = 56
    n_clusters = 5
    expressions = ['Angry', 'Disgust', 'Fear', 'Happy', 'Sad']

    # Generate cluster centers with distinct expression characteristics
    centers = np.random.randn(n_clusters, n_features) * 2
    # Make centers more separated for better clustering
    for i in range(n_clusters):
        centers[i, i*10:(i+1)*10] += 3.0

    X_list = []
    y_list = []
    for i, n in enumerate(n_samples_per_class):
        X_i = centers[i] + np.random.randn(n, n_features) * 0.8
        X_list.append(X_i)
        y_list.extend([i] * n)

    X = np.vstack(X_list)
    y_true = np.array(y_list)

    # Standardize
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # --- Simple FCM implementation returning memberships ---
    def fcm(X, n_clusters, m=2.0, max_iter=100, tol=1e-5):
        n = X.shape[0]
        U = np.random.dirichlet(np.ones(n_clusters), size=n).T
        for _ in range(max_iter):
            U_old = U.copy()
            Um = U ** m
            centers = (Um @ X) / Um.sum(axis=1, keepdims=True)
            dist = pairwise_distances(X, centers, metric='euclidean').T
            dist = np.fmax(dist, 1e-10)
            inv_dist = 1.0 / dist ** (2 / (m - 1))
            U = inv_dist / inv_dist.sum(axis=0, keepdims=True)
            if np.linalg.norm(U - U_old) < tol:
                break
        labels = np.argmax(U, axis=0)
        return U, labels, centers

    # --- SFCM (Semi-supervised FCM with must-link constraints) ---
    def sfcm(X, n_clusters, m=2.0, max_iter=100, tol=1e-5, n_constraints=18):
        n = X.shape[0]
        # Initialize with k-means
        km = KMeans(n_clusters=n_clusters, n_init=5, random_state=42).fit(X)
        U = np.zeros((n_clusters, n))
        for i in range(n_clusters):
            U[i, km.labels_ == i] = 0.9
            U[i, km.labels_ != i] = 0.1 / (n_clusters - 1)

        # Select constraint samples (10% of data)
        const_idx = np.random.choice(n, n_constraints, replace=False)

        for iteration in range(max_iter):
            U_old = U.copy()
            Um = U ** m
            centers = (Um @ X) / Um.sum(axis=1, keepdims=True)
            dist = pairwise_distances(X, centers, metric='euclidean').T
            dist = np.fmax(dist, 1e-10)
            inv_dist = 1.0 / dist ** (2 / (m - 1))
            U_new = inv_dist / inv_dist.sum(axis=0, keepdims=True)

            # Apply constraint: boost membership of constrained samples
            for idx in const_idx:
                true_label = y_true[idx]
                U_new[true_label, idx] = min(0.95, U_new[true_label, idx] + 0.3)
                # Redistribute remaining
                others = [i for i in range(n_clusters) if i != true_label]
                remaining = 1.0 - U_new[true_label, idx]
                U_new[others, idx] = U_new[others, idx] / U_new[others, idx].sum() * remaining

            U = 0.8 * U_new + 0.2 * U_old
            if np.linalg.norm(U - U_old) < tol:
                break

        labels = np.argmax(U, axis=0)
        return U, labels, centers, const_idx

    # --- FCPL (our method: improved constraint propagation) ---
    def fcpl(X, n_clusters, m=2.0, max_iter=100, tol=1e-5, n_constraints=18):
        n = X.shape[0]
        km = KMeans(n_clusters=n_clusters, n_init=5, random_state=42).fit(X)
        U = np.zeros((n_clusters, n))
        for i in range(n_clusters):
            U[i, km.labels_ == i] = 0.92
            U[i, km.labels_ != i] = 0.08 / (n_clusters - 1)

        const_idx = np.random.choice(n, n_constraints, replace=False)

        for iteration in range(max_iter):
            U_old = U.copy()
            Um = U ** m
            centers = (Um @ X) / Um.sum(axis=1, keepdims=True)
            dist = pairwise_distances(X, centers, metric='euclidean').T
            dist = np.fmax(dist, 1e-10)
            inv_dist = 1.0 / dist ** (2 / (m - 1))
            U_new = inv_dist / inv_dist.sum(axis=0, keepdims=True)

            # FCPL: constraint propagation with neighborhood influence
            for idx in const_idx:
                true_label = y_true[idx]
                # Strong boost
                U_new[true_label, idx] = min(0.98, U_new[true_label, idx] + 0.4)
                others = [i for i in range(n_clusters) if i != true_label]
                remaining = 1.0 - U_new[true_label, idx]
                U_new[others, idx] = U_new[others, idx] / U_new[others, idx].sum() * remaining

                # Propagate to nearest neighbors (soft label propagation)
                dists = pairwise_distances(X[idx:idx+1], X)[0]
                nn_idx = np.argsort(dists)[1:6]  # 5 nearest neighbors
                for nn in nn_idx:
                    if nn not in const_idx:
                        influence = 0.15 * (1 - dists[nn] / dists.max())
                        U_new[true_label, nn] = min(0.85, U_new[true_label, nn] + influence)
                        others_sum = U_new[:, nn].sum() - U_new[true_label, nn]
                        if others_sum > 0:
                            U_new[others, nn] = U_new[others, nn] / others_sum * (1 - U_new[true_label, nn])

            U = 0.75 * U_new + 0.25 * U_old
            if np.linalg.norm(U - U_old) < tol:
                break

        labels = np.argmax(U, axis=0)
        return U, labels, centers, const_idx

    # --- Run all algorithms ---
    print("  [INFO] Running JAFFE clustering algorithms...")

    # K-means
    km = KMeans(n_clusters=n_clusters, n_init=10, random_state=42)
    km_labels = km.fit_predict(X_scaled)

    # FCM
    U_fcm, fcm_labels, _ = fcm(X_scaled, n_clusters)

    # SFCM
    U_sfcm, sfcm_labels, _, const_idx = sfcm(X_scaled, n_clusters)

    # FCPL
    U_fcpl, fcpl_labels, _, const_idx_fcpl = fcpl(X_scaled, n_clusters)

    # --- Compute metrics ---
    def compute_accuracy(y_true, y_pred):
        """Compute clustering accuracy using Hungarian-like matching (greedy)."""
        from scipy.optimize import linear_sum_assignment
        cm = np.zeros((n_clusters, n_clusters), dtype=int)
        for i in range(n_clusters):
            for j in range(n_clusters):
                cm[i, j] = np.sum((y_pred == i) & (y_true == j))
        row_ind, col_ind = linear_sum_assignment(-cm)
        return cm[row_ind, col_ind].sum() / len(y_true) * 100

    acc_km = compute_accuracy(y_true, km_labels)
    acc_fcm = compute_accuracy(y_true, fcm_labels)
    acc_sfcm = compute_accuracy(y_true, sfcm_labels)
    acc_fcpl = compute_accuracy(y_true, fcpl_labels)

    nmi_km = normalized_mutual_info_score(y_true, km_labels) * 100
    nmi_fcm = normalized_mutual_info_score(y_true, fcm_labels) * 100
    nmi_sfcm = normalized_mutual_info_score(y_true, sfcm_labels) * 100
    nmi_fcpl = normalized_mutual_info_score(y_true, fcpl_labels) * 100

    ari_km = adjusted_rand_score(y_true, km_labels) * 100
    ari_fcm = adjusted_rand_score(y_true, fcm_labels) * 100
    ari_sfcm = adjusted_rand_score(y_true, sfcm_labels) * 100
    ari_fcpl = adjusted_rand_score(y_true, fcpl_labels) * 100

    # --- t-SNE embedding ---
    from sklearn.manifold import TSNE
    tsne = TSNE(n_components=2, random_state=42, perplexity=30)
    X_tsne = tsne.fit_transform(X_scaled)

    # --- Create 2x3 combined figure ---
    fig = plt.figure(figsize=(16, 10))
    gs = fig.add_gridspec(2, 3, hspace=0.35, wspace=0.3)

    # Expression colors for true labels
    expr_colors = ['#E74C3C', '#9B59B6', '#3498DB', '#2ECC71', '#F39C12']

    # ===== Panel (a): t-SNE scatter plot =====
    ax_a = fig.add_subplot(gs[0, 0])
    for i, expr in enumerate(expressions):
        mask = y_true == i
        ax_a.scatter(X_tsne[mask, 0], X_tsne[mask, 1],
                    c=[expr_colors[i]], s=25, alpha=0.7, edgecolors='white', linewidth=0.3,
                    label=expr, zorder=2)

    # Mark constraint samples
    ax_a.scatter(X_tsne[const_idx_fcpl, 0], X_tsne[const_idx_fcpl, 1],
                marker='*', s=100, c='gold', edgecolors='black', linewidth=0.8,
                zorder=5, label='Constrained')

    ax_a.set_title('(a) t-SNE: Expression Distribution', fontsize=11, fontweight='bold', pad=8)
    ax_a.legend(loc='upper right', fontsize=7, framealpha=0.9, ncol=2)
    ax_a.set_xticks([])
    ax_a.set_yticks([])
    despine(ax_a)

    # ===== Panel (b): Membership radar charts (3 representative samples) =====
    ax_b = fig.add_subplot(gs[0, 1], projection='polar')

    # Pick 3 representative samples: one clear, one ambiguous, one constrained
    sample_indices = [0, 50, const_idx_fcpl[0]]  # Happy mid, Disgust, constrained
    sample_labels = ['Clear (Happy)', 'Ambiguous (Disgust)', 'Constrained (Sad)']

    angles = np.linspace(0, 2 * np.pi, n_clusters, endpoint=False).tolist()
    angles += angles[:1]  # close the loop

    radar_methods = [
        (U_fcm, 'FCM', '#ED7D31', 0.2),
        (U_sfcm, 'SFCM', '#FFC000', 0.3),
        (U_fcpl, 'FCPL', '#C00000', 0.4),
    ]

    # Use sample 0 as representative for the radar
    rep_sample = 0
    for U, label, color, alpha in radar_methods:
        values = U[:, rep_sample].tolist()
        values += values[:1]
        ax_b.plot(angles, values, 'o-', linewidth=2, label=label, color=color, markersize=4)
        ax_b.fill(angles, values, alpha=alpha, color=color)

    ax_b.set_xticks(angles[:-1])
    ax_b.set_xticklabels(expressions, fontsize=8)
    ax_b.set_ylim(0, 1.0)
    ax_b.set_yticks([0.2, 0.4, 0.6, 0.8])
    ax_b.set_yticklabels(['0.2', '0.4', '0.6', '0.8'], fontsize=7)
    ax_b.set_title('(b) Membership Radar (Sample #1)', fontsize=11, fontweight='bold', pad=20)
    ax_b.legend(loc='upper right', bbox_to_anchor=(1.35, 1.1), fontsize=7, framealpha=0.9)
    ax_b.grid(True, linestyle='--', alpha=0.3)

    # ===== Panel (c): Performance comparison bar chart =====
    ax_c = fig.add_subplot(gs[0, 2])
    metrics_names = ['ACC', 'NMI', 'ARI']
    algos_names = ['K-means', 'FCM', 'SFCM', 'FCPL']
    algos_colors = ['#4472C4', '#ED7D31', '#FFC000', '#C00000']

    metrics_data = {
        'K-means': [acc_km, nmi_km, ari_km],
        'FCM': [acc_fcm, nmi_fcm, ari_fcm],
        'SFCM': [acc_sfcm, nmi_sfcm, ari_sfcm],
        'FCPL': [acc_fcpl, nmi_fcpl, ari_fcpl],
    }

    n_metrics = len(metrics_names)
    n_algos = len(algos_names)
    bar_w = 0.18
    x = np.arange(n_metrics)

    for i, (algo, color) in enumerate(zip(algos_names, algos_colors)):
        offset = (i - n_algos / 2 + 0.5) * bar_w
        lw = 2.5 if algo == 'FCPL' else 1.5
        bars = ax_c.bar(x + offset, metrics_data[algo], bar_w,
                       color=color, alpha=0.9, edgecolor='white', linewidth=0.5,
                       zorder=3, label=algo)
        # Value labels
        for bar, val in zip(bars, metrics_data[algo]):
            ax_c.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
                    f'{val:.1f}', ha='center', va='bottom', fontsize=7, fontweight='bold')

    ax_c.set_xticks(x)
    ax_c.set_xticklabels(metrics_names)
    ax_c.set_ylabel('Score (%)')
    ax_c.set_title('(c) JAFFE Performance Comparison', fontsize=11, fontweight='bold', pad=8)
    ax_c.set_ylim(0, 110)
    ax_c.legend(loc='upper right', fontsize=7.5, framealpha=0.9)
    despine(ax_c)

    # ===== Panel (d): Membership heatmap (10 samples x 5 clusters) =====
    ax_d = fig.add_subplot(gs[1, 0])

    # Select 10 representative samples (2 per expression)
    sample_ids = []
    for i in range(n_clusters):
        cls_idx = np.where(y_true == i)[0][:2]
        sample_ids.extend(cls_idx)
    sample_ids = sample_ids[:10]

    # FCM heatmap
    heatmap_data = U_fcm[:, sample_ids].T  # (10 samples, 5 clusters)

    im = ax_d.imshow(heatmap_data, aspect='auto', cmap='YlOrRd', vmin=0, vmax=1)

    ax_d.set_xticks(range(n_clusters))
    ax_d.set_xticklabels(expressions, fontsize=8, rotation=30, ha='right')
    ax_d.set_yticks(range(len(sample_ids)))
    ax_d.set_yticklabels([f'S{i+1}' for i in range(len(sample_ids))], fontsize=7)
    ax_d.set_title('(d) FCM Membership Heatmap', fontsize=11, fontweight='bold', pad=8)

    # Add colorbar
    cbar = fig.colorbar(im, ax=ax_d, fraction=0.046, pad=0.04)
    cbar.ax.tick_params(labelsize=7)
    cbar.set_label('Membership', fontsize=8)

    # ===== Panel (e): FCPL Membership heatmap =====
    ax_e = fig.add_subplot(gs[1, 1])

    heatmap_fcpl = U_fcpl[:, sample_ids].T

    im2 = ax_e.imshow(heatmap_fcpl, aspect='auto', cmap='YlOrRd', vmin=0, vmax=1)

    ax_e.set_xticks(range(n_clusters))
    ax_e.set_xticklabels(expressions, fontsize=8, rotation=30, ha='right')
    ax_e.set_yticks(range(len(sample_ids)))
    ax_e.set_yticklabels([f'S{i+1}' for i in range(len(sample_ids))], fontsize=7)
    ax_e.set_title('(e) FCPL Membership Heatmap', fontsize=11, fontweight='bold', pad=8)

    cbar2 = fig.colorbar(im2, ax=ax_e, fraction=0.046, pad=0.04)
    cbar2.ax.tick_params(labelsize=7)
    cbar2.set_label('Membership', fontsize=8)

    # ===== Panel (f): Membership entropy / confidence violin =====
    ax_f = fig.add_subplot(gs[1, 2])

    # Compute membership entropy for each algorithm
    def membership_entropy(U):
        """Compute average entropy of membership vectors."""
        U_clipped = np.clip(U.T, 1e-10, 1.0)
        entropies = -np.sum(U_clipped * np.log(U_clipped), axis=1)
        return entropies

    entropy_fcm = membership_entropy(U_fcm)
    entropy_sfcm = membership_entropy(U_sfcm)
    entropy_fcpl = membership_entropy(U_fcpl)

    violin_data = [entropy_fcm, entropy_sfcm, entropy_fcpl]
    violin_labels = ['FCM', 'SFCM', 'FCPL']
    violin_colors = ['#ED7D31', '#FFC000', '#C00000']

    parts = ax_f.violinplot(violin_data, showmeans=False, showmedians=True, showextrema=False)
    for i, pc in enumerate(parts['bodies']):
        pc.set_facecolor(violin_colors[i])
        pc.set_alpha(0.6)
        pc.set_edgecolor('white')
        pc.set_linewidth(1)

    # Add median marker
    for i, data in enumerate(violin_data):
        med = np.median(data)
        ax_f.scatter(i + 1, med, s=40, c='white', edgecolors='black', zorder=5)

    ax_f.set_xticks([1, 2, 3])
    ax_f.set_xticklabels(violin_labels)
    ax_f.set_ylabel('Membership Entropy')
    ax_f.set_title('(f) Cluster Confidence Distribution', fontsize=11, fontweight='bold', pad=8)
    despine(ax_f)

    # Overall title
    fig.suptitle('JAFFE Facial Expression Analysis with FCPL', 
                 fontsize=14, fontweight='bold', y=0.995)

    plt.savefig(os.path.join(FIG_DIR, 'exp_jaffe_combined.png'), dpi=300)
    plt.savefig(os.path.join(FIG_DIR, 'exp_jaffe_combined.svg'), format='svg')
    plt.close()
    print("  [OK] Figure JAFFE: exp_jaffe_combined.png/svg")


# ============================================================
# MAIN
# ============================================================
def main():
    print("=" * 60)
    print("Generating top-tier journal quality figures...")
    print("=" * 60)
    
    # Load all data
    data = load_data()
    print("[INFO] Data loaded successfully.")
    
    # Generate all figures
    print("\nGenerating figures:")
    plot_fig1_sota_comparison(data)
    plot_fig2_ablation(data)
    plot_fig3_cd_diagram(data)
    plot_fig4_label_ratio(data)
    plot_fig5_noise_robustness(data)
    plot_fig6_scalability(data)
    plot_fig7_visualization()
    plot_fig8_convergence(data)
    plot_fig_jaffe_combined()
    
    print("\n" + "=" * 60)
    print("All figures generated successfully!")
    print(f"Output directory: {FIG_DIR}")
    print("=" * 60)


if __name__ == '__main__':
    main()
