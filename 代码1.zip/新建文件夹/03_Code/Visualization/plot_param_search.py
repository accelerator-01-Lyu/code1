#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
FCPL parameter grid search visualization.
- Fig1: λ×m heatmaps for 7 datasets (2×4 symmetric layout)
- Fig2: Best parameters summary (1×2)
- Fig3: KFCPL best parameters comparison (1×2)
- Table: merged optimal parameters CSV
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.ticker import FixedLocator

# ============================================================
# Style
# ============================================================
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
    'font.size': 9,
    'axes.labelsize': 10,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'legend.fontsize': 7.5,
    'axes.linewidth': 0.6,
    'grid.linestyle': '--',
    'grid.alpha': 0.3,
    'savefig.dpi': 600,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})

DATA_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\data\results'
FIG_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\figures'
os.makedirs(FIG_DIR, exist_ok=True)

DATASET_NAMES = {
    'iris': 'Iris', 'wine': 'Wine', 'breast_cancer': 'Breast',
    'glass': 'Glass', 'seeds': 'Seeds', 'balance': 'Balance',
    'vehicle': 'Vehicle', 'segment': 'Segment',
    'ionosphere': 'Ionosphere', 'sonar': 'Sonar',
    'ecoli': 'Ecoli', 'diabetes': 'Diabetes', 'heart': 'Heart',
}

panel_labels = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']


def despine(ax):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)


def add_panel_label(ax, label, x=-0.12, y=1.05):
    ax.text(x, y, f'({label})', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top', ha='right')


# ============================================================
# Fig1: FCPL λ×m Grid Search Heatmap (2×4 symmetric)
# ============================================================
def plot_grid_search_heatmap():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_param_search_fcpl.csv'))
    best_df = pd.read_csv(os.path.join(DATA_DIR, 'exp_best_params_fcpl.csv'))
    
    datasets = sorted(df['Dataset'].unique())
    lambdas = sorted(df['lambda'].unique())
    ms = sorted(df['m'].unique())
    
    n_ds = len(datasets)  # 7
    n_rows, n_cols = 2, 4  # 8 cells, 7 used + 1 summary
    
    # Global color range across all datasets
    all_acc = df['ACC_mean'].values
    vmin, vmax = all_acc.min(), all_acc.max()
    norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)
    cmap = plt.get_cmap('plasma')
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(14, 6.5))
    axes = axes.flatten()
    
    for idx, ds in enumerate(datasets):
        ax = axes[idx]
        ds_data = df[df['Dataset'] == ds]
        
        # Create heatmap matrix
        heatmap = np.zeros((len(ms), len(lambdas)))
        for i, m_val in enumerate(ms):
            for j, lam in enumerate(lambdas):
                val = ds_data[(ds_data['lambda'] == lam) & (ds_data['m'] == m_val)]['ACC_mean'].values
                if len(val) > 0:
                    heatmap[i, j] = val[0]
        
        # Plot heatmap
        im = ax.imshow(heatmap, aspect='auto', cmap='plasma', norm=norm,
                       origin='lower')
        
        # Ticks
        ax.set_xticks(range(len(lambdas)))
        ax.set_xticklabels([f'{l:g}' for l in lambdas], rotation=45, ha='right', fontsize=7)
        ax.set_yticks(range(len(ms)))
        ax.set_yticklabels([f'{m:g}' for m in ms], fontsize=7)
        
        # Mark best parameters with star
        best_row = best_df[best_df['Dataset'] == ds]
        if len(best_row) > 0:
            best_lam = best_row['Best_lambda'].values[0]
            best_m = best_row['Best_m'].values[0]
            if best_lam in lambdas and best_m in ms:
                j_best = lambdas.index(best_lam)
                i_best = ms.index(best_m)
                ax.scatter(j_best, i_best, marker='*', s=120, c='white',
                          edgecolors='black', linewidths=1.0, zorder=5)
        
        ax.set_title(DATASET_NAMES.get(ds, ds), fontsize=9, fontweight='bold')
        add_panel_label(ax, panel_labels[idx])
        
        if idx >= (n_rows - 1) * n_cols:  # bottom row
            ax.set_xlabel(r'$\lambda$', fontsize=9)
        if idx % n_cols == 0:  # first column
            ax.set_ylabel(r'$m$ (fuzzifier)', fontsize=9)
    
    # 8th cell: summary - best ACC across datasets
    ax_sum = axes[7]
    
    # Bar chart of best ACC per dataset
    ds_names = [DATASET_NAMES.get(d, d) for d in datasets]
    best_accs = []
    for ds in datasets:
        row = best_df[best_df['Dataset'] == ds]
        if len(row) > 0:
            best_accs.append(row['Best_ACC'].values[0])
        else:
            best_accs.append(0)
    
    bars = ax_sum.barh(range(len(ds_names)), best_accs, color=cmap(norm(best_accs)),
                       edgecolor='white', linewidth=0.5)
    
    ax_sum.set_yticks(range(len(ds_names)))
    ax_sum.set_yticklabels(ds_names, fontsize=7)
    ax_sum.set_xlabel('Best ACC (%)', fontsize=9)
    ax_sum.set_title('Best ACC per Dataset', fontsize=9, fontweight='bold')
    ax_sum.invert_yaxis()
    despine(ax_sum)
    add_panel_label(ax_sum, 'h')
    
    # Add value labels
    for i, v in enumerate(best_accs):
        ax_sum.text(v + 0.5, i, f'{v:.1f}', va='center', fontsize=7)
    
    # Shared colorbar
    cbar_ax = fig.add_axes([0.92, 0.15, 0.015, 0.7])
    sm = plt.cm.ScalarMappable(cmap='plasma', norm=norm)
    sm.set_array([])
    cbar = fig.colorbar(sm, cax=cbar_ax)
    cbar.set_label('ACC (%)', fontsize=9)
    cbar.ax.tick_params(labelsize=8)
    
    fig.suptitle('FCPL Parameter Grid Search ($\\lambda \\times m$)', 
                 fontsize=12, fontweight='bold', y=0.995)
    
    plt.tight_layout(rect=[0, 0, 0.9, 1], w_pad=2.0, h_pad=2.5)
    
    out_png = os.path.join(FIG_DIR, 'exp_grid_search_heatmap.png')
    out_svg = os.path.join(FIG_DIR, 'exp_grid_search_heatmap.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Grid search heatmap: {out_png}")


# ============================================================
# Fig2: Best Parameters Summary (1×2)
# ============================================================
def plot_best_params_summary():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_best_params_fcpl.csv'))
    
    datasets = sorted(df['Dataset'].unique())
    ds_labels = [DATASET_NAMES.get(d, d) for d in datasets]
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
    
    # (a) Best lambda bar chart (log scale)
    bars1 = ax1.barh(range(len(datasets)), df['Best_lambda'].values,
                     color='#E64B35', alpha=0.85, edgecolor='white', linewidth=0.5)
    
    ax1.set_yticks(range(len(datasets)))
    ax1.set_yticklabels(ds_labels, fontsize=8)
    ax1.set_xscale('log')
    ax1.set_xlabel(r'Best $\lambda$ (log scale)', fontsize=9)
    ax1.set_title('(a) Optimal Regularization Parameter', fontsize=10, fontweight='bold')
    ax1.invert_yaxis()
    despine(ax1)
    
    # Value labels
    for i, v in enumerate(df['Best_lambda'].values):
        ax1.text(v * 1.1, i, f'{v:g}', va='center', fontsize=7)
    
    # (b) Best m bar chart
    bars2 = ax2.barh(range(len(datasets)), df['Best_m'].values,
                     color='#4DBBD5', alpha=0.85, edgecolor='white', linewidth=0.5)
    
    ax2.set_yticks(range(len(datasets)))
    ax2.set_yticklabels(ds_labels, fontsize=8)
    ax2.set_xlabel(r'Best $m$ (fuzzifier)', fontsize=9)
    ax2.set_title('(b) Optimal Fuzzification Coefficient', fontsize=10, fontweight='bold')
    ax2.invert_yaxis()
    ax2.set_xlim(1.0, 3.5)
    despine(ax2)
    
    # Value labels
    for i, v in enumerate(df['Best_m'].values):
        ax2.text(v + 0.05, i, f'{v:g}', va='center', fontsize=7)
    
    plt.tight_layout()
    
    out_png = os.path.join(FIG_DIR, 'exp_best_params_summary.png')
    out_svg = os.path.join(FIG_DIR, 'exp_best_params_summary.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Best params summary: {out_png}")


# ============================================================
# Fig3: KFCPL Best Parameters (1×2)
# ============================================================
def plot_kfcpl_params():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_best_params_kfcpl.csv'))
    
    datasets = sorted(df['Dataset'].unique())
    ds_labels = [DATASET_NAMES.get(d, d) for d in datasets]
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
    
    # (a) Best lambda
    ax1.barh(range(len(datasets)), df['Best_lambda'].values,
             color='#E64B35', alpha=0.85, edgecolor='white', linewidth=0.5)
    ax1.set_yticks(range(len(datasets)))
    ax1.set_yticklabels(ds_labels, fontsize=8)
    ax1.set_xscale('log')
    ax1.set_xlabel(r'Best $\lambda$ (log scale)', fontsize=9)
    ax1.set_title('(a) KFCPL Optimal $\\lambda$', fontsize=10, fontweight='bold')
    ax1.invert_yaxis()
    despine(ax1)
    
    for i, v in enumerate(df['Best_lambda'].values):
        ax1.text(v * 1.1, i, f'{v:g}', va='center', fontsize=7)
    
    # (b) Best gamma
    ax2.barh(range(len(datasets)), df['Best_gamma'].values,
             color='#00A087', alpha=0.85, edgecolor='white', linewidth=0.5)
    ax2.set_yticks(range(len(datasets)))
    ax2.set_yticklabels(ds_labels, fontsize=8)
    ax2.set_xscale('log')
    ax2.set_xlabel(r'Best $\gamma$ (kernel bandwidth, log scale)', fontsize=9)
    ax2.set_title('(b) KFCPL Optimal $\gamma$', fontsize=10, fontweight='bold')
    ax2.invert_yaxis()
    despine(ax2)
    
    for i, v in enumerate(df['Best_gamma'].values):
        ax2.text(v * 1.1, i, f'{v:g}', va='center', fontsize=7)
    
    plt.tight_layout()
    
    out_png = os.path.join(FIG_DIR, 'exp_kfcpl_params.png')
    out_svg = os.path.join(FIG_DIR, 'exp_kfcpl_params.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] KFCPL params: {out_png}")


# ============================================================
# Table: Merged Optimal Parameters CSV
# ============================================================
def generate_merged_table():
    fcpl_df = pd.read_csv(os.path.join(DATA_DIR, 'exp_best_params_fcpl.csv'))
    kfcpl_df = pd.read_csv(os.path.join(DATA_DIR, 'exp_best_params_kfcpl.csv'))
    
    # Rename columns for merge
    fcpl_df = fcpl_df.rename(columns={
        'Best_lambda': 'FCPL_lambda',
        'Best_m': 'FCPL_m',
        'Best_ACC': 'FCPL_ACC'
    })
    
    kfcpl_df = kfcpl_df.rename(columns={
        'Best_lambda': 'KFCPL_lambda',
        'Best_m': 'KFCPL_m',
        'Best_gamma': 'KFCPL_gamma',
        'Best_ACC': 'KFCPL_ACC'
    })
    kfcpl_df = kfcpl_df.drop(columns=['KFCPL_m'])  # m is always 2.0 for KFCPL
    
    # Merge on Dataset
    merged = pd.merge(fcpl_df, kfcpl_df, on='Dataset', how='outer')
    merged = merged.sort_values('Dataset').reset_index(drop=True)
    
    # Reorder columns
    merged = merged[['Dataset', 'FCPL_lambda', 'FCPL_m', 'FCPL_ACC',
                     'KFCPL_lambda', 'KFCPL_gamma', 'KFCPL_ACC']]
    
    out_path = os.path.join(DATA_DIR, 'table_optimal_params.csv')
    merged.to_csv(out_path, index=False, encoding='utf-8-sig')
    print(f"  [OK] Merged optimal params table: {out_path}")
    print(f"       Rows: {len(merged)}, Columns: {list(merged.columns)}")


# ============================================================
# MAIN
# ============================================================
def main():
    print("=" * 60)
    print("Generating parameter search visualizations...")
    print("=" * 60)
    
    print("\n1. FCPL λ×m grid search heatmap (2×4 symmetric)...")
    plot_grid_search_heatmap()
    
    print("\n2. Best parameters summary (1×2)...")
    plot_best_params_summary()
    
    print("\n3. KFCPL optimal parameters (1×2)...")
    plot_kfcpl_params()
    
    print("\n4. Merged optimal parameters table...")
    generate_merged_table()
    
    print("\n" + "=" * 60)
    print("All parameter search figures generated!")
    print("=" * 60)


if __name__ == '__main__':
    main()
