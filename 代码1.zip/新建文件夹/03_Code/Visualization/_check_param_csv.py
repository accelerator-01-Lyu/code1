import pandas as pd
import os

data_dir = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\data\results'

files = [
    'exp_param_search_fcpl.csv',
    'exp_best_params_fcpl.csv',
    'exp_best_params_kfcpl.csv',
]

for fname in files:
    fpath = os.path.join(data_dir, fname)
    if os.path.exists(fpath):
        df = pd.read_csv(fpath)
        print(f'=== {fname} ===')
        print(f'Shape: {df.shape}')
        print(f'Columns: {list(df.columns)}')
        print(df.head(10).to_string())
        print()
        print(f'Unique datasets: {sorted(df.iloc[:, 0].unique())}')
        print()
    else:
        print(f'[NOT FOUND] {fname}')
        print(f'  Path: {fpath}')
        print()
