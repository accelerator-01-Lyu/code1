"""
Generate professional visualization for MES vs QP verification results.
Multi-panel figure: convergence overlap, time comparison, speedup, precision.
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import LogLocator
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from models.mes import mes_solve_single, qp_solve_single
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler

# Style config
plt.rcParams.update({
    'font.family': 'Times New Roman',
    'font.size': 10,
    'axes.labelsize': 11,
    'axes.titlesize': 12,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'legend.fontsize': 9,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'grid.alpha': 0.3,
    'grid.linestyle': '--',
    'figure.dpi': 150,
})

COLORS = {
    'MES': '#C00000',
    'QP': '#4472C4',
    'MES_fill': '#C00000',
    'QP_fill': '#4472C4',
}


def gaussian_kernel(X, gamma):
    X1_sq = np.sum(X ** 2, axis=1, keepdims=True)
    dist_sq = X1_sq + X1_sq.T - 2.0 * X @ X.T
    return np.exp(-gamma * np.maximum(dist_sq, 0))


def compute_kernel_distances(X, U, K, m):
    n, k = U.shape
    um = U ** m
    S = np.maximum(um.sum(axis=0), 1e-10)
    weighted_K = K @ um
    term2 = -2.0 * weighted_K / S[np.newaxis, :]
    term3 = np.array([(um[:, kk:kk+1].T @ K @ um[:, kk:kk+1])[0,0] / S[kk]**2 for kk in range(k)])
    return np.maximum(np.ones(n)[:, None] + term2 + term3[None, :], 1e-10)


def run_kfcpl_track(X, P, mask, k, m, lam, gamma, max_iter, tol, solver, seed=42):
    rng = np.random.RandomState(seed)
    n = X.shape[0]
    K = gaussian_kernel(X, gamma)
    U = rng.rand(n, k)
    U /= U.sum(axis=1, keepdims=True)
    for i in range(n):
        if mask[i]:
            U[i] = 0.5 * P[i] + 0.5 * U[i]
            U[i] /= U[i].sum()
    obj_hist = []
    for it in range(max_iter):
        D = compute_kernel_distances(X, U, K, m)
        U_new = np.zeros_like(U)
        for i in range(n):
            if mask[i]:
                if solver == 'mes':
                    U_new[i] = mes_solve_single(D[i], P[i], lam)
                else:
                    U_new[i] = qp_solve_single(D[i], P[i], lam)
            else:
                d = np.maximum(D[i], 1e-10)
                inv_d = (1.0/d) ** (1.0/(m-1))
                U_new[i] = inv_d / inv_d.sum()
        um = U_new ** m
        obj = np.sum(um * D)
        if mask.any():
            obj += lam * np.sum((U_new[mask] - P[mask])**2)
        obj_hist.append(obj)
        if it > 0 and abs(obj_hist[-2] - obj_hist[-1]) < tol:
            U = U_new
            break
        U = U_new
    return obj_hist


def main():
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle('MES Solver vs Traditional QP Solver: Verification and Efficiency Comparison',
                 fontsize=14, fontweight='bold', y=0.98)

    # === Panel (a): Convergence curves on Iris (should overlap perfectly) ===
    ax = axes[0, 0]
    data = load_iris()
    X = StandardScaler().fit_transform(data.data)
    y = data.target
    k = 3
    rng = np.random.RandomState(42)
    P = np.zeros((len(y), k))
    mask = np.zeros(len(y), dtype=bool)
    for c in range(k):
        idx = np.where(y == c)[0]
        chosen = rng.choice(idx, 5, replace=False)
        mask[chosen] = True
        P[chosen, c] = 1.0

    obj_mes = run_kfcpl_track(X, P, mask, k, 2.0, 1.0, 1.0, 100, 1e-7, 'mes')
    obj_qp = run_kfcpl_track(X, P, mask, k, 2.0, 1.0, 1.0, 100, 1e-7, 'qp')

    ax.plot(range(1, len(obj_mes)+1), obj_mes, '-', color=COLORS['MES'],
            linewidth=2.5, markersize=6, label='MES (proposed)', zorder=3)
    ax.plot(range(1, len(obj_qp)+1), obj_qp, '--', color=COLORS['QP'],
            linewidth=2, markersize=5, label='Traditional QP (SLSQP)', zorder=2)
    ax.set_xlabel('Iteration')
    ax.set_ylabel('Objective Function Value')
    ax.set_title('(a) Convergence Trajectories (Iris)')
    ax.legend(framealpha=0.9, edgecolor='#ccc')
    ax.grid(True)
    ax.text(0.95, 0.05, 'Curves overlap perfectly\n→ Identical optimization path',
            transform=ax.transAxes, fontsize=9, ha='right', va='bottom',
            bbox=dict(boxstyle='round,pad=0.4', facecolor='#E8F5E9', edgecolor='#4CAF50', alpha=0.9))

    # === Panel (b): Running time comparison ===
    ax = axes[0, 1]
    datasets = ['Iris\n(n=150)', 'Wine\n(n=178)', 'BreastCancer\n(n=569)',
                'Synth-500\n(n=500)', 'Synth-2k\n(n=2000)', 'Synth-5k\n(n=5000)']
    mes_times = [0.0251, 0.0061, 0.0199, 0.0228, 0.1058, 0.3882]
    qp_times = [0.3994, 0.0778, 0.1952, 0.3601, 1.4826, 3.9583]
    x = np.arange(len(datasets))
    width = 0.35
    bars1 = ax.bar(x - width/2, mes_times, width, label='MES (proposed)',
                    color=COLORS['MES'], alpha=0.85, edgecolor='white', linewidth=0.5)
    bars2 = ax.bar(x + width/2, qp_times, width, label='Traditional QP',
                    color=COLORS['QP'], alpha=0.85, edgecolor='white', linewidth=0.5)
    ax.set_ylabel('Running Time (seconds)')
    ax.set_title('(b) Total Running Time Comparison')
    ax.set_xticks(x)
    ax.set_xticklabels(datasets, fontsize=8)
    ax.legend(framealpha=0.9, edgecolor='#ccc')
    ax.grid(True, axis='y')
    # Add speedup annotations
    for i, (m, q) in enumerate(zip(mes_times, qp_times)):
        speedup = q / m
        ax.annotate(f'{speedup:.1f}x', xy=(i, max(m, q) * 1.05),
                    ha='center', va='bottom', fontsize=8, fontweight='bold',
                    color='#C00000')

    # === Panel (c): Speedup vs dataset size ===
    ax = axes[1, 0]
    sizes = [150, 178, 569, 500, 2000, 5000]
    speedups = [q/m for q, m in zip(qp_times, mes_times)]
    solve_speedups = [47.4, 41.9, 31.4, 51.2, 56.5, 52.2]
    ax.scatter(sizes, speedups, s=120, color=COLORS['MES'], marker='o',
               zorder=3, label='Total speedup', edgecolors='white', linewidth=1.5)
    ax.scatter(sizes, solve_speedups, s=120, color='#ED7D31', marker='s',
               zorder=3, label='Solver-only speedup', edgecolors='white', linewidth=1.5)
    # Trend lines
    z = np.polyfit(sizes, speedups, 1)
    ax.plot(sorted(sizes), np.polyval(z, sorted(sizes)), '--', color=COLORS['MES'], alpha=0.4)
    ax.set_xlabel('Number of Samples')
    ax.set_ylabel('Speedup Factor (QP / MES)')
    ax.set_title('(c) Speedup vs Dataset Size')
    ax.legend(framealpha=0.9, edgecolor='#ccc')
    ax.grid(True)
    ax.axhline(y=1, color='gray', linestyle=':', alpha=0.5)
    ax.text(0.95, 0.05, f'Avg total: {np.mean(speedups):.1f}x\nAvg solver: {np.mean(solve_speedups):.1f}x',
            transform=ax.transAxes, fontsize=9, ha='right', va='bottom',
            bbox=dict(boxstyle='round,pad=0.4', facecolor='#FFF3E0', edgecolor='#FF9800', alpha=0.9))

    # === Panel (d): Numerical precision verification ===
    ax = axes[1, 1]
    max_diffs = [4.29e-9, 2.98e-9, 3.96e-9, 7.57e-9, 6.11e-9, 3.89e-9]
    obj_diffs = [2.55e-12, 2.84e-14, 5.68e-14, 0.0, 5.68e-14, 0.0]
    x_pos = np.arange(len(datasets))
    ax.bar(x_pos - 0.2, max_diffs, 0.4, label='max |U_MES - U_QP|',
           color='#7B2D8B', alpha=0.85, edgecolor='white')
    ax.bar(x_pos + 0.2, [max(d, 1e-15) for d in obj_diffs], 0.4, label='|J_MES - J_QP|',
           color='#2E8B8B', alpha=0.85, edgecolor='white')
    ax.axhline(y=1e-6, color='red', linestyle='--', linewidth=1.5, label='Tolerance (1e-6)')
    ax.set_yscale('log')
    ax.set_ylabel('Absolute Difference (log scale)')
    ax.set_title('(d) Numerical Precision: MES ≡ QP')
    ax.set_xticks(x_pos)
    ax.set_xticklabels(datasets, fontsize=8)
    ax.legend(framealpha=0.9, edgecolor='#ccc', loc='upper right')
    ax.grid(True, axis='y', which='both')
    ax.text(0.5, 0.95, 'ALL DIFFERENCES < 1e-8\n→ Mathematically identical solutions',
            transform=ax.transAxes, fontsize=9, ha='center', va='top',
            bbox=dict(boxstyle='round,pad=0.4', facecolor='#E8F5E9', edgecolor='#4CAF50', alpha=0.9))

    plt.tight_layout(rect=[0, 0, 1, 0.96])

    out_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'figures')
    os.makedirs(out_dir, exist_ok=True)
    png_path = os.path.join(out_dir, 'exp_mes_qp_verification.png')
    svg_path = os.path.join(out_dir, 'exp_mes_qp_verification.svg')
    plt.savefig(png_path, dpi=300, bbox_inches='tight')
    plt.savefig(svg_path, format='svg', bbox_inches='tight')
    plt.close()
    print(f"Saved: {png_path}")
    print(f"Saved: {svg_path}")


if __name__ == '__main__':
    main()
