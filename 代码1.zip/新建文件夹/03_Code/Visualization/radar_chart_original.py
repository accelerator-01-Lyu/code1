import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Polygon
import os
import logging
import gc

# ------------- 人脸识别图表配置 -------------
FILE_CONFIG = {
    "IMPORT_DIR": "C:/Users/FJZ/Desktop",
    "EXPORT_DIR": "MCP",
    "TRUE_DATA_FILE": "2.xlsx",  # 第一个文件为CSV格式
    "PRED_DATA_FILE": "3.xlsx",  # 预测数据为XLSX格式
    "COLORBAR_FILE": "face_recog_colorbar.png"
}

# 维度配置（人脸识别特征维度）
DIMENSION_CONFIG = {
    "TRUE_DIMENSIONS": {"cluster0": "Ha", "cluster1": "Sa", "cluster2": "Su", "cluster3": "An", "cluster4": "Dis"},
    "PRED_DIMENSIONS": {"cluster0": "Ha", "cluster1": "Sa", "cluster2": "Su", "cluster3": "An", "cluster4": "Dis"}}

# 日志配置
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ------------- 配色方案：红色（CSV）和蓝色（XLSX） -------------
COLOR_SCHEME = {
    "true": {
        # CSV数据：深红色系
        "line": "#8B0000",       # 深暗红线条
        "cmap": LinearSegmentedColormap.from_list(
            'face_true_red', 
            ['#FFE6E6', '#FFCCCC', '#FF9999', '#FF6666', '#FF3333', '#CC0000']  # 红色渐变
        )
    },
    "pred": {
        # XLSX数据：深蓝色系
        "line": "#00008B",       # 深海蓝线条
        "cmap": LinearSegmentedColormap.from_list(
            'face_pred_blue', 
            ['#E6F2FF', '#CCE5FF', '#99CBFF', '#66B2FF', '#3399FF', '#007FFF']  # 蓝色渐变
        )
    }
}

# 图表配置
RADAR_CONFIG = {
    "grid_interval": 0.2,
    "line_width": 1.2,
    "marker_size": 5,
    "marker_edge_width": 0.8,
    "grad_alpha": 0.3,
    "fig_size": (4.0, 4.0),
    "font_family": "Arial",
    "dpi": 600,
    "label_fontsize": 8,
    "tick_fontsize": 6,
    "annotation_fontsize": 7,
    "cbar_label_fontsize": 7,
    "show_colorbar_in_radar": False,  # 不嵌入色阶条
    "label_pad": 10,
    "grid_linewidth": 0.5,
    "grid_alpha": 0.8
}

# 色阶条配置（仅真实和预测数据）
COLORBAR_CONFIG = {
    "fig_size": (4.0, 0.6),
    "label": "Feature Matching Degree",
    "ticks": [0.0, 0.2, 0.4, 0.6, 0.8, 1.0],
    "orientation": "horizontal",
    "pad": 0.05,
    "shrink": 0.9,
    "axes_position": [0.1, 0.4, 0.8, 0.2]
}

DEFAULT_CONFIG = {
    "SHOW_RADAR_CHARTS": True,
    "RADAR_MODEL": "FaceNet",
    "USE_REAL_DATA": True,
    "BATCH_SIZE": 30,
    "MAX_SAMPLES": None,
    "COLOR_RANGE": [0.0, 1.0]
}

# ------------- 数据加载（适配CSV和XLSX） -------------
class DataLoader:
    def __init__(self, file_config=FILE_CONFIG):
        self.file_config = file_config
        self.import_dir = file_config["IMPORT_DIR"]
        
    def get_true_membership(self):
        """读取CSV格式的真实数据"""
        try:
            file_path = os.path.join(self.import_dir, self.file_config["TRUE_DATA_FILE"])
            cols = ['OriginalID'] + [f'cluster{i}' for i in range(5)]
            logger.info(f"加载CSV真实数据: {file_path}")
            
            # 根据文件扩展名选择读取方法
            if file_path.endswith('.csv'):
                return pd.read_csv(file_path, usecols=cols)
            else:
                logger.warning("真实数据文件不是CSV格式，尝试用Excel读取")
                return pd.read_excel(file_path, usecols=cols)
                
        except Exception as e:
            logger.error(f"真实数据加载失败: {str(e)}")
            raise
    
    def get_pred_membership(self, model_name):
        """读取XLSX格式的预测数据"""
        try:
            file_path = os.path.join(self.import_dir, self.file_config["PRED_DATA_FILE"])
            cols = ['OriginalID'] + [f'cluster{i}' for i in range(5)]
            logger.info(f"加载XLSX预测数据: {file_path}")
            
            # 根据文件扩展名选择读取方法
            if file_path.endswith('.xlsx') or file_path.endswith('.xls'):
                return pd.read_excel(file_path, usecols=cols)
            else:
                logger.warning("预测数据文件不是Excel格式，尝试用CSV读取")
                return pd.read_csv(file_path, usecols=cols)
                
        except Exception as e:
            logger.error(f"预测数据加载失败: {str(e)}")
            raise

# ------------- 图表生成 -------------
class RadarChartGenerator:
    def __init__(self, chart_type, config=None, data_loader=None):
        self.config = config or DEFAULT_CONFIG
        self.dl = data_loader or DataLoader()
        self.chart_type = chart_type  # 仅"true"或"pred"
        self.output_dir = os.path.join(FILE_CONFIG["EXPORT_DIR"], chart_type)
        os.makedirs(self.output_dir, exist_ok=True)
        self.batch_size = self.config["BATCH_SIZE"]
        self.max_samples = self.config["MAX_SAMPLES"]
        
    def plot_radar_charts(self):
        if not self.config.get("SHOW_RADAR_CHARTS", True):
            logger.info("跳过图表生成")
            return
            
        logger.info(f"生成{self.chart_type}类型人脸特征图表")
        
        # 加载数据
        if self.chart_type == "true":
            data_df = self.dl.get_true_membership()
            cats = list(DIMENSION_CONFIG["TRUE_DIMENSIONS"].keys())
            display_cats = [DIMENSION_CONFIG["TRUE_DIMENSIONS"][dim] for dim in cats]
        else:
            pred_model = self.config.get("RADAR_MODEL", "FaceNet")
            data_df = self.dl.get_pred_membership(pred_model)
            cats = list(DIMENSION_CONFIG["PRED_DIMENSIONS"].keys())
            display_cats = [DIMENSION_CONFIG["PRED_DIMENSIONS"][dim] for dim in cats]
        
        # 数据验证与处理
        cluster_cols = [f'cluster{i}' for i in range(5)]
        for col in cluster_cols:
            if col not in data_df.columns:
                data_df[col] = 0.0
        
        if 'OriginalID' not in data_df.columns:
            logger.error("缺少人脸ID列")
            return
            
        sample_ids = sorted(list(data_df['OriginalID'].unique()))
        if self.max_samples:
            sample_ids = sample_ids[:self.max_samples]
        total_samples = len(sample_ids)
        logger.info(f"总计需处理{total_samples}个人脸样本")
        
        # 分批处理
        for batch_start in range(0, total_samples, self.batch_size):
            batch_end = min(batch_start + self.batch_size, total_samples)
            for sample_id in sample_ids[batch_start:batch_end]:
                try:
                    row = data_df[data_df['OriginalID'] == sample_id].iloc[0]
                    values = row[cats].values
                    
                    # 归一化
                    row_sum = np.sum(values)
                    if row_sum != 0:
                        values = values / row_sum
                    else:
                        logger.warning(f"人脸样本{sample_id}特征值全为0，跳过归一化")
                    
                    max_index = np.argmax(values)
                    labeled_cats = []
                    for i, name in enumerate(display_cats):
                        if i == max_index:
                            labeled_cats.append(f"{name} ({values[i]:.2f})")
                        else:
                            labeled_cats.append(name)
                    
                    max_radius = max(np.max(values), 0.1) * 1.1
                    self._create_single_radar(
                        sample_id=sample_id,
                        data=values,
                        categories=labeled_cats,
                        max_radius=max_radius,
                        max_index=max_index
                    )
                    
                except Exception as e:
                    logger.error(f"人脸样本{sample_id}处理失败: {str(e)}")
                    continue
            
            gc.collect()
        
        logger.info(f"图表已保存至: {os.path.abspath(self.output_dir)}")
    
    def _create_single_radar(self, sample_id, data, categories, max_radius, max_index):
        plt.rcParams.update({
            "font.family": RADAR_CONFIG["font_family"],
            "axes.unicode_minus": False,
            "font.sans-serif": ["Arial", "Helvetica"],
            "pdf.fonttype": 42,
            "ps.fonttype": 42
        })
        
        fig = plt.figure(figsize=RADAR_CONFIG["fig_size"])
        ax = fig.add_subplot(111, polar=True)
        
        angles = self._get_radar_angles(len(categories))
        data = np.concatenate([data, [data[0]]])
        
        color_cfg = COLOR_SCHEME[self.chart_type]
        self._plot_radar_data(ax, angles, data, color_cfg)
        self._configure_axis(ax, angles, categories, max_radius)
        
        plt.subplots_adjust(left=0.15, right=0.85, top=0.85, bottom=0.15)
        
        save_path = os.path.join(self.output_dir, f"face_radar_{self.chart_type}_{sample_id}.png")
        plt.savefig(
            save_path, 
            dpi=RADAR_CONFIG["dpi"], 
            bbox_inches='tight', 
            pad_inches=0.05,
            transparent=False
        )
        plt.close(fig)
    
    def _get_radar_angles(self, n):
        return np.linspace(0, 2 * np.pi, n, endpoint=False).tolist() + [0]
    
    def _plot_radar_data(self, ax, angles, data, color_cfg):
        self._add_gradient_fill(ax, angles, data, color_cfg["cmap"])
        ax.plot(
            angles, data, 
            color=color_cfg["line"], 
            linewidth=RADAR_CONFIG["line_width"],
            marker='o', 
            markersize=RADAR_CONFIG["marker_size"],
            markeredgecolor='white',
            markeredgewidth=RADAR_CONFIG["marker_edge_width"],
            markerfacecolor=color_cfg["line"]
        )
    
    def _add_gradient_fill(self, ax, angles, data, cmap):
        n_points = 50
        max_radius = max(data)
        r_grid = np.linspace(0, max_radius, n_points)
        theta_grid = np.linspace(0, 2*np.pi, n_points)
        R, THETA = np.meshgrid(r_grid, theta_grid)
        
        Z = np.zeros_like(R)
        for i, theta in enumerate(theta_grid):
            for j in range(len(angles)-1):
                if angles[j] <= theta < angles[j+1]:
                    t = (theta - angles[j]) / (angles[j+1] - angles[j])
                    val = data[j] + t * (data[j+1] - data[j])
                    Z[i, :] = np.minimum(r_grid / val, 1.0) if val > 0 else 0
                    break
        
        im = ax.pcolormesh(THETA, R, Z, cmap=cmap, shading='gouraud', alpha=RADAR_CONFIG["grad_alpha"])
        vertices = [(angles[i], data[i]) for i in range(len(angles)-1)]
        poly = Polygon(vertices, closed=True, fill=False, edgecolor='none')
        ax.add_patch(poly)
        im.set_clip_path(poly)
    
    def _configure_axis(self, ax, angles, categories, max_radius):
        ax.set_theta_offset(np.pi/2)
        ax.set_theta_direction(-1)
        
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(
            categories, 
            fontsize=RADAR_CONFIG["label_fontsize"],
            color='#212121'
        )
        ax.tick_params(pad=RADAR_CONFIG["label_pad"])
        
        ax.set_ylim(0, max_radius)
        grid_interval = RADAR_CONFIG["grid_interval"]
        yticks = np.arange(0, max_radius + grid_interval/2, grid_interval)
        yticks = yticks[yticks <= max_radius]
        ax.set_yticks(yticks)
        ax.set_yticklabels(
            [f"{x:.1f}" for x in yticks], 
            fontsize=RADAR_CONFIG["tick_fontsize"],
            color='#555555'
        )
        ax.grid(
            color='#E0E0E0',
            linestyle='-', 
            linewidth=RADAR_CONFIG["grid_linewidth"], 
            alpha=RADAR_CONFIG["grid_alpha"]
        )
        ax.spines['polar'].set_visible(False)


class ColorbarGenerator:
    """仅生成真实和预测数据的色阶条"""
    def __init__(self, config=None):
        self.config = config or DEFAULT_CONFIG
        self.output_dir = FILE_CONFIG["EXPORT_DIR"]
        os.makedirs(self.output_dir, exist_ok=True)
        
    def generate_colorbars(self):
        """生成红色（CSV）和蓝色（XLSX）的色阶条"""
        for chart_type in ["true", "pred"]:  # 仅保留两种类型
            output_path = os.path.join(self.output_dir, f"{chart_type}_{FILE_CONFIG['COLORBAR_FILE']}")
            self._create_single_colorbar(chart_type, output_path)
            logger.info(f"已生成{chart_type}色阶条: {output_path}")
        logger.info(f"所有色阶条已保存至: {os.path.abspath(self.output_dir)}")
    
    def _create_single_colorbar(self, chart_type, output_path):
        plt.rcParams.update({
            "font.family": RADAR_CONFIG["font_family"],
            "axes.unicode_minus": False,
            "pdf.fonttype": 42,
            "ps.fonttype": 42
        })
        
        fig = plt.figure(figsize=COLORBAR_CONFIG["fig_size"])
        cax = fig.add_axes(COLORBAR_CONFIG["axes_position"])
        
        cmap = COLOR_SCHEME[chart_type]["cmap"]
        sm = plt.cm.ScalarMappable(
            cmap=cmap,
            norm=plt.Normalize(*self.config["COLOR_RANGE"])
        )
        sm.set_array([])
        
        cbar = fig.colorbar(
            sm,
            cax=cax,
            orientation=COLORBAR_CONFIG["orientation"],
            pad=COLORBAR_CONFIG["pad"],
            shrink=COLORBAR_CONFIG["shrink"],
            ticks=COLORBAR_CONFIG["ticks"]
        )
        
        cbar.set_label(
            COLORBAR_CONFIG["label"],
            fontsize=RADAR_CONFIG["cbar_label_fontsize"],
            color='#212121'
        )
        cbar.ax.tick_params(
            labelsize=RADAR_CONFIG["tick_fontsize"],
            color='#555555'
        )
        
        plt.savefig(
            output_path,
            dpi=RADAR_CONFIG["dpi"],
            bbox_inches='tight',
            pad_inches=0.05
        )
        plt.close(fig)

# ------------- 主函数 -------------
def main():
    logger.info("开始生成人脸识别特征雷达图及色阶条...")
    
    config = {
        "SHOW_RADAR_CHARTS": True,
        "RADAR_MODEL": "FaceNet",
        "BATCH_SIZE": 10,
        "MAX_SAMPLES": None,
        "COLOR_RANGE": [0.0, 1.0]
    }
    
    data_loader = DataLoader()
    
    # 生成CSV真实数据图表（红色）
    true_generator = RadarChartGenerator(chart_type="true", config=config, data_loader=data_loader)
    true_generator.plot_radar_charts()
    
    # 生成XLSX预测数据图表（蓝色）
    pred_generator = RadarChartGenerator(chart_type="pred", config=config, data_loader=data_loader)
    pred_generator.plot_radar_charts()
    
    # 生成对应的色阶条
    colorbar_generator = ColorbarGenerator(config=config)
    colorbar_generator.generate_colorbars()
    
    logger.info("所有人脸识别特征图表及色阶条生成完成！")

if __name__ == "__main__":
    main()
    