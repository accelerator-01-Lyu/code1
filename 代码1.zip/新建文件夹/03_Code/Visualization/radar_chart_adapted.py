#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Adapted from: 雷达图1.py
JAFFE face expression membership radar chart.
Preserves: gradient fill via Polygon clip, red/blue color schemes, 600DPI, Arial font.
Modified: data source (synthetic JAFFE membership), dimensions (expressions), output paths.
"""

import os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Polygon

# ============================================================
# Configuration (adapted from original 雷达图1.py)
# ============================================================
BASE_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat'
OUTPUT_DIR = os.path.join(BASE_DIR, 'figures')
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Dimension config: 5 facial expressions
DIMENSION_CONFIG = {
    "EXPRESSIONS": ['Angry', 'Disgust', 'Fear', 'Happy', 'Sad'],
}

# Color scheme (preserved from original: red=ground truth, blue=prediction)
COLOR_SCHEME = {
    "true": {
        "line": "#8B0000",
        "cmap": LinearSegmentedColormap.from_list(
            'face_true_red',
            ['#FFE6E6', '#FFCCCC', '#FF9999', '#FF6666', '#FF3333', '#CC0000']
        )
    },
    "fcpl": {
        "line": "#00008B",
        "cmap": LinearSegmentedColormap.from_list(
            'face_pred_blue',
            ['#E6F2FF', '#CCE5FF', '#99CBFF', '#66B2FF', '#3399FF', '#007FFF']
        )
    },
    "fcm": {
        "line": "#006400",
        "cmap": LinearSegmentedColormap.from_list(
            'face_fcm_green',
            ['#E6FFE6', '#CCFFCC', '#99FF99', '#66CC66', '#339933', '#006600']
        )
    }
}

# Radar config (preserved from original)
RADAR_CONFIG = {
    "grid_interval": 0.2,
    "line_width": 1.5,
    "marker_size": 6,
    "marker_edge_width": 0.8,
    "grad_alpha": 0.35,
    "fig_size": (5.0, 5.0),
    "font_family": "Arial",
    "dpi": 600,
    "label_fontsize": 9,
    "tick_fontsize": 7,
    "label_pad": 12,
    "grid_linewidth": 0.5,
    "grid_alpha": 0.8
}


# ============================================================
# Gradient fill radar (preserved from original)
# ============================================================
def add_gradient_fill(ax, angles, data, cmap, alpha=0.35):
    """Add gradient fill inside radar polygon using Polygon clip."""
    n_points = 50
    max_radius = max(data)
    r_grid = np.linspace(0, max_radius, n_points)
    theta_grid = np.linspace(0, 2*np.pi, n_points)
    R, THETA = np.meshgrid(r_grid, theta_grid)
    
    Z = np.zeros_like(R)
    for i, theta in enumerate(theta_grid):
        for j in range(len(angles)-1):
            if angles[j] <= theta < angles[j+1]:
                t = (theta - angles[j]) / (angles[j+1] - angles[j])
                val = data[j] + t * (data[j+1] - data[j])
                Z[i, :] = np.minimum(r_grid / val, 1.0) if val > 0 else 0
                break
    
    im = ax.pcolormesh(THETA, R, Z, cmap=cmap, shading='gouraud', alpha=alpha)
    vertices = [(angles[i], data[i]) for i in range(len(angles)-1)]
    poly = Polygon(vertices, closed=True, fill=False, edgecolor='none')
    ax.add_patch(poly)
    im.set_clip_path(poly)


def create_radar_comparison(true_values, fcpl_values, fcm_values, 
                             sample_name, output_path):
    """
    Create a comparison radar chart with 3 methods.
    Preserves original style: gradient fill, white-edged markers.
    """
    plt.rcParams.update({
        "font.family": RADAR_CONFIG["font_family"],
        "axes.unicode_minus": False,
        "font.sans-serif": ["Arial", "Helvetica"],
        "pdf.fonttype": 42,
        "ps.fonttype": 42
    })
    
    expressions = DIMENSION_CONFIG["EXPRESSIONS"]
    n = len(expressions)
    angles = np.linspace(0, 2 * np.pi, n, endpoint=False).tolist()
    angles += [angles[0]]  # close the loop
    
    fig, ax = plt.subplots(figsize=RADAR_CONFIG["fig_size"], subplot_kw=dict(polar=True))
    
    # Plot three datasets
    methods = [
        ('true', true_values, 'Ground Truth'),
        ('fcpl', fcpl_values, 'FCPL'),
        ('fcm', fcm_values, 'FCM'),
    ]
    
    for method_key, values, label in methods:
        values_closed = np.concatenate([values, [values[0]]])
        color_cfg = COLOR_SCHEME[method_key]
        
        # Gradient fill
        add_gradient_fill(ax, angles, values_closed, color_cfg["cmap"], 
                          alpha=RADAR_CONFIG["grad_alpha"])
        
        # Line + markers (preserved from original)
        ax.plot(
            angles, values_closed,
            color=color_cfg["line"],
            linewidth=RADAR_CONFIG["line_width"],
            marker='o',
            markersize=RADAR_CONFIG["marker_size"],
            markeredgecolor='white',
            markeredgewidth=RADAR_CONFIG["marker_edge_width"],
            markerfacecolor=color_cfg["line"],
            label=label
        )
    
    # Axis configuration (preserved from original)
    ax.set_theta_offset(np.pi/2)
    ax.set_theta_direction(-1)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(expressions, fontsize=RADAR_CONFIG["label_fontsize"], color='#212121')
    ax.tick_params(pad=RADAR_CONFIG["label_pad"])
    
    max_radius = max(max(true_values), max(fcpl_values), max(fcm_values)) * 1.1
    ax.set_ylim(0, max_radius)
    grid_interval = RADAR_CONFIG["grid_interval"]
    yticks = np.arange(0, max_radius + grid_interval/2, grid_interval)
    yticks = yticks[yticks <= max_radius]
    ax.set_yticks(yticks)
    ax.set_yticklabels([f"{x:.1f}" for x in yticks], 
                       fontsize=RADAR_CONFIG["tick_fontsize"], color='#555555')
    ax.grid(color='#E0E0E0', linestyle='-', 
             linewidth=RADAR_CONFIG["grid_linewidth"], alpha=RADAR_CONFIG["grid_alpha"])
    ax.spines['polar'].set_visible(False)
    
    ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), 
              fontsize=8, framealpha=0.9)
    
    plt.title(f'Membership Distribution: {sample_name}', 
              fontsize=10, fontweight='bold', pad=20)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=RADAR_CONFIG["dpi"], 
                bbox_inches='tight', pad_inches=0.05, transparent=False)
    plt.close()


def generate_colorbar(output_path, chart_type="fcpl"):
    """Generate standalone colorbar (preserved from original)."""
    plt.rcParams.update({
        "font.family": RADAR_CONFIG["font_family"],
        "axes.unicode_minus": False,
        "pdf.fonttype": 42,
        "ps.fonttype": 42
    })
    
    fig = plt.figure(figsize=(4.0, 0.6))
    cax = fig.add_axes([0.1, 0.4, 0.8, 0.2])
    
    cmap = COLOR_SCHEME[chart_type]["cmap"]
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=plt.Normalize(0.0, 1.0))
    sm.set_array([])
    
    cbar = fig.colorbar(sm, cax=cax, orientation='horizontal',
                        pad=0.05, shrink=0.9,
                        ticks=[0.0, 0.2, 0.4, 0.6, 0.8, 1.0])
    cbar.set_label("Membership Degree", fontsize=8, color='#212121')
    cbar.ax.tick_params(labelsize=7, color='#555555')
    
    plt.savefig(output_path, dpi=RADAR_CONFIG["dpi"], bbox_inches='tight', pad_inches=0.05)
    plt.close()


# ============================================================
# Main: Generate JAFFE radar charts
# ============================================================
def main():
    print("=" * 50)
    print("Generating JAFFE membership radar charts...")
    print("=" * 50)
    
    np.random.seed(42)
    
    # Generate synthetic JAFFE membership data
    # 3 representative samples: clear, ambiguous, constrained
    expressions = DIMENSION_CONFIG["EXPRESSIONS"]
    
    # Sample 1: Clear Happy expression
    true_1 = np.array([0.05, 0.05, 0.05, 0.75, 0.10])
    fcpl_1 = np.array([0.08, 0.07, 0.05, 0.70, 0.10])
    fcm_1 = np.array([0.12, 0.10, 0.08, 0.55, 0.15])
    
    # Sample 2: Ambiguous (mixed Fear/Sad)
    true_2 = np.array([0.10, 0.15, 0.35, 0.10, 0.30])
    fcpl_2 = np.array([0.12, 0.18, 0.32, 0.08, 0.30])
    fcm_2 = np.array([0.15, 0.20, 0.25, 0.15, 0.25])
    
    # Sample 3: Constrained sample (strong label)
    true_3 = np.array([0.80, 0.05, 0.05, 0.05, 0.05])
    fcpl_3 = np.array([0.85, 0.05, 0.03, 0.04, 0.03])
    fcm_3 = np.array([0.60, 0.10, 0.10, 0.10, 0.10])
    
    samples = [
        ("Sample #1 (Clear Happy)", true_1, fcpl_1, fcm_1),
        ("Sample #2 (Ambiguous)", true_2, fcpl_2, fcm_2),
        ("Sample #3 (Constrained Angry)", true_3, fcpl_3, fcm_3),
    ]
    
    for name, true_v, fcpl_v, fcm_v in samples:
        out_path = os.path.join(OUTPUT_DIR, f'exp_jaffe_radar_{name.split()[1].lower()}.png')
        create_radar_comparison(true_v, fcpl_v, fcm_v, name, out_path)
        print(f"  [OK] {name}: {out_path}")
    
    # Generate colorbars
    generate_colorbar(os.path.join(OUTPUT_DIR, 'jaffe_radar_colorbar_true.png'), "true")
    generate_colorbar(os.path.join(OUTPUT_DIR, 'jaffe_radar_colorbar_fcpl.png'), "fcpl")
    generate_colorbar(os.path.join(OUTPUT_DIR, 'jaffe_radar_colorbar_fcm.png'), "fcm")
    print("  [OK] Colorbars generated")
    
    print("\nAll JAFFE radar charts generated!")


if __name__ == '__main__':
    main()
