#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
v5 Flowcharts - Nature/Applied Energy style
Figure 1: Paradigm comparison (3 columns)
Figure 2: FCPL/KFCPL algorithm flowchart
"""

import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np

FIG_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\figures'

# Macaron colors
COLORS = {
    'input':      {'face': '#DBEEF3', 'edge': '#337BAC'},
    'process':    {'face': '#F5DECA', 'edge': '#E5A179'},
    'constraint': {'face': '#F4F8EE', 'edge': '#7DA494'},
    'output':     {'face': '#E7E1EC', 'edge': '#9FB0D8'},
    'highlight':  {'face': '#FFCCCC', 'edge': '#C16E71'},
    'shared':     {'face': '#E8F0E8', 'edge': '#5A9E6F'},
}


def draw_box(ax, x, y, w, h, text, color_key, fontsize=8, bold=False):
    """Draw a rounded rectangle with text."""
    c = COLORS[color_key]
    box = FancyBboxPatch((x, y), w, h,
                         boxstyle="round,pad=0.02,rounding_size=0.08",
                         facecolor=c['face'], edgecolor=c['edge'],
                         linewidth=1.5, zorder=2)
    ax.add_patch(box)
    
    weight = 'bold' if bold else 'normal'
    ax.text(x + w/2, y + h/2, text,
            ha='center', va='center', fontsize=fontsize,
            fontweight=weight, zorder=3, wrap=True)
    return box


def draw_arrow(ax, x1, y1, x2, y2, style='->', color='#666666', lw=1.2, ls='-'):
    """Draw an arrow."""
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle=style, color=color,
                               lw=lw, linestyle=ls), zorder=1)


# ============================================================
# Figure 1: Paradigm Comparison (3 columns)
# ============================================================
def fig1_paradigm_comparison():
    fig, ax = plt.subplots(figsize=(14, 8))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 8)
    ax.axis('off')
    
    # Three columns
    col_width = 3.5
    col_gap = 0.75
    col_x = [0.5, 0.5 + col_width + col_gap, 0.5 + 2*(col_width + col_gap)]
    
    # Titles
    ax.text(col_x[0] + col_width/2, 7.6, 'Traditional Hard Clustering',
            ha='center', fontsize=11, fontweight='bold', color='#555555')
    ax.text(col_x[1] + col_width/2, 7.6, 'Unsupervised Fuzzy Clustering',
            ha='center', fontsize=11, fontweight='bold', color='#555555')
    ax.text(col_x[2] + col_width/2, 7.6, 'FCPL: Semi-Supervised Fuzzy Clustering',
            ha='center', fontsize=11, fontweight='bold', color='#C16E71')
    
    # Column 1: Traditional Hard Clustering
    cx = col_x[0]
    # Input
    draw_box(ax, cx+0.3, 6.2, 2.9, 0.7, 'Input Data\n(X, unlabeled)', 'input', fontsize=8)
    # Algorithm
    draw_box(ax, cx+0.3, 4.8, 2.9, 0.9, 'K-means\nHard assignment\nu ∈ {0,1}', 'process', fontsize=8)
    # Output
    draw_box(ax, cx+0.3, 3.2, 2.9, 0.7, 'Hard Partition\n(crisp labels)', 'output', fontsize=8)
    # Arrows
    draw_arrow(ax, cx+1.75, 6.2, cx+1.75, 5.7)
    draw_arrow(ax, cx+1.75, 4.8, cx+1.75, 3.9)
    # Limitation box
    draw_box(ax, cx+0.3, 1.8, 2.9, 1.0, 'Limitations:\n• Cannot handle overlap\n• No prior knowledge\n• Sensitive to init', 'highlight', fontsize=7.5)
    
    # Column 2: Unsupervised Fuzzy Clustering
    cx = col_x[1]
    # Input
    draw_box(ax, cx+0.3, 6.2, 2.9, 0.7, 'Input Data\n(X, unlabeled)', 'input', fontsize=8)
    # Algorithm
    draw_box(ax, cx+0.3, 4.8, 2.9, 0.9, 'FCM / KFCM\nFuzzy assignment\nu ∈ [0,1]', 'process', fontsize=8)
    # Output
    draw_box(ax, cx+0.3, 3.2, 2.9, 0.7, 'Fuzzy Partition\n(soft membership)', 'output', fontsize=8)
    # Arrows
    draw_arrow(ax, cx+1.75, 6.2, cx+1.75, 5.7)
    draw_arrow(ax, cx+1.75, 4.8, cx+1.75, 3.9)
    # Limitation
    draw_box(ax, cx+0.3, 1.8, 2.9, 1.0, 'Limitations:\n• No supervision\n• Uncertain boundaries\n• No constraint incorporation', 'highlight', fontsize=7.5)
    
    # Column 3: FCPL (highlighted)
    cx = col_x[2]
    # Input data
    draw_box(ax, cx+0.3, 6.2, 2.9, 0.7, 'Input Data\n(X + labeled samples)', 'input', fontsize=8)
    # Prior constraints
    draw_box(ax, cx+0.3, 5.2, 2.9, 0.6, 'Prior Constraints P\n(partition-level)', 'constraint', fontsize=7.5)
    # FCPL algorithm (highlighted)
    draw_box(ax, cx+0.3, 3.8, 2.9, 1.0, 'FCPL / KFCPL\nMES Solver\n(partition-level guidance)', 'highlight', fontsize=8, bold=True)
    # Output
    draw_box(ax, cx+0.3, 2.5, 2.9, 0.7, 'Improved Fuzzy Partition\n(better boundaries)', 'output', fontsize=8)
    # Arrows
    draw_arrow(ax, cx+1.75, 6.2, cx+1.75, 4.8)  # data -> algorithm
    draw_arrow(ax, cx+1.75, 5.2, cx+1.75, 4.8, ls='--', color='#7DA494')  # constraint -> algorithm
    draw_arrow(ax, cx+1.75, 3.8, cx+1.75, 3.2)  # algorithm -> output
    # Advantage
    draw_box(ax, cx+0.3, 1.2, 2.9, 0.9, 'Advantages:\n• Partition-level guidance\n• Efficient MES solver\n• Kernel extension', 'shared', fontsize=7.5)
    
    # Panel label
    ax.text(0.2, 7.8, '(a)', fontsize=12, fontweight='bold')
    
    fig.suptitle('Figure 1: Paradigm Comparison of Clustering Approaches',
                 fontsize=13, fontweight='bold', y=0.98)
    
    plt.tight_layout()
    out = os.path.join(FIG_DIR, 'v5_fig1_paradigm_comparison')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig1: {out}.png")


# ============================================================
# Figure 2: FCPL/KFCPL Algorithm Flowchart
# ============================================================
def fig2_algorithm_flowchart():
    fig, ax = plt.subplots(figsize=(14, 9))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 10)
    ax.axis('off')
    
    # Left column: FCPL (Euclidean)
    ax.text(2.5, 9.5, 'FCPL (Euclidean Space)', ha='center',
            fontsize=11, fontweight='bold', color='#337BAC')
    
    # Right column: KFCPL (Kernel)
    ax.text(11.5, 9.5, 'KFCPL (RKHS Kernel Space)', ha='center',
            fontsize=11, fontweight='bold', color='#7DA494')
    
    # Center: MES shared module
    ax.text(7, 9.5, 'MES Shared Solver', ha='center',
            fontsize=11, fontweight='bold', color='#5A9E6F')
    
    # --- FCPL column (left) ---
    cx = 1.0
    draw_box(ax, cx, 8.2, 3.0, 0.6, 'Input: X, P, constraint_mask', 'input', fontsize=7.5)
    draw_box(ax, cx, 7.2, 3.0, 0.6, 'Initialize U, C', 'process', fontsize=7.5)
    draw_box(ax, cx, 6.2, 3.0, 0.6, 'Update Centers C\n(weighted mean)', 'process', fontsize=7.5)
    draw_box(ax, cx, 5.2, 3.0, 0.6, 'Compute Distances D\n(Euclidean)', 'process', fontsize=7.5)
    
    # --- KFCPL column (right) ---
    cx = 10.0
    draw_box(ax, cx, 8.2, 3.0, 0.6, 'Input: X, P, constraint_mask\n+ kernel γ', 'input', fontsize=7.5)
    draw_box(ax, cx, 7.2, 3.0, 0.6, 'Initialize U, implicit C', 'process', fontsize=7.5)
    draw_box(ax, cx, 6.2, 3.0, 0.6, 'Compute Kernel K\nGaussian kernel', 'process', fontsize=7.5)
    draw_box(ax, cx, 5.2, 3.0, 0.6, 'Kernel Distances D\n(RKHS inner product)', 'process', fontsize=7.5)
    
    # --- MES shared module (center) ---
    draw_box(ax, 5.2, 5.5, 3.6, 2.5, 
             'MES Solver\n(Lagrangian Relaxation)\n\n'
             '• KKT block matrix\n'
             '• Schur complement\n'
             '• Closed-form solution\n'
             '• Active-set truncation',
             'shared', fontsize=8, bold=True)
    
    # Arrows from FCPL to MES
    draw_arrow(ax, 4.0, 5.5, 5.2, 6.5, color='#337BAC', lw=1.5)
    # Arrows from KFCPL to MES
    draw_arrow(ax, 10.0, 5.5, 8.8, 6.5, color='#7DA494', lw=1.5)
    
    # MES output
    draw_box(ax, 5.2, 4.0, 3.6, 0.6, 'Updated Membership U', 'output', fontsize=7.5)
    draw_arrow(ax, 7, 5.5, 7, 4.6)
    
    # Convergence check
    draw_box(ax, 5.2, 2.8, 3.6, 0.6, 'Convergence Check\n|J(t)-J(t-1)| < ε', 'process', fontsize=7.5)
    draw_arrow(ax, 7, 4.0, 7, 3.4)
    
    # Loop back arrows
    draw_arrow(ax, 5.2, 3.1, 2.5, 3.1, ls='--', color='#888')
    draw_arrow(ax, 2.5, 3.1, 2.5, 6.2, ls='--', color='#888')
    ax.text(2.0, 4.5, 'Iterate', fontsize=7, color='#888', rotation=90)
    
    draw_arrow(ax, 8.8, 3.1, 11.5, 3.1, ls='--', color='#888')
    draw_arrow(ax, 11.5, 3.1, 11.5, 6.2, ls='--', color='#888')
    ax.text(12.5, 4.5, 'Iterate', fontsize=7, color='#888', rotation=270)
    
    # Output
    draw_box(ax, 3.5, 1.2, 7.0, 0.7, 'Output: Optimal Membership U, Cluster Centers C, Labels', 'output', fontsize=8, bold=True)
    draw_arrow(ax, 7, 2.8, 7, 1.9)
    
    # Complexity note
    ax.text(7, 0.5, 'MES Complexity: O(r·c²)  vs  QP Standard: O((n·c)³)',
            ha='center', fontsize=8, style='italic', color='#5A9E6F', fontweight='bold')
    
    # Panel label
    ax.text(0.2, 9.7, '(b)', fontsize=12, fontweight='bold')
    
    fig.suptitle('Figure 2: FCPL/KFCPL Algorithm Flowchart with MES Solver',
                 fontsize=13, fontweight='bold', y=0.98)
    
    plt.tight_layout()
    out = os.path.join(FIG_DIR, 'v5_fig2_algorithm_flowchart')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"  [OK] Fig2: {out}.png")


# ============================================================
# MAIN
# ============================================================
def main():
    print("=" * 60)
    print("Generating v5 Flowcharts...")
    print("=" * 60)
    
    print("\n1. Paradigm comparison figure...")
    fig1_paradigm_comparison()
    
    print("\n2. Algorithm flowchart...")
    fig2_algorithm_flowchart()
    
    print("\n" + "=" * 60)
    print("Flowcharts complete!")
    print("=" * 60)


if __name__ == '__main__':
    main()
