#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
v5 Fig18-19: Face Semantic Clarity Charts
Fig18: Membership distribution heatmap
Fig19: Entropy distribution boxplot
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

BASE_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat'
DATA_DIR = os.path.join(BASE_DIR, 'data', 'results')
FIG_DIR = os.path.join(BASE_DIR, 'figures')

plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
    'font.size': 9,
    'axes.labelsize': 10,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'legend.fontsize': 7.5,
    'axes.linewidth': 0.6,
    'grid.linestyle': '--',
    'grid.alpha': 0.3,
    'savefig.dpi': 600,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})

# Blue-green gradient colormap
BLUE_GREEN_CMAP = LinearSegmentedColormap.from_list(
    'blue_green',
    ['#D5E8F1', '#ABD7DF', '#CAEBE7', '#A9D9BB', '#90B4CF', '#337BAC', '#4FB1B2']
)

# Algorithm colors
ALGO_COLORS = {
    'FCM': '#C16E71',
    'SFCM': '#EAB67A',
    'FCPL': '#6E8FB2',
}


def despine(ax):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)


def add_panel_label(ax, label, x=-0.12, y=1.05):
    ax.text(x, y, f'({label})', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top', ha='right')


# ============================================================
# Fig18: Face Membership Distribution Heatmap
# ============================================================
def fig18_face_membership_heatmap():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_face_membership_comparison.csv'))
    
    # Select 4 representative samples (sample IDs: 0, 50, 100, 150)
    sample_ids = sorted(df['sample_id'].unique())[:4]
    emotions = ['Happy', 'Sad', 'Angry', 'Fear', 'Disgust', 'Surprise']
    algorithms = ['FCM', 'SFCM', 'FCPL']
    
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    axes = axes.flatten()
    
    for s_idx, sid in enumerate(sample_ids):
        ax = axes[s_idx]
        sample_data = df[df['sample_id'] == sid]
        true_label = sample_data['true_label'].values[0]
        
        # Build heatmap matrix: rows=algorithms, cols=emotions
        heatmap = np.zeros((len(algorithms), len(emotions)))
        for i, algo in enumerate(algorithms):
            algo_data = sample_data[sample_data['algorithm'] == algo]
            for j, emo in enumerate(emotions):
                heatmap[i, j] = algo_data[emo].values[0]
        
        im = ax.imshow(heatmap, aspect='auto', cmap=BLUE_GREEN_CMAP,
                       vmin=0, vmax=1, origin='lower')
        
        ax.set_xticks(range(len(emotions)))
        ax.set_xticklabels(emotions, fontsize=7.5, rotation=45, ha='right')
        ax.set_yticks(range(len(algorithms)))
        ax.set_yticklabels(algorithms, fontsize=8)
        
        # Annotate values
        for i in range(len(algorithms)):
            for j in range(len(emotions)):
                val = heatmap[i, j]
                color = 'white' if val > 0.5 else 'black'
                ax.text(j, i, f'{val:.2f}', ha='center', va='center',
                       fontsize=6.5, color=color)
        
        ax.set_title(f'Sample {sid} (True: {true_label})',
                    fontsize=9, fontweight='bold')
        despine(ax)
        add_panel_label(ax, chr(97+s_idx))
    
    # Shared colorbar
    cbar_ax = fig.add_axes([0.92, 0.15, 0.015, 0.7])
    sm = plt.cm.ScalarMappable(cmap=BLUE_GREEN_CMAP, norm=plt.Normalize(vmin=0, vmax=1))
    sm.set_array([])
    fig.colorbar(sm, cax=cbar_ax, label='Membership')
    
    fig.suptitle('Fuzzy Membership Distribution: Face Emotion Recognition',
                 fontsize=11, fontweight='bold', y=0.98)
    
    plt.tight_layout(rect=[0, 0, 0.9, 1])
    
    out = os.path.join(FIG_DIR, 'v5_fig18_face_membership_heatmap')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"[OK] Fig18: {out}.png")


# ============================================================
# Fig19: Face Entropy Distribution Boxplot
# ============================================================
def fig19_face_entropy_boxplot():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_face_entropy_distribution.csv'))
    
    algorithms = ['FCM', 'SFCM', 'FCPL']
    colors = [ALGO_COLORS[a] for a in algorithms]
    
    fig, ax = plt.subplots(figsize=(7, 5))
    
    box_data = [df[df['algorithm'] == a]['entropy'].values for a in algorithms]
    
    bp = ax.boxplot(box_data, patch_artist=True, tick_labels=algorithms,
                    medianprops={'color': 'black', 'linewidth': 1.5},
                    whiskerprops={'linewidth': 0.8},
                    capprops={'linewidth': 0.8},
                    flierprops={'marker': 'o', 'markersize': 2, 'alpha': 0.3})
    
    for patch, color in zip(bp['boxes'], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)
        patch.set_edgecolor('white')
        patch.set_linewidth(0.5)
    
    # Add jittered points
    np.random.seed(42)
    for i, data in enumerate(box_data):
        x = np.random.normal(i + 1, 0.04, size=len(data))
        ax.scatter(x, data, s=8, alpha=0.3, color=colors[i], zorder=2)
    
    # Mean annotations
    for i, data in enumerate(box_data):
        mean_val = np.mean(data)
        ax.text(i + 1, mean_val - 0.05, f'μ={mean_val:.3f}',
               ha='center', fontsize=7, fontweight='bold')
    
    ax.set_ylabel('Normalized Membership Entropy', fontsize=9)
    ax.set_title('Fuzzy Membership Entropy Distribution\n(Lower = More Confident Clustering)',
                 fontsize=10, fontweight='bold')
    despine(ax)
    
    plt.tight_layout()
    out = os.path.join(FIG_DIR, 'v5_fig19_face_entropy_boxplot')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"[OK] Fig19: {out}.png")


if __name__ == '__main__':
    print("Generating face clarity charts...")
    fig18_face_membership_heatmap()
    fig19_face_entropy_boxplot()
    print("Done!")
