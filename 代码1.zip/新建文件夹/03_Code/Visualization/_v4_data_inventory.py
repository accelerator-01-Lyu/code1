"""Full inventory of all available CSV data for v4 chart generation."""
import pandas as pd
import os

data_dir = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat\data\results'

csv_files = sorted([f for f in os.listdir(data_dir) if f.endswith('.csv')])

print("=" * 80)
print("V4 DATA READINESS INVENTORY")
print("=" * 80)

ready = []
pending = []

for fname in csv_files:
    fpath = os.path.join(data_dir, fname)
    try:
        df = pd.read_csv(fpath)
        n_nan = df.isna().sum().sum()
        status = "READY" if n_nan == 0 else f"HAS {n_nan} NANs"
        
        # Check key columns
        cols = list(df.columns)[:10]
        print(f"  [{status:8s}] {fname:45s} {df.shape[0]:4d} rows × {df.shape[1]:2d} cols")
        print(f"             Columns: {cols}")
        
        if n_nan == 0:
            ready.append(fname)
        else:
            pending.append(fname)
    except Exception as e:
        print(f"  [ERROR   ] {fname:45s} {e}")
        pending.append(fname)

print("\n" + "=" * 80)
print(f"READY: {len(ready)} files")
print(f"PENDING/ERROR: {len(pending)} files")
print("=" * 80)

# Check specific files mentioned in v4 requirements
print("\n=== v4 Required Files Check ===")
required_files = [
    'exp_sota_final.csv',
    'exp_synthetic_compound.csv', 
    'exp_synthetic_aggregation.csv',
    'exp_param_sensitivity_semisupervised.csv',
    'exp_face_redone.csv',
    'exp_mes_qp_strict_verification.csv',
    'exp4_label_ratio.csv',
    'exp5_noise_robustness.csv',
    'exp6_scalability.csv',
    'exp13_large_scale_scalability.csv',
    'exp_large_scale_summary.csv',
    'exp3_mean_ranks.csv',
    'exp8_convergence.csv',
    'exp_param_search_fcpl.csv',
    'exp2_ablation.csv',
]

for rf in required_files:
    exists = os.path.exists(os.path.join(data_dir, rf))
    status = "✓ EXISTS" if exists else "✗ MISSING"
    print(f"  {status:12s} {rf}")
