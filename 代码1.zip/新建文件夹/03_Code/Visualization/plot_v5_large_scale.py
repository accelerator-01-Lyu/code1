#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
v5 Fig16: Large-Scale Industrial Dataset Comparison
3 datasets: Fashion-MNIST, Shuttle, Letter
6 representative algorithms: K-means, MBKMeans, FCM, SFCM, SSFCM, FCPL
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat'
DATA_DIR = os.path.join(BASE_DIR, 'data', 'results')
FIG_DIR = os.path.join(BASE_DIR, 'figures')

plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
    'font.size': 9,
    'axes.labelsize': 10,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'legend.fontsize': 7.5,
    'axes.linewidth': 0.6,
    'grid.linestyle': '--',
    'grid.alpha': 0.3,
    'savefig.dpi': 600,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})

# v5 Nature colors
ALGO_COLORS = {
    'K-means': '#EDABC1',
    'MBKMeans': '#9FB0D8',
    'FCM': '#C16E71',
    'SFCM': '#EAB67A',
    'SSFCM': '#E5A179',
    'FCPL': '#6E8FB2',
}

REPR_ALGOS = ['K-means', 'MBKMeans', 'FCM', 'SFCM', 'SSFCM', 'FCPL']


def despine(ax):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)


def add_panel_label(ax, label, x=-0.12, y=1.05):
    ax.text(x, y, f'({label})', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top', ha='right')


def main():
    df = pd.read_csv(os.path.join(DATA_DIR, 'exp_large_scale_30k_auto.csv'))
    df = df[df['algorithm'].isin(REPR_ALGOS)].copy()
    
    datasets = ['Fashion-MNIST', 'Shuttle', 'Letter']
    metrics = [
        ('ACC_mean', 'ACC_ci95', 'ACC (%)'),
        ('NMI_mean', 'NMI_ci95', 'NMI (%)'),
        ('ARI_mean', 'ARI_ci95', 'ARI (%)'),
    ]
    
    # ============================================================
    # Fig16: Comparison bar chart (1x3: 3 datasets)
    # Each subplot shows ACC/NMI/ARI for 6 algorithms
    # ============================================================
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
    
    for ds_idx, dataset in enumerate(datasets):
        ax = axes[ds_idx]
        ds_data = df[df['dataset'] == dataset].set_index('algorithm')
        
        x = np.arange(len(REPR_ALGOS))
        width = 0.25
        
        for m_idx, (mean_col, ci_col, ylabel) in enumerate(metrics):
            offset = (m_idx - 1) * width
            means = [ds_data.loc[a, mean_col] for a in REPR_ALGOS]
            cis = [ds_data.loc[a, ci_col] for a in REPR_ALGOS]
            
            colors = [ALGO_COLORS[a] for a in REPR_ALGOS]
            bars = ax.bar(x + offset, means, width,
                         yerr=cis,
                         color=colors, alpha=0.85, edgecolor='white', linewidth=0.5,
                         capsize=2, label=metrics[m_idx][2])
        
        ax.set_xticks(x)
        ax.set_xticklabels(REPR_ALGOS, rotation=30, ha='right', fontsize=7.5)
        ax.set_ylabel('Score (%)')
        ax.set_title(f'({chr(97+ds_idx)}) {dataset}', fontsize=10, fontweight='bold')
        ax.legend(fontsize=7)
        despine(ax)
    
    fig.suptitle('Large-Scale Industrial Dataset Comparison (30k auto-sampling)',
                 fontsize=11, fontweight='bold', y=1.02)
    
    plt.tight_layout()
    out = os.path.join(FIG_DIR, 'v5_fig16_large_scale_comparison')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"[OK] Fig16: {out}.png")
    
    # ============================================================
    # Fig17: Runtime comparison
    # ============================================================
    fig, ax = plt.subplots(figsize=(8, 4.5))
    
    x = np.arange(len(REPR_ALGOS))
    width = 0.25
    
    for ds_idx, dataset in enumerate(datasets):
        ds_data = df[df['dataset'] == dataset].set_index('algorithm')
        times = [ds_data.loc[a, 'time_mean'] for a in REPR_ALGOS]
        offset = (ds_idx - 1) * width
        
        colors = ['#6E8FB2', '#7DA494', '#EAB67A']
        ax.bar(x + offset, times, width,
               color=colors[ds_idx], alpha=0.85, edgecolor='white', linewidth=0.5,
               label=dataset)
    
    ax.set_xticks(x)
    ax.set_xticklabels(REPR_ALGOS, rotation=30, ha='right', fontsize=8)
    ax.set_ylabel('Runtime (s)')
    ax.set_title('Runtime Comparison: Large-Scale Industrial Datasets',
                 fontsize=10, fontweight='bold')
    ax.legend(fontsize=7)
    despine(ax)
    
    # Add value labels
    for ds_idx, dataset in enumerate(datasets):
        ds_data = df[df['dataset'] == dataset].set_index('algorithm')
        times = [ds_data.loc[a, 'time_mean'] for a in REPR_ALGOS]
        offset = (ds_idx - 1) * width
        for i, t in enumerate(times):
            ax.text(x[i] + offset, t + 0.1, f'{t:.2f}',
                   ha='center', fontsize=6.5)
    
    plt.tight_layout()
    out = os.path.join(FIG_DIR, 'v5_fig17_large_scale_time')
    plt.savefig(out + '.png', dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.savefig(out + '.svg', format='svg', bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"[OK] Fig17: {out}.png")


if __name__ == '__main__':
    main()
