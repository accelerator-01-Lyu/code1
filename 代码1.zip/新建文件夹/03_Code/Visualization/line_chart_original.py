import pandas as pd
import matplotlib.pyplot as plt

# 设置通用格式配置
plt.rcParams.update({
    'figure.dpi': 300,
    'font.family': 'WenQuanYi Zen Hei',
    'font.size': 8,
    'axes.labelsize': 8,
    'xtick.labelsize': 7,
    'ytick.labelsize': 7,
    'legend.fontsize': 7,
    'axes.linewidth': 0.5,
    'xtick.major.width': 0.5,
    'ytick.major.width': 0.5,
    'xtick.major.size': 3,
    'ytick.major.size': 3,
})

# 读取数据
excel_file = pd.ExcelFile('C:/Users/FJZ/Desktop/4.xlsx')
df = excel_file.parse('Sheet1')

# 数据筛选
filtered_df = df[(df['Lambda'] >= 0.01) & (df['Lambda'] <= 7.04) &
                 (df['ARI'] >= 0) & (df['ARI'] <= 1) &
                 (df['ACC'] >= 0) & (df['ACC'] <= 1) &
                 (df['NMI'] >= 0) & (df['NMI'] <= 1)]

# 模型列表
selected_models = ['FCM', 'FCPL', 'PCAKM', 'KFCM', 'GK', 'KM', 'SFCM']
filtered_df = filtered_df[filtered_df['Model'].isin(selected_models)]

# 数据聚合处理
def aggregate_metric(group, metric):
    model = group['Model'].iloc[0]
    if model in ['FCM', 'FCPL']:
        return group[metric].max()
    else:
        return group[metric].min()

# 样式参数
colors = [
    '#E64B35', '#4DBBD5', '#00A087', '#3C5488',
    '#F39B7F', '#8491B4', '#91D1C2'
]
markers = ['o', 's', '^', 'v', 'p', '*', 'D']
line_styles = ['-', '--', '-.', ':', '-', '--', '-.']
marker_interval = 1  


# 绘图函数（优化图例显示）
def plot_metric(metric, save_path):
    processed_df = filtered_df.groupby(['Model', 'Lambda']).apply(
        lambda x: aggregate_metric(x, metric)
    ).reset_index()
    processed_df.columns = ['Model', 'Lambda', metric]
    
    fig, ax = plt.subplots(figsize=(3.5, 3.5))
    
    # 绘制曲线
    for i, model in enumerate(selected_models):
        model_df = processed_df[processed_df['Model'] == model].sort_values('Lambda')
        if not model_df.empty:
            x = model_df['Lambda'].values
            y = model_df[metric].values
            marker_indices = range(0, len(x), marker_interval)
            ax.plot(x, y,
                    marker=markers[i % len(markers)],
                    markersize=3,
                    markerfacecolor='white',
                    markeredgewidth=0.5,
                    linewidth=1.0,
                    linestyle=line_styles[i % len(line_styles)],
                    color=colors[i % len(colors)],
                    label=model,
                    markevery=marker_indices)
    
    # 坐标轴美化
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.xaxis.set_ticks_position('bottom')
    ax.yaxis.set_ticks_position('left')
    ax.set_xlabel('λ')
    ax.set_ylabel(metric)
    
    # ----------------------
    # 图例优化核心方案（三选一）
    # ----------------------
    
    # 方案1：自动选择空白区域（推荐，matplotlib会尝试寻找无数据的位置）
    ax.legend(loc='best', frameon=True, framealpha=0.8,  # 半透明边框
              labelspacing=0.2, handlelength=1.2, fontsize=6)
    
    # 方案2：手动指定稀疏位置（例如右上角，若该区域折线少）
    # ax.legend(loc='upper right', frameon=True, framealpha=0.8,
    #           labelspacing=0.2, handlelength=1.2, fontsize=6)
    
    # 方案3：压缩图例大小并放在左侧（适合右侧折线密集的情况）
    # ax.legend(loc='center left', bbox_to_anchor=(1, 0.5),  # 图例在图右侧外部
    #           frameon=True, framealpha=0.8, fontsize=6)
    
    plt.tight_layout()
    fig.savefig(save_path, dpi=600, bbox_inches='tight', pad_inches=0.05)
    plt.close()
    print(f"{metric}图表已保存至: {save_path}")


# 生成图表
plot_metric('ACC', 'C:/Users/FJZ/Desktop/lambda_acc_plot_nature.png')
plot_metric('ARI', 'C:/Users/FJZ/Desktop/lambda_ari_plot_nature.png')
plot_metric('NMI', 'C:/Users/FJZ/Desktop/lambda_nmi_plot_nature.png')