#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Adapted from: 敏感性分析图.py
3D parameter sensitivity bar chart for KFCPL (lambda x gamma).
Preserves: plasma colormap, global unified color scale, 3D bar3d, custom log ticks, 600DPI.
Modified: data source (simulated KFCPL grid search), model name, output paths.
"""

import os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.ticker import FixedLocator

# ============================================================
# Style configuration (preserved from original)
# ============================================================
mpl.rcParams.update({
    'font.family': 'Arial',
    'font.size': 10,
    'axes.labelsize': 12,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'lines.linewidth': 0.5,
    'axes.linewidth': 0.7,
    'figure.dpi': 600,
    'savefig.dpi': 600,
})

BASE_DIR = r'C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat'
OUTPUT_DIR = os.path.join(BASE_DIR, 'figures')
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Custom ticks (preserved from original)
CUSTOM_TICKS = [0.001, 0.01, 0.1, 1, 10, 100, 1000]
LINEAR_POS = np.arange(len(CUSTOM_TICKS))

# Metrics (preserved from original)
METRICS = [
    ('ACC', 'ACC'),
    ('Precision', 'Precision'),
    ('Recall', 'Recall'),
    ('F1', 'F1'),
    ('NMI', 'NMI'),
    ('ARI', 'ARI')
]


def format_tick_label(value):
    """Format tick label (preserved from original)."""
    if value == 0.001:
        return "0.001"
    elif value == 0.01:
        return "0.01"
    elif value == 0.1:
        return "0.1"
    else:
        return f"{int(value)}"


def generate_simulated_data():
    """
    Generate simulated λ×γ grid search data for KFCPL.
    Real data would come from exp_param_search.csv.
    """
    np.random.seed(42)
    n = len(CUSTOM_TICKS)
    
    # Optimal region around lambda=1, gamma=0.1-1
    lam_grid, gamma_grid = np.meshgrid(np.log10(CUSTOM_TICKS), np.log10(CUSTOM_TICKS))
    
    # Base performance + Gaussian peak at optimal params
    peak_lam = 0  # log10(1) = 0
    peak_gam = -1  # log10(0.1) = -1
    
    # ACC: peak around (1, 0.1), base ~85
    acc = 85 + 8 * np.exp(-((lam_grid - peak_lam)**2 / 8 + (gamma_grid - peak_gam)**2 / 4))
    acc += np.random.normal(0, 0.5, (n, n))
    
    # Other metrics correlated with ACC
    precision = acc - 3 + np.random.normal(0, 0.5, (n, n))
    recall = acc - 2 + np.random.normal(0, 0.5, (n, n))
    f1 = (precision + recall) / 2 + np.random.normal(0, 0.3, (n, n))
    nmi = acc - 15 + np.random.normal(0, 1.0, (n, n))
    ari = acc - 20 + np.random.normal(0, 1.5, (n, n))
    
    data = {
        'ACC': acc,
        'Precision': precision,
        'Recall': recall,
        'F1': f1,
        'NMI': nmi,
        'ARI': ari,
    }
    return data


def create_3d_bar_plot(metric_name, data_matrix, global_norm, cmap):
    """
    Create single metric 3D bar plot with global unified color scale.
    Preserved from original: bar3d, FixedLocator, view_init.
    """
    fig = plt.figure(figsize=(7, 6), dpi=600)
    ax = fig.add_subplot(111, projection='3d')
    
    plt.subplots_adjust(left=0.2, right=0.85, bottom=0.2, top=0.85)
    
    # Prepare data
    xs, ys, dz_list = [], [], []
    for i in range(len(CUSTOM_TICKS)):
        for j in range(len(CUSTOM_TICKS)):
            xs.append(LINEAR_POS[j])
            ys.append(LINEAR_POS[i])
            dz_list.append(data_matrix[i, j])
    
    # Color mapping with global norm (preserved from original)
    colors = cmap(global_norm(dz_list))
    
    dx = 0.7
    dy = 0.7
    
    ax.bar3d(
        xs, ys, np.zeros_like(dz_list),
        dx, dy, dz_list,
        color=colors, alpha=0.9, edgecolor='w', linewidth=0.2
    )
    
    # Axis labels (preserved from original)
    ax.set_xlabel(r'$\lambda$', labelpad=12, fontsize=12)
    ax.set_ylabel(r'$\gamma$', labelpad=12, fontsize=12)
    ax.set_zlabel(metric_name, labelpad=10, fontsize=12, rotation=90)
    
    # Ticks (preserved from original)
    ax.xaxis.set_major_locator(FixedLocator(LINEAR_POS))
    ax.yaxis.set_major_locator(FixedLocator(LINEAR_POS))
    ax.set_xticklabels([format_tick_label(x) for x in CUSTOM_TICKS])
    ax.set_yticklabels([format_tick_label(y) for y in CUSTOM_TICKS])
    
    plt.setp(ax.get_xticklabels(), rotation=0, ha='left')
    plt.setp(ax.get_yticklabels(), rotation=0, ha='right')
    
    ax.zaxis.set_rotate_label(True)
    ax.zaxis.set_label_coords(0.5, -0.05)
    
    # View angle (preserved from original)
    ax.view_init(elev=25, azim=-30)
    
    ax.xaxis._axinfo["tick"]["inward_factor"] = 0.0
    ax.yaxis._axinfo["tick"]["inward_factor"] = 0.0
    ax.zaxis._axinfo["tick"]["inward_factor"] = 0.0
    ax.tick_params(axis='both', direction='out', pad=6, labelsize=8)
    
    # Save
    out_png = os.path.join(OUTPUT_DIR, f'exp_3d_sensitivity_{metric_name}.png')
    out_svg = os.path.join(OUTPUT_DIR, f'exp_3d_sensitivity_{metric_name}.svg')
    plt.savefig(out_png, dpi=600, bbox_inches='tight', pad_inches=0.3)
    plt.savefig(out_svg, format='svg', bbox_inches='tight', pad_inches=0.3)
    plt.close()
    print(f"  [OK] {metric_name}: {out_png}")


def create_unified_colorbar(cmap, global_norm):
    """Create global unified colorbar (preserved from original)."""
    fig = plt.figure(figsize=(6, 1.0), dpi=600)
    plt.subplots_adjust(left=0.15, right=0.85, bottom=0.3, top=0.7)
    
    ax = fig.add_axes([0.1, 0.4, 0.8, 0.2])
    
    sm = mpl.cm.ScalarMappable(cmap=cmap, norm=global_norm)
    sm.set_array([])
    cbar = fig.colorbar(sm, cax=ax, orientation='horizontal')
    cbar.ax.set_xlabel("Metric Value", fontsize=10, labelpad=8)
    cbar.ax.tick_params(labelsize=8, pad=6)
    
    out_path = os.path.join(OUTPUT_DIR, 'exp_3d_sensitivity_unified_colorbar.png')
    plt.savefig(out_path, dpi=600, bbox_inches='tight', pad_inches=0.1)
    plt.close()
    print(f"  [OK] Unified colorbar: {out_path}")


# ============================================================
# Main
# ============================================================
def main():
    print("=" * 50)
    print("Generating 3D parameter sensitivity plots...")
    print("=" * 50)
    
    # Generate data
    data = generate_simulated_data()
    
    # Collect all values for global color scale (preserved from original)
    all_dz = np.concatenate([data[m].flatten() for m, _ in METRICS])
    
    global_vmin = np.min(all_dz)
    global_vmax = np.max(all_dz)
    global_norm = mpl.colors.Normalize(vmin=global_vmin, vmax=global_vmax)
    print(f"  Global color range: {global_vmin:.2f} ~ {global_vmax:.2f}")
    
    cmap = plt.get_cmap('plasma')  # preserved from original
    
    # Generate 6 metrics
    for metric_col, metric_name in METRICS:
        create_3d_bar_plot(metric_name, data[metric_col], global_norm, cmap)
    
    # Unified colorbar
    create_unified_colorbar(cmap, global_norm)
    
    print("\nAll 3D sensitivity plots generated!")


if __name__ == '__main__':
    main()
