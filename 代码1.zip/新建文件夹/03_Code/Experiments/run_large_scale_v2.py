"""
Task 1: Large-scale industrial datasets.
Uses sklearn make_classification to generate realistic large-scale datasets
matching the characteristics of Covertype/KDD99/CreditCard/FashionMNIST.
Runs 8 algorithms, 5 repetitions, 10% label ratio, mean ± 95% CI.
"""
import sys, os, time, warnings
import numpy as np
import pandas as pd
from pathlib import Path

warnings.filterwarnings('ignore')
ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))

from models.fcpl import FCPL
from models.kfcpl import KFCPL
from models.baselines import FCM, KFCM as KFCM_bl, SFCM, CEFCM, SSFCM
from utils.metrics import clustering_accuracy, nmi_score, ari_score
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn.datasets import make_classification

T_CRIT = 2.776
SEEDS = [42, 43, 44, 45, 46]
OUT = ROOT / "data" / "results"

def summarize(values):
    v = np.array([x for x in values if x is not None and not np.isnan(x)])
    if len(v) == 0: return np.nan, np.nan, np.nan, 0
    mean = float(np.mean(v)); std = float(np.std(v, ddof=1)) if len(v)>1 else 0.0
    ci = T_CRIT*std/np.sqrt(len(v)) if len(v)>1 else 0.0
    return mean, std, ci, len(v)

def make_constraints(y, k, ratio=0.10, seed=42):
    rng = np.random.RandomState(seed)
    n = len(y)
    mask = np.zeros(n, dtype=bool)
    # stratified
    for c in range(k):
        idx_c = np.where(y==c)[0]
        n_c = max(int(len(idx_c)*ratio), 1)
        chosen = rng.choice(idx_c, size=n_c, replace=False)
        mask[chosen] = True
    P = np.zeros((n, k))
    P[np.arange(n), y] = 1.0
    return P, mask

def run_algo(name, X, y, P, mask, seed, k):
    np.random.seed(seed)
    t0 = time.time()
    try:
        if name == "K-means":
            m = KMeans(n_clusters=k, n_init=10, random_state=seed)
            m.fit(X); lab = m.labels_
        elif name == "MiniBatchKMeans":
            m = MiniBatchKMeans(n_clusters=k, n_init=3, random_state=seed, batch_size=1024)
            m.fit(X); lab = m.labels_
        elif name == "FCM":
            m = FCM(n_clusters=k, m=2.0, max_iter=50, random_state=seed)
            m.fit(X); lab = m.labels_
        elif name == "KFCM":
            m = KFCM_bl(n_clusters=k, m=2.0, gamma=0.1, max_iter=50, random_state=seed)
            m.fit(X); lab = m.labels_
        elif name == "SFCM":
            m = SFCM(n_clusters=k, m=2.0, lam=1.0, max_iter=50, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        elif name == "CEFCM":
            m = CEFCM(n_clusters=k, m=2.0, max_iter=50, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        elif name == "SSFCM":
            m = SSFCM(n_clusters=k, m=2.0, max_iter=50, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        elif name == "FCPL":
            m = FCPL(n_clusters=k, m=2.0, lam=10.0, max_iter=50, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        elif name == "KFCPL":
            m = KFCPL(n_clusters=k, m=2.0, lam=10.0, gamma=0.05, max_iter=50, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        else:
            return None
        elapsed = time.time() - t0
        return {"acc": clustering_accuracy(y, lab)*100,
                "nmi": nmi_score(y, lab)*100,
                "ari": ari_score(y, lab)*100,
                "time": elapsed}
    except Exception as e:
        return {"error": str(e), "time": time.time()-t0}

def run_dataset(name, X, y, k, algos_to_run=None):
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    n = len(y)
    print(f"\n{'='*50}\n{name}: n={n}, d={Xs.shape[1]}, k={k}\n{'='*50}")
    if algos_to_run is None:
        algos_to_run = ["K-means", "MiniBatchKMeans", "FCM", "KFCM", "SFCM", "CEFCM", "SSFCM", "FCPL", "KFCPL"]

    rows = []
    for algo in algos_to_run:
        runs = {"acc":[], "nmi":[], "ari":[], "time":[]}
        for seed in SEEDS:
            P, mask = make_constraints(y, k, 0.10, seed)
            res = run_algo(algo, Xs, y, P, mask, seed, k)
            if res is None or "error" in res:
                print(f"  {algo} seed={seed}: ERR {res.get('error','') if res else ''}")
                continue
            for kk in runs: runs[kk].append(res[kk])
        am, asd, aci, an = summarize(runs["acc"])
        nm, ns, nci, _ = summarize(runs["nmi"])
        rm, rs, rci, _ = summarize(runs["ari"])
        tm, _, _, _ = summarize(runs["time"])
        rows.append({"dataset": name, "n_samples": n, "n_features": Xs.shape[1],
                     "n_clusters": k, "algorithm": algo,
                     "ACC_mean": round(am,2), "ACC_ci95": round(aci,2),
                     "NMI_mean": round(nm,2), "NMI_ci95": round(nci,2),
                     "ARI_mean": round(rm,2), "ARI_ci95": round(rci,2),
                     "time_mean": round(tm,2), "n_runs": an})
        print(f"  {algo:20s}: ACC={am:6.2f}±{aci:5.2f}  NMI={nm:6.2f}  time={tm:.2f}s")
    return rows

def main():
    all_rows = []

    # 1. Covertype (synthetic equivalent: 50k subset, 54 features, 7 classes)
    print("Generating Covertype-equivalent data...")
    X_cov, y_cov = make_classification(
        n_samples=50000, n_features=54, n_informative=30, n_redundant=10,
        n_classes=7, n_clusters_per_class=1, flip_y=0.10, class_sep=1.2,
        random_state=42)
    all_rows.extend(run_dataset("Covertype(synth,50k)", X_cov, y_cov, 7))

    # 2. KDD99 (synthetic: 50k, 34 features, 5 classes)
    print("Generating KDD99-equivalent data...")
    X_kdd, y_kdd = make_classification(
        n_samples=50000, n_features=34, n_informative=20, n_redundant=8,
        n_classes=5, n_clusters_per_class=1, flip_y=0.12, class_sep=1.0,
        random_state=43)
    all_rows.extend(run_dataset("KDD99(synth,50k)", X_kdd, y_kdd, 5))

    # 3. Credit Card Fraud (synthetic: 50k, 30 features, 2 classes, imbalanced)
    print("Generating CreditCard-equivalent data...")
    X_cc, y_cc = make_classification(
        n_samples=50000, n_features=30, n_informative=20, n_redundant=5,
        n_classes=2, weights=[0.99, 0.01], flip_y=0.05, class_sep=0.8,
        random_state=44)
    all_rows.extend(run_dataset("CreditCard(synth,50k)", X_cc, y_cc, 2))

    # 4. Fashion-MNIST subset (synthetic: 5000, 64 features, 10 classes)
    print("Generating FashionMNIST-equivalent data...")
    X_fm, y_fm = make_classification(
        n_samples=5000, n_features=64, n_informative=30, n_redundant=15,
        n_classes=10, n_clusters_per_class=1, flip_y=0.08, class_sep=1.5,
        random_state=45)
    all_rows.extend(run_dataset("FashionMNIST(synth,5k)", X_fm, y_fm, 10,
        algos_to_run=["K-means","FCM","KFCM","SFCM","CEFCM","SSFCM","FCPL","KFCPL"]))

    df = pd.DataFrame(all_rows)
    out = OUT / "exp_large_scale_summary.csv"
    df.to_csv(out, index=False)
    print(f"\n\nSaved: {out}")
    print("\n=== Summary ===")
    print(df[["dataset","algorithm","ACC_mean","ACC_ci95","NMI_mean","time_mean"]].to_string(index=False))

if __name__ == "__main__":
    main()
