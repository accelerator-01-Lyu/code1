"""FCPL-only parameter grid search (lambda x m)."""
import sys, os, itertools
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_dataset, get_constraint_samples
from code.utils.metrics import evaluate_clustering
from code.models.fcpl import FCPL

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')

LAMBDAS = [0.01, 0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 50.0]
MS = [1.5, 2.0, 2.5, 3.0]
DATASETS = ['iris', 'wine', 'breast_cancer', 'glass', 'seeds', 'balance', 'vehicle']

all_results = []
optimal_rows = []

for ds_name in DATASETS:
    print(f"\n--- {ds_name} ---")
    X, y, n_clusters = get_dataset(ds_name, random_state=42)
    
    best_acc = 0
    best_params = None
    
    for lam, m in itertools.product(LAMBDAS, MS):
        accs = []
        for rep in range(3):
            rs = 42 + rep
            _, P, cm = get_constraint_samples(y, 0.1, rs)
            model = FCPL(n_clusters=n_clusters, m=m, lam=lam,
                        max_iter=100, tol=1e-5, random_state=rs)
            model.fit(X, P, cm)
            res = evaluate_clustering(y, model.labels_)
            accs.append(res['ACC'])
        
        mean_acc = np.mean(accs)
        all_results.append({
            'Dataset': ds_name, 'lambda': lam, 'm': m,
            'ACC_mean': mean_acc, 'ACC_std': np.std(accs)
        })
        
        if mean_acc > best_acc:
            best_acc = mean_acc
            best_params = (lam, m)
    
    print(f"  Best: lambda={best_params[0]}, m={best_params[1]}, ACC={best_acc:.2f}%")
    optimal_rows.append({
        'Dataset': ds_name, 'Best_lambda': best_params[0],
        'Best_m': best_params[1], 'Best_ACC': best_acc
    })

df_all = pd.DataFrame(all_results)
df_all.to_csv(os.path.join(RESULTS_DIR, 'exp_param_search_fcpl.csv'), index=False)

df_opt = pd.DataFrame(optimal_rows)
df_opt.to_csv(os.path.join(RESULTS_DIR, 'exp_param_optimal_fcpl.csv'), index=False)

# Heatmap
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

n_ds = len(DATASETS)
fig, axes = plt.subplots(2, 4, figsize=(18, 8))
axes = axes.flatten()

for idx, ds_name in enumerate(DATASETS):
    ax = axes[idx]
    df_ds = df_all[df_all['Dataset'] == ds_name]
    pivot = df_ds.pivot(index='lambda', columns='m', values='ACC_mean')
    sns.heatmap(pivot, annot=True, fmt='.1f', cmap='YlOrRd', ax=ax, cbar=True)
    ax.set_title(ds_name)
    ax.set_xlabel('m')
    ax.set_ylabel('lambda')

axes[7].set_visible(False)
plt.suptitle('FCPL: ACC Sensitivity to lambda and m', fontsize=14)
plt.tight_layout()
plt.savefig(os.path.join(FIGURES_DIR, 'exp_param_heatmap_fcpl.png'), dpi=300, bbox_inches='tight')
plt.savefig(os.path.join(FIGURES_DIR, 'exp_param_heatmap_fcpl.svg'), bbox_inches='tight')
plt.close()

print(f"\nDone. Results saved.")
print(df_opt.to_string())
