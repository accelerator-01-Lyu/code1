"""30k large-scale with REAL downloadable datasets + auto-downsample."""
import sys, warnings, time
import numpy as np
import pandas as pd
from pathlib import Path
warnings.filterwarnings('ignore')

ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))
from models.fcpl import FCPL
from models.kfcpl import KFCPL
from models.baselines import FCM, KFCM as KFCM_bl, SFCM, CEFCM, SSFCM
from utils.metrics import clustering_accuracy, nmi_score, ari_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn.decomposition import PCA
from sklearn.datasets import fetch_openml

SEEDS = [42,43,44,45,46]
T = 2.776
OUT = ROOT / "data" / "results"
SIZES = [10000, 8000, 5000, 3000, 1000]

def stratified_sample(X, y, n, seed=42):
    rng = np.random.RandomState(seed)
    classes = np.unique(y)
    out_idx = []
    for c in classes:
        idx = np.where(y == c)[0]
        nc = max(int(len(idx) * n / len(y)), 1)
        out_idx.append(rng.choice(idx, min(nc, len(idx)), replace=False))
    idx = np.concatenate(out_idx)
    return X[idx], y[idx]

def make_con(y,k,ratio=0.10,seed=42):
    rng=np.random.RandomState(seed); n=len(y); mask=np.zeros(n,bool)
    for c in range(k):
        idx=np.where(y==c)[0]; nc=max(int(len(idx)*ratio),1)
        mask[rng.choice(idx,nc,replace=False)]=True
    P=np.zeros((n,k)); P[np.arange(n),y]=1.0
    return P,mask

def try_size(algo, X, y, P, mask, k, seed=42):
    """Test if algo runs on this size without OOM."""
    try:
        np.random.seed(seed)
        if algo == "K-means":
            KMeans(n_clusters=k, n_init=1, random_state=seed).fit(X)
        elif algo == "FCM":
            FCM(n_clusters=k, m=2.0, max_iter=2, random_state=seed).fit(X)
        elif algo == "KFCM":
            KFCM_bl(n_clusters=k, m=2.0, gamma=0.1, max_iter=2, random_state=seed).fit(X)
        elif algo == "SFCM":
            SFCM(n_clusters=k, m=2.0, lam=1.0, max_iter=2, random_state=seed).fit(X,P=P,constraint_mask=mask)
        elif algo == "CEFCM":
            CEFCM(n_clusters=k, m=2.0, contrast_weight=0.5, max_iter=2, random_state=seed).fit(X,P=P,constraint_mask=mask)
        elif algo == "FCPL":
            FCPL(n_clusters=k, m=2.0, lam=5.0, max_iter=2, random_state=seed).fit(X,P=P,constraint_mask=mask)
        elif algo == "KFCPL":
            KFCPL(n_clusters=k, m=2.0, lam=5.0, gamma=0.1, max_iter=2, random_state=seed).fit(X,P=P,constraint_mask=mask)
        return True
    except:
        return False

def run_algo(name, X, y, P, mask, seed, k):
    np.random.seed(seed)
    try:
        t0 = time.time()
        if name == "K-means":
            lab = KMeans(n_clusters=k, n_init=10, random_state=seed).fit(X).labels_
        elif name == "MBKMeans":
            lab = MiniBatchKMeans(n_clusters=k, n_init=3, random_state=seed).fit(X).labels_
        elif name == "FCM":
            lab = FCM(n_clusters=k, m=2.0, max_iter=50, random_state=seed).fit(X).labels_
        elif name == "KFCM":
            lab = KFCM_bl(n_clusters=k, m=2.0, gamma=0.1, max_iter=30, random_state=seed).fit(X).labels_
        elif name == "SFCM":
            m = SFCM(n_clusters=k, m=2.0, lam=1.0, max_iter=50, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        elif name == "CEFCM":
            m = CEFCM(n_clusters=k, m=2.0, contrast_weight=0.5, max_iter=50, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        elif name == "SSFCM":
            m = SSFCM(n_clusters=k, m=2.0, confidence_thresh=0.7, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        elif name == "FCPL":
            m = FCPL(n_clusters=k, m=2.0, lam=5.0, max_iter=50, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        elif name == "KFCPL":
            m = KFCPL(n_clusters=k, m=2.0, lam=5.0, gamma=0.1, max_iter=30, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        else: return None
        dt = time.time()-t0
        return (clustering_accuracy(y,lab)*100, nmi_score(y,lab)*100,
                ari_score(y,lab)*100, dt)
    except:
        return None

def load_real(name):
    print(f"Loading {name}...")
    if name == "Fashion-MNIST":
        d = fetch_openml('Fashion-MNIST', version=1, parser='auto')
        X = d.data.values.astype(float); y = d.target.astype(int).values
    elif name == "MNIST":
        d = fetch_openml('mnist_784', version=1, parser='auto')
        X = d.data.values.astype(float); y = d.target.astype(int).values
    elif name == "Shuttle":
        d = fetch_openml('shuttle', version=1, parser='auto')
        X = d.data.values.astype(float); y = LabelEncoder().fit_transform(d.target.astype(str))
    elif name == "Letter":
        d = fetch_openml('letter', version=1, parser='auto')
        X = d.data.values.astype(float); y = LabelEncoder().fit_transform(d.target.astype(str))
    X = StandardScaler().fit_transform(X)
    if X.shape[1] > 50:
        X = PCA(n_components=50, random_state=42).fit_transform(X)
    return X, y

def main():
    rows = []
    size_log = []
    ALGOS = ["K-means","MBKMeans","FCM","KFCM","SFCM","CEFCM","SSFCM","FCPL","KFCPL"]
    TEST_ALGOS = ["KFCM","KFCPL"]  # only kernel algos need size test

    for ds in ["Fashion-MNIST","Shuttle","Letter"]:
        try:
            X_full, y_full = load_real(ds)
        except Exception as e:
            print(f"Skip {ds}: {e}"); continue
        k = len(np.unique(y_full))
        print(f"\n=== {ds}: full n={len(y_full)}, d={X_full.shape[1]}, k={k} ===")

        # Auto-find max size that works for KFCM/KFCPL
        chosen_size = min(SIZES[-1], len(y_full))
        X_sub, y_sub = None, None
        for sz in SIZES:
            if sz > len(y_full): continue
            Xt, yt = stratified_sample(X_full, y_full, sz, seed=42)
            Pt, mt = make_con(yt, k, 0.10, 42)
            ok = all(try_size(a, Xt, yt, Pt, mt, k) for a in TEST_ALGOS)
            if ok:
                chosen_size = sz; X_sub, y_sub = Xt, yt
                print(f"  -> {sz} samples works")
                break
            else:
                print(f"  -> {sz} too large, trying smaller...")
        if X_sub is None:
            print(f"  SKIP {ds}")
            continue

        n = len(y_sub)
        size_log.append({"dataset":ds, "n_samples_used":n, "n_features":X_sub.shape[1],
                         "n_clusters":k, "source":"sklearn.fetch_openml"})

        for algo in ALGOS:
            accs,nmis,aris,times = [],[],[],[]
            for seed in SEEDS:
                P, mask = make_con(y_sub, k, 0.10, seed)
                res = run_algo(algo, X_sub, y_sub, P, mask, seed, k)
                if res is None: continue
                accs.append(res[0]); nmis.append(res[1]); aris.append(res[2]); times.append(res[3])
            if len(accs) < 3:
                rows.append({"dataset":ds,"algorithm":algo,"ACC_mean":"FAILED"})
                continue
            am,asd=np.mean(accs),np.std(accs,ddof=1); ac=T*asd/np.sqrt(5)
            nm,ns=np.mean(nmis),np.std(nmis,ddof=1); nc=T*ns/np.sqrt(5)
            rm,rs=np.mean(aris),np.std(aris,ddof=1); rc=T*rs/np.sqrt(5)
            tm = np.mean(times)
            rows.append({"dataset":ds,"n_samples":n,"n_features":X_sub.shape[1],"n_clusters":k,
                "algorithm":algo,"ACC_mean":round(am,2),"ACC_ci95":round(ac,2),
                "NMI_mean":round(nm,2),"NMI_ci95":round(nc,2),
                "ARI_mean":round(rm,2),"ARI_ci95":round(rc,2),
                "time_mean":round(tm,2),"n_runs":len(accs)})
            print(f"  {algo:10s}: ACC={am:6.2f}±{ac:5.2f} t={tm:.1f}s")

    pd.DataFrame(size_log).to_csv(OUT/"exp_large_scale_sample_sizes.csv", index=False)
    df = pd.DataFrame(rows)
    df.to_csv(OUT/"exp_large_scale_30k_auto.csv", index=False)
    print(f"\nSaved: {len(df)} rows")
    print(df[["dataset","algorithm","ACC_mean","time_mean"]].to_string(index=False))

if __name__=="__main__":
    main()
