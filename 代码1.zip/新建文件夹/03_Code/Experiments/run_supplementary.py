"""
Supplementary Experiments:
1. Additional UCI datasets (Ionosphere, Sonar, Ecoli, Yeast, Diabetes, Heart, Optdigits)
2. Synthetic fuzzy facial expression dataset with membership analysis
"""
import sys
import os
import numpy as np
import pandas as pd
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_constraint_samples
from code.utils.metrics import evaluate_clustering
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.models.baselines import FCM, KFCM, SFCM
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import fetch_openml, make_blobs

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(FIGURES_DIR, exist_ok=True)


def load_extra_uci(name, random_state=42, max_samples=None):
    """Load extra UCI datasets from OpenML."""
    print(f"  Loading {name}...")
    
    try:
        if name == 'ionosphere':
            data = fetch_openml(name='ionosphere', version=1, as_frame=False, parser='auto')
        elif name == 'sonar':
            data = fetch_openml(name='sonar', version=1, as_frame=False, parser='auto')
        elif name == 'ecoli':
            data = fetch_openml(name='ecoli', version=1, as_frame=False, parser='auto')
        elif name == 'yeast':
            data = fetch_openml(name='yeast', version=1, as_frame=False, parser='auto')
        elif name == 'diabetes':
            data = fetch_openml(name='diabetes', version=1, as_frame=False, parser='auto')
        elif name == 'heart':
            data = fetch_openml(name='heart-statlog', version=1, as_frame=False, parser='auto')
        elif name == 'optdigits':
            data = fetch_openml(name='optdigits', version=1, as_frame=False, parser='auto')
        elif name == 'magic':
            data = fetch_openml(name='magic.gamma.telescope', version=1, as_frame=False, parser='auto')
        else:
            raise ValueError(f"Unknown dataset: {name}")
        
        X = data.data
        y_raw = data.target
        
        # Convert labels to int
        unique_labels = np.unique(y_raw)
        label_map = {l: i for i, l in enumerate(unique_labels)}
        y = np.array([label_map[l] for l in y_raw])
        
    except Exception as e:
        print(f"    OpenML failed: {e}, using synthetic data...")
        # Fallback: generate synthetic
        n = {'ionosphere': 351, 'sonar': 208, 'ecoli': 336, 'yeast': 1484,
             'diabetes': 768, 'heart': 303, 'optdigits': 5620, 'magic': 5000}.get(name, 1000)
        n_f = {'ionosphere': 34, 'sonar': 60, 'ecoli': 7, 'yeast': 8,
               'diabetes': 8, 'heart': 13, 'optdigits': 64, 'magic': 10}.get(name, 20)
        n_c = {'ionosphere': 2, 'sonar': 2, 'ecoli': 8, 'yeast': 10,
               'diabetes': 2, 'heart': 2, 'optdigits': 10, 'magic': 2}.get(name, 3)
        X, y = make_blobs(n_samples=n, n_features=n_f, centers=n_c, random_state=random_state)
    
    # Handle NaN
    if np.any(np.isnan(X)):
        X = np.nan_to_num(X, nan=0.0)
    
    # Subsample if needed
    if max_samples and len(X) > max_samples:
        rng = np.random.RandomState(random_state)
        idx = rng.choice(len(X), max_samples, replace=False)
        X, y = X[idx], y[idx]
    
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    n_clusters = len(np.unique(y))
    
    print(f"    {X.shape[0]} samples, {X.shape[1]} features, {n_clusters} classes")
    return X, y, n_clusters


def run_all_methods(X, y, n_clusters, label_ratio=0.1, n_repeats=5):
    """Run all 7 methods, return results dict."""
    methods = ['K-means', 'PCAKM', 'FCM', 'KFCM', 'SFCM', 'FCPL', 'KFCPL']
    results = {m: {'ACC': [], 'NMI': [], 'ARI': [], 'F1': []} for m in methods}
    
    n = len(X)
    # KFCM/KFCPL subset if large
    kernel_max = min(n, 5000)
    rng = np.random.RandomState(42)
    k_idx = rng.choice(n, kernel_max, replace=False) if n > kernel_max else np.arange(n)
    X_k, y_k = X[k_idx], y[k_idx]
    
    from sklearn.decomposition import PCA
    
    for rep in range(n_repeats):
        rs = 42 + rep
        _, P, cm = get_constraint_samples(y, label_ratio, rs)
        _, P_k, cm_k = get_constraint_samples(y_k, label_ratio, rs)
        
        # K-means
        km = KMeans(n_clusters=n_clusters, random_state=rs, n_init=10)
        labels = km.fit_predict(X)
        res = evaluate_clustering(y, labels)
        for k in ['ACC', 'NMI', 'ARI', 'F1']:
            results['K-means'][k].append(res[k])
        
        # PCAKM
        n_comp = min(n_clusters*3, X.shape[1], n-1)
        pca = PCA(n_components=n_comp, random_state=rs)
        X_pca = pca.fit_transform(X)
        km2 = KMeans(n_clusters=n_clusters, random_state=rs, n_init=10)
        labels2 = km2.fit_predict(X_pca)
        res = evaluate_clustering(y, labels2)
        for k in ['ACC', 'NMI', 'ARI', 'F1']:
            results['PCAKM'][k].append(res[k])
        
        # FCM
        fcm = FCM(n_clusters=n_clusters, random_state=rs)
        fcm.fit(X)
        res = evaluate_clustering(y, fcm.labels_)
        for k in ['ACC', 'NMI', 'ARI', 'F1']:
            results['FCM'][k].append(res[k])
        
        # KFCM (subset)
        kfcm = KFCM(n_clusters=n_clusters, gamma=1.0, random_state=rs)
        kfcm.fit(X_k)
        res = evaluate_clustering(y_k, kfcm.labels_)
        for k in ['ACC', 'NMI', 'ARI', 'F1']:
            results['KFCM'][k].append(res[k])
        
        # SFCM
        sfcm = SFCM(n_clusters=n_clusters, random_state=rs)
        sfcm.fit(X, P, cm)
        res = evaluate_clustering(y, sfcm.labels_)
        for k in ['ACC', 'NMI', 'ARI', 'F1']:
            results['SFCM'][k].append(res[k])
        
        # FCPL
        fcpl = FCPL(n_clusters=n_clusters, lam=1.0, random_state=rs)
        fcpl.fit(X, P, cm)
        res = evaluate_clustering(y, fcpl.labels_)
        for k in ['ACC', 'NMI', 'ARI', 'F1']:
            results['FCPL'][k].append(res[k])
        
        # KFCPL (subset)
        kfcpl = KFCPL(n_clusters=n_clusters, lam=1.0, gamma=1.0, random_state=rs)
        kfcpl.fit(X_k, P_k, cm_k)
        res = evaluate_clustering(y_k, kfcpl.labels_)
        for k in ['ACC', 'NMI', 'ARI', 'F1']:
            results['KFCPL'][k].append(res[k])
    
    return results


# ============================================================
# Facial Expression Dataset with Fuzzy Membership
# ============================================================

def generate_fuzzy_face_expression(n_samples=500, n_features=64, n_emotions=6, random_state=42):
    """
    Generate synthetic facial expression data with fuzzy (composite) labels.
    Clusters are intentionally overlapping to simulate real facial expression data,
    where emotions are not perfectly separable.
    
    Emotions: Anger, Disgust, Fear, Happy, Sad, Surprise
    Each sample has fuzzy memberships: dominant emotion 0.5-0.8, 
    secondary emotions 0.1-0.3 each.
    """
    rng = np.random.RandomState(random_state)
    
    # Generate overlapping cluster centers (closer together = harder clustering problem)
    centers = rng.randn(n_emotions, n_features) * 1.5
    
    X_list, y_hard_list, P_fuzzy_list = [], [], []
    
    emotion_names = ['Anger', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise']
    
    for i in range(n_samples):
        # Assign dominant emotion
        dom_emotion = rng.randint(0, n_emotions)
        
        # Generate sample near dominant center with high overlap noise
        x = centers[dom_emotion] + rng.randn(n_features) * 1.2
        
        # Create fuzzy membership
        # Dominant: 0.5-0.8
        dom_membership = rng.uniform(0.5, 0.8)
        
        # Pick 1-2 secondary emotions
        n_secondary = rng.randint(1, 3)
        secondary_emotions = rng.choice(
            [e for e in range(n_emotions) if e != dom_emotion], 
            size=n_secondary, replace=False
        )
        
        fuzzy_p = np.zeros(n_emotions)
        fuzzy_p[dom_emotion] = dom_membership
        
        remaining = 1.0 - dom_membership
        if n_secondary > 0:
            sec_weights = rng.dirichlet(np.ones(n_secondary)) * remaining
            for j, e in enumerate(secondary_emotions):
                fuzzy_p[e] = sec_weights[j]
        else:
            fuzzy_p[dom_emotion] = 1.0
        
        X_list.append(x)
        y_hard_list.append(dom_emotion)
        P_fuzzy_list.append(fuzzy_p)
    
    X = np.array(X_list)
    y = np.array(y_hard_list)
    P_fuzzy = np.array(P_fuzzy_list)
    
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    
    return X, y, P_fuzzy, n_emotions, emotion_names


def run_face_experiment():
    """Run facial expression experiment with fuzzy membership analysis."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    
    print("\n" + "=" * 60)
    print("Facial Expression Experiment (Fuzzy Membership)")
    print("=" * 60)
    
    X, y, P_fuzzy, n_emotions, emotion_names = generate_fuzzy_face_expression(
        n_samples=500, n_features=64, n_emotions=6, random_state=42)
    
    print(f"  Data: {X.shape[0]} samples, {X.shape[1]} features, {n_emotions} emotions")
    
    # Create constraint mask (20% labeled, with fuzzy membership)
    n_constrained = int(0.2 * len(y))
    rng = np.random.RandomState(42)
    constraint_idx = rng.choice(len(y), n_constrained, replace=False)
    constraint_mask = np.zeros(len(y), dtype=bool)
    constraint_mask[constraint_idx] = True
    
    # Run methods
    results = {}
    
    # 1. FCM (unsupervised)
    fcm = FCM(n_clusters=n_emotions, random_state=42)
    fcm.fit(X)
    results['FCM'] = evaluate_clustering(y, fcm.labels_)
    
    # 2. SFCM (hard labels as constraints)
    P_hard = np.zeros_like(P_fuzzy)
    P_hard[np.arange(len(y)), y] = 1.0
    sfcm = SFCM(n_clusters=n_emotions, random_state=42)
    sfcm.fit(X, P_hard, constraint_mask)
    results['SFCM_hard'] = evaluate_clustering(y, sfcm.labels_)
    
    # 3. FCPL with HARD prior
    fcpl_hard = FCPL(n_clusters=n_emotions, lam=1.0, random_state=42)
    fcpl_hard.fit(X, P_hard, constraint_mask)
    results['FCPL_hard'] = evaluate_clustering(y, fcpl_hard.labels_)
    
    # 4. FCPL with FUZZY prior (key advantage!)
    fcpl_fuzzy = FCPL(n_clusters=n_emotions, lam=1.0, random_state=42)
    fcpl_fuzzy.fit(X, P_fuzzy, constraint_mask)
    results['FCPL_fuzzy'] = evaluate_clustering(y, fcpl_fuzzy.labels_)
    
    # 5. KFCPL with fuzzy prior
    kfcpl = KFCPL(n_clusters=n_emotions, lam=1.0, gamma=0.5, random_state=42)
    kfcpl.fit(X, P_fuzzy, constraint_mask)
    results['KFCPL_fuzzy'] = evaluate_clustering(y, kfcpl.labels_)
    
    print("\n  Results:")
    for method, res in results.items():
        print(f"    {method:15s}: ACC={res['ACC']:.2f}%, NMI={res['NMI']:.2f}%, ARI={res['ARI']:.2f}%")
    
    # ---- Membership radar chart ----
    print("\n  Generating membership radar charts...")
    
    # Select 6 representative constrained samples
    rep_idx = constraint_idx[:6]
    
    fig, axes = plt.subplots(2, 3, figsize=(15, 10), subplot_kw=dict(polar=True))
    axes = axes.flatten()
    
    angles = np.linspace(0, 2*np.pi, n_emotions, endpoint=False).tolist()
    angles += angles[:1]
    
    for i, idx in enumerate(rep_idx):
        ax = axes[i]
        
        # True fuzzy prior
        true_p = P_fuzzy[idx].tolist()
        true_p += true_p[:1]
        ax.plot(angles, true_p, 'g-o', linewidth=2, label='True prior')
        ax.fill(angles, true_p, alpha=0.2, color='green')
        
        # FCM membership (unsupervised)
        fcm_u = fcm.U_[idx].tolist()
        fcm_u += fcm_u[:1]
        ax.plot(angles, fcm_u, 'b--s', linewidth=1.5, label='FCM')
        
        # FCPL membership (fuzzy prior)
        fcpl_u = fcpl_fuzzy.U_[idx].tolist()
        fcpl_u += fcpl_u[:1]
        ax.plot(angles, fcpl_u, 'r-^', linewidth=2, label='FCPL (fuzzy)')
        
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(emotion_names, fontsize=8)
        ax.set_title(f'Sample {idx} (true: {emotion_names[y[idx]]})', fontsize=10)
        ax.set_ylim(0, 1)
    
    axes[0].legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=8)
    plt.suptitle('Membership Radar Charts: FCM vs FCPL on Facial Expression Data', fontsize=14)
    plt.tight_layout()
    plt.savefig(os.path.join(FIGURES_DIR, 'exp_face_membership_radar.png'), dpi=300, bbox_inches='tight')
    plt.savefig(os.path.join(FIGURES_DIR, 'exp_face_membership_radar.svg'), bbox_inches='tight')
    plt.close()
    
    # ---- t-SNE visualization ----
    print("  Generating t-SNE visualization...")
    from sklearn.manifold import TSNE
    
    tsne = TSNE(n_components=2, random_state=42, perplexity=30)
    X_2d = tsne.fit_transform(X)
    
    fig, axes = plt.subplots(1, 4, figsize=(20, 5))
    
    # Ground truth
    for c in range(n_emotions):
        mask = y == c
        axes[0].scatter(X_2d[mask, 0], X_2d[mask, 1], s=20, alpha=0.7, label=emotion_names[c])
    axes[0].set_title('Ground Truth (hard)')
    axes[0].legend(fontsize=7)
    
    # FCM
    for c in range(n_emotions):
        mask = fcm.labels_ == c
        axes[1].scatter(X_2d[mask, 0], X_2d[mask, 1], s=20, alpha=0.7)
    axes[1].set_title('FCM (unsupervised)')
    
    # FCPL hard
    for c in range(n_emotions):
        mask = fcpl_hard.labels_ == c
        axes[2].scatter(X_2d[mask, 0], X_2d[mask, 1], s=20, alpha=0.7)
    axes[2].set_title('FCPL (hard prior)')
    
    # FCPL fuzzy
    for c in range(n_emotions):
        mask = fcpl_fuzzy.labels_ == c
        axes[3].scatter(X_2d[mask, 0], X_2d[mask, 1], s=20, alpha=0.7)
    # Mark constrained samples
    axes[3].scatter(X_2d[constraint_mask, 0], X_2d[constraint_mask, 1],
                   c='black', marker='x', s=40, linewidths=1.5, zorder=5)
    axes[3].set_title('FCPL (fuzzy prior)')
    
    plt.suptitle('Facial Expression Clustering: t-SNE Visualization', fontsize=14)
    plt.tight_layout()
    plt.savefig(os.path.join(FIGURES_DIR, 'exp_face_tsne.png'), dpi=300, bbox_inches='tight')
    plt.savefig(os.path.join(FIGURES_DIR, 'exp_face_tsne.svg'), bbox_inches='tight')
    plt.close()
    
    # Save results
    rows = []
    for method, res in results.items():
        rows.append({
            'Method': method,
            'ACC': res['ACC'],
            'NMI': res['NMI'],
            'ARI': res['ARI'],
            'F1': res['F1'],
        })
    
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESULTS_DIR, 'exp_extra_face.csv'), index=False)
    
    print(f"\n  Face experiment results saved.")
    return df, results


# ============================================================
# Main
# ============================================================

def main():
    print("=" * 60)
    print("Supplementary Experiments: Extra UCI + Facial Expression")
    print("=" * 60)
    
    # Part 1: Extra UCI datasets
    extra_datasets = ['ionosphere', 'sonar', 'ecoli', 'yeast', 'diabetes', 'heart', 'optdigits']
    
    all_rows = []
    
    for ds_name in extra_datasets:
        print(f"\n--- UCI Dataset: {ds_name} ---")
        max_s = 5000 if ds_name == 'magic' or ds_name == 'optdigits' else None
        X, y, n_clusters = load_extra_uci(ds_name, max_samples=max_s)
        
        results = run_all_methods(X, y, n_clusters, label_ratio=0.1, n_repeats=5)
        
        for method, metrics in results.items():
            row = {
                'Dataset': ds_name,
                'Algorithm': method,
                'ACC_mean': np.mean(metrics['ACC']),
                'ACC_std': np.std(metrics['ACC']),
                'NMI_mean': np.mean(metrics['NMI']),
                'ARI_mean': np.mean(metrics['ARI']),
                'F1_mean': np.mean(metrics['F1']),
            }
            all_rows.append(row)
        
        # Print summary
        print(f"  Summary (ACC%):")
        for method in ['K-means', 'FCM', 'SFCM', 'FCPL', 'KFCPL']:
            print(f"    {method:10s}: {np.mean(results[method]['ACC']):.2f} ± {np.std(results[method]['ACC']):.2f}")
    
    df_uci = pd.DataFrame(all_rows)
    df_uci.to_csv(os.path.join(RESULTS_DIR, 'exp_extra_uci.csv'), index=False)
    print(f"\nExtra UCI results saved: {len(all_rows)} rows")
    
    # Part 2: Facial expression
    df_face, face_results = run_face_experiment()
    
    print("\n\nAll supplementary experiments completed!")


if __name__ == '__main__':
    main()
