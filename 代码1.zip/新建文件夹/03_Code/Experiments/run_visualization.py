"""
Experiment 7: Clustering visualization with t-SNE.
Visualize clustering results on 3+ datasets.
"""
import sys
import os
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_dataset, get_constraint_samples
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.models.baselines import FCM
from sklearn.cluster import KMeans

FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')
os.makedirs(FIGURES_DIR, exist_ok=True)


def run_visualization():
    """Generate t-SNE visualization of clustering results."""
    
    datasets = ['iris', 'wine', 'moons']
    
    print("=" * 60)
    print("Experiment 7: Clustering Visualization (t-SNE)")
    print("=" * 60)
    
    try:
        from sklearn.manifold import TSNE
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        print("Required packages not available for visualization")
        return
    
    methods = ['K-means', 'FCM', 'FCPL', 'KFCPL']
    colors = ['#e41a1c', '#377eb8', '#4daf4a', '#984ea3', '#ff7f00', 
              '#ffff33', '#a65628', '#f781bf', '#999999', '#66c2a5']
    
    for ds_name in datasets:
        print(f"\n--- Dataset: {ds_name} ---")
        X, y, n_clusters = get_dataset(ds_name, random_state=42)
        _, P, constraint_mask = get_constraint_samples(y, 0.1, 42)
        
        # t-SNE embedding
        print("  Computing t-SNE embedding...")
        tsne = TSNE(n_components=2, random_state=42, perplexity=30)
        X_2d = tsne.fit_transform(X)
        
        # Run all methods
        results = {}
        
        # K-means
        km = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        results['K-means'] = km.fit_predict(X)
        
        # FCM
        fcm = FCM(n_clusters=n_clusters, random_state=42)
        fcm.fit(X)
        results['FCM'] = fcm.labels_
        
        # FCPL
        fcpl = FCPL(n_clusters=n_clusters, lam=1.0, random_state=42)
        fcpl.fit(X, P, constraint_mask)
        results['FCPL'] = fcpl.labels_
        
        # KFCPL
        kfcpl = KFCPL(n_clusters=n_clusters, lam=1.0, gamma=1.0, random_state=42)
        kfcpl.fit(X, P, constraint_mask)
        results['KFCPL'] = kfcpl.labels_
        
        # Plot
        fig, axes = plt.subplots(1, 5, figsize=(20, 4))
        
        # Ground truth
        for c in range(n_clusters):
            mask = y == c
            axes[0].scatter(X_2d[mask, 0], X_2d[mask, 1], c=[colors[c]], 
                          s=15, alpha=0.7, label=f'C{c}')
        axes[0].set_title('Ground Truth', fontsize=12)
        axes[0].set_xticks([])
        axes[0].set_yticks([])
        
        for ax_idx, method in enumerate(methods):
            labels = results[method]
            for c in range(n_clusters):
                mask = labels == c
                axes[ax_idx+1].scatter(X_2d[mask, 0], X_2d[mask, 1], c=[colors[c]],
                                      s=15, alpha=0.7)
            # Mark constrained samples with X
            axes[ax_idx+1].scatter(X_2d[constraint_mask, 0], X_2d[constraint_mask, 1],
                                  c='black', marker='x', s=30, linewidths=1.5, zorder=5)
            axes[ax_idx+1].set_title(method, fontsize=12)
            axes[ax_idx+1].set_xticks([])
            axes[ax_idx+1].set_yticks([])
        
        plt.suptitle(f'Clustering Visualization on {ds_name}', fontsize=14, y=1.02)
        plt.tight_layout()
        plt.savefig(os.path.join(FIGURES_DIR, f'exp7_visualization_{ds_name}.png'), 
                   dpi=300, bbox_inches='tight')
        plt.savefig(os.path.join(FIGURES_DIR, f'exp7_visualization_{ds_name}.svg'), 
                   bbox_inches='tight')
        plt.close()
        print(f"  Saved visualization for {ds_name}")
    
    print("\nVisualization complete.")


if __name__ == '__main__':
    run_visualization()
