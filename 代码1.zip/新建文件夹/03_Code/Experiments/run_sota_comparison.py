"""
Experiment 1: SOTA comparison on benchmark datasets.
Compares FCPL/KFCPL against multiple baselines on UCI and image datasets.
Each experiment repeated 10 times, reports mean ± std.
"""
import sys
import os
import time
import numpy as np
import pandas as pd

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_dataset, get_constraint_samples
from code.utils.metrics import evaluate_clustering
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.models.baselines import FCM, KFCM, SFCM, run_kmeans, run_pcakm, ContraClust, CDRSC, SimplifiedDeepSC

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
os.makedirs(RESULTS_DIR, exist_ok=True)


def run_single_experiment(X, y, n_clusters, label_ratio=0.1, random_state=42):
    """
    Run all algorithms on a single dataset.
    Returns dict of results.
    """
    # Get constraint samples
    _, P, constraint_mask = get_constraint_samples(y, label_ratio, random_state)
    
    results = {}
    
    # 1. K-means
    t0 = time.time()
    labels_km, _ = run_kmeans(X, n_clusters, random_state)
    results['K-means'] = evaluate_clustering(y, labels_km)
    results['K-means']['time'] = time.time() - t0
    
    # 2. PCAKM
    t0 = time.time()
    labels_pcakm = run_pcakm(X, n_clusters, random_state)
    results['PCAKM'] = evaluate_clustering(y, labels_pcakm)
    results['PCAKM']['time'] = time.time() - t0
    
    # 3. FCM
    t0 = time.time()
    fcm = FCM(n_clusters=n_clusters, m=2.0, max_iter=100, tol=1e-5, random_state=random_state)
    fcm.fit(X)
    results['FCM'] = evaluate_clustering(y, fcm.labels_)
    results['FCM']['time'] = time.time() - t0
    
    # 4. KFCM
    t0 = time.time()
    kfcm = KFCM(n_clusters=n_clusters, m=2.0, gamma=1.0, max_iter=100, tol=1e-5, random_state=random_state)
    kfcm.fit(X)
    results['KFCM'] = evaluate_clustering(y, kfcm.labels_)
    results['KFCM']['time'] = time.time() - t0
    
    # 5. SFCM (semi-supervised FCM)
    t0 = time.time()
    sfcm = SFCM(n_clusters=n_clusters, m=2.0, lam=1.0, max_iter=100, tol=1e-5, random_state=random_state)
    sfcm.fit(X, P, constraint_mask)
    results['SFCM'] = evaluate_clustering(y, sfcm.labels_)
    results['SFCM']['time'] = time.time() - t0
    
    # 6. CDRSC (simplified)
    t0 = time.time()
    cdrsc = CDRSC(n_clusters=n_clusters, random_state=random_state)
    cdrsc.fit(X, P, constraint_mask)
    results['CDRSC'] = evaluate_clustering(y, cdrsc.labels_)
    results['CDRSC']['time'] = time.time() - t0
    
    # 7. ContraClust (simplified)
    t0 = time.time()
    cc = ContraClust(n_clusters=n_clusters, random_state=random_state)
    cc.fit(X, P, constraint_mask)
    results['ContraClust'] = evaluate_clustering(y, cc.labels_)
    results['ContraClust']['time'] = time.time() - t0
    
    # 8. FCPL (proposed)
    t0 = time.time()
    fcpl = FCPL(n_clusters=n_clusters, m=2.0, lam=1.0, max_iter=100, tol=1e-5, 
                solver='mes', random_state=random_state)
    fcpl.fit(X, P, constraint_mask)
    results['FCPL'] = evaluate_clustering(y, fcpl.labels_)
    results['FCPL']['time'] = time.time() - t0
    
    # 9. KFCPL (proposed)
    t0 = time.time()
    kfcpl = KFCPL(n_clusters=n_clusters, m=2.0, lam=1.0, gamma=1.0, 
                  max_iter=100, tol=1e-5, random_state=random_state)
    kfcpl.fit(X, P, constraint_mask)
    results['KFCPL'] = evaluate_clustering(y, kfcpl.labels_)
    results['KFCPL']['time'] = time.time() - t0
    
    return results


def run_sota_comparison(n_repeats=10):
    """
    Run SOTA comparison on all datasets.
    """
    # UCI datasets
    uci_datasets = ['iris', 'wine', 'breast_cancer', 'glass', 'seeds', 
                    'balance', 'vehicle', 'segment']
    
    # For efficiency, use smaller datasets for repeated runs
    # Use a subset for 10 repeats, then large datasets once
    small_datasets = ['iris', 'wine', 'breast_cancer', 'glass', 'seeds', 'balance']
    large_datasets = ['vehicle', 'segment']
    
    all_results = {}
    
    print("=" * 60)
    print("Experiment 1: SOTA Comparison on Benchmark Datasets")
    print("=" * 60)
    
    # Small datasets: 10 repeats
    for ds_name in small_datasets:
        print(f"\n--- Dataset: {ds_name} ---")
        X, y, n_clusters = get_dataset(ds_name, random_state=42)
        print(f"  Samples: {X.shape[0]}, Features: {X.shape[1]}, Clusters: {n_clusters}")
        
        repeat_results = []
        for rep in range(n_repeats):
            rs = 42 + rep
            try:
                res = run_single_experiment(X, y, n_clusters, label_ratio=0.1, random_state=rs)
                repeat_results.append(res)
                print(f"  Rep {rep+1}/{n_repeats}: FCPL ACC={res['FCPL']['ACC']:.2f}%, KFCPL ACC={res['KFCPL']['ACC']:.2f}%")
            except Exception as e:
                print(f"  Rep {rep+1} failed: {e}")
                continue
        
        all_results[ds_name] = repeat_results
    
    # Large datasets: 3 repeats (time constraint)
    for ds_name in large_datasets:
        print(f"\n--- Dataset: {ds_name} (3 repeats) ---")
        X, y, n_clusters = get_dataset(ds_name, random_state=42)
        print(f"  Samples: {X.shape[0]}, Features: {X.shape[1]}, Clusters: {n_clusters}")
        
        repeat_results = []
        for rep in range(3):
            rs = 42 + rep
            try:
                res = run_single_experiment(X, y, n_clusters, label_ratio=0.1, random_state=rs)
                repeat_results.append(res)
                print(f"  Rep {rep+1}/3: FCPL ACC={res['FCPL']['ACC']:.2f}%")
            except Exception as e:
                print(f"  Rep {rep+1} failed: {e}")
                continue
        
        all_results[ds_name] = repeat_results
    
    # Compile results into summary table
    rows = []
    algorithms = ['K-means', 'PCAKM', 'FCM', 'KFCM', 'SFCM', 'CDRSC', 'ContraClust', 'FCPL', 'KFCPL']
    metrics = ['ACC', 'NMI', 'ARI', 'F1']
    
    for ds_name, repeats in all_results.items():
        if len(repeats) == 0:
            continue
        for alg in algorithms:
            row = {'Dataset': ds_name, 'Algorithm': alg}
            for metric in metrics:
                vals = [r[alg][metric] for r in repeats if alg in r]
                if len(vals) > 0:
                    row[f'{metric}_mean'] = np.mean(vals)
                    row[f'{metric}_std'] = np.std(vals)
            # Average time
            times = [r[alg]['time'] for r in repeats if alg in r]
            if len(times) > 0:
                row['time_mean'] = np.mean(times)
            rows.append(row)
    
    df = pd.DataFrame(rows)
    csv_path = os.path.join(RESULTS_DIR, 'exp1_sota_comparison.csv')
    df.to_csv(csv_path, index=False)
    print(f"\nResults saved to: {csv_path}")
    
    # Print summary
    print("\n" + "=" * 80)
    print("SOTA Comparison Summary (ACC %, mean±std)")
    print("=" * 80)
    for ds_name in all_results.keys():
        print(f"\n{ds_name}:")
        ds_df = df[df['Dataset'] == ds_name]
        for _, row in ds_df.iterrows():
            print(f"  {row['Algorithm']:15s}: {row['ACC_mean']:.2f}±{row['ACC_std']:.2f}")
    
    return all_results, df


if __name__ == '__main__':
    results, df = run_sota_comparison(n_repeats=10)
