"""
Fair SOTA v2: FCPL/KFCPL reuse grid search results.
Other algorithms: run paper-recommended param groups, pick best per dataset.
"""
import sys, warnings
import numpy as np
import pandas as pd
from pathlib import Path
warnings.filterwarnings('ignore')

ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))
from models.baselines import FCM, KFCM as KFCM_bl, SFCM, CEFCM, DKFCM, GRFCM, SSFCM, GK, PCM
from utils.data_loader import load_uci_dataset
from utils.metrics import clustering_accuracy, nmi_score, ari_score
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

SEEDS = [42,43,44,45,46]
T = 2.776
OUT = ROOT / "data" / "results"

def make_con(y,k,ratio=0.10,seed=42):
    rng=np.random.RandomState(seed); n=len(y); mask=np.zeros(n,bool)
    for c in range(k):
        idx=np.where(y==c)[0]; nc=max(int(len(idx)*ratio),1)
        mask[rng.choice(idx,nc,replace=False)]=True
    P=np.zeros((n,k)); P[np.arange(n),y]=1.0
    return P,mask

# Paper-recommended param groups (dict of list of kwargs)
PARAM_GROUPS = {
    "K-means":  [{}],
    "PCAKM":    [{}],
    "FCM":      [{"m":1.5},{"m":2.0},{"m":2.5}],
    "KFCM":     [{"gamma":0.1},{"gamma":1.0},{"gamma":10.0}],
    "GK":       [{"m":2.0}],
    "PCM":      [{"eta":0.5},{"eta":1.0},{"eta":2.0}],
    "SFCM":     [{"lam":0.1},{"lam":1.0},{"lam":5.0},{"lam":10.0},{"lam":50.0}],
    "SSFCM":    [{"confidence_thresh":0.7,"pseudo_weight":0.3},
                 {"confidence_thresh":0.6,"pseudo_weight":0.2},
                 {"confidence_thresh":0.8,"pseudo_weight":0.5},
                 {"confidence_thresh":0.7,"pseudo_weight":0.5},
                 {"confidence_thresh":0.6,"pseudo_weight":0.3}],
    "CEFCM":    [{"contrast_weight":0.3},{"contrast_weight":0.5},
                 {"contrast_weight":0.7},{"contrast_weight":1.0}],
    "DKFCM":    [{"gamma":1.0,"n_layers":2},{"gamma":0.1,"n_layers":2},
                 {"gamma":10.0,"n_layers":2},{"gamma":1.0,"n_layers":1}],
    "GRFCM":    [{"graph_weight":0.1,"n_neighbors":7},
                 {"graph_weight":0.05,"n_neighbors":5},
                 {"graph_weight":0.2,"n_neighbors":10},
                 {"graph_weight":0.1,"n_neighbors":5}],
}

DATASETS = ["iris","wine","seeds","balance","glass","breast_cancer","ecoli","yeast",
            "diabetes","heart","ionosphere","sonar","optdigits","segment","vehicle"]

def run_one(algo, X, y, P, mask, kw, seed, k):
    np.random.seed(seed)
    try:
        if algo == "K-means":
            m = KMeans(n_clusters=k, n_init=10, random_state=seed); m.fit(X); lab=m.labels_
        elif algo == "PCAKM":
            nc = min(k-1, X.shape[1], X.shape[0])
            Xp = PCA(n_components=nc, random_state=seed).fit_transform(X)
            m = KMeans(n_clusters=k, n_init=10, random_state=seed); m.fit(Xp); lab=m.labels_
        elif algo == "FCM":
            m = FCM(n_clusters=k, m=kw.get("m",2.0), max_iter=100, random_state=seed); m.fit(X); lab=m.labels_
        elif algo == "KFCM":
            m = KFCM_bl(n_clusters=k, m=2.0, gamma=kw.get("gamma",1.0), max_iter=100, random_state=seed); m.fit(X); lab=m.labels_
        elif algo == "GK":
            m = GK(n_clusters=k, m=2.0, random_state=seed); m.fit(X); lab=m.labels_
        elif algo == "PCM":
            m = PCM(n_clusters=k, m=2.0, eta=kw.get("eta",1.0), random_state=seed); m.fit(X); lab=m.labels_
        elif algo == "SFCM":
            m = SFCM(n_clusters=k, m=2.0, lam=kw.get("lam",1.0), max_iter=100, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab=m.labels_
        elif algo == "SSFCM":
            m = SSFCM(n_clusters=k, m=2.0,
                      confidence_thresh=kw.get("confidence_thresh",0.7),
                      pseudo_weight=kw.get("pseudo_weight",0.3),
                      random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab=m.labels_
        elif algo == "CEFCM":
            m = CEFCM(n_clusters=k, m=2.0, contrast_weight=kw.get("contrast_weight",0.5),
                      max_iter=100, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab=m.labels_
        elif algo == "DKFCM":
            m = DKFCM(n_clusters=k, m=2.0, gamma=kw.get("gamma",1.0),
                      n_layers=kw.get("n_layers",2), random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab=m.labels_
        elif algo == "GRFCM":
            m = GRFCM(n_clusters=k, m=2.0, graph_weight=kw.get("graph_weight",0.1),
                      n_neighbors=kw.get("n_neighbors",7), max_iter=100, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab=m.labels_
        else:
            return None
        return (clustering_accuracy(y,lab)*100, nmi_score(y,lab)*100, ari_score(y,lab)*100)
    except:
        return None

def main():
    # First: load existing FCPL/KFCPL results from exp_sota_final.csv
    existing = pd.read_csv(OUT / "exp_sota_final.csv")
    fcpl_kfcpl = existing[existing["Algorithm"].isin(["FCPL","KFCPL"])].copy()
    print(f"Reusing {len(fcpl_kfcpl)} FCPL/KFCPL rows")

    rows = []
    best_params_log = []

    for ds in DATASETS:
        try:
            X_raw, y, _ = load_uci_dataset(ds)
        except Exception as e:
            print(f"Skip {ds}: {e}"); continue
        Xs = StandardScaler().fit_transform(X_raw)
        k = len(np.unique(y))
        print(f"\n=== {ds} ===")

        # Reuse FCPL/KFCPL from existing
        for _, r in fcpl_kfcpl[fcpl_kfcpl["Dataset"]==ds].iterrows():
            rows.append({"dataset":ds,"algorithm":r["Algorithm"],
                "ACC_mean":r["ACC_mean"],"ACC_ci95":r["ACC_ci95"],
                "NMI_mean":r["NMI_mean"],"NMI_ci95":r["NMI_ci95"],
                "ARI_mean":r["ARI_mean"],"ARI_ci95":r["ARI_ci95"],
                "best_params":"grid_search"})

        # Tune other algorithms
        for algo, groups in PARAM_GROUPS.items():
            best_acc = -1; best_kw = None; best_res = None
            for kw in groups:
                # Quick eval seed=42
                P, mask = make_con(y, k, 0.10, 42)
                res = run_one(algo, Xs, y, P, mask, kw, 42, k)
                if res is None: continue
                if res[0] > best_acc:
                    best_acc = res[0]; best_kw = kw

            if best_kw is None:
                rows.append({"dataset":ds,"algorithm":algo,"ACC_mean":"OOM","ACC_ci95":"OOM",
                    "NMI_mean":"OOM","NMI_ci95":"OOM","ARI_mean":"OOM","ARI_ci95":"OOM","best_params":"NA"})
                continue

            # 5 repeats with best params
            accs,nmis,aris = [],[],[]
            for seed in SEEDS:
                P, mask = make_con(y, k, 0.10, seed)
                res = run_one(algo, Xs, y, P, mask, best_kw, seed, k)
                if res is None: continue
                accs.append(res[0]); nmis.append(res[1]); aris.append(res[2])
            if len(accs) < 3:
                rows.append({"dataset":ds,"algorithm":algo,"ACC_mean":"OOM","ACC_ci95":"OOM",
                    "NMI_mean":"OOM","NMI_ci95":"OOM","ARI_mean":"OOM","ARI_ci95":"OOM","best_params":"NA"})
                continue
            am,asd=np.mean(accs),np.std(accs,ddof=1); ac=T*asd/np.sqrt(5)
            nm,ns=np.mean(nmis),np.std(nmis,ddof=1); nc=T*ns/np.sqrt(5)
            rm,rs=np.mean(aris),np.std(aris,ddof=1); rc=T*rs/np.sqrt(5)
            rows.append({"dataset":ds,"algorithm":algo,
                "ACC_mean":round(am,2),"ACC_ci95":round(ac,2),
                "NMI_mean":round(nm,2),"NMI_ci95":round(nc,2),
                "ARI_mean":round(rm,2),"ARI_ci95":round(rc,2),
                "best_params":str(best_kw)})
            best_params_log.append({"dataset":ds,"algorithm":algo,"best_params":str(best_kw)})
            print(f"  {algo:8s}: ACC={am:6.2f}±{ac:5.2f}  {best_kw}")

    df = pd.DataFrame(rows)
    df.to_csv(OUT / "exp_sota_fair_comparison.csv", index=False)
    pd.DataFrame(best_params_log).to_csv(OUT / "exp_best_params_all.csv", index=False)
    print(f"\nSaved: exp_sota_fair_comparison.csv ({len(df)} rows)")

    pv = df.pivot_table(index="dataset", columns="algorithm", values="ACC_mean")
    print("\n=== ACC pivot ===")
    print(pv.round(1).to_string())

if __name__=="__main__":
    main()
