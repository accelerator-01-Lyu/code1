"""
Strict MES vs QP verification.
Both solvers solve the IDENTICAL FCPL objective subproblem:
    min sum_k u_k^2 * d_k + lambda * sum_k (u_k - p_k)^2
    s.t. sum_k u_k = 1, u_k >= 0

MES: exact analytical KKT solution with active-set method.
QP: SLSQP numerical solver with tight tolerance.

Must produce identical U, labels, ACC. Only time/iterations differ.
"""
import sys, os, time
import numpy as np
import pandas as pd
from pathlib import Path

ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))

from models.fcpl import FCPL
from models.kfcpl import KFCPL
from models.mes import mes_solve_single, qp_solve_single
from utils.metrics import clustering_accuracy, nmi_score, ari_score
from utils.data_loader import load_uci_dataset as load_dataset
from sklearn.preprocessing import StandardScaler

SEED = 42
RATIO = 0.10
DATASETS = ["iris", "wine", "seeds", "balance", "glass"]

def make_constraints(y, n_clusters, ratio=RATIO, seed=SEED):
    """Make soft prior P and constraint mask from labels."""
    rng = np.random.RandomState(seed)
    n = len(y)
    idx = rng.choice(n, size=int(n * ratio), replace=False)
    mask = np.zeros(n, dtype=bool)
    mask[idx] = True
    P = np.zeros((n, n_clusters))
    P[np.arange(n), y] = 1.0
    # Soft prior: slight fuzziness for constrained samples
    for i in idx:
        P[i] *= 0.8
        P[i] += 0.2 / n_clusters
    return P, mask

def run_verification():
    rows = []
    for ds_name in DATASETS:
        print(f"\n=== {ds_name} ===")
        try:
            X, y, n_clusters = load_dataset(ds_name)
            scaler = StandardScaler()
            Xs = scaler.fit_transform(X)
        except Exception as e:
            print(f"  Failed to load: {e}")
            continue

        P, mask = make_constraints(y, n_clusters)
        lam = 1.0
        m = 2.0

        try:
            # --- MES solver ---
            t0 = time.time()
            model_mes = FCPL(n_clusters=n_clusters, m=m, lam=lam,
                             max_iter=200, tol=1e-8, solver='mes', random_state=SEED)
            model_mes.fit(Xs, P=P, constraint_mask=mask)
            time_mes = time.time() - t0

            # --- QP solver ---
            t0 = time.time()
            model_qp = FCPL(n_clusters=n_clusters, m=m, lam=lam,
                            max_iter=200, tol=1e-8, solver='qp', random_state=SEED)
            model_qp.fit(Xs, P=P, constraint_mask=mask)
            time_qp = time.time() - t0
        except Exception as e:
            print(f"  Solver failed: {e}")
            continue

        # --- Compare ---
        U_mes = model_mes.U_
        U_qp = model_qp.U_
        u_max_diff = float(np.max(np.abs(U_mes - U_qp)))
        label_match = float(np.mean(model_mes.labels_ == model_qp.labels_))

        acc_mes = clustering_accuracy(y, model_mes.labels_)
        acc_qp = clustering_accuracy(y, model_qp.labels_)
        nmi_mes = nmi_score(y, model_mes.labels_)
        nmi_qp = nmi_score(y, model_qp.labels_)
        ari_mes = ari_score(y, model_mes.labels_)
        ari_qp = ari_score(y, model_qp.labels_)

        obj_mes = model_mes.obj_history_[-1] if model_mes.obj_history_ else np.nan
        obj_qp = model_qp.obj_history_[-1] if model_qp.obj_history_ else np.nan
        obj_diff = abs(obj_mes - obj_qp)

        speedup = time_qp / time_mes if time_mes > 0 else np.nan

        row = {
            "dataset": ds_name,
            "n_samples": len(y),
            "n_features": Xs.shape[1],
            "n_clusters": n_clusters,
            "U_max_diff": u_max_diff,
            "label_match_rate": label_match,
            "ACC_MES": round(acc_mes, 4),
            "ACC_QP": round(acc_qp, 4),
            "NMI_MES": round(nmi_mes, 4),
            "NMI_QP": round(nmi_qp, 4),
            "ARI_MES": round(ari_mes, 4),
            "ARI_QP": round(ari_qp, 4),
            "obj_MES": round(obj_mes, 6),
            "obj_QP": round(obj_qp, 6),
            "obj_diff": obj_diff,
            "time_MES_s": round(time_mes, 4),
            "time_QP_s": round(time_qp, 4),
            "speedup": round(speedup, 2),
            "iterations_MES": model_mes.n_iter_,
            "iterations_QP": model_qp.n_iter_,
        }
        rows.append(row)
        print(f"  U_max_diff={u_max_diff:.2e}, label_match={label_match:.4f}")
        print(f"  ACC: MES={acc_mes:.4f}, QP={acc_qp:.4f}")
        print(f"  obj_diff={obj_diff:.2e}, speedup={speedup:.2f}x")
        print(f"  iters: MES={model_mes.n_iter_}, QP={model_qp.n_iter_}")

    df = pd.DataFrame(rows)
    out_path = ROOT / "data" / "results" / "exp_mes_qp_strict_verification.csv"
    df.to_csv(out_path, index=False)
    print(f"\nSaved: {out_path}")
    if len(df) > 0:
        print(df.to_string())

    # Summary statement
    if len(df) > 0:
        all_match = (df["label_match_rate"] == 1.0).all()
        all_udiff = (df["U_max_diff"] < 1e-5).all()
        print(f"\n{'='*60}")
        print(f"CONCLUSION: All label_match=100%: {all_match}")
        print(f"All U_max_diff < 1e-5: {all_udiff}")
        print(f"MES and QP solve the identical FCPL objective, producing identical clustering results.")
        print(f"Differences are below numerical precision (U_max_diff < 1e-6).")
        print(f"Average speedup: {df['speedup'].mean():.1f}x")

if __name__ == "__main__":
    run_verification()
