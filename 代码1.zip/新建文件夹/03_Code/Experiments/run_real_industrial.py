"""Real industrial datasets: Fashion-MNIST, MNIST, PenDigits subsets."""
import sys, warnings, time
import numpy as np
import pandas as pd
from pathlib import Path
warnings.filterwarnings('ignore')

ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))
from models.fcpl import FCPL
from models.kfcpl import KFCPL
from models.baselines import FCM, SFCM, CEFCM, SSFCM
from utils.metrics import clustering_accuracy, nmi_score, ari_score
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.datasets import fetch_openml, load_digits
from sklearn.decomposition import PCA

SEEDS = [42,43,44,45,46]
T = 2.776
OUT = ROOT / "data" / "results"

def make_con(y,k,ratio=0.10,seed=42):
    rng=np.random.RandomState(seed); n=len(y); mask=np.zeros(n,bool)
    for c in range(k):
        idx=np.where(y==c)[0]; nc=max(int(len(idx)*ratio),1)
        mask[rng.choice(idx,nc,replace=False)]=True
    P=np.zeros((n,k)); P[np.arange(n),y]=1.0
    return P,mask

def load_real(name):
    if name == "Fashion-MNIST":
        print("Loading Fashion-MNIST...")
        d = fetch_openml('Fashion-MNIST', version=1, parser='auto')
        X = d.data.values.astype(float); y = d.target.astype(int).values
        # Subsample 10000
        rng = np.random.RandomState(42)
        idx = rng.choice(len(y), 10000, replace=False)
        return X[idx], y[idx], 10
    elif name == "MNIST":
        print("Loading MNIST...")
        d = fetch_openml('mnist_784', version=1, parser='auto')
        X = d.data.values.astype(float); y = d.target.astype(int).values
        rng = np.random.RandomState(42)
        idx = rng.choice(len(y), 10000, replace=False)
        return X[idx], y[idx], 10
    elif name == "PenDigits":
        print("Loading PenDigits...")
        d = fetch_openml('pendigits', version=1, parser='auto')
        X = d.data.values.astype(float); y = d.target.astype(int).values
        return X, y, 10

def main():
    rows = []
    for ds in ["PenDigits", "Fashion-MNIST", "MNIST"]:
        try:
            X_raw, y, k = load_real(ds)
        except Exception as e:
            print(f"Skip {ds}: {e}")
            continue
        # High-dim: PCA to 50
        Xs = StandardScaler().fit_transform(X_raw)
        if Xs.shape[1] > 100:
            Xs = PCA(n_components=50, random_state=42).fit_transform(Xs)
        n = len(y)
        print(f"\n=== {ds}: n={n}, d={Xs.shape[1]}, k={k} ===")

        algos = [
            ("K-means", lambda seed: KMeans(n_clusters=k, n_init=10, random_state=seed).fit(Xs).labels_),
            ("FCM", lambda seed: FCM(n_clusters=k, m=2.0, max_iter=50, random_state=seed).fit(Xs).labels_),
            ("SFCM", lambda seed: SFCM(n_clusters=k, m=2.0, lam=1.0, max_iter=50, random_state=seed).fit(
                Xs, P=make_con(y,k,0.10,seed)[0], constraint_mask=make_con(y,k,0.10,seed)[1]).labels_),
            ("CEFCM", lambda seed: CEFCM(n_clusters=k, m=2.0, contrast_weight=0.5, max_iter=50, random_state=seed).fit(
                Xs, P=make_con(y,k,0.10,seed)[0], constraint_mask=make_con(y,k,0.10,seed)[1]).labels_),
            ("FCPL", lambda seed: FCPL(n_clusters=k, m=2.0, lam=5.0, max_iter=50, random_state=seed).fit(
                Xs, P=make_con(y,k,0.10,seed)[0], constraint_mask=make_con(y,k,0.10,seed)[1]).labels_),
        ]
        # KFCPL only for small (n<=10k)
        if n <= 10000:
            algos.append(("KFCPL", lambda seed: KFCPL(n_clusters=k, m=2.0, lam=5.0, gamma=1.0, max_iter=50, random_state=seed).fit(
                Xs, P=make_con(y,k,0.10,seed)[0], constraint_mask=make_con(y,k,0.10,seed)[1]).labels_))

        for algo_name, fn in algos:
            accs,nmis,aris,times = [],[],[],[]
            for seed in SEEDS:
                try:
                    t0 = time.time()
                    lab = fn(seed)
                    dt = time.time()-t0
                    accs.append(clustering_accuracy(y,lab)*100)
                    nmis.append(nmi_score(y,lab)*100)
                    aris.append(ari_score(y,lab)*100)
                    times.append(dt)
                except Exception as e:
                    print(f"  {algo_name} seed={seed} failed: {e}")
            if len(accs) < 3:
                continue
            am,asd=np.mean(accs),np.std(accs,ddof=1); ac=T*asd/np.sqrt(5)
            nm,ns=np.mean(nmis),np.std(nmis,ddof=1); nc=T*ns/np.sqrt(5)
            rm,rs=np.mean(aris),np.std(aris,ddof=1); rc=T*rs/np.sqrt(5)
            tm = np.mean(times)
            rows.append({"dataset":ds,"n_samples":n,"n_features":Xs.shape[1],"n_clusters":k,
                "algorithm":algo_name,
                "ACC_mean":round(am,2),"ACC_ci95":round(ac,2),
                "NMI_mean":round(nm,2),"NMI_ci95":round(nc,2),
                "ARI_mean":round(rm,2),"ARI_ci95":round(rc,2),
                "time_mean":round(tm,2),"n_runs":len(accs)})
            print(f"  {algo:10s}: ACC={am:6.2f}±{ac:5.2f} time={tm:.1f}s")

    df = pd.DataFrame(rows)
    df.to_csv(OUT / "exp_large_scale_real.csv", index=False)
    print(f"\nSaved: {len(df)} rows")
    print(df.to_string(index=False))

if __name__=="__main__":
    main()
