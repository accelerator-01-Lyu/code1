"""Fuzzy face expression experiment with membership entropy analysis."""
import sys, os
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
from code.utils.data_loader import get_constraint_samples
from code.utils.metrics import evaluate_clustering
from code.models.fcpl import FCPL
from code.models.baselines import FCM, SFCM
from sklearn.preprocessing import StandardScaler

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')

def generate_face_data(n=600, d=64, k=6, rs=42):
    rng = np.random.RandomState(rs)
    centers = rng.randn(k, d) * 1.5
    X_list, y_list, P_list = [], [], []
    names = ['Anger', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise']
    for _ in range(n):
        dom = rng.randint(k)
        x = centers[dom] + rng.randn(d) * 1.2
        # Fuzzy membership
        p = np.zeros(k)
        p[dom] = rng.uniform(0.5, 0.8)
        sec = rng.choice([e for e in range(k) if e != dom], size=rng.randint(1,3), replace=False)
        rem = 1.0 - p[dom]
        w = rng.dirichlet(np.ones(len(sec))) * rem
        for j, e in enumerate(sec):
            p[e] = w[j]
        X_list.append(x)
        y_list.append(dom)
        P_list.append(p)
    X = StandardScaler().fit_transform(np.array(X_list))
    return X, np.array(y_list), np.array(P_list), k, names


def membership_entropy(U, k):
    """Average normalized membership entropy (0=confident, 1=uniform)."""
    eps = 1e-10
    h = -np.sum(U * np.log(U + eps), axis=1) / np.log(k)
    return np.mean(h)


X, y, P_true, k, names = generate_face_data()
n_constrained = int(0.2 * len(y))
rng = np.random.RandomState(42)
c_idx = rng.choice(len(y), n_constrained, replace=False)
cm = np.zeros(len(y), dtype=bool)
cm[c_idx] = True
P_hard = np.zeros_like(P_true)
P_hard[np.arange(len(y)), y] = 1.0

results = []
membership_data = {}

for rep in range(5):
    rs = 42 + rep
    
    # FCM (unsupervised)
    fcm = FCM(n_clusters=k, random_state=rs)
    fcm.fit(X)
    res = evaluate_clustering(y, fcm.labels_)
    results.append({'Method': 'FCM', 'Rep': rep, **res,
                    'Entropy': membership_entropy(fcm.U_, k)})
    
    # SFCM (hard)
    sfcm = SFCM(n_clusters=k, random_state=rs)
    sfcm.fit(X, P_hard, cm)
    res = evaluate_clustering(y, sfcm.labels_)
    results.append({'Method': 'SFCM_hard', 'Rep': rep, **res,
                    'Entropy': membership_entropy(sfcm.U_, k)})
    
    # FCPL hard
    fcpl_h = FCPL(n_clusters=k, lam=1.0, random_state=rs)
    fcpl_h.fit(X, P_hard, cm)
    res = evaluate_clustering(y, fcpl_h.labels_)
    results.append({'Method': 'FCPL_hard', 'Rep': rep, **res,
                    'Entropy': membership_entropy(fcpl_h.U_, k)})
    
    # FCPL fuzzy (key)
    fcpl_f = FCPL(n_clusters=k, lam=1.0, random_state=rs)
    fcpl_f.fit(X, P_true, cm)
    res = evaluate_clustering(y, fcpl_f.labels_)
    results.append({'Method': 'FCPL_fuzzy', 'Rep': rep, **res,
                    'Entropy': membership_entropy(fcpl_f.U_, k)})
    
    if rep == 0:
        membership_data['FCM'] = fcm.U_
        membership_data['FCPL'] = fcpl_f.U_

# Summary
df = pd.DataFrame(results)
T = 2.776
summary = []
for method in df['Method'].unique():
    sub = df[df['Method'] == method]
    row = {'Method': method}
    for m in ['ACC', 'NMI', 'ARI', 'F1', 'Entropy']:
        v = sub[m].values
        row[f'{m}_mean'] = np.mean(v)
        row[f'{m}_ci95'] = T * np.std(v, ddof=1) / np.sqrt(len(v))
    summary.append(row)

df_sum = pd.DataFrame(summary)
df_sum.to_csv(os.path.join(RESULTS_DIR, 'exp_face_fuzzy_final.csv'), index=False)
np.savetxt(os.path.join(RESULTS_DIR, 'exp_face_membership_fcpl.csv'), membership_data['FCPL'], delimiter=',')
np.savetxt(os.path.join(RESULTS_DIR, 'exp_face_membership_fcm.csv'), membership_data['FCM'], delimiter=',')

print("Face experiment results (mean ± 95% CI):")
print(df_sum.to_string(index=False))

# Radar chart
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
angles = np.linspace(0, 2*np.pi, k, endpoint=False).tolist()
angles += angles[:1]
fig, axes = plt.subplots(2, 3, figsize=(15, 10), subplot_kw=dict(polar=True))
axes = axes.flatten()
for i in range(6):
    ax = axes[i]
    true_p = P_true[c_idx[i]].tolist(); true_p += true_p[:1]
    fcm_u = membership_data['FCM'][c_idx[i]].tolist(); fcm_u += fcm_u[:1]
    fcpl_u = membership_data['FCPL'][c_idx[i]].tolist(); fcpl_u += fcpl_u[:1]
    ax.plot(angles, true_p, 'g-o', lw=2, label='True')
    ax.fill(angles, true_p, alpha=0.15, color='g')
    ax.plot(angles, fcm_u, 'b--s', lw=1.5, label='FCM')
    ax.plot(angles, fcpl_u, 'r-^', lw=2, label='FCPL')
    ax.set_xticks(angles[:-1]); ax.set_xticklabels(names, fontsize=8)
    ax.set_title(f'Sample {c_idx[i]} ({names[y[c_idx[i]]]})', fontsize=10)
axes[0].legend(fontsize=8)
plt.suptitle('Membership Radar: FCM vs FCPL (fuzzy prior)', fontsize=14)
plt.tight_layout()
plt.savefig(os.path.join(FIGURES_DIR, 'exp_face_membership_radar_final.png'), dpi=300, bbox_inches='tight')
plt.close()
print("\nRadar chart saved.")
