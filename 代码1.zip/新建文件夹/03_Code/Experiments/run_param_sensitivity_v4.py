"""
v4 Task 1: Parameter sensitivity - semi-supervised algorithms only.
6 semi-supervised algorithms x 9 lambda values x 5 datasets x 5 seeds.
Same init, same constraint set across algorithms.
"""
import sys, os, time, warnings
import numpy as np
import pandas as pd
from pathlib import Path

warnings.filterwarnings('ignore')
ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))

from models.fcpl import FCPL
from models.kfcpl import KFCPL
from models.baselines import FCM, SFCM, CEFCM, SSFCM, GRFCM
from utils.data_loader import load_uci_dataset
from utils.metrics import clustering_accuracy, nmi_score, ari_score
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

T_CRIT = 2.776
SEEDS = [42, 43, 44, 45, 46]
LAMBDAS = [0.01, 0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 50.0, 100.0]
DATASETS = ["iris", "wine", "seeds", "balance", "glass"]
OUT = ROOT / "data" / "results"

def summarize(values):
    v = np.array([x for x in values if x is not None and not np.isnan(x)])
    if len(v)==0: return np.nan, np.nan, np.nan, 0
    mean=float(np.mean(v)); std=float(np.std(v,ddof=1)) if len(v)>1 else 0.0
    ci=T_CRIT*std/np.sqrt(len(v)) if len(v)>1 else 0.0
    return mean,std,ci,len(v)

def make_constraints(y, k, ratio=0.10, seed=42):
    rng = np.random.RandomState(seed)
    n = len(y); mask = np.zeros(n, dtype=bool)
    for c in range(k):
        idx_c = np.where(y==c)[0]
        n_c = max(int(len(idx_c)*ratio), 1)
        chosen = rng.choice(idx_c, size=n_c, replace=False)
        mask[chosen] = True
    P = np.zeros((n, k)); P[np.arange(n), y] = 1.0
    return P, mask

def run_semisup(name, X, y, P, mask, lam, seed, k):
    """Run semi-supervised algorithm at given lambda."""
    np.random.seed(seed)
    try:
        if name == "SFCM":
            m = SFCM(n_clusters=k, m=2.0, lam=lam, max_iter=200, tol=1e-5, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask)
        elif name == "CEFCM":
            m = CEFCM(n_clusters=k, m=2.0, max_iter=200, tol=1e-5, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask)
        elif name == "SSFCM":
            m = SSFCM(n_clusters=k, m=2.0, max_iter=200, tol=1e-5, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask)
        elif name == "GRFCM":
            m = GRFCM(n_clusters=k, m=2.0, max_iter=200, tol=1e-5, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask)
        elif name == "FCPL":
            m = FCPL(n_clusters=k, m=2.0, lam=lam, max_iter=200, tol=1e-5, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask)
        elif name == "KFCPL":
            m = KFCPL(n_clusters=k, m=2.0, lam=lam, gamma=0.1, max_iter=200, tol=1e-5, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask)
        else:
            return None
        return {"acc": clustering_accuracy(y, m.labels_)*100,
                "nmi": nmi_score(y, m.labels_)*100,
                "ari": ari_score(y, m.labels_)*100}
    except Exception as e:
        return {"error": str(e)}

def main():
    rows = []
    baselines = []

    for ds_name in DATASETS:
        X, y, _ = load_uci_dataset(ds_name)
        scaler = StandardScaler(); Xs = scaler.fit_transform(X)
        k = len(np.unique(y))
        n = len(y)
        print(f"\n=== {ds_name}: n={n}, k={k} ===")

        # --- Unsupervised baselines (fixed, no lambda) ---
        for seed in SEEDS:
            # FCM
            fcm = FCM(n_clusters=k, m=2.0, max_iter=200, random_state=seed)
            fcm.fit(Xs)
            baselines.append({"dataset": ds_name, "algorithm": "FCM",
                "ACC_mean": clustering_accuracy(y, fcm.labels_)*100,
                "NMI_mean": nmi_score(y, fcm.labels_)*100,
                "ARI_mean": ari_score(y, fcm.labels_)*100})
            # K-means
            km = KMeans(n_clusters=k, n_init=10, random_state=seed)
            km.fit(Xs)
            baselines.append({"dataset": ds_name, "algorithm": "K-means",
                "ACC_mean": clustering_accuracy(y, km.labels_)*100,
                "NMI_mean": nmi_score(y, km.labels_)*100,
                "ARI_mean": ari_score(y, km.labels_)*100})

        # --- Semi-supervised: vary lambda ---
        semi_algos = ["SFCM", "CEFCM", "SSFCM", "GRFCM", "FCPL", "KFCPL"]
        for algo in semi_algos:
            for lam in LAMBDAS:
                runs = {"acc":[], "nmi":[], "ari":[]}
                for seed in SEEDS:
                    P, mask = make_constraints(y, k, 0.10, seed)
                    res = run_semisup(algo, Xs, y, P, mask, lam, seed, k)
                    if res is None or "error" in res:
                        continue
                    for kk in runs: runs[kk].append(res[kk])
                am, asd, aci, an = summarize(runs["acc"])
                nm, ns, nci, _ = summarize(runs["nmi"])
                rm, rs, rci, _ = summarize(runs["ari"])
                rows.append({
                    "dataset": ds_name, "algorithm": algo, "lambda": lam,
                    "ACC_mean": round(am,2), "ACC_std": round(asd,3), "ACC_ci95": round(aci,3),
                    "NMI_mean": round(nm,2), "NMI_std": round(ns,3), "NMI_ci95": round(nci,3),
                    "ARI_mean": round(rm,2), "ARI_std": round(rs,3), "ARI_ci95": round(rci,3),
                    "n_runs": an})
                print(f"  {algo:8s} λ={lam:6.2f}: ACC={am:6.2f}±{aci:5.2f}")

    df = pd.DataFrame(rows)
    out1 = OUT / "exp_param_sensitivity_semisupervised.csv"
    df.to_csv(out1, index=False)
    print(f"\nSaved: {out1} ({len(df)} rows)")

    # Average baselines across seeds
    bl = pd.DataFrame(baselines)
    bl_avg = bl.groupby(["dataset","algorithm"])[["ACC_mean","NMI_mean","ARI_mean"]].mean().reset_index()
    out2 = OUT / "exp_unsupervised_baseline.csv"
    bl_avg.to_csv(out2, index=False)
    print(f"Saved: {out2} ({len(bl_avg)} rows)")

    # Quick check: show FCPL best lambda per dataset
    print("\n=== FCPL best lambda per dataset ===")
    fcpl = df[df.algorithm=="FCPL"]
    for ds in DATASETS:
        sub = fcpl[fcpl.dataset==ds]
        best = sub.loc[sub.ACC_mean.idxmax()]
        print(f"  {ds:10s}: best λ={best['lambda']:6.2f}, ACC={best.ACC_mean:.2f}")

if __name__ == "__main__":
    main()
