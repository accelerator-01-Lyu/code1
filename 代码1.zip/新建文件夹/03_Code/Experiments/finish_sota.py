"""Compute summary from raw SOTA data + run optdigits quickly."""
import sys, os
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
from code.utils.data_loader import get_constraint_samples
from code.utils.metrics import evaluate_clustering
from code.models.fcpl import FCPL
from code.models.baselines import FCM, KFCM, SFCM, SSFCM, CEFCM, run_pcakm
from sklearn.cluster import KMeans

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
T_975 = 2.776

# Load raw
df_raw = pd.read_csv(os.path.join(RESULTS_DIR, 'exp_sota_final_raw.csv'))
print(f"Raw data: {len(df_raw)} rows, datasets: {df_raw['Dataset'].unique()}")

# Run optdigits (skip DKFCM/GRFCM - too slow on high-dim)
print("\nRunning optdigits (fast, skip DKFCM/GRFCM)...")
from code.experiments.run_final_tuning import load_dataset
X, y, nc = load_dataset('optdigits')
SEEDS = [42, 43, 44, 45, 46]
new_rows = []

# Load best params
fcpl_best = pd.read_csv(os.path.join(RESULTS_DIR, 'exp_best_params_fcpl.csv'))
bl = fcpl_best[fcpl_best['Dataset']=='optdigits']['Best_lambda'].values[0]
bm = fcpl_best[fcpl_best['Dataset']=='optdigits']['Best_m'].values[0]

for rep, rs in enumerate(SEEDS):
    _, P, cm = get_constraint_samples(y, 0.1, rs)
    
    km = KMeans(n_clusters=nc, random_state=rs, n_init=10)
    res = evaluate_clustering(y, km.fit_predict(X))
    new_rows.append({'Dataset': 'optdigits', 'Algorithm': 'K-means', 'Repeat': rep, **res})
    
    labels_pca = run_pcakm(X, nc, random_state=rs)
    res = evaluate_clustering(y, labels_pca)
    new_rows.append({'Dataset': 'optdigits', 'Algorithm': 'PCAKM', 'Repeat': rep, **res})
    
    fcm = FCM(n_clusters=nc, random_state=rs)
    fcm.fit(X)
    res = evaluate_clustering(y, fcm.labels_)
    new_rows.append({'Dataset': 'optdigits', 'Algorithm': 'FCM', 'Repeat': rep, **res})
    
    # KFCM on subset
    idx = np.random.RandomState(rs).choice(len(X), 3000, replace=False)
    kfcm = KFCM(n_clusters=nc, gamma=0.01, random_state=rs)
    kfcm.fit(X[idx])
    res = evaluate_clustering(y[idx], kfcm.labels_)
    new_rows.append({'Dataset': 'optdigits', 'Algorithm': 'KFCM', 'Repeat': rep, **res})
    
    cefcm = CEFCM(n_clusters=nc, random_state=rs)
    cefcm.fit(X)
    res = evaluate_clustering(y, cefcm.labels_)
    new_rows.append({'Dataset': 'optdigits', 'Algorithm': 'CEFCM', 'Repeat': rep, **res})
    
    ssfcm = SSFCM(n_clusters=nc, random_state=rs)
    ssfcm.fit(X)
    res = evaluate_clustering(y, ssfcm.labels_)
    new_rows.append({'Dataset': 'optdigits', 'Algorithm': 'SSFCM', 'Repeat': rep, **res})
    
    sfcm = SFCM(n_clusters=nc, random_state=rs)
    sfcm.fit(X, P, cm)
    res = evaluate_clustering(y, sfcm.labels_)
    new_rows.append({'Dataset': 'optdigits', 'Algorithm': 'SFCM', 'Repeat': rep, **res})
    
    fcpl = FCPL(n_clusters=nc, m=bm, lam=bl, max_iter=100, tol=1e-5, random_state=rs)
    fcpl.fit(X, P, cm)
    res = evaluate_clustering(y, fcpl.labels_)
    new_rows.append({'Dataset': 'optdigits', 'Algorithm': 'FCPL', 'Repeat': rep, **res})
    
    print(f"  rep {rep+1}/5 done")

df_new = pd.DataFrame(new_rows)
df_all = pd.concat([df_raw, df_new], ignore_index=True)
df_all.to_csv(os.path.join(RESULTS_DIR, 'exp_sota_final_raw.csv'), index=False)

# Compute summary with 95% CI
summary_rows = []
for (ds, alg), grp in df_all.groupby(['Dataset', 'Algorithm']):
    row = {'Dataset': ds, 'Algorithm': alg}
    for metric in ['ACC', 'NMI', 'ARI', 'F1']:
        vals = grp[metric].values
        n = len(vals)
        m = np.mean(vals)
        s = np.std(vals, ddof=1) if n > 1 else 0
        ci = T_975 * s / np.sqrt(n) if n > 1 else 0
        row[f'{metric}_mean'] = m
        row[f'{metric}_std'] = s
        row[f'{metric}_ci95'] = ci
        row[f'{metric}_min'] = np.min(vals)
        row[f'{metric}_max'] = np.max(vals)
        row[f'{metric}_runs'] = n
    summary_rows.append(row)

df_summary = pd.DataFrame(summary_rows)
df_summary.to_csv(os.path.join(RESULTS_DIR, 'exp_sota_final.csv'), index=False)

# Print table
print("\n" + "=" * 90)
print("FINAL SOTA: ACC% (mean ± 95% CI)")
print("=" * 90)
pivot = df_summary.pivot(index='Dataset', columns='Algorithm', values='ACC_mean')
print(pivot.round(2).to_string())

print("\nBest params:")
print(pd.read_csv(os.path.join(RESULTS_DIR, 'exp_best_params_fcpl.csv')).to_string(index=False))
