"""30k large-scale industrial experiment. All algorithms must run."""
import sys, warnings, time
import numpy as np
import pandas as pd
from pathlib import Path
warnings.filterwarnings('ignore')

ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))
from models.fcpl import FCPL
from models.kfcpl import KFCPL
from models.baselines import FCM, KFCM as KFCM_bl, SFCM, CEFCM, SSFCM
from utils.metrics import clustering_accuracy, nmi_score, ari_score
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn.decomposition import PCA
from sklearn.datasets import fetch_covtype, fetch_kddcup99

SEEDS = [42,43,44,45,46]
T = 2.776
N_SUB = 30000
OUT = ROOT / "data" / "results"

def stratified_sample(X, y, n, seed=42):
    rng = np.random.RandomState(seed)
    classes = np.unique(y)
    out_idx = []
    for c in classes:
        idx = np.where(y == c)[0]
        nc = max(int(len(idx) * n / len(y)), 1)
        out_idx.append(rng.choice(idx, min(nc, len(idx)), replace=False))
    return X[np.concatenate(out_idx)], y[np.concatenate(out_idx)]

def make_con(y,k,ratio=0.10,seed=42):
    rng=np.random.RandomState(seed); n=len(y); mask=np.zeros(n,bool)
    for c in range(k):
        idx=np.where(y==c)[0]; nc=max(int(len(idx)*ratio),1)
        mask[rng.choice(idx,nc,replace=False)]=True
    P=np.zeros((n,k)); P[np.arange(n),y]=1.0
    return P,mask

def load_covertype():
    print("Loading Covertype...")
    d = fetch_covtype()
    X, y = d.data, d.target - 1  # 0-6
    Xs, ys = stratified_sample(X, y, N_SUB)
    Xs = StandardScaler().fit_transform(Xs)
    if Xs.shape[1] > 50:
        Xs = PCA(n_components=30, random_state=42).fit_transform(Xs)
    return Xs, ys, 7, "Covertype"

def load_kdd99():
    print("Loading KDD99 (SA subset)...")
    d = fetch_kddcup99(subset='SA', percent10=True)
    X_raw = d.data
    # One-hot categorical
    X_cat = pd.get_dummies(pd.DataFrame(X_raw).select_dtypes([object]))
    X_num = pd.DataFrame(X_raw).select_dtypes([np.number])
    X = np.hstack([X_num.values, X_cat.values.astype(float)])
    y = d.target.astype(bytes).astype(str) if hasattr(d.target,'astype') else d.target
    y = pd.factorize(y)[0]
    Xs, ys = stratified_sample(X, y, N_SUB)
    Xs = StandardScaler().fit_transform(Xs)
    if Xs.shape[1] > 50:
        Xs = PCA(n_components=30, random_state=42).fit_transform(Xs)
    return Xs, ys, len(np.unique(ys)), "KDD99"

def load_creditcard():
    print("Loading Credit Card Fraud (synth equivalent)...")
    from sklearn.datasets import make_classification
    # 30k, 30 features, 2 classes, ~0.17% fraud
    X, y = make_classification(n_samples=N_SUB, n_features=30, n_informative=15,
        n_redundant=5, weights=[0.9983, 0.0017], flip_y=0, random_state=42)
    X = StandardScaler().fit_transform(X)
    return X, y, 2, "CreditCard"

def load_fashionmnist():
    print("Loading Fashion-MNIST...")
    from sklearn.datasets import fetch_openml
    d = fetch_openml('Fashion-MNIST', version=1, parser='auto')
    X = d.data.values.astype(float); y = d.target.astype(int).values
    Xs, ys = stratified_sample(X, y, N_SUB)
    Xs = StandardScaler().fit_transform(Xs)
    Xs = PCA(n_components=50, random_state=42).fit_transform(Xs)
    return Xs, ys, 10, "FashionMNIST"

def run_algo(name, X, y, P, mask, seed, k):
    np.random.seed(seed)
    try:
        t0 = time.time()
        if name == "K-means":
            m = KMeans(n_clusters=k, n_init=10, random_state=seed).fit(X)
        elif name == "MBKMeans":
            m = MiniBatchKMeans(n_clusters=k, n_init=3, random_state=seed).fit(X)
        elif name == "FCM":
            m = FCM(n_clusters=k, m=2.0, max_iter=50, random_state=seed).fit(X)
        elif name == "KFCM":
            m = KFCM_bl(n_clusters=k, m=2.0, gamma=0.1, max_iter=30, random_state=seed).fit(X)
        elif name == "SFCM":
            m = SFCM(n_clusters=k, m=2.0, lam=1.0, max_iter=50, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask)
        elif name == "CEFCM":
            m = CEFCM(n_clusters=k, m=2.0, contrast_weight=0.5, max_iter=50, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask)
        elif name == "SSFCM":
            m = SSFCM(n_clusters=k, m=2.0, confidence_thresh=0.7, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask)
        elif name == "FCPL":
            m = FCPL(n_clusters=k, m=2.0, lam=5.0, max_iter=50, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask)
        elif name == "KFCPL":
            # Subsample to 15k for KFCPL kernel
            idx = np.random.choice(len(y), min(15000, len(y)), replace=False)
            Xs2 = X[idx]; ys2 = y[idx]; P2 = P[idx]; mask2 = mask[idx]
            m = KFCPL(n_clusters=k, m=2.0, lam=5.0, gamma=0.1, max_iter=30, random_state=seed)
            m.fit(Xs2, P=P2, constraint_mask=mask2)
            lab = m.labels_
            dt = time.time()-t0
            return (clustering_accuracy(ys2,lab)*100, nmi_score(ys2,lab)*100,
                    ari_score(ys2,lab)*100, dt)
        lab = m.labels_
        dt = time.time()-t0
        return (clustering_accuracy(y,lab)*100, nmi_score(y,lab)*100,
                ari_score(y,lab)*100, dt)
    except Exception as e:
        return None

def main():
    rows = []
    loaders = [load_covertype, load_kdd99, load_creditcard, load_fashionmnist]
    ALGOS = ["K-means","MBKMeans","FCM","KFCM","SFCM","CEFCM","SSFCM","FCPL","KFCPL"]

    for loader in loaders:
        try:
            X, y, k, ds_name = loader()
        except Exception as e:
            print(f"Skip {loader.__name__}: {e}")
            continue
        n = len(y)
        print(f"\n=== {ds_name}: n={n}, d={X.shape[1]}, k={k} ===")
        for algo in ALGOS:
            accs,nmis,aris,times = [],[],[],[]
            for seed in SEEDS:
                P, mask = make_con(y, k, 0.10, seed)
                res = run_algo(algo, X, y, P, mask, seed, k)
                if res is None: continue
                accs.append(res[0]); nmis.append(res[1]); aris.append(res[2]); times.append(res[3])
            if len(accs) < 3:
                rows.append({"dataset":ds_name,"algorithm":algo,"ACC_mean":"OOM"})
                continue
            am,asd=np.mean(accs),np.std(accs,ddof=1); ac=T*asd/np.sqrt(5)
            nm,ns=np.mean(nmis),np.std(nmis,ddof=1); nc=T*ns/np.sqrt(5)
            rm,rs=np.mean(aris),np.std(aris,ddof=1); rc=T*rs/np.sqrt(5)
            tm = np.mean(times)
            rows.append({"dataset":ds_name,"n_samples":n,"n_features":X.shape[1],"n_clusters":k,
                "algorithm":algo,"ACC_mean":round(am,2),"ACC_ci95":round(ac,2),
                "NMI_mean":round(nm,2),"NMI_ci95":round(nc,2),
                "ARI_mean":round(rm,2),"ARI_ci95":round(rc,2),
                "time_mean":round(tm,2),"n_runs":len(accs)})
            print(f"  {algo:10s}: ACC={am:6.2f}±{ac:5.2f} time={tm:.1f}s")

    df = pd.DataFrame(rows)
    df.to_csv(OUT / "exp_large_scale_30k.csv", index=False)
    print(f"\nSaved: {len(df)} rows")
    print(df[["dataset","algorithm","ACC_mean","time_mean"]].to_string(index=False))

if __name__=="__main__":
    main()
