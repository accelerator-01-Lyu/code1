"""Re-run only the facial expression experiment with adjusted parameters."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.experiments.run_supplementary import run_face_experiment
import pandas as pd

if __name__ == '__main__':
    df, results = run_face_experiment()
    print("\nFinal Results:")
    print(df.to_string())
