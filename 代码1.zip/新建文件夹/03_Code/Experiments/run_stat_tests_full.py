"""Statistical tests v2: handle NaN properly."""
import numpy as np
import pandas as pd
from pathlib import Path
from scipy import stats

ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
RES = ROOT / "data" / "results"

df = pd.read_csv(RES / "exp_sota_final.csv")
pivot = df.pivot_table(index="Dataset", columns="Algorithm", values="ACC_mean")
algos = list(pivot.columns)
N = len(pivot)
print(f"Pivot: {pivot.shape}")

# === 1. Wilcoxon (pairwise complete cases) ===
rows_wil = []
for ref in ["FCPL", "KFCPL"]:
    for other in algos:
        if other == ref: continue
        pair = pivot[[ref, other]].dropna()
        if len(pair) < 5:
            rows_wil.append({"reference":ref,"compared":other,"n_pairs":len(pair),
                "statistic":"N/A","p_value":"N/A","p_0.05":"N/A","p_0.01":"N/A",
                "effect_size_r":"N/A","mean_diff":"N/A"})
            continue
        x = pair[ref].values; y = pair[other].values
        try:
            w, p = stats.wilcoxon(x, y, alternative="two-sided")
            n = len(x)
            # z approximation
            z = stats.norm.ppf(p/2) * (-1 if np.median(x-y) > 0 else 1)
            r = abs(z) / np.sqrt(n)
            rows_wil.append({
                "reference":ref, "compared":other, "n_pairs":n,
                "statistic": round(float(w),4),
                "p_value": f"{p:.8f}",
                "p_0.05": "Yes" if p<0.05 else "No",
                "p_0.01": "Yes" if p<0.01 else "No",
                "effect_size_r": round(float(r),4),
                "mean_diff": round(float(np.mean(x-y)),2)
            })
        except Exception as e:
            rows_wil.append({"reference":ref,"compared":other,"n_pairs":len(pair),
                "statistic":"N/A","p_value":f"ERR:{e}","p_0.05":"N/A","p_0.01":"N/A",
                "effect_size_r":"N/A","mean_diff":round(float(np.mean(x-y)),2)})

df_wil = pd.DataFrame(rows_wil)
df_wil.to_csv(RES / "exp3_wilcoxon_tests_full.csv", index=False)
print(f"\nWilcoxon: {len(df_wil)} pairs")
print(df_wil[["reference","compared","n_pairs","p_value","p_0.05","effect_size_r"]].to_string(index=False))

# === 2. Friedman: use complete columns only ===
complete_cols = pivot.columns[pivot.notna().all()].tolist()
print(f"\nComplete columns (all {N} datasets): {complete_cols}")
sub = pivot[complete_cols].dropna()
data_matrix = sub.values
chi2, p_fried = stats.friedmanchisquare(*[data_matrix[:,i] for i in range(data_matrix.shape[1])])
k = len(complete_cols)
pd.DataFrame([{
    "test":"Friedman","chi2":round(float(chi2),4),
    "p_value":f"{p_fried:.10f}",
    "n_algorithms":k,"n_datasets":len(sub),
    "algorithms":",".join(complete_cols),
    "significant_0.05":"Yes" if p_fried<0.05 else "No"
}]).to_csv(RES / "exp3_friedman_test.csv", index=False)
print(f"Friedman (k={k}, N={len(sub)}): chi2={chi2:.4f}, p={p_fried:.10e}")

# === 3. Mean ranks (all available, NaN=worst rank per dataset) ===
ranks = pivot.rank(axis=1, ascending=False, method="average", na_option="bottom")
mean_ranks = ranks.mean().sort_values()
rank_std = ranks.std()
df_ranks = pd.DataFrame({
    "algorithm": mean_ranks.index,
    "mean_rank": [round(v,3) for v in mean_ranks.values],
    "rank_std": [round(rank_std[a],3) for a in mean_ranks.index],
    "n_datasets": [int(pivot[a].notna().sum()) for a in mean_ranks.index]
}).sort_values("mean_rank")
df_ranks.to_csv(RES / "exp3_mean_ranks_full.csv", index=False)
print(f"\nMean ranks:")
print(df_ranks.to_string(index=False))

# === 4. CD value ===
q_table = {8:3.031, 9:3.164, 10:3.258, 11:3.338, 12:3.408, 13:3.472, 14:3.530, 15:3.580}
qa = q_table.get(k, 3.472)
cd = qa * np.sqrt(k*(k+1)/(6*len(sub)))
pd.DataFrame([{"k":k,"N":len(sub),"q_alpha_0.05":qa,"CD":round(cd,3)}]).to_csv(RES/"exp3_cd_value.csv", index=False)
print(f"\nCD (alpha=0.05): {cd:.3f}")
print("Done.")
