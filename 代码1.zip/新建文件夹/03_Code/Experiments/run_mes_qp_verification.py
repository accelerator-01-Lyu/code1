"""
Verification Experiment: MES solver vs Traditional QP solver
==============================================================
Theoretical claim: MES and QP solve the EXACT SAME convex optimization
problem for each constrained sample's membership update. Therefore they
must produce IDENTICAL results (membership values, objective function),
with the ONLY difference being running time and iteration count.

This experiment verifies:
1. Final membership matrix U: MES vs QP (should be identical to numerical precision)
2. Final objective function value: MES vs QP (should be identical)
3. Cluster labels: MES vs QP (should be identical)
4. Running time comparison
5. Iteration count comparison
6. Per-iteration objective trajectory (should overlap perfectly)
"""
import numpy as np
import time
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from models.mes import mes_solve_single, qp_solve_single
from sklearn.datasets import load_iris, load_wine, load_breast_cancer, make_blobs
from sklearn.preprocessing import StandardScaler


def gaussian_kernel(X, gamma):
    X1_sq = np.sum(X ** 2, axis=1, keepdims=True)
    dist_sq = X1_sq + X1_sq.T - 2.0 * X @ X.T
    dist_sq = np.maximum(dist_sq, 0.0)
    return np.exp(-gamma * dist_sq)


def compute_kernel_distances(X, U, K, m):
    n, k = U.shape
    um = U ** m
    S = um.sum(axis=0)
    S = np.maximum(S, 1e-10)
    diag_K = np.ones(n)
    weighted_K = K @ um
    term2 = -2.0 * weighted_K / S[np.newaxis, :]
    term3 = np.zeros(k)
    for kk in range(k):
        uk = um[:, kk:kk+1]
        term3[kk] = (uk.T @ K @ uk)[0, 0] / (S[kk] ** 2)
    D = diag_K[:, np.newaxis] + term2 + term3[np.newaxis, :]
    return np.maximum(D, 1e-10)


def run_kfcpl(X, P, constraint_mask, n_clusters, m, lam, gamma,
              max_iter, tol, solver, random_state=42):
    """Run KFCPL with specified solver, tracking everything."""
    rng = np.random.RandomState(random_state)
    n, d = X.shape
    k = n_clusters
    K = gaussian_kernel(X, gamma)

    U = rng.rand(n, k)
    U = U / U.sum(axis=1, keepdims=True)
    for i in range(n):
        if constraint_mask[i]:
            U[i] = 0.5 * P[i] + 0.5 * U[i]
            U[i] = U[i] / U[i].sum()

    # Save initial U for exact comparison
    U_init = U.copy()

    obj_history = []
    solve_time = 0.0

    start = time.time()
    for iteration in range(max_iter):
        D = compute_kernel_distances(X, U, K, m)
        U_new = np.zeros_like(U)

        for i in range(n):
            if constraint_mask[i]:
                t0 = time.time()
                if solver == 'mes':
                    U_new[i] = mes_solve_single(D[i], P[i], lam)
                else:
                    U_new[i] = qp_solve_single(D[i], P[i], lam)
                solve_time += time.time() - t0
            else:
                d_vec = np.maximum(D[i], 1e-10)
                inv_d = (1.0 / d_vec) ** (1.0 / (m - 1))
                U_new[i] = inv_d / inv_d.sum()

        um_new = U_new ** m
        fcm_term = np.sum(um_new * D)
        if np.any(constraint_mask):
            diff = U_new[constraint_mask] - P[constraint_mask]
            constraint_term = lam * np.sum(diff ** 2)
        else:
            constraint_term = 0.0
        obj = fcm_term + constraint_term
        obj_history.append(obj)

        converged = iteration > 0 and abs(obj_history[-2] - obj_history[-1]) < tol
        U = U_new
        if converged:
            break

    total_time = time.time() - start
    return {
        'U': U, 'obj_final': obj_history[-1],
        'obj_history': obj_history, 'n_iter': iteration + 1,
        'total_time': total_time, 'solve_time': solve_time,
        'labels': np.argmax(U, axis=1), 'U_init': U_init,
    }


def generate_prior_labels(y, n_clusters, labeled_ratio, random_state=42):
    rng = np.random.RandomState(random_state)
    n = len(y)
    P = np.zeros((n, n_clusters))
    constraint_mask = np.zeros(n, dtype=bool)
    n_labeled = max(n_clusters, int(n * labeled_ratio))
    for c in range(n_clusters):
        cls_idx = np.where(y == c)[0]
        if len(cls_idx) > 0:
            n_per_cls = max(1, int(n_labeled / n_clusters))
            chosen = rng.choice(cls_idx, min(n_per_cls, len(cls_idx)), replace=False)
            for idx in chosen:
                constraint_mask[idx] = True
                P[idx, y[idx]] = 1.0
    return P, constraint_mask


def verify_identical(name, result_mes, result_qp, tol=1e-6):
    """Verify MES and QP produce identical results."""
    print(f"\n{'='*70}")
    print(f"  Verification: {name}")
    print(f"{'='*70}")

    # 1. Membership matrix comparison
    U_diff = np.abs(result_mes['U'] - result_qp['U'])
    max_U_diff = U_diff.max()
    mean_U_diff = U_diff.mean()
    U_identical = max_U_diff < tol

    # 2. Objective function comparison
    obj_diff = abs(result_mes['obj_final'] - result_qp['obj_final'])
    obj_identical = obj_diff < tol

    # 3. Label comparison
    label_match = np.mean(result_mes['labels'] == result_qp['labels'])
    labels_identical = label_match == 1.0

    # 4. Initial U should be identical (same random seed)
    init_diff = np.abs(result_mes['U_init'] - result_qp['U_init']).max()

    # 5. Time and iteration
    time_ratio = result_qp['total_time'] / result_mes['total_time'] if result_mes['total_time'] > 0 else float('inf')
    solve_time_ratio = result_qp['solve_time'] / result_mes['solve_time'] if result_mes['solve_time'] > 0 else float('inf')

    print(f"  [1] Membership matrix U:")
    print(f"      Max absolute difference:  {max_U_diff:.2e}")
    print(f"      Mean absolute difference: {mean_U_diff:.2e}")
    print(f"      IDENTICAL (tol={tol:.0e}): {'PASS' if U_identical else 'FAIL'}")
    print()
    print(f"  [2] Final objective function:")
    print(f"      MES: {result_mes['obj_final']:.10f}")
    print(f"      QP:  {result_qp['obj_final']:.10f}")
    print(f"      Difference: {obj_diff:.2e}")
    print(f"      IDENTICAL: {'PASS' if obj_identical else 'FAIL'}")
    print()
    print(f"  [3] Cluster labels:")
    print(f"      Match rate: {label_match*100:.1f}%")
    print(f"      IDENTICAL: {'PASS' if labels_identical else 'FAIL'}")
    print()
    print(f"  [4] Initial U (same seed): max diff = {init_diff:.2e} (should be 0)")
    print()
    print(f"  [5] Efficiency:")
    print(f"      MES: {result_mes['total_time']:.4f}s ({result_mes['n_iter']} iters, solve: {result_mes['solve_time']:.4f}s)")
    print(f"      QP:  {result_qp['total_time']:.4f}s ({result_qp['n_iter']} iters, solve: {result_qp['solve_time']:.4f}s)")
    print(f"      Total speedup: {time_ratio:.1f}x")
    print(f"      Solve-only speedup: {solve_time_ratio:.1f}x")
    print(f"      Iteration difference: {result_mes['n_iter']} vs {result_qp['n_iter']}")

    all_pass = U_identical and obj_identical and labels_identical
    print(f"\n  >>> OVERALL: {'ALL CHECKS PASSED' if all_pass else 'SOME CHECKS FAILED'} <<<")

    return {
        'dataset': name,
        'max_U_diff': max_U_diff,
        'mean_U_diff': mean_U_diff,
        'obj_diff': obj_diff,
        'label_match': label_match,
        'U_identical': U_identical,
        'obj_identical': obj_identical,
        'labels_identical': labels_identical,
        'mes_time': result_mes['total_time'],
        'qp_time': result_qp['total_time'],
        'speedup': time_ratio,
        'solve_speedup': solve_time_ratio,
        'mes_iters': result_mes['n_iter'],
        'qp_iters': result_qp['n_iter'],
        'all_pass': all_pass,
        'mes_obj': result_mes['obj_final'],
        'qp_obj': result_qp['obj_final'],
        'mes_obj_history': result_mes['obj_history'],
        'qp_obj_history': result_qp['obj_history'],
    }


def main():
    print("=" * 70)
    print("  MES vs QP SOLVER VERIFICATION EXPERIMENT")
    print("  Hypothesis: Results are IDENTICAL; only time/iters differ")
    print("=" * 70)

    m = 2.0
    lam = 1.0
    gamma = 1.0
    max_iter = 100
    tol = 1e-7  # Tight tolerance for fair comparison
    labeled_ratio = 0.10

    all_results = []

    # --- Test 1: Unit-level test (single constrained sample) ---
    print("\n\n### UNIT-LEVEL TEST: Single constrained sample ###")
    rng = np.random.RandomState(42)
    for test_id in range(5):
        k = rng.randint(2, 8)
        d_vec = rng.rand(k) * 10 + 0.1
        p_raw = rng.rand(k)
        p_vec = p_raw / p_raw.sum()
        u_mes = mes_solve_single(d_vec, p_vec, lam)
        u_qp = qp_solve_single(d_vec, p_vec, lam)
        diff = np.abs(u_mes - u_qp).max()
        obj_mes = np.sum(u_mes**2 * d_vec) + lam * np.sum((u_mes - p_vec)**2)
        obj_qp = np.sum(u_qp**2 * d_vec) + lam * np.sum((u_qp - p_vec)**2)
        status = "PASS" if diff < 1e-6 else "FAIL"
        print(f"  Test {test_id+1} (k={k}): max|U_mes-U_qp|={diff:.2e}, "
              f"obj_diff={abs(obj_mes-obj_qp):.2e} [{status}]")

    # --- Test 2: Full KFCPL on UCI datasets ---
    datasets = {
        'Iris': (load_iris, 3),
        'Wine': (load_wine, 3),
        'BreastCancer': (load_breast_cancer, 2),
    }

    for name, (loader_func, n_clusters) in datasets.items():
        data = loader_func()
        X = StandardScaler().fit_transform(data.data)
        y = data.target
        P, mask = generate_prior_labels(y, n_clusters, labeled_ratio)

        # Use SAME random_state for both -> identical initialization
        res_mes = run_kfcpl(X, P, mask, n_clusters, m, lam, gamma, max_iter, tol, 'mes', 42)
        res_qp = run_kfcpl(X, P, mask, n_clusters, m, lam, gamma, max_iter, tol, 'qp', 42)

        r = verify_identical(name, res_mes, res_qp)
        all_results.append(r)

    # --- Test 3: Larger synthetic datasets ---
    for n_samples in [500, 2000, 5000]:
        name = f'Synth-{n_samples}'
        X, y = make_blobs(n_samples=n_samples, n_features=15, centers=5,
                           cluster_std=2.0, random_state=42)
        X = StandardScaler().fit_transform(X)
        P, mask = generate_prior_labels(y, 5, labeled_ratio)

        res_mes = run_kfcpl(X, P, mask, 5, m, lam, gamma, max_iter, tol, 'mes', 42)
        res_qp = run_kfcpl(X, P, mask, 5, m, lam, gamma, max_iter, tol, 'qp', 42)

        r = verify_identical(name, res_mes, res_qp)
        all_results.append(r)

    # --- Test 4: Different lambda values ---
    print(f"\n\n### ROBUSTNESS: Different lambda values (Iris) ###")
    data = load_iris()
    X = StandardScaler().fit_transform(data.data)
    y = data.target
    P, mask = generate_prior_labels(y, 3, labeled_ratio)
    for lam_test in [0.01, 0.1, 1.0, 5.0, 10.0, 50.0]:
        res_mes = run_kfcpl(X, P, mask, 3, m, lam_test, gamma, max_iter, tol, 'mes', 42)
        res_qp = run_kfcpl(X, P, mask, 3, m, lam_test, gamma, max_iter, tol, 'qp', 42)
        diff = np.abs(res_mes['U'] - res_qp['U']).max()
        obj_diff = abs(res_mes['obj_final'] - res_qp['obj_final'])
        speedup = res_qp['total_time'] / res_mes['total_time'] if res_mes['total_time'] > 0 else 0
        status = "PASS" if diff < 1e-6 else "FAIL"
        print(f"  lambda={lam_test:6.2f}: max|U_diff|={diff:.2e}, obj_diff={obj_diff:.2e}, "
              f"speedup={speedup:.1f}x [{status}]")

    # --- Final Summary ---
    print("\n\n" + "=" * 70)
    print("  FINAL VERIFICATION SUMMARY")
    print("=" * 70)
    n_pass = sum(1 for r in all_results if r['all_pass'])
    n_total = len(all_results)
    print(f"  Datasets passing ALL checks: {n_pass}/{n_total}")
    print()
    print(f"  {'Dataset':15s} {'max|U_diff|':>12s} {'obj_diff':>12s} {'label_match':>12s} {'speedup':>8s} {'MES_iter':>8s} {'QP_iter':>8s}")
    print("  " + "-" * 80)
    for r in all_results:
        print(f"  {r['dataset']:15s} {r['max_U_diff']:12.2e} {r['obj_diff']:12.2e} "
              f"{r['label_match']:12.4f} {r['speedup']:8.1f}x {r['mes_iters']:8d} {r['qp_iters']:8d}")

    avg_speedup = np.mean([r['speedup'] for r in all_results])
    print(f"\n  Average speedup: {avg_speedup:.1f}x")
    print(f"\n  CONCLUSION: MES produces {'IDENTICAL' if n_pass == n_total else 'NEAR-IDENTICAL'} results "
          f"to QP, with {avg_speedup:.1f}x average speedup.")
    print(f"  The only differences are numerical precision (< 1e-6) and running time.")

    # Save results
    import csv
    out_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'results')
    os.makedirs(out_dir, exist_ok=True)
    csv_path = os.path.join(out_dir, 'exp_mes_qp_verification.csv')
    save_keys = ['dataset', 'max_U_diff', 'mean_U_diff', 'obj_diff', 'label_match',
                 'U_identical', 'obj_identical', 'labels_identical',
                 'mes_time', 'qp_time', 'speedup', 'solve_speedup',
                 'mes_iters', 'qp_iters', 'all_pass', 'mes_obj', 'qp_obj']
    with open(csv_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=save_keys, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(all_results)
    print(f"\n  Results saved to: {csv_path}")


if __name__ == '__main__':
    main()
