"""
Experiment 2: Ablation study.
Systematically ablates key components of FCPL/KFCPL.
"""
import sys
import os
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_dataset, get_constraint_samples
from code.utils.metrics import evaluate_clustering
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.models.baselines import FCM

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
os.makedirs(RESULTS_DIR, exist_ok=True)


def run_ablation(n_repeats=5):
    """Run ablation study on 5 datasets."""
    
    datasets = ['iris', 'wine', 'glass', 'seeds', 'balance']
    
    rows = []
    
    print("=" * 60)
    print("Experiment 2: Ablation Study")
    print("=" * 60)
    
    for ds_name in datasets:
        print(f"\n--- Dataset: {ds_name} ---")
        X, y, n_clusters = get_dataset(ds_name, random_state=42)
        
        for rep in range(n_repeats):
            rs = 42 + rep
            _, P, constraint_mask = get_constraint_samples(y, 0.1, rs)
            
            # 1. w/o constraint term (pure FCM)
            fcm = FCM(n_clusters=n_clusters, m=2.0, max_iter=100, tol=1e-5, random_state=rs)
            fcm.fit(X)
            res_fcm = evaluate_clustering(y, fcm.labels_)
            
            # 2. FCPL with MES solver (full model)
            fcpl_mes = FCPL(n_clusters=n_clusters, m=2.0, lam=1.0, max_iter=100, 
                           tol=1e-5, solver='mes', random_state=rs)
            fcpl_mes.fit(X, P, constraint_mask)
            res_fcpl_mes = evaluate_clustering(y, fcpl_mes.labels_)
            
            # 3. FCPL with QP solver (ablate MES)
            fcpl_qp = FCPL(n_clusters=n_clusters, m=2.0, lam=1.0, max_iter=100,
                          tol=1e-5, solver='qp', random_state=rs)
            fcpl_qp.fit(X, P, constraint_mask)
            res_fcpl_qp = evaluate_clustering(y, fcpl_qp.labels_)
            
            # 4. KFCPL (with kernel)
            kfcpl = KFCPL(n_clusters=n_clusters, m=2.0, lam=1.0, gamma=1.0,
                         max_iter=100, tol=1e-5, random_state=rs)
            kfcpl.fit(X, P, constraint_mask)
            res_kfcpl = evaluate_clustering(y, kfcpl.labels_)
            
            rows.append({
                'Dataset': ds_name, 'Rep': rep,
                'w/o_constraint': res_fcm,
                'FCPL_MES': res_fcpl_mes,
                'FCPL_QP': res_fcpl_qp,
                'KFCPL': res_kfcpl,
            })
    
    # Also test different lambda values
    print("\n--- Lambda sensitivity (part of ablation) ---")
    lambda_values = [0.01, 0.1, 0.5, 1.0, 2.0, 5.0, 10.0]
    lambda_rows = []
    
    for ds_name in ['iris', 'wine', 'glass', 'seeds', 'balance']:
        X, y, n_clusters = get_dataset(ds_name, random_state=42)
        _, P, constraint_mask = get_constraint_samples(y, 0.1, 42)
        
        for lam in lambda_values:
            fcpl = FCPL(n_clusters=n_clusters, m=2.0, lam=lam, max_iter=100,
                       tol=1e-5, solver='mes', random_state=42)
            fcpl.fit(X, P, constraint_mask)
            res = evaluate_clustering(y, fcpl.labels_)
            lambda_rows.append({
                'Dataset': ds_name, 'lambda': lam,
                'ACC': res['ACC'], 'NMI': res['NMI'], 
                'ARI': res['ARI'], 'F1': res['F1']
            })
    
    # Save results
    df_ablation = pd.DataFrame(rows)
    df_ablation.to_csv(os.path.join(RESULTS_DIR, 'exp2_ablation.csv'), index=False)
    
    df_lambda = pd.DataFrame(lambda_rows)
    df_lambda.to_csv(os.path.join(RESULTS_DIR, 'exp2_lambda_sensitivity.csv'), index=False)
    
    # Print summary
    print("\nAblation Summary (mean ACC %):")
    for ds_name in datasets:
        ds_rows = [r for r in rows if r['Dataset'] == ds_name]
        if len(ds_rows) == 0:
            continue
        print(f"\n  {ds_name}:")
        for method in ['w/o_constraint', 'FCPL_MES', 'FCPL_QP', 'KFCPL']:
            accs = [r[method]['ACC'] for r in ds_rows]
            print(f"    {method:20s}: {np.mean(accs):.2f}±{np.std(accs):.2f}")
    
    return rows, lambda_rows


if __name__ == '__main__':
    run_ablation()
