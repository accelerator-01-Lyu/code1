"""Generate face membership comparison + entropy distribution data."""
import sys, warnings
import numpy as np
import pandas as pd
from pathlib import Path
warnings.filterwarnings('ignore')

ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))
from models.fcpl import FCPL
from models.baselines import FCM, SFCM
from utils.metrics import clustering_accuracy
from sklearn.preprocessing import StandardScaler

OUT = ROOT / "data" / "results"
SEED = 42
K = 6
EMOTIONS = ["Happy","Sad","Angry","Fear","Disgust","Surprise"]

# Generate synthetic fuzzy face data (same as before)
rng = np.random.RandomState(SEED)
N = 600  # 100 per class
# Centers in 20-dim
centers = rng.randn(K, 20) * 3
X_list, y_list, P_true_list = [], [], []
for c in range(K):
    n_c = N // K
    X_c = centers[c] + rng.randn(n_c, 20) * 0.8
    X_list.append(X_c); y_list.append(np.full(n_c, c))
    # True fuzzy membership: dominant 0.7, neighbors 0.15 each
    p = np.zeros((n_c, K))
    p[:, c] = 0.7
    # adjacent emotions get 0.15
    p[:, (c+1) % K] = 0.15
    p[:, (c-1) % K] = 0.15
    P_true_list.append(p)
X = StandardScaler().fit_transform(np.vstack(X_list))
y = np.concatenate(y_list)
P_true = np.vstack(P_true_list)

# 10% labeled
n = len(y); mask = np.zeros(n, bool)
for c in range(K):
    idx = np.where(y == c)[0]
    mask[rng.choice(idx, 10, replace=False)] = True
P_prior = P_true.copy()

# Run algorithms
print("Running FCM...")
fcm = FCM(n_clusters=K, m=2.0, max_iter=200, random_state=SEED)
fcm.fit(X)
U_fcm = fcm.U_

print("Running SFCM...")
sfcm = SFCM(n_clusters=K, m=2.0, lam=1.0, max_iter=200, random_state=SEED)
sfcm.fit(X, P=P_prior, constraint_mask=mask)
U_sfcm = sfcm.U_

print("Running FCPL...")
fcpl = FCPL(n_clusters=K, m=2.0, lam=10.0, max_iter=200, random_state=SEED)
fcpl.fit(X, P=P_prior, constraint_mask=mask)
U_fcpl = fcpl.U_

# Pick 4 representative samples
# Sample 0: pure Happy (dominant)
# Sample 100: pure Sad
# Sample 200: pure Angry
# Sample 300: pure Fear
# Sample 50: near Happy-Sad boundary (composite)
# Sample 150: near Sad-Angry boundary (composite)
rep_idx = [0, 50, 100, 150, 200, 300]

# 1. Membership comparison CSV
rows = []
for i in rep_idx:
    true_lab = EMOTIONS[y[i]]
    for algo, U in [("FCM", U_fcm), ("SFCM", U_sfcm), ("FCPL", U_fcpl)]:
        row = {"sample_id": i, "true_label": true_lab, "algorithm": algo}
        for j, emo in enumerate(EMOTIONS):
            row[emo] = round(float(U[i, j]), 4)
        rows.append(row)
df_mem = pd.DataFrame(rows)
df_mem.to_csv(OUT / "exp_face_membership_comparison.csv", index=False)
print(f"\nMembership comparison: {len(df_mem)} rows")
print(df_mem.to_string(index=False))

# 2. Entropy distribution
def entropy_norm(U, K):
    Uc = np.clip(U, 1e-12, 1.0)
    H = -np.sum(Uc * np.log(Uc), axis=1) / np.log(K)
    return H

H_fcm = entropy_norm(U_fcm, K)
H_sfcm = entropy_norm(U_sfcm, K)
H_fcpl = entropy_norm(U_fcpl, K)

ent_rows = []
for i in range(n):
    ent_rows.append({"sample_id": i, "algorithm": "FCM", "entropy": round(H_fcm[i], 4)})
    ent_rows.append({"sample_id": i, "algorithm": "SFCM", "entropy": round(H_sfcm[i], 4)})
    ent_rows.append({"sample_id": i, "algorithm": "FCPL", "entropy": round(H_fcpl[i], 4)})
df_ent = pd.DataFrame(ent_rows)
df_ent.to_csv(OUT / "exp_face_entropy_distribution.csv", index=False)
print(f"\nEntropy distribution: {len(df_ent)} rows")
print(f"Mean entropy - FCM: {H_fcm.mean():.3f}, SFCM: {H_sfcm.mean():.3f}, FCPL: {H_fcpl.mean():.3f}")
print(f"Median entropy - FCM: {np.median(H_fcm):.3f}, SFCM: {np.median(H_sfcm):.3f}, FCPL: {np.median(H_fcpl):.3f}")

# Also verify ACC
acc_fcm = clustering_accuracy(y, fcm.labels_)*100
acc_sfcm = clustering_accuracy(y, sfcm.labels_)*100
acc_fcpl = clustering_accuracy(y, fcpl.labels_)*100
print(f"\nACC - FCM: {acc_fcm:.2f}, SFCM: {acc_sfcm:.2f}, FCPL: {acc_fcpl:.2f}")
print("Done.")
