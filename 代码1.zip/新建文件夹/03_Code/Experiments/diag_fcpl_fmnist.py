"""Quick FCPL tuning on Fashion-MNIST 10k subset."""
import sys, warnings
import numpy as np
from pathlib import Path
warnings.filterwarnings('ignore')
ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))
from models.fcpl import FCPL
from models.baselines import SFCM
from utils.metrics import clustering_accuracy, nmi_score
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.datasets import fetch_openml

print("Loading Fashion-MNIST...")
d = fetch_openml('Fashion-MNIST', version=1, parser='auto')
X = d.data.values.astype(float); y = d.target.astype(int).values
# 10k subset stratified
rng = np.random.RandomState(42)
idx = []
for c in np.unique(y):
    ci = np.where(y==c)[0]; idx.append(rng.choice(ci, 1000, replace=False))
idx = np.concatenate(idx)
Xs = StandardScaler().fit_transform(X[idx])
Xs = PCA(n_components=50, random_state=42).fit_transform(Xs)
ys = y[idx]
k = 10
print(f"n={len(ys)}, d={Xs.shape[1]}, k={k}")

def make_con(y,k,ratio=0.10,seed=42):
    rng=np.random.RandomState(seed); n=len(y); mask=np.zeros(n,bool)
    for c in range(k):
        idx=np.where(y==c)[0]; nc=max(int(len(idx)*ratio),1)
        mask[rng.choice(idx,nc,replace=False)]=True
    P=np.zeros((n,k)); P[np.arange(n),y]=1.0
    return P,mask

P, mask = make_con(ys, k, 0.10, 42)
print(f"Constrained: {mask.sum()} samples")

# Test FCPL across lambda
print("\n=== FCPL lambda sweep (seed=42) ===")
for lam in [0.01, 0.1, 0.5, 1.0, 5.0, 10.0, 50.0]:
    try:
        m = FCPL(n_clusters=k, m=2.0, lam=lam, max_iter=100, random_state=42)
        m.fit(Xs, P=P, constraint_mask=mask)
        acc = clustering_accuracy(ys, m.labels_)*100
        nmi = nmi_score(ys, m.labels_)*100
        print(f"  lam={lam:6.2f}: ACC={acc:.2f} NMI={nmi:.2f}")
    except Exception as e:
        print(f"  lam={lam:6.2f}: ERROR {e}")

# Test SFCM
print("\n=== SFCM lam sweep ===")
for lam in [0.1, 1.0, 5.0, 10.0, 50.0]:
    m = SFCM(n_clusters=k, m=2.0, lam=lam, max_iter=100, random_state=42)
    m.fit(Xs, P=P, constraint_mask=mask)
    acc = clustering_accuracy(ys, m.labels_)*100
    print(f"  lam={lam:6.2f}: ACC={acc:.2f}")
