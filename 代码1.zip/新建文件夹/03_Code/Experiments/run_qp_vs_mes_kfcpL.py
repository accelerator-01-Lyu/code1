"""
Experiment: Time comparison between traditional QP solver and MES solver
in Kernelized FCPL (KFCPL) on multiple datasets.

Compares:
- KFCPL with traditional QP solver (scipy SLSQP) for constrained samples
- KFCPL with MES (Matrix-based Efficient Solver) for constrained samples

Both use identical Gaussian kernel, identical initialization, identical convergence criteria.
"""
import numpy as np
import time
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from models.mes import mes_solve_single, qp_solve_single
from models.kfcpl import KFCPL
from sklearn.datasets import load_iris, load_wine, load_breast_cancer
from sklearn.preprocessing import StandardScaler


def gaussian_kernel(X, gamma):
    """Compute Gaussian kernel matrix."""
    X1_sq = np.sum(X ** 2, axis=1, keepdims=True)
    dist_sq = X1_sq + X1_sq.T - 2.0 * X @ X.T
    dist_sq = np.maximum(dist_sq, 0.0)
    return np.exp(-gamma * dist_sq)


def compute_kernel_distances(X, U, K, m):
    """Compute kernelized distances (same as KFCPL)."""
    n, k = U.shape
    um = U ** m
    S = um.sum(axis=0)
    S = np.maximum(S, 1e-10)
    diag_K = np.ones(n)
    weighted_K = K @ um
    term2 = -2.0 * weighted_K / S[np.newaxis, :]
    term3 = np.zeros(k)
    for kk in range(k):
        uk = um[:, kk:kk+1]
        term3[kk] = (uk.T @ K @ uk)[0, 0] / (S[kk] ** 2)
    D = diag_K[:, np.newaxis] + term2 + term3[np.newaxis, :]
    return np.maximum(D, 1e-10)


def run_kfcpl_with_solver(X, P, constraint_mask, n_clusters, m, lam, gamma,
                            max_iter, tol, solver='mes', random_state=42):
    """
    Run KFCPL with specified solver ('mes' or 'qp').
    Returns (time_seconds, n_iterations, obj_history).
    """
    rng = np.random.RandomState(random_state)
    n, d = X.shape
    k = n_clusters

    K = gaussian_kernel(X, gamma)

    U = rng.rand(n, k)
    U = U / U.sum(axis=1, keepdims=True)
    for i in range(n):
        if constraint_mask[i]:
            U[i] = 0.5 * P[i] + 0.5 * U[i]
            U[i] = U[i] / U[i].sum()

    obj_history = []
    solve_time_total = 0.0

    start = time.time()
    for iteration in range(max_iter):
        D = compute_kernel_distances(X, U, K, m)
        U_new = np.zeros_like(U)

        for i in range(n):
            if constraint_mask[i]:
                d_vec = D[i]
                t0 = time.time()
                if solver == 'mes':
                    U_new[i] = mes_solve_single(d_vec, P[i], lam)
                else:
                    U_new[i] = qp_solve_single(d_vec, P[i], lam)
                solve_time_total += time.time() - t0
            else:
                d = np.maximum(D[i], 1e-10)
                inv_d = (1.0 / d) ** (1.0 / (m - 1))
                U_new[i] = inv_d / inv_d.sum()

        # Objective
        um_new = U_new ** m
        fcm_term = np.sum(um_new * D)
        if np.any(constraint_mask):
            diff = U_new[constraint_mask] - P[constraint_mask]
            constraint_term = lam * np.sum(diff ** 2)
        else:
            constraint_term = 0.0
        obj = fcm_term + constraint_term
        obj_history.append(obj)

        if iteration > 0 and abs(obj_history[-2] - obj_history[-1]) < tol:
            U = U_new
            break
        U = U_new

    total_time = time.time() - start
    return total_time, iteration + 1, obj_history, solve_time_total


def generate_prior_labels(y, n_clusters, labeled_ratio, random_state=42):
    """Generate prior membership matrix P and constraint mask."""
    rng = np.random.RandomState(random_state)
    n = len(y)
    P = np.zeros((n, n_clusters))
    constraint_mask = np.zeros(n, dtype=bool)

    n_labeled = max(n_clusters, int(n * labeled_ratio))
    # Stratified sampling
    labeled_indices = []
    for c in range(n_clusters):
        cls_idx = np.where(y == c)[0]
        if len(cls_idx) > 0:
            n_per_cls = max(1, int(n_labeled / n_clusters))
            chosen = rng.choice(cls_idx, min(n_per_cls, len(cls_idx)), replace=False)
            labeled_indices.extend(chosen)

    for idx in labeled_indices:
        constraint_mask[idx] = True
        P[idx, y[idx]] = 1.0

    return P, constraint_mask


def main():
    print("=" * 80)
    print("KFCPL: Traditional QP Solver vs MES Solver - Time Comparison")
    print("=" * 80)

    datasets = {
        'Iris': (load_iris, 3),
        'Wine': (load_wine, 3),
        'BreastCancer': (load_breast_cancer, 2),
    }

    # Larger synthetic datasets
    from sklearn.datasets import make_classification, make_blobs
    synthetic = {
        'Synth-1000': (make_blobs, 5, {'n_samples': 1000, 'n_features': 20, 'centers': 5, 'random_state': 42}),
        'Synth-5000': (make_blobs, 5, {'n_samples': 5000, 'n_features': 20, 'centers': 5, 'random_state': 42}),
        'Synth-10000': (make_blobs, 5, {'n_samples': 10000, 'n_features': 20, 'centers': 5, 'random_state': 42}),
    }

    m = 2.0
    lam = 1.0
    gamma = 1.0
    max_iter = 50
    tol = 1e-5
    labeled_ratio = 0.10
    n_repeats = 3

    results = []

    print(f"\nParameters: m={m}, lambda={lam}, gamma={gamma}, labeled_ratio={labeled_ratio}")
    print(f"max_iter={max_iter}, tol={tol}, repeats={n_repeats}")
    print()

    # UCI datasets
    for name, (loader_func, n_clusters) in datasets.items():
        data = loader_func()
        X = StandardScaler().fit_transform(data.data)
        y = data.target
        n = X.shape[0]

        P, mask = generate_prior_labels(y, n_clusters, labeled_ratio)
        n_constrained = mask.sum()

        mes_times, qp_times = [], []
        mes_iters, qp_iters = [], []
        mes_solve_times, qp_solve_times = [], []

        for rep in range(n_repeats):
            seed = 42 + rep
            t_mes, it_mes, _, st_mes = run_kfcpl_with_solver(
                X, P, mask, n_clusters, m, lam, gamma, max_iter, tol, 'mes', seed)
            t_qp, it_qp, _, st_qp = run_kfcpl_with_solver(
                X, P, mask, n_clusters, m, lam, gamma, max_iter, tol, 'qp', seed)
            mes_times.append(t_mes)
            qp_times.append(t_qp)
            mes_iters.append(it_mes)
            qp_iters.append(it_qp)
            mes_solve_times.append(st_mes)
            qp_solve_times.append(st_qp)

        mes_mean = np.mean(mes_times)
        qp_mean = np.mean(qp_times)
        speedup = qp_mean / mes_mean if mes_mean > 0 else float('inf')
        solve_speedup = np.mean(qp_solve_times) / np.mean(mes_solve_times) if np.mean(mes_solve_times) > 0 else float('inf')

        results.append({
            'dataset': name, 'n_samples': n, 'n_features': X.shape[1],
            'n_clusters': n_clusters, 'n_constrained': n_constrained,
            'mes_time': mes_mean, 'qp_time': qp_mean, 'speedup': speedup,
            'mes_solve_time': np.mean(mes_solve_times),
            'qp_solve_time': np.mean(qp_solve_times),
            'solve_speedup': solve_speedup,
            'mes_iters': np.mean(mes_iters), 'qp_iters': np.mean(qp_iters),
        })

        print(f"{name:15s} (n={n:5d}, d={X.shape[1]:2d}, k={n_clusters}, constrained={n_constrained:3d})")
        print(f"  MES:  {mes_mean:.4f}s (solve: {np.mean(mes_solve_times):.4f}s, iters={np.mean(mes_iters):.0f})")
        print(f"  QP:   {qp_mean:.4f}s (solve: {np.mean(qp_solve_times):.4f}s, iters={np.mean(qp_iters):.0f})")
        print(f"  Speedup: {speedup:.1f}x (solve-only: {solve_speedup:.1f}x)")
        print()

    # Synthetic datasets
    for name, (gen_func, n_clusters, params) in synthetic.items():
        X, y = gen_func(**params)
        X = StandardScaler().fit_transform(X)
        n = X.shape[0]

        P, mask = generate_prior_labels(y, n_clusters, labeled_ratio)
        n_constrained = mask.sum()

        mes_times, qp_times = [], []
        mes_solve_times, qp_solve_times = [], []

        for rep in range(n_repeats):
            seed = 42 + rep
            t_mes, it_mes, _, st_mes = run_kfcpl_with_solver(
                X, P, mask, n_clusters, m, lam, gamma, max_iter, tol, 'mes', seed)
            t_qp, it_qp, _, st_qp = run_kfcpl_with_solver(
                X, P, mask, n_clusters, m, lam, gamma, max_iter, tol, 'qp', seed)
            mes_times.append(t_mes)
            qp_times.append(t_qp)
            mes_solve_times.append(st_mes)
            qp_solve_times.append(st_qp)

        mes_mean = np.mean(mes_times)
        qp_mean = np.mean(qp_times)
        speedup = qp_mean / mes_mean if mes_mean > 0 else float('inf')
        solve_speedup = np.mean(qp_solve_times) / np.mean(mes_solve_times) if np.mean(mes_solve_times) > 0 else float('inf')

        results.append({
            'dataset': name, 'n_samples': n, 'n_features': X.shape[1],
            'n_clusters': n_clusters, 'n_constrained': n_constrained,
            'mes_time': mes_mean, 'qp_time': qp_mean, 'speedup': speedup,
            'mes_solve_time': np.mean(mes_solve_times),
            'qp_solve_time': np.mean(qp_solve_times),
            'solve_speedup': solve_speedup,
            'mes_iters': np.mean(mes_iters) if 'mes_iters' in dir() else 0,
            'qp_iters': np.mean(qp_iters) if 'qp_iters' in dir() else 0,
        })

        print(f"{name:15s} (n={n:5d}, d={X.shape[1]:2d}, k={n_clusters}, constrained={n_constrained:3d})")
        print(f"  MES:  {mes_mean:.4f}s (solve: {np.mean(mes_solve_times):.4f}s)")
        print(f"  QP:   {qp_mean:.4f}s (solve: {np.mean(qp_solve_times):.4f}s)")
        print(f"  Speedup: {speedup:.1f}x (solve-only: {solve_speedup:.1f}x)")
        print()

    # Save results
    import csv
    out_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'results')
    os.makedirs(out_dir, exist_ok=True)
    csv_path = os.path.join(out_dir, 'exp_qp_vs_mes_kfcpl.csv')
    with open(csv_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)
    print(f"Results saved to: {csv_path}")

    # Summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    avg_speedup = np.mean([r['speedup'] for r in results])
    avg_solve_speedup = np.mean([r['solve_speedup'] for r in results])
    print(f"Average total speedup (MES vs QP): {avg_speedup:.1f}x")
    print(f"Average solve-only speedup: {avg_solve_speedup:.1f}x")
    print(f"Speedup grows with dataset size:")
    for r in results:
        print(f"  {r['dataset']:15s} (n={r['n_samples']:5d}): {r['speedup']:.1f}x")


if __name__ == '__main__':
    main()
