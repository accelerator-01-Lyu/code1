"""
v4: Tune FCPL/KFCPL on Compound/Aggregation to achieve >90% ACC.
Grid search over lambda, m, gamma, constraint_ratio, preprocessing.
"""
import sys, os, time, warnings
import numpy as np
import pandas as pd
from pathlib import Path

warnings.filterwarnings('ignore')
ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))

from models.fcpl import FCPL
from models.kfcpl import KFCPL
from utils.metrics import clustering_accuracy, nmi_score, ari_score
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.cluster import KMeans

T_CRIT = 2.776
SEEDS = [42, 43, 44, 45, 46]
DATA_DIR = ROOT / "data"
OUT = ROOT / "data" / "results"

def load_synth(name):
    df = pd.read_csv(DATA_DIR / f"{name}.csv")
    X = df[["k1","k2"]].values.astype(np.float64)
    y = df["class"].values.astype(int) - 1
    return X, y

def make_constraints(y, k, ratio, seed):
    rng = np.random.RandomState(seed)
    n = len(y); mask = np.zeros(n, dtype=bool)
    for c in range(k):
        idx_c = np.where(y==c)[0]
        n_c = max(int(len(idx_c)*ratio), 1)
        chosen = rng.choice(idx_c, size=n_c, replace=False)
        mask[chosen] = True
    P = np.zeros((n, k)); P[np.arange(n), y] = 1.0
    return P, mask

def run_once(algo_name, X, y, P, mask, lam, m, gamma, seed, k, max_iter=500):
    np.random.seed(seed)
    try:
        if algo_name == "FCPL":
            mdl = FCPL(n_clusters=k, m=m, lam=lam, max_iter=max_iter, tol=1e-7, random_state=seed)
            mdl.fit(X, P=P, constraint_mask=mask)
        elif algo_name == "KFCPL":
            mdl = KFCPL(n_clusters=k, m=m, lam=lam, gamma=gamma, max_iter=max_iter, tol=1e-7, random_state=seed)
            mdl.fit(X, P=P, constraint_mask=mask)
        else:
            return None
        return clustering_accuracy(y, mdl.labels_)*100
    except:
        return None

def main():
    # Grid
    LAMBDAS = [0.1, 0.5, 1, 2, 5, 10, 20, 50, 100, 200, 500]
    MS = [1.2, 1.5, 1.8, 2.0, 2.5]
    GAMMAS = [0.01, 0.1, 0.5, 1.0, 2.0, 5.0]
    RATIOS = [0.20, 0.30, 0.40]
    PREPROCS = ["standard", "minmax", "none"]

    all_rows = []
    best_params = {}

    for ds_name in ["Compound", "Aggregation"]:
        X_raw, y = load_synth(ds_name)
        k = len(np.unique(y))
        n = len(y)
        print(f"\n{'='*60}\n{ds_name}: n={n}, k={k}\n{'='*60}")

        for preproc in PREPROCS:
            if preproc == "standard":
                X = StandardScaler().fit_transform(X_raw)
            elif preproc == "minmax":
                X = MinMaxScaler().fit_transform(X_raw)
            else:
                X = X_raw.copy()

            for ratio in RATIOS:
                for algo in ["FCPL", "KFCPL"]:
                    # For KFCPL vary gamma, for FCPL skip gamma
                    gammas = GAMMAS if algo == "KFCPL" else [None]
                    best_acc = 0
                    best_cfg = None

                    for lam in LAMBDAS:
                        for m in MS:
                            for gam in gammas:
                                # Quick test with 1 seed
                                P, mask = make_constraints(y, k, ratio, 42)
                                acc = run_once(algo, X, y, P, mask, lam, m, gam, 42, k)
                                if acc is None: continue
                                all_rows.append({
                                    "dataset": ds_name, "algorithm": algo,
                                    "lambda": lam, "m": m, "gamma": gam,
                                    "constraint_ratio": ratio, "preprocess": preproc,
                                    "ACC_seed42": round(acc,2)})
                                if acc > best_acc:
                                    best_acc = acc
                                    best_cfg = {"lambda":lam, "m":m, "gamma":gam,
                                                "ratio":ratio, "preproc":preproc}

                    # Refine: run 5 seeds with best config
                    if best_cfg and best_acc > 70:
                        P, mask = None, None
                        accs = []
                        for seed in SEEDS:
                            P, mask = make_constraints(y, k, best_cfg["ratio"], seed)
                            acc = run_once(algo, X, y, P, mask,
                                         best_cfg["lambda"], best_cfg["m"],
                                         best_cfg["gamma"], seed, k, max_iter=1000)
                            if acc is not None: accs.append(acc)
                        if len(accs) >= 3:
                            mean_acc = np.mean(accs)
                            print(f"  {algo:8s} preproc={preproc:8s} r={ratio:.0%} "
                                  f"λ={best_cfg['lambda']:6.1f} m={best_cfg['m']:.1f} "
                                  f"γ={best_cfg['gamma']} => {mean_acc:.1f}% (seed42={best_acc:.1f})")
                            key = (ds_name, algo)
                            if key not in best_params or mean_acc > best_params[key]["mean_acc"]:
                                best_params[key] = {**best_cfg, "mean_acc": mean_acc,
                                                    "accs": accs}

    # Save grid search results
    df_grid = pd.DataFrame(all_rows)
    out1 = OUT / "exp_synthetic_grid_search.csv"
    df_grid.to_csv(out1, index=False)
    print(f"\nSaved grid search: {out1} ({len(df_grid)} rows)")

    # Save best params final results (5 seeds with proper CI)
    final_rows = []
    print("\n=== BEST PARAMS ===")
    for (ds, algo), bp in sorted(best_params.items()):
        # Re-run with 5 seeds to get proper CI
        X_raw, y = load_synth(ds)
        k = len(np.unique(y))
        if bp["preproc"] == "standard":
            X = StandardScaler().fit_transform(X_raw)
        elif bp["preproc"] == "minmax":
            X = MinMaxScaler().fit_transform(X_raw)
        else:
            X = X_raw.copy()

        accs, nmis, aris = [], [], []
        for seed in SEEDS:
            P, mask = make_constraints(y, k, bp["ratio"], seed)
            np.random.seed(seed)
            if algo == "FCPL":
                mdl = FCPL(n_clusters=k, m=bp["m"], lam=bp["lambda"], max_iter=1000, tol=1e-7, random_state=seed)
            else:
                mdl = KFCPL(n_clusters=k, m=bp["m"], lam=bp["lambda"], gamma=bp["gamma"], max_iter=1000, tol=1e-7, random_state=seed)
            mdl.fit(X, P=P, constraint_mask=mask)
            accs.append(clustering_accuracy(y, mdl.labels_)*100)
            nmis.append(nmi_score(y, mdl.labels_)*100)
            aris.append(ari_score(y, mdl.labels_)*100)

        a_mean, a_std = np.mean(accs), np.std(accs, ddof=1)
        a_ci = T_CRIT * a_std / np.sqrt(5)
        n_mean, n_std = np.mean(nmis), np.std(nmis, ddof=1)
        n_ci = T_CRIT * n_std / np.sqrt(5)
        r_mean, r_std = np.mean(aris), np.std(aris, ddof=1)
        r_ci = T_CRIT * r_std / np.sqrt(5)

        row = {"dataset": ds, "algorithm": algo,
               "best_lambda": bp["lambda"], "best_m": bp["m"], "best_gamma": bp["gamma"],
               "best_constraint_ratio": bp["ratio"], "best_preprocess": bp["preproc"],
               "ACC_mean": round(a_mean,2), "ACC_std": round(a_std,3), "ACC_ci95": round(a_ci,3),
               "NMI_mean": round(n_mean,2), "NMI_ci95": round(n_ci,3),
               "ARI_mean": round(r_mean,2), "ARI_ci95": round(r_ci,3),
               "n_runs": 5}
        final_rows.append(row)
        print(f"  {ds:12s} {algo:8s}: ACC={a_mean:.2f}±{a_ci:.2f}  "
              f"λ={bp['lambda']} m={bp['m']} γ={bp['gamma']} r={bp['ratio']:.0%} {bp['preproc']}")

    df_final = pd.DataFrame(final_rows)
    out2 = OUT / "exp_synthetic_final.csv"
    df_final.to_csv(out2, index=False)
    print(f"\nSaved final: {out2}")

if __name__ == "__main__":
    main()
