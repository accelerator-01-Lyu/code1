"""
Expanded SOTA Comparison: All algorithms including 2025-2026 methods.
Runs 15 algorithms on 8 UCI datasets + 2 synthetic.
"""
import sys, os, time
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_dataset, get_constraint_samples
from code.utils.metrics import evaluate_clustering
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.models.baselines import (FCM, KFCM, SFCM, GK, PCM,
                                   CEFCM, DKFCM, GRFCM, SSFCM,
                                   run_pcakm)
from sklearn.cluster import KMeans
from sklearn.datasets import make_moons, make_blobs
from sklearn.preprocessing import StandardScaler

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(FIGURES_DIR, exist_ok=True)

DATASETS_UCI = ['iris', 'wine', 'breast_cancer', 'glass', 'seeds', 'balance', 'vehicle', 'segment']


def run_unsupervised(X, y, n_clusters, method_name, rs):
    """Run an unsupervised method, return metrics dict."""
    if method_name == 'K-means':
        km = KMeans(n_clusters=n_clusters, random_state=rs, n_init=10)
        labels = km.fit_predict(X)
    elif method_name == 'PCAKM':
        labels = run_pcakm(X, n_clusters, random_state=rs)
    elif method_name == 'FCM':
        m = FCM(n_clusters=n_clusters, random_state=rs)
        m.fit(X)
        labels = m.labels_
    elif method_name == 'KFCM':
        # Subsample for kernel methods
        n = len(X)
        k_max = min(n, 3000)
        rng = np.random.RandomState(rs)
        idx = rng.choice(n, k_max, replace=False) if n > k_max else np.arange(n)
        X_k, y_k = X[idx], y[idx]
        m = KFCM(n_clusters=n_clusters, gamma=1.0, random_state=rs)
        m.fit(X_k)
        return evaluate_clustering(y_k, m.labels_)
    elif method_name == 'GK':
        m = GK(n_clusters=n_clusters, random_state=rs)
        m.fit(X)
        labels = m.labels_
    elif method_name == 'PCM':
        m = PCM(n_clusters=n_clusters, random_state=rs)
        m.fit(X)
        labels = m.labels_
    elif method_name == 'CEFCM':
        m = CEFCM(n_clusters=n_clusters, random_state=rs)
        m.fit(X)
        labels = m.labels_
    elif method_name == 'DKFCM':
        m = DKFCM(n_clusters=n_clusters, random_state=rs)
        m.fit(X)
        labels = m.labels_
    elif method_name == 'GRFCM':
        m = GRFCM(n_clusters=n_clusters, random_state=rs)
        m.fit(X)
        labels = m.labels_
    elif method_name == 'SSFCM':
        m = SSFCM(n_clusters=n_clusters, random_state=rs)
        m.fit(X)
        labels = m.labels_
    else:
        raise ValueError(f"Unknown method: {method_name}")
    
    return evaluate_clustering(y, labels)


def run_semi_supervised(X, y, n_clusters, method_name, P, constraint_mask, rs):
    """Run a semi-supervised method."""
    if method_name == 'SFCM':
        m = SFCM(n_clusters=n_clusters, random_state=rs)
        m.fit(X, P, constraint_mask)
        return evaluate_clustering(y, m.labels_)
    elif method_name == 'FCPL':
        m = FCPL(n_clusters=n_clusters, lam=1.0, random_state=rs)
        m.fit(X, P, constraint_mask)
        return evaluate_clustering(y, m.labels_)
    elif method_name == 'KFCPL':
        # Subsample
        n = len(X)
        k_max = min(n, 3000)
        rng = np.random.RandomState(rs)
        idx = rng.choice(n, k_max, replace=False) if n > k_max else np.arange(n)
        X_k, y_k = X[idx], y[idx]
        P_k = P[idx]
        cm_k = constraint_mask[idx]
        m = KFCPL(n_clusters=n_clusters, lam=1.0, gamma=1.0, random_state=rs)
        m.fit(X_k, P_k, cm_k)
        return evaluate_clustering(y_k, m.labels_)
    else:
        raise ValueError(f"Unknown semi-supervised method: {method_name}")


def main():
    print("=" * 70)
    print("Expanded SOTA Comparison: All 15 Algorithms")
    print("=" * 70)
    
    unsup_methods = ['K-means', 'PCAKM', 'FCM', 'KFCM', 'CEFCM', 'DKFCM', 'GRFCM', 'SSFCM']
    # GK and PCM only for low-dim datasets (Mahalanobis is O(n*d^2))
    unsup_methods_lowdim = ['GK', 'PCM']
    semi_methods = ['SFCM', 'FCPL', 'KFCPL']
    all_methods = unsup_methods + semi_methods
    
    all_rows = []
    
    # Load existing partial results if any
    partial_csv = os.path.join(RESULTS_DIR, 'exp1_sota_comparison_v2.csv')
    if os.path.exists(partial_csv):
        df_existing = pd.read_csv(partial_csv)
        all_rows = df_existing.to_dict('records')
        done_datasets = set(df_existing['Dataset'].unique())
        print(f"  Resuming, already done: {done_datasets}")
    else:
        done_datasets = set()
    
    for ds_name in DATASETS_UCI:
        if ds_name in done_datasets:
            print(f"\n--- {ds_name} (already done, skipping) ---")
            continue
        print(f"\n--- {ds_name} ---")
        X, y, n_clusters = get_dataset(ds_name, random_state=42)
        print(f"  {X.shape[0]} samples, {X.shape[1]} features, {n_clusters} clusters")
        
        for rep in range(3):
            rs = 42 + rep
            _, P, cm = get_constraint_samples(y, 0.1, rs)
            
            # Unsupervised (all)
            for method in unsup_methods:
                try:
                    res = run_unsupervised(X, y, n_clusters, method, rs)
                    all_rows.append({
                        'Dataset': ds_name, 'Algorithm': method,
                        'Repeat': rep, **res
                    })
                except Exception as e:
                    print(f"    {method} failed: {e}")
            
            # GK/PCM only for low-dim (d <= 15)
            if X.shape[1] <= 15:
                for method in unsup_methods_lowdim:
                    try:
                        res = run_unsupervised(X, y, n_clusters, method, rs)
                        all_rows.append({
                            'Dataset': ds_name, 'Algorithm': method,
                            'Repeat': rep, **res
                        })
                    except Exception as e:
                        print(f"    {method} failed: {e}")
            
            # Semi-supervised
            for method in semi_methods:
                try:
                    res = run_semi_supervised(X, y, n_clusters, method, P, cm, rs)
                    all_rows.append({
                        'Dataset': ds_name, 'Algorithm': method,
                        'Repeat': rep, **res
                    })
                except Exception as e:
                    print(f"    {method} failed: {e}")
        
        # Print summary
        print(f"  Summary (mean ACC%):")
        for method in all_methods:
            vals = [r for r in all_rows if r.get('Dataset') == ds_name and r.get('Algorithm') == method]
            if vals:
                accs = [r['ACC'] for r in vals]
                print(f"    {method:12s}: {np.mean(accs):.2f} ± {np.std(accs):.2f}")
        
        # Incremental save
        pd.DataFrame(all_rows).to_csv(partial_csv, index=False)
        print(f"  [Incremental save: {len(all_rows)} rows]")
    
    # Skip synthetic (already done in run_synthetic.py)
    
    # Save full results
    df = pd.DataFrame(all_rows)
    df.to_csv(os.path.join(RESULTS_DIR, 'exp1_sota_comparison_v2.csv'), index=False)
    
    # Create summary table (mean ± std)
    summary_rows = []
    for ds in df['Dataset'].unique():
        for method in df['Algorithm'].unique():
            sub = df[(df['Dataset'] == ds) & (df['Algorithm'] == method)]
            if len(sub) > 0:
                summary_rows.append({
                    'Dataset': ds,
                    'Algorithm': method,
                    'ACC_mean': sub['ACC'].mean(),
                    'ACC_std': sub['ACC'].std(),
                    'NMI_mean': sub['NMI'].mean(),
                    'ARI_mean': sub['ARI'].mean(),
                    'F1_mean': sub['F1'].mean(),
                })
    
    df_summary = pd.DataFrame(summary_rows)
    df_summary.to_csv(os.path.join(RESULTS_DIR, 'exp1_sota_comparison_v2_summary.csv'), index=False)
    
    # Print final table
    print("\n" + "=" * 90)
    print("FINAL SOTA COMPARISON (ACC %)")
    print("=" * 90)
    
    pivot = df_summary.pivot(index='Dataset', columns='Algorithm', values='ACC_mean')
    print(pivot.round(2).to_string())
    
    print(f"\nResults saved to exp1_sota_comparison_v2.csv")


if __name__ == '__main__':
    main()
