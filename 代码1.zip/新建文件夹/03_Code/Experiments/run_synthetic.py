"""
Synthetic structural datasets (Section 4.3): Compound + Aggregation.
Runs all 13 algorithms on these two classic clustering benchmarks.
"""
import sys, os
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_constraint_samples
from code.utils.metrics import evaluate_clustering
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.models.baselines import (FCM, KFCM, SFCM, GK, PCM,
                                   CEFCM, DKFCM, GRFCM, SSFCM,
                                   run_pcakm)
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data')
RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(FIGURES_DIR, exist_ok=True)


def load_synthetic_csv(filename):
    """Load Compound or Aggregation CSV."""
    filepath = os.path.join(DATA_DIR, filename)
    df = pd.read_csv(filepath)
    X = df[['k1', 'k2']].values.astype(float)
    y = df['class'].values.astype(int) - 1  # 1-indexed -> 0-indexed
    
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    
    n_clusters = len(np.unique(y))
    print(f"  Loaded {filename}: {X.shape[0]} samples, {X.shape[1]} features, {n_clusters} classes")
    return X, y, n_clusters


def run_all(X, y, n_clusters, label_ratio=0.1, n_repeats=5):
    """Run all algorithms, return summary DataFrame."""
    unsup_methods = ['K-means', 'PCAKM', 'FCM', 'KFCM', 'GK', 'PCM',
                     'CEFCM', 'DKFCM', 'GRFCM', 'SSFCM']
    semi_methods = ['SFCM', 'FCPL', 'KFCPL']
    all_methods = unsup_methods + semi_methods
    
    rows = []
    
    for rep in range(n_repeats):
        rs = 42 + rep
        _, P, cm = get_constraint_samples(y, label_ratio, rs)
        
        # K-means
        km = KMeans(n_clusters=n_clusters, random_state=rs, n_init=10)
        labels = km.fit_predict(X)
        res = evaluate_clustering(y, labels)
        rows.append({'Repeat': rep, 'Algorithm': 'K-means', **res})
        
        # PCAKM
        labels_pca = run_pcakm(X, n_clusters, random_state=rs)
        res = evaluate_clustering(y, labels_pca)
        rows.append({'Repeat': rep, 'Algorithm': 'PCAKM', **res})
        
        # FCM
        fcm = FCM(n_clusters=n_clusters, random_state=rs)
        fcm.fit(X)
        res = evaluate_clustering(y, fcm.labels_)
        rows.append({'Repeat': rep, 'Algorithm': 'FCM', **res})
        
        # KFCM
        kfcm = KFCM(n_clusters=n_clusters, gamma=0.5, random_state=rs)
        kfcm.fit(X)
        res = evaluate_clustering(y, kfcm.labels_)
        rows.append({'Repeat': rep, 'Algorithm': 'KFCM', **res})
        
        # GK
        gk = GK(n_clusters=n_clusters, random_state=rs)
        gk.fit(X)
        res = evaluate_clustering(y, gk.labels_)
        rows.append({'Repeat': rep, 'Algorithm': 'GK', **res})
        
        # PCM
        pcm = PCM(n_clusters=n_clusters, random_state=rs)
        pcm.fit(X)
        res = evaluate_clustering(y, pcm.labels_)
        rows.append({'Repeat': rep, 'Algorithm': 'PCM', **res})
        
        # CEFCM
        cefcm = CEFCM(n_clusters=n_clusters, random_state=rs)
        cefcm.fit(X)
        res = evaluate_clustering(y, cefcm.labels_)
        rows.append({'Repeat': rep, 'Algorithm': 'CEFCM', **res})
        
        # DKFCM
        dkfcm = DKFCM(n_clusters=n_clusters, gamma=0.5, random_state=rs)
        dkfcm.fit(X)
        res = evaluate_clustering(y, dkfcm.labels_)
        rows.append({'Repeat': rep, 'Algorithm': 'DKFCM', **res})
        
        # GRFCM
        grfcm = GRFCM(n_clusters=n_clusters, random_state=rs)
        grfcm.fit(X)
        res = evaluate_clustering(y, grfcm.labels_)
        rows.append({'Repeat': rep, 'Algorithm': 'GRFCM', **res})
        
        # SSFCM
        ssfcm = SSFCM(n_clusters=n_clusters, random_state=rs)
        ssfcm.fit(X)
        res = evaluate_clustering(y, ssfcm.labels_)
        rows.append({'Repeat': rep, 'Algorithm': 'SSFCM', **res})
        
        # SFCM
        sfcm = SFCM(n_clusters=n_clusters, random_state=rs)
        sfcm.fit(X, P, cm)
        res = evaluate_clustering(y, sfcm.labels_)
        rows.append({'Repeat': rep, 'Algorithm': 'SFCM', **res})
        
        # FCPL
        fcpl = FCPL(n_clusters=n_clusters, lam=1.0, random_state=rs)
        fcpl.fit(X, P, cm)
        res = evaluate_clustering(y, fcpl.labels_)
        rows.append({'Repeat': rep, 'Algorithm': 'FCPL', **res})
        
        # KFCPL
        kfcpl = KFCPL(n_clusters=n_clusters, lam=1.0, gamma=0.5, random_state=rs)
        kfcpl.fit(X, P, cm)
        res = evaluate_clustering(y, kfcpl.labels_)
        rows.append({'Repeat': rep, 'Algorithm': 'KFCPL', **res})
    
    df = pd.DataFrame(rows)
    
    # Summary
    summary = df.groupby('Algorithm').agg({
        'ACC': ['mean', 'std'],
        'NMI': 'mean',
        'ARI': 'mean',
        'F1': 'mean'
    }).reset_index()
    summary.columns = ['Algorithm', 'ACC_mean', 'ACC_std', 'NMI_mean', 'ARI_mean', 'F1_mean']
    
    return df, summary


def plot_synthetic(X, y, n_clusters, dataset_name, fcpl_labels, kfcpl_labels, 
                   fcpl_U, constraint_idx, save_prefix):
    """Plot 2D clustering visualization."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))
    
    colors = plt.cm.tab10(np.linspace(0, 1, n_clusters))
    
    # Ground truth
    for c in range(n_clusters):
        mask = y == c
        axes[0,0].scatter(X[mask, 0], X[mask, 1], s=15, alpha=0.7, color=colors[c])
    axes[0,0].set_title('Ground Truth')
    
    # FCM
    from code.models.baselines import FCM
    fcm = FCM(n_clusters=n_clusters, random_state=42)
    fcm.fit(X)
    for c in range(n_clusters):
        mask = fcm.labels_ == c
        axes[0,1].scatter(X[mask, 0], X[mask, 1], s=15, alpha=0.7, color=colors[c])
    axes[0,1].set_title('FCM')
    
    # K-means
    km = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    labels_km = km.fit_predict(X)
    for c in range(n_clusters):
        mask = labels_km == c
        axes[0,2].scatter(X[mask, 0], X[mask, 1], s=15, alpha=0.7, color=colors[c])
    axes[0,2].set_title('K-means')
    
    # SFCM
    from code.models.baselines import SFCM
    _, P, cm = get_constraint_samples(y, 0.1, 42)
    sfcm = SFCM(n_clusters=n_clusters, random_state=42)
    sfcm.fit(X, P, cm)
    for c in range(n_clusters):
        mask = sfcm.labels_ == c
        axes[1,0].scatter(X[mask, 0], X[mask, 1], s=15, alpha=0.7, color=colors[c])
    axes[1,0].set_title('SFCM')
    
    # FCPL
    for c in range(n_clusters):
        mask = fcpl_labels == c
        axes[1,1].scatter(X[mask, 0], X[mask, 1], s=15, alpha=0.7, color=colors[c])
    # Mark constrained samples
    axes[1,1].scatter(X[constraint_idx, 0], X[constraint_idx, 1],
                      c='black', marker='x', s=40, linewidths=1.5, zorder=5)
    axes[1,1].set_title('FCPL (proposed)')
    
    # KFCPL
    for c in range(n_clusters):
        mask = kfcpl_labels == c
        axes[1,2].scatter(X[mask, 0], X[mask, 1], s=15, alpha=0.7, color=colors[c])
    axes[1,2].scatter(X[constraint_idx, 0], X[constraint_idx, 1],
                      c='black', marker='x', s=40, linewidths=1.5, zorder=5)
    axes[1,2].set_title('KFCPL (proposed)')
    
    plt.suptitle(f'{dataset_name} Dataset Clustering Comparison', fontsize=14)
    plt.tight_layout()
    plt.savefig(os.path.join(FIGURES_DIR, f'{save_prefix}.png'), dpi=300, bbox_inches='tight')
    plt.savefig(os.path.join(FIGURES_DIR, f'{save_prefix}.svg'), bbox_inches='tight')
    plt.close()
    print(f"  Plot saved: {save_prefix}.png")


def main():
    print("=" * 60)
    print("Synthetic Structural Datasets: Compound + Aggregation")
    print("=" * 60)
    
    for dataset_file, dataset_name, save_prefix in [
        ('Compound.csv', 'Compound', 'exp_synthetic_compound'),
        ('Aggregation.csv', 'Aggregation', 'exp_synthetic_aggregation'),
    ]:
        print(f"\n--- {dataset_name} ---")
        X, y, n_clusters = load_synthetic_csv(dataset_file)
        
        df, summary = run_all(X, y, n_clusters, label_ratio=0.1, n_repeats=5)
        df.to_csv(os.path.join(RESULTS_DIR, f'{save_prefix}.csv'), index=False)
        
        print(f"\n  Results (ACC%):")
        for _, row in summary.iterrows():
            print(f"    {row['Algorithm']:12s}: {row['ACC_mean']:.2f} ± {row['ACC_std']:.2f}  "
                  f"NMI={row['NMI_mean']:.2f}  ARI={row['ARI_mean']:.2f}")
        
        # Visualization
        _, P, cm = get_constraint_samples(y, 0.1, 42)
        constraint_idx = np.where(cm)[0]
        
        fcpl = FCPL(n_clusters=n_clusters, lam=1.0, random_state=42)
        fcpl.fit(X, P, cm)
        
        kfcpl = KFCPL(n_clusters=n_clusters, lam=1.0, gamma=0.5, random_state=42)
        kfcpl.fit(X, P, cm)
        
        plot_synthetic(X, y, n_clusters, dataset_name, 
                      fcpl.labels_, kfcpl.labels_, fcpl.U_,
                      constraint_idx, save_prefix)
    
    print("\n\nSynthetic experiments completed!")


if __name__ == '__main__':
    main()
