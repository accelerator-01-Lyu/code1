"""
Parameter Grid Search for FCPL and KFCPL.
Searches optimal lambda/m/gamma on multiple datasets.
Generates heatmaps and optimal parameter tables.
"""
import sys
import os
import itertools
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_dataset, get_constraint_samples
from code.utils.metrics import evaluate_clustering
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(FIGURES_DIR, exist_ok=True)

# Parameter grids
FCPL_LAMBDAS = [0.01, 0.05, 0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 50.0]
FCPL_MS = [1.5, 2.0, 2.5, 3.0]

KFCPL_LAMBDAS = [0.01, 0.1, 0.5, 1.0, 2.0, 5.0, 10.0]
KFCPL_GAMMAS = [0.01, 0.05, 0.1, 0.5, 1.0, 2.0, 5.0, 10.0]
KFCPL_MS = [1.5, 2.0, 2.5]

DATASETS = ['iris', 'wine', 'breast_cancer', 'glass', 'seeds', 'balance', 'vehicle']


def run_fcpl_search(X, y, n_clusters, label_ratio=0.1, n_repeats=3):
    """Grid search for FCPL: lambda x m."""
    results = []
    
    for lam, m in itertools.product(FCPL_LAMBDAS, FCPL_MS):
        accs, nmis, aris = [], [], []
        for rep in range(n_repeats):
            rs = 42 + rep
            _, P, cm = get_constraint_samples(y, label_ratio, rs)
            
            try:
                model = FCPL(n_clusters=n_clusters, m=m, lam=lam,
                            max_iter=100, tol=1e-5, random_state=rs)
                model.fit(X, P, cm)
                res = evaluate_clustering(y, model.labels_)
                accs.append(res['ACC'])
                nmis.append(res['NMI'])
                aris.append(res['ARI'])
            except Exception:
                accs.append(0)
                nmis.append(0)
                aris.append(0)
        
        results.append({
            'lambda': lam,
            'm': m,
            'ACC_mean': np.mean(accs),
            'ACC_std': np.std(accs),
            'NMI_mean': np.mean(nmis),
            'ARI_mean': np.mean(aris),
        })
    
    return pd.DataFrame(results)


def run_kfcpl_search(X, y, n_clusters, label_ratio=0.1, n_repeats=3):
    """Grid search for KFCPL: lambda x gamma x m."""
    results = []
    
    for lam, gamma, m in itertools.product(KFCPL_LAMBDAS, KFCPL_GAMMAS, KFCPL_MS):
        accs, nmis, aris = [], [], []
        for rep in range(n_repeats):
            rs = 42 + rep
            _, P, cm = get_constraint_samples(y, label_ratio, rs)
            
            try:
                model = KFCPL(n_clusters=n_clusters, m=m, lam=lam, gamma=gamma,
                             max_iter=100, tol=1e-5, random_state=rs)
                model.fit(X, P, cm)
                res = evaluate_clustering(y, model.labels_)
                accs.append(res['ACC'])
                nmis.append(res['NMI'])
                aris.append(res['ARI'])
            except Exception:
                accs.append(0)
                nmis.append(0)
                aris.append(0)
        
        results.append({
            'lambda': lam,
            'gamma': gamma,
            'm': m,
            'ACC_mean': np.mean(accs),
            'ACC_std': np.std(accs),
            'NMI_mean': np.mean(nmis),
            'ARI_mean': np.mean(aris),
        })
    
    return pd.DataFrame(results)


def plot_fcpl_heatmap(all_results, datasets):
    """Plot FCPL lambda x m ACC heatmaps as multi-panel figure."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import seaborn as sns
    
    n_ds = len(datasets)
    n_cols = 3
    n_rows = (n_ds + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 4*n_rows))
    axes = axes.flatten() if n_ds > 1 else [axes]
    
    for idx, ds_name in enumerate(datasets):
        ax = axes[idx]
        df = all_results[ds_name]
        
        # Pivot: lambda (rows) x m (cols)
        pivot = df.pivot(index='lambda', columns='m', values='ACC_mean')
        
        sns.heatmap(pivot, annot=True, fmt='.1f', cmap='YlOrRd',
                   ax=ax, cbar=True, vmin=40, vmax=95)
        ax.set_title(f'{ds_name}')
        ax.set_xlabel('m (fuzzifier)')
        ax.set_ylabel('lambda')
        
        # Mark best
        best_idx = df['ACC_mean'].idxmax()
        best_row = df.loc[best_idx]
        best_lam = best_row['lambda']
        best_m = best_row['m']
        
        # Find position in heatmap
        row_pos = list(pivot.index).index(best_lam)
        col_pos = list(pivot.columns).index(best_m)
        ax.plot(col_pos + 0.5, row_pos + 0.5, 'k*', markersize=15, markeredgecolor='white')
    
    # Hide unused axes
    for idx in range(n_ds, len(axes)):
        axes[idx].set_visible(False)
    
    plt.suptitle('FCPL: ACC Sensitivity to lambda and m', fontsize=14, y=1.02)
    plt.tight_layout()
    plt.savefig(os.path.join(FIGURES_DIR, 'exp_param_heatmap_fcpl.png'), dpi=300, bbox_inches='tight')
    plt.savefig(os.path.join(FIGURES_DIR, 'exp_param_heatmap_fcpl.svg'), bbox_inches='tight')
    plt.close()
    print("FCPL heatmap saved.")


def plot_kfcpl_heatmap(all_results, datasets):
    """Plot KFCPL lambda x gamma ACC heatmaps (m=2.0)."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import seaborn as sns
    
    n_ds = len(datasets)
    n_cols = 3
    n_rows = (n_ds + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 4*n_rows))
    axes = axes.flatten() if n_ds > 1 else [axes]
    
    for idx, ds_name in enumerate(datasets):
        ax = axes[idx]
        df = all_results[ds_name]
        
        # Filter to m=2.0 for cleaner heatmap
        df_m2 = df[df['m'] == 2.0]
        if len(df_m2) == 0:
            df_m2 = df
        
        # Pivot: lambda (rows) x gamma (cols)
        pivot = df_m2.pivot(index='lambda', columns='gamma', values='ACC_mean')
        
        sns.heatmap(pivot, annot=True, fmt='.1f', cmap='YlOrRd',
                   ax=ax, cbar=True, vmin=30, vmax=95)
        ax.set_title(f'{ds_name} (m=2.0)')
        ax.set_xlabel('gamma (kernel bandwidth)')
        ax.set_ylabel('lambda')
        
        # Mark best
        best_idx = df_m2['ACC_mean'].idxmax()
        best_row = df_m2.loc[best_idx]
        best_lam = best_row['lambda']
        best_gam = best_row['gamma']
        
        row_pos = list(pivot.index).index(best_lam)
        col_pos = list(pivot.columns).index(best_gam)
        ax.plot(col_pos + 0.5, row_pos + 0.5, 'k*', markersize=15, markeredgecolor='white')
    
    for idx in range(n_ds, len(axes)):
        axes[idx].set_visible(False)
    
    plt.suptitle('KFCPL: ACC Sensitivity to lambda and gamma (m=2.0)', fontsize=14, y=1.02)
    plt.tight_layout()
    plt.savefig(os.path.join(FIGURES_DIR, 'exp_param_heatmap_kfcpl.png'), dpi=300, bbox_inches='tight')
    plt.savefig(os.path.join(FIGURES_DIR, 'exp_param_heatmap_kfcpl.svg'), bbox_inches='tight')
    plt.close()
    print("KFCPL heatmap saved.")


def run_param_search():
    """Main parameter search."""
    print("=" * 60)
    print("Parameter Grid Search: FCPL and KFCPL")
    print("=" * 60)
    
    fcpl_results_all = {}
    kfcpl_results_all = {}
    optimal_rows = []
    
    for ds_name in DATASETS:
        print(f"\n--- Dataset: {ds_name} ---")
        X, y, n_clusters = get_dataset(ds_name, random_state=42)
        print(f"  {X.shape[0]} samples, {X.shape[1]} features, {n_clusters} clusters")
        
        # FCPL search
        print(f"  FCPL grid search ({len(FCPL_LAMBDAS) * len(FCPL_MS)} combos)...")
        df_fcpl = run_fcpl_search(X, y, n_clusters, n_repeats=3)
        fcpl_results_all[ds_name] = df_fcpl
        
        best_fcpl = df_fcpl.loc[df_fcpl['ACC_mean'].idxmax()]
        print(f"  Best FCPL: lambda={best_fcpl['lambda']}, m={best_fcpl['m']}, "
              f"ACC={best_fcpl['ACC_mean']:.2f}%, NMI={best_fcpl['NMI_mean']:.2f}%, ARI={best_fcpl['ARI_mean']:.2f}%")
        
        # KFCPL search
        print(f"  KFCPL grid search ({len(KFCPL_LAMBDAS) * len(KFCPL_GAMMAS) * len(KFCPL_MS)} combos)...")
        df_kfcpl = run_kfcpl_search(X, y, n_clusters, n_repeats=3)
        kfcpl_results_all[ds_name] = df_kfcpl
        
        best_kfcpl = df_kfcpl.loc[df_kfcpl['ACC_mean'].idxmax()]
        print(f"  Best KFCPL: lambda={best_kfcpl['lambda']}, gamma={best_kfcpl['gamma']}, m={best_kfcpl['m']}, "
              f"ACC={best_kfcpl['ACC_mean']:.2f}%")
        
        # Optimal parameter row
        optimal_rows.append({
            'Dataset': ds_name,
            'Method': 'FCPL',
            'Best_lambda': best_fcpl['lambda'],
            'Best_m': best_fcpl['m'],
            'Best_gamma': '-',
            'Best_ACC': best_fcpl['ACC_mean'],
            'Best_NMI': best_fcpl['NMI_mean'],
            'Best_ARI': best_fcpl['ARI_mean'],
        })
        optimal_rows.append({
            'Dataset': ds_name,
            'Method': 'KFCPL',
            'Best_lambda': best_kfcpl['lambda'],
            'Best_m': best_kfcpl['m'],
            'Best_gamma': best_kfcpl['gamma'],
            'Best_ACC': best_kfcpl['ACC_mean'],
            'Best_NMI': best_kfcpl['NMI_mean'],
            'Best_ARI': best_kfcpl['ARI_mean'],
        })
    
    # Save combined results
    all_fcpl_dfs = []
    for ds, df in fcpl_results_all.items():
        df = df.copy()
        df['Dataset'] = ds
        df['Method'] = 'FCPL'
        all_fcpl_dfs.append(df)
    
    all_kfcpl_dfs = []
    for ds, df in kfcpl_results_all.items():
        df = df.copy()
        df['Dataset'] = ds
        df['Method'] = 'KFCPL'
        all_kfcpl_dfs.append(df)
    
    df_all = pd.concat(all_fcpl_dfs + all_kfcpl_dfs, ignore_index=True)
    df_all.to_csv(os.path.join(RESULTS_DIR, 'exp_param_search.csv'), index=False)
    
    # Save optimal parameters
    df_opt = pd.DataFrame(optimal_rows)
    df_opt.to_csv(os.path.join(RESULTS_DIR, 'exp_param_optimal.csv'), index=False)
    
    # Generate heatmaps
    print("\nGenerating heatmaps...")
    plot_fcpl_heatmap(fcpl_results_all, DATASETS)
    plot_kfcpl_heatmap(kfcpl_results_all, DATASETS)
    
    # Print optimal table
    print("\n" + "=" * 80)
    print("Optimal Parameters Summary")
    print("=" * 80)
    print(f"{'Dataset':15s} {'Method':8s} {'lambda':>8s} {'m':>5s} {'gamma':>8s} {'ACC':>8s} {'NMI':>8s} {'ARI':>8s}")
    print("-" * 80)
    for row in optimal_rows:
        print(f"{row['Dataset']:15s} {row['Method']:8s} {row['Best_lambda']:8.2f} "
              f"{row['Best_m']:5.1f} {str(row['Best_gamma']):>8s} "
              f"{row['Best_ACC']:8.2f} {row['Best_NMI']:8.2f} {row['Best_ARI']:8.2f}")
    
    print(f"\nResults saved to: {RESULTS_DIR}")
    return df_all, df_opt


if __name__ == '__main__':
    run_param_search()
