"""
Experiment 4: Label ratio sensitivity analysis.
Tests different label ratios: 5%, 10%, 20%, 30%, 50% on 5 datasets.
"""
import sys
import os
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_dataset, get_constraint_samples
from code.utils.metrics import evaluate_clustering
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.models.baselines import SFCM

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(FIGURES_DIR, exist_ok=True)


def run_label_ratio_experiment(n_repeats=5):
    """Test sensitivity to label ratio."""
    
    datasets = ['iris', 'wine', 'glass', 'seeds', 'balance']
    label_ratios = [0.05, 0.10, 0.20, 0.30, 0.50]
    
    rows = []
    
    print("=" * 60)
    print("Experiment 4: Label Ratio Sensitivity")
    print("=" * 60)
    
    for ds_name in datasets:
        print(f"\n--- Dataset: {ds_name} ---")
        X, y, n_clusters = get_dataset(ds_name, random_state=42)
        
        for ratio in label_ratios:
            accs_fcpl, accs_kfcpl, accs_sfcm = [], [], []
            nmis_fcpl, nmis_kfcpl = [], []
            aris_fcpl, aris_kfcpl = [], []
            
            for rep in range(n_repeats):
                rs = 42 + rep
                _, P, constraint_mask = get_constraint_samples(y, ratio, rs)
                
                # FCPL
                fcpl = FCPL(n_clusters=n_clusters, lam=1.0, random_state=rs)
                fcpl.fit(X, P, constraint_mask)
                res = evaluate_clustering(y, fcpl.labels_)
                accs_fcpl.append(res['ACC'])
                nmis_fcpl.append(res['NMI'])
                aris_fcpl.append(res['ARI'])
                
                # KFCPL
                kfcpl = KFCPL(n_clusters=n_clusters, lam=1.0, gamma=1.0, random_state=rs)
                kfcpl.fit(X, P, constraint_mask)
                res = evaluate_clustering(y, kfcpl.labels_)
                accs_kfcpl.append(res['ACC'])
                nmis_kfcpl.append(res['NMI'])
                aris_kfcpl.append(res['ARI'])
                
                # SFCM
                sfcm = SFCM(n_clusters=n_clusters, random_state=rs)
                sfcm.fit(X, P, constraint_mask)
                res = evaluate_clustering(y, sfcm.labels_)
                accs_sfcm.append(res['ACC'])
            
            rows.append({
                'Dataset': ds_name, 'LabelRatio': ratio,
                'FCPL_ACC_mean': np.mean(accs_fcpl), 'FCPL_ACC_std': np.std(accs_fcpl),
                'FCPL_NMI_mean': np.mean(nmis_fcpl), 'FCPL_ARI_mean': np.mean(aris_fcpl),
                'KFCPL_ACC_mean': np.mean(accs_kfcpl), 'KFCPL_ACC_std': np.std(accs_kfcpl),
                'KFCPL_NMI_mean': np.mean(nmis_kfcpl), 'KFCPL_ARI_mean': np.mean(aris_kfcpl),
                'SFCM_ACC_mean': np.mean(accs_sfcm), 'SFCM_ACC_std': np.std(accs_sfcm),
            })
            
            print(f"  Ratio {ratio:.0%}: FCPL={np.mean(accs_fcpl):.2f}%, KFCPL={np.mean(accs_kfcpl):.2f}%, SFCM={np.mean(accs_sfcm):.2f}%")
    
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESULTS_DIR, 'exp4_label_ratio.csv'), index=False)
    
    # Generate plot
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        
        fig, axes = plt.subplots(1, len(datasets), figsize=(15, 4), sharey=True)
        if len(datasets) == 1:
            axes = [axes]
        
        for ax, ds_name in zip(axes, datasets):
            ds_df = df[df['Dataset'] == ds_name]
            ax.errorbar(ds_df['LabelRatio']*100, ds_df['FCPL_ACC_mean'], 
                       yerr=ds_df['FCPL_ACC_std'], marker='o', label='FCPL', linewidth=2)
            ax.errorbar(ds_df['LabelRatio']*100, ds_df['KFCPL_ACC_mean'],
                       yerr=ds_df['KFCPL_ACC_std'], marker='s', label='KFCPL', linewidth=2)
            ax.errorbar(ds_df['LabelRatio']*100, ds_df['SFCM_ACC_mean'],
                       yerr=ds_df['SFCM_ACC_std'], marker='^', label='SFCM', linewidth=2)
            ax.set_xlabel('Label Ratio (%)')
            ax.set_title(ds_name)
            ax.grid(True, alpha=0.3)
        
        axes[0].set_ylabel('ACC (%)')
        axes[0].legend()
        plt.suptitle('Clustering Accuracy vs. Label Ratio', fontsize=14)
        plt.tight_layout()
        plt.savefig(os.path.join(FIGURES_DIR, 'exp4_label_ratio.png'), dpi=300, bbox_inches='tight')
        plt.savefig(os.path.join(FIGURES_DIR, 'exp4_label_ratio.svg'), bbox_inches='tight')
        plt.close()
        print("\nLabel ratio plot saved.")
    except Exception as e:
        print(f"Plot generation failed: {e}")
    
    return df


if __name__ == '__main__':
    run_label_ratio_experiment()
