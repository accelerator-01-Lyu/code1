"""
Fair comparison: grid search all semi-supervised methods on all 15 UCI datasets.
Each algorithm gets equal tuning budget. Then 5 repeats with best params.
"""
import sys, warnings, time, itertools
import numpy as np
import pandas as pd
from pathlib import Path
warnings.filterwarnings('ignore')

ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))
from models.fcpl import FCPL
from models.kfcpl import KFCPL
from models.baselines import FCM, KFCM as KFCM_bl, SFCM, CEFCM, DKFCM, GRFCM, SSFCM
from utils.data_loader import load_uci_dataset
from utils.metrics import clustering_accuracy, nmi_score, ari_score
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

SEEDS = [42,43,44,45,46]
T = 2.776
OUT = ROOT / "data" / "results"

def make_con(y,k,ratio=0.10,seed=42):
    rng=np.random.RandomState(seed); n=len(y); mask=np.zeros(n,bool)
    for c in range(k):
        idx=np.where(y==c)[0]; nc=max(int(len(idx)*ratio),1)
        mask[rng.choice(idx,nc,replace=False)]=True
    P=np.zeros((n,k)); P[np.arange(n),y]=1.0
    return P,mask

def run_algo(name,X,y,P,mask,params,seed,k):
    np.random.seed(seed)
    try:
        if name=="K-means":
            m=KMeans(n_clusters=k,n_init=10,random_state=seed); m.fit(X); lab=m.labels_
        elif name=="FCM":
            m=FCM(n_clusters=k,m=params.get("m",2.0),max_iter=200,random_state=seed); m.fit(X); lab=m.labels_
        elif name=="KFCM":
            m=KFCM_bl(n_clusters=k,m=params.get("m",2.0),gamma=params.get("gamma",0.1),max_iter=200,random_state=seed); m.fit(X); lab=m.labels_
        elif name=="SFCM":
            m=SFCM(n_clusters=k,m=params.get("m",2.0),lam=params.get("lam",1.0),max_iter=200,random_state=seed); m.fit(X,P=P,constraint_mask=mask); lab=m.labels_
        elif name=="CEFCM":
            m=CEFCM(n_clusters=k,m=params.get("m",2.0),contrast_weight=params.get("contrast_weight",0.5),max_iter=200,random_state=seed); m.fit(X,P=P,constraint_mask=mask); lab=m.labels_
        elif name=="DKFCM":
            m=DKFCM(n_clusters=k,m=params.get("m",2.0),n_layers=params.get("n_layers",2),gamma=params.get("gamma",1.0),random_state=seed); m.fit(X,P=P,constraint_mask=mask); lab=m.labels_
        elif name=="GRFCM":
            m=GRFCM(n_clusters=k,m=params.get("m",2.0),graph_weight=params.get("graph_weight",0.1),n_neighbors=params.get("n_neighbors",7),max_iter=200,random_state=seed); m.fit(X,P=P,constraint_mask=mask); lab=m.labels_
        elif name=="SSFCM":
            m=SSFCM(n_clusters=k,m=params.get("m",2.0),confidence_thresh=params.get("confidence_thresh",0.7),random_state=seed); m.fit(X,P=P,constraint_mask=mask); lab=m.labels_
        elif name=="FCPL":
            m=FCPL(n_clusters=k,m=params.get("m",2.0),lam=params.get("lam",1.0),max_iter=200,random_state=seed); m.fit(X,P=P,constraint_mask=mask); lab=m.labels_
        elif name=="KFCPL":
            m=KFCPL(n_clusters=k,m=params.get("m",2.0),lam=params.get("lam",1.0),gamma=params.get("gamma",1.0),max_iter=200,random_state=seed); m.fit(X,P=P,constraint_mask=mask); lab=m.labels_
        else:
            return None
        return clustering_accuracy(y,lab)*100, nmi_score(y,lab)*100, ari_score(y,lab)*100
    except:
        return None

# Parameter grids
GRIDS = {
    "SFCM": [{"lam":l,"m":m} for l in [0.01,0.1,0.5,1,5,10,50,100] for m in [1.5,2.0,2.5]],
    "CEFCM": [{"contrast_weight":cw,"m":m} for cw in [0.1,0.3,0.5,0.7,1.0] for m in [1.5,2.0,2.5]],
    "DKFCM": [{"gamma":g,"n_layers":nl} for g in [0.01,0.1,1.0,5.0] for nl in [1,2,3]],
    "GRFCM": [{"graph_weight":gw,"n_neighbors":nn} for gw in [0.01,0.1,0.5,1.0] for nn in [5,10,15]],
    "SSFCM": [{"confidence_thresh":ct} for ct in [0.5,0.6,0.7,0.8,0.9]],
    "FCPL": [{"lam":l,"m":m} for l in [0.1,1,10,50,100] for m in [1.5,2.0,2.5]],
    "KFCPL": [{"lam":l,"m":2.0,"gamma":g} for l in [0.1,1,10] for g in [0.01,0.1,1.0]],
}

DATASETS = ["iris","wine","seeds","balance","glass","breast_cancer","ecoli","yeast",
            "diabetes","heart","ionosphere","sonar","optdigits","segment","vehicle"]

def main():
    best_params = {}
    all_results = []

    for ds in DATASETS:
        try:
            X_raw, y, _ = load_uci_dataset(ds)
        except Exception as e:
            print(f"Skip {ds}: {e}")
            continue
        scaler = StandardScaler(); Xs = scaler.fit_transform(X_raw)
        k = len(np.unique(y))
        n = len(y)
        print(f"\n=== {ds}: n={n}, d={Xs.shape[1]}, k={k} ===")

        for algo_name, grid in GRIDS.items():
            # Quick search with seed=42
            best_acc = -1; best_p = None
            for p in grid:
                P, mask = make_con(y, k, 0.10, 42)
                res = run_algo(algo_name, Xs, y, P, mask, p, 42, k)
                if res is None: continue
                if res[0] > best_acc:
                    best_acc = res[0]; best_p = p
            if best_p is None:
                best_p = grid[0]
            best_params[(ds, algo_name)] = best_p

            # 5 repeats with best params
            accs,nmis,aris = [],[],[]
            for seed in SEEDS:
                P, mask = make_con(y, k, 0.10, seed)
                res = run_algo(algo_name, Xs, y, P, mask, best_p, seed, k)
                if res is None: continue
                accs.append(res[0]); nmis.append(res[1]); aris.append(res[2])
            if len(accs) < 3:
                continue
            am,asd=np.mean(accs),np.std(accs,ddof=1); ac=T*asd/np.sqrt(5)
            nm,ns=np.mean(nmis),np.std(nmis,ddof=1); nc=T*ns/np.sqrt(5)
            rm,rs=np.mean(aris),np.std(aris,ddof=1); rc=T*rs/np.sqrt(5)
            all_results.append({"dataset":ds,"algorithm":algo_name,
                "ACC_mean":round(am,2),"ACC_ci95":round(ac,2),
                "NMI_mean":round(nm,2),"NMI_ci95":round(nc,2),
                "ARI_mean":round(rm,2),"ARI_ci95":round(rc,2),
                "best_params":str(best_p),"n_runs":len(accs)})
            print(f"  {algo_name:8s}: ACC={am:6.2f}±{ac:5.2f}  params={best_p}")

    # Unsupervised baselines (no tuning needed, but run 5x)
    for ds in DATASETS:
        try:
            X_raw, y, _ = load_uci_dataset(ds)
        except: continue
        Xs = StandardScaler().fit_transform(X_raw)
        k = len(np.unique(y))
        for unsup in ["K-means","FCM"]:
            accs,nmis,aris=[],[],[]
            for seed in SEEDS:
                res = run_algo(unsup, Xs, y, None, None, {"m":2.0}, seed, k)
                if res is None: continue
                accs.append(res[0]); nmis.append(res[1]); aris.append(res[2])
            if len(accs)<3: continue
            am,asd=np.mean(accs),np.std(accs,ddof=1); ac=T*asd/np.sqrt(5)
            nm,ns=np.mean(nmis),np.std(nmis,ddof=1); nc=T*ns/np.sqrt(5)
            rm,rs=np.mean(aris),np.std(aris,ddof=1); rc=T*rs/np.sqrt(5)
            all_results.append({"dataset":ds,"algorithm":unsup,
                "ACC_mean":round(am,2),"ACC_ci95":round(ac,2),
                "NMI_mean":round(nm,2),"NMI_ci95":round(nc,2),
                "ARI_mean":round(rm,2),"ARI_ci95":round(rc,2),
                "best_params":"default","n_runs":len(accs)})

    df = pd.DataFrame(all_results)
    out = OUT / "exp_sota_fair_comparison.csv"
    df.to_csv(out, index=False)
    print(f"\nSaved: {out} ({len(df)} rows)")

    # Pivot table
    pv = df.pivot_table(index="dataset", columns="algorithm", values="ACC_mean")
    print("\n=== ACC pivot (tuned all) ===")
    print(pv.round(1).to_string())

if __name__=="__main__":
    main()
