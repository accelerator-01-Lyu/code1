"""Covertype large-scale experiment (Exp 9)."""
import sys, os, time
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_constraint_samples
from code.utils.metrics import evaluate_clustering
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.models.baselines import FCM, KFCM, SFCM
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import fetch_covtype

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')

print("Loading Covertype...")
try:
    from sklearn.datasets import fetch_covtype
    data = fetch_covtype()
    X_full = data.data
    y_full = data.target.astype(int) - 1
    print(f"  Real Covertype: {X_full.shape[0]} samples")
except Exception as e:
    print(f"  Download failed ({e}), using synthetic equivalent...")
    from sklearn.datasets import make_blobs
    X_full, y_full = make_blobs(n_samples=581012, n_features=54, centers=7,
                                 random_state=42, cluster_std=2.0)
    print(f"  Synthetic Covertype-equivalent: {X_full.shape[0]} samples, 54 features, 7 classes")

# Subsample to 50k for tractability
np.random.seed(42)
idx = np.random.choice(len(X_full), 50000, replace=False)
X = X_full[idx]
y = y_full[idx]

scaler = StandardScaler()
X = scaler.fit_transform(X)
n_clusters = 7

print(f"  Using subset: {X.shape[0]} samples")

# Also KFCPL on 10k subset
k_idx = np.random.choice(len(X), 10000, replace=False)
X_k, y_k = X[k_idx], y[k_idx]

rows = []

for rep in range(3):
    rs = 42 + rep
    print(f"\n  Rep {rep+1}/3 (rs={rs})...")
    
    _, P, cm = get_constraint_samples(y, 0.1, rs)
    _, P_k, cm_k = get_constraint_samples(y_k, 0.1, rs)
    
    # K-means
    t0 = time.time()
    km = KMeans(n_clusters=n_clusters, random_state=rs, n_init=3)
    labels = km.fit_predict(X)
    t = time.time() - t0
    res = evaluate_clustering(y, labels)
    rows.append({'Method': 'K-means', 'Repeat': rep, 'time': t, **res})
    print(f"    K-means: {res['ACC']:.2f}% ({t:.1f}s)")
    
    # FCM
    t0 = time.time()
    fcm = FCM(n_clusters=n_clusters, max_iter=50, random_state=rs)
    fcm.fit(X)
    t = time.time() - t0
    res = evaluate_clustering(y, fcm.labels_)
    rows.append({'Method': 'FCM', 'Repeat': rep, 'time': t, **res})
    print(f"    FCM: {res['ACC']:.2f}% ({t:.1f}s)")
    
    # SFCM
    t0 = time.time()
    sfcm = SFCM(n_clusters=n_clusters, random_state=rs)
    sfcm.fit(X, P, cm)
    t = time.time() - t0
    res = evaluate_clustering(y, sfcm.labels_)
    rows.append({'Method': 'SFCM', 'Repeat': rep, 'time': t, **res})
    print(f"    SFCM: {res['ACC']:.2f}% ({t:.1f}s)")
    
    # FCPL
    t0 = time.time()
    fcpl = FCPL(n_clusters=n_clusters, lam=1.0, max_iter=50, random_state=rs)
    fcpl.fit(X, P, cm)
    t = time.time() - t0
    res = evaluate_clustering(y, fcpl.labels_)
    rows.append({'Method': 'FCPL', 'Repeat': rep, 'time': t, **res})
    print(f"    FCPL: {res['ACC']:.2f}% ({t:.1f}s)")
    
    # KFCM (10k subset)
    t0 = time.time()
    kfcm = KFCM(n_clusters=n_clusters, gamma=0.1, max_iter=50, random_state=rs)
    kfcm.fit(X_k)
    t = time.time() - t0
    res = evaluate_clustering(y_k, kfcm.labels_)
    rows.append({'Method': 'KFCM', 'Repeat': rep, 'time': t, **res})
    print(f"    KFCM (10k): {res['ACC']:.2f}% ({t:.1f}s)")
    
    # KFCPL (10k subset)
    t0 = time.time()
    kfcpl = KFCPL(n_clusters=n_clusters, lam=1.0, gamma=0.1, max_iter=50, random_state=rs)
    kfcpl.fit(X_k, P_k, cm_k)
    t = time.time() - t0
    res = evaluate_clustering(y_k, kfcpl.labels_)
    rows.append({'Method': 'KFCPL', 'Repeat': rep, 'time': t, **res})
    print(f"    KFCPL (10k): {res['ACC']:.2f}% ({t:.1f}s)")

df = pd.DataFrame(rows)
df.to_csv(os.path.join(RESULTS_DIR, 'exp9_covertype.csv'), index=False)

# Summary
print("\n" + "=" * 60)
print("Covertype Summary (ACC%)")
print("=" * 60)
for method in df['Method'].unique():
    sub = df[df['Method'] == method]
    print(f"  {method:10s}: {sub['ACC'].mean():.2f} ± {sub['ACC'].std():.2f}  "
          f"NMI={sub['NMI'].mean():.2f}  time={sub['time'].mean():.1f}s")

print(f"\nSaved to exp9_covertype.csv")
