"""
Master tuning: FCPL + KFCPL grid search on all datasets.
Finds optimal (lambda, m) for FCPL and (lambda, gamma, m) for KFCPL per dataset.
"""
import sys, os, itertools, time
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_dataset, get_constraint_samples
from code.utils.metrics import evaluate_clustering
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')
os.makedirs(RESULTS_DIR, exist_ok=True)

# ============================================================
# FCPL grid
# ============================================================
FCPL_LAMBDAS = [0.001, 0.01, 0.05, 0.1, 0.5, 1.0, 5.0, 10.0, 50.0, 100.0]
FCPL_MS = [1.5, 2.0, 2.5, 3.0]

FCPL_DATASETS = ['iris', 'wine', 'breast_cancer', 'glass', 'seeds', 'balance',
                 'vehicle', 'segment', 'ionosphere', 'sonar', 'ecoli', 'yeast',
                 'diabetes', 'heart', 'optdigits']

# KFCPL: only low-dim (kernel is O(n^2))
KFCPL_DATASETS = ['iris', 'wine', 'seeds', 'balance', 'glass',
                  'ionosphere', 'sonar', 'ecoli', 'diabetes', 'heart']
KFCPL_LAMBDAS = [0.01, 0.1, 1.0, 10.0, 100.0]
KFCPL_GAMMAS = [0.001, 0.01, 0.1, 1.0, 10.0, 100.0]


def fcpl_grid_search(ds_name, n_repeats=3):
    """Grid search FCPL on one dataset."""
    X, y, n_clusters = get_dataset(ds_name, random_state=42)
    n = len(X)
    
    rows = []
    best_acc = -1
    best_params = None
    
    for lam, m in itertools.product(FCPL_LAMBDAS, FCPL_MS):
        accs, nmis, aris = [], [], []
        for rep in range(n_repeats):
            rs = 42 + rep
            _, P, cm = get_constraint_samples(y, 0.1, rs)
            try:
                model = FCPL(n_clusters=n_clusters, m=m, lam=lam,
                            max_iter=100, tol=1e-5, random_state=rs)
                model.fit(X, P, cm)
                res = evaluate_clustering(y, model.labels_)
                accs.append(res['ACC'])
                nmis.append(res['NMI'])
                aris.append(res['ARI'])
            except Exception:
                accs.append(0); nmis.append(0); aris.append(0)
        
        mean_acc = np.mean(accs)
        rows.append({
            'Dataset': ds_name, 'lambda': lam, 'm': m,
            'ACC_mean': mean_acc, 'ACC_std': np.std(accs),
            'NMI_mean': np.mean(nmis), 'ARI_mean': np.mean(aris)
        })
        
        if mean_acc > best_acc:
            best_acc = mean_acc
            best_params = (lam, m, mean_acc, np.mean(nmis), np.mean(aris))
    
    return rows, best_params


def kfcpl_grid_search(ds_name, n_repeats=3):
    """Grid search KFCPL on one dataset."""
    X, y, n_clusters = get_dataset(ds_name, random_state=42)
    n = len(X)
    
    # Subsample if >3000
    if n > 3000:
        rng = np.random.RandomState(42)
        idx = rng.choice(n, 3000, replace=False)
        X, y = X[idx], y[idx]
    
    rows = []
    best_acc = -1
    best_params = None
    
    for lam, gamma in itertools.product(KFCPL_LAMBDAS, KFCPL_GAMMAS):
        accs, nmis, aris = [], [], []
        for rep in range(n_repeats):
            rs = 42 + rep
            _, P, cm = get_constraint_samples(y, 0.1, rs)
            try:
                model = KFCPL(n_clusters=n_clusters, m=2.0, lam=lam, gamma=gamma,
                             max_iter=100, tol=1e-5, random_state=rs)
                model.fit(X, P, cm)
                res = evaluate_clustering(y, model.labels_)
                accs.append(res['ACC'])
                nmis.append(res['NMI'])
                aris.append(res['ARI'])
            except Exception:
                accs.append(0); nmis.append(0); aris.append(0)
        
        mean_acc = np.mean(accs)
        rows.append({
            'Dataset': ds_name, 'lambda': lam, 'gamma': gamma, 'm': 2.0,
            'ACC_mean': mean_acc, 'ACC_std': np.std(accs),
            'NMI_mean': np.mean(nmis), 'ARI_mean': np.mean(aris)
        })
        
        if mean_acc > best_acc:
            best_acc = mean_acc
            best_params = (lam, 2.0, gamma, mean_acc, np.mean(nmis), np.mean(aris))
    
    return rows, best_params


def main():
    t_start = time.time()
    
    # ---- FCPL grid search ----
    print("=" * 60)
    print("Task 1: FCPL Grid Search")
    print("=" * 60)
    
    all_fcpl_rows = []
    fcpl_best = {}
    
    for ds in FCPL_DATASETS:
        print(f"\n  FCPL: {ds}...")
        rows, best = fcpl_grid_search(ds)
        all_fcpl_rows.extend(rows)
        fcpl_best[ds] = best
        print(f"    Best: λ={best[0]}, m={best[1]}, ACC={best[2]:.2f}%")
    
    df_fcpl = pd.DataFrame(all_fcpl_rows)
    df_fcpl.to_csv(os.path.join(RESULTS_DIR, 'exp_grid_search_fcpl_full.csv'), index=False)
    
    df_fcpl_best = pd.DataFrame([
        {'Dataset': ds, 'Best_lambda': b[0], 'Best_m': b[1],
         'Best_ACC': b[2], 'Best_NMI': b[3], 'Best_ARI': b[4]}
        for ds, b in fcpl_best.items()
    ])
    df_fcpl_best.to_csv(os.path.join(RESULTS_DIR, 'exp_best_params_fcpl.csv'), index=False)
    
    print(f"\nFCPL grid search done ({time.time()-t_start:.1f}s)")
    
    # ---- KFCPL grid search ----
    t2 = time.time()
    print("\n" + "=" * 60)
    print("Task 2: KFCPL Grid Search")
    print("=" * 60)
    
    all_kfcpl_rows = []
    kfcpl_best = {}
    
    for ds in KFCPL_DATASETS:
        print(f"\n  KFCPL: {ds}...")
        rows, best = kfcpl_grid_search(ds)
        all_kfcpl_rows.extend(rows)
        kfcpl_best[ds] = best
        print(f"    Best: λ={best[0]}, m={best[1]}, γ={best[2]}, ACC={best[3]:.2f}%")
    
    df_kfcpl = pd.DataFrame(all_kfcpl_rows)
    df_kfcpl.to_csv(os.path.join(RESULTS_DIR, 'exp_grid_search_kfcpl_full.csv'), index=False)
    
    df_kfcpl_best = pd.DataFrame([
        {'Dataset': ds, 'Best_lambda': b[0], 'Best_m': b[1], 'Best_gamma': b[2],
         'Best_ACC': b[3], 'Best_NMI': b[4], 'Best_ARI': b[5]}
        for ds, b in kfcpl_best.items()
    ])
    df_kfcpl_best.to_csv(os.path.join(RESULTS_DIR, 'exp_best_params_kfcpl.csv'), index=False)
    
    print(f"\nKFCPL grid search done ({time.time()-t2:.1f}s)")
    
    # Print summary
    print("\n" + "=" * 70)
    print("OPTIMAL PARAMETERS SUMMARY")
    print("=" * 70)
    print("\nFCPL:")
    print(df_fcpl_best.to_string(index=False))
    print("\nKFCPL:")
    print(df_kfcpl_best.to_string(index=False))
    
    print(f"\nTotal time: {time.time()-t_start:.1f}s")


if __name__ == '__main__':
    main()
