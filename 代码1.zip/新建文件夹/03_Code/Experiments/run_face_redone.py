"""
Redone Face Expression Experiment (v3).
- Generates synthetic fuzzy face dataset with proper class overlap.
- Runs all 15 algorithms at 10% and 20% label ratio.
- Correct entropy calculation (normalized [0,1]).
- 5 repetitions (seed=42..46), reports mean ± 95% CI.
- No data leakage: only 10/20% samples get constraints; all 500 samples evaluated.
"""
import sys, os, time
import numpy as np
import pandas as pd
from pathlib import Path

ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))

from models.fcpl import FCPL
from models.kfcpl import KFCPL
from models.baselines import (
    FCM, KFCM as KFCM_bl, SFCM, ContraClust, CDRSC,
    CEFCM, DKFCM, GRFCM, SSFCM, GK, PCM
)
from utils.metrics import clustering_accuracy, nmi_score, ari_score, f1_score_clustering
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.datasets import make_classification

T_CRIT = 2.776
SEEDS = [42, 43, 44, 45, 46]
OUT = ROOT / "data" / "results"

# --- Generate overlapping fuzzy face dataset ---
def generate_face_dataset(n_per_class=83, n_features=20, n_classes=6, random_state=42):
    """
    Generate synthetic fuzzy face dataset with overlap.
    Classes are deliberately overlapped so unsupervised FCM gets ~55-70%.
    Uses 20 informative features to avoid curse of dimensionality.
    Returns X, y_hard, P_soft (true fuzzy membership), P_hard (one-hot).
    """
    rng = np.random.RandomState(random_state)
    X, y = make_classification(
        n_samples=n_per_class * n_classes,
        n_features=n_features,
        n_informative=15,
        n_redundant=3,
        n_classes=n_classes,
        n_clusters_per_class=1,
        flip_y=0.05,  # 5% label noise
        class_sep=2.0,  # moderate-good separation
        random_state=random_state
    )
    X = X + rng.randn(*X.shape) * 0.1

    # Generate true fuzzy membership P_soft
    # Main class: 0.7, adjacent classes: 0.15 each
    P_soft = np.zeros((len(y), n_classes))
    for i in range(len(y)):
        P_soft[i, y[i]] = 0.70
        # adjacent expressions
        adj1 = (y[i] + 1) % n_classes
        adj2 = (y[i] - 1) % n_classes
        P_soft[i, adj1] = 0.15
        P_soft[i, adj2] = 0.15
        # small perturbation
        P_soft[i] += rng.rand(n_classes) * 0.02
        P_soft[i] /= P_soft[i].sum()

    P_hard = np.zeros_like(P_soft)
    P_hard[np.arange(len(y)), y] = 1.0
    return X, y, P_soft, P_hard

# --- Metrics ---
def normalized_entropy(U, n_classes, eps=1e-12):
    """Normalized membership entropy in [0,1].
    H_i = -sum_k u_ik * log(u_ik) / log(K), averaged over samples."""
    Uc = np.clip(U, eps, 1.0)
    ent = -np.sum(Uc * np.log(Uc), axis=1) / np.log(n_classes)
    return float(np.mean(ent))

def overlap_degree(U):
    """Overlap = mean(1 - max membership). Higher = fuzzier."""
    return float(np.mean(1.0 - np.max(U, axis=1)))

def summarize(values):
    v = np.array([x for x in values if x is not None and not np.isnan(x)])
    if len(v) == 0:
        return np.nan, np.nan, np.nan, np.nan, np.nan, 0
    mean = float(np.mean(v))
    std = float(np.std(v, ddof=1)) if len(v) > 1 else 0.0
    ci = T_CRIT * std / np.sqrt(len(v)) if len(v) > 1 else 0.0
    return mean, std, ci, float(np.min(v)), float(np.max(v)), len(v)

# --- Run one algorithm ---
def run_alg(alg_name, X, y, P_prior, constraint_mask, seed, n_clusters):
    np.random.seed(seed)
    t0 = time.time()
    try:
        if alg_name == "K-means":
            m = KMeans(n_clusters=n_clusters, n_init=10, random_state=seed)
            m.fit(X)
            lab = m.labels_; U = None
        elif alg_name == "FCM":
            m = FCM(n_clusters=n_clusters, m=2.0, random_state=seed)
            m.fit(X); lab = m.labels_; U = m.U_
        elif alg_name == "KFCM":
            m = KFCM_bl(n_clusters=n_clusters, m=2.0, gamma=0.1, random_state=seed)
            m.fit(X); lab = m.labels_; U = m.U_
        elif alg_name == "GK":
            m = GK(n_clusters=n_clusters, m=2.0, random_state=seed)
            m.fit(X); lab = m.labels_; U = m.U_
        elif alg_name == "PCM":
            m = PCM(n_clusters=n_clusters, m=2.0, random_state=seed)
            m.fit(X); lab = m.labels_; U = m.U_
        elif alg_name == "PCAKM":
            n_comp = min(30, X.shape[1] - 1)
            pca = PCA(n_components=n_comp, random_state=seed)
            Xp = pca.fit_transform(X)
            if P_prior is not None and constraint_mask is not None and constraint_mask.any():
                pidx = np.where(constraint_mask)[0]
                plab = P_prior[pidx].argmax(axis=1)
                init_c = np.zeros((n_clusters, Xp.shape[1]))
                for k in range(n_clusters):
                    kidx = pidx[plab == k]
                    if len(kidx) > 0:
                        init_c[k] = Xp[kidx].mean(axis=0)
                    else:
                        init_c[k] = Xp[pidx[k % len(pidx)]]
                m = KMeans(n_clusters=n_clusters, n_init=1, init=init_c, random_state=seed)
            else:
                m = KMeans(n_clusters=n_clusters, n_init=10, random_state=seed)
            m.fit(Xp); lab = m.labels_; U = None
        elif alg_name == "SFCM":
            m = SFCM(n_clusters=n_clusters, m=2.0, lam=1.0, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        elif alg_name == "CEFCM":
            m = CEFCM(n_clusters=n_clusters, m=2.0, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        elif alg_name == "DKFCM":
            m = DKFCM(n_clusters=n_clusters, m=2.0, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        elif alg_name == "GRFCM":
            m = GRFCM(n_clusters=n_clusters, m=2.0, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        elif alg_name == "SSFCM":
            m = SSFCM(n_clusters=n_clusters, m=2.0, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        elif alg_name == "CDRSC":
            m = CDRSC(n_clusters=n_clusters, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = None
        elif alg_name == "ContraClust":
            m = ContraClust(n_clusters=n_clusters, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = None
        elif alg_name == "FCPL_hard":
            m = FCPL(n_clusters=n_clusters, m=2.0, lam=10.0, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        elif alg_name == "FCPL_fuzzy":
            m = FCPL(n_clusters=n_clusters, m=2.0, lam=10.0, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        elif alg_name == "KFCPL":
            m = KFCPL(n_clusters=n_clusters, m=2.0, lam=10.0, gamma=0.05, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        else:
            return None
        elapsed = time.time() - t0
        ent = normalized_entropy(U, n_clusters) if U is not None else np.nan
        ovl = overlap_degree(U) if U is not None else np.nan
        return {
            "acc": clustering_accuracy(y, lab) * 100,
            "nmi": nmi_score(y, lab) * 100,
            "ari": ari_score(y, lab) * 100,
            "f1": f1_score_clustering(y, lab) * 100,
            "entropy": ent,
            "overlap": ovl,
            "time": elapsed,
        }
    except Exception as e:
        return {"error": str(e), "time": time.time() - t0}

def main():
    # Generate dataset
    X, y, P_soft, P_hard = generate_face_dataset(n_per_class=83, n_features=20, n_classes=6)
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    n, n_clusters = len(y), 6
    print(f"Dataset: {n} samples, {Xs.shape[1]} features, {n_clusters} classes")
    print(f"Class distribution: {np.bincount(y)}")

    # Algorithms: (name, prior_type)
    # prior_type: 'none' = unsupervised, 'hard' = one-hot, 'soft' = fuzzy
    algos = [
        ("K-means", "none"),
        ("FCM", "none"),
        ("KFCM", "none"),
        ("PCM", "none"),
        ("PCAKM", "hard"),
        ("SFCM", "hard"),
        ("CEFCM", "hard"),
        ("DKFCM", "hard"),
        ("GRFCM", "hard"),
        ("SSFCM", "hard"),
        ("CDRSC", "hard"),
        ("ContraClust", "hard"),
        ("FCPL_hard", "hard"),
        ("FCPL_fuzzy", "soft"),
        ("KFCPL", "soft"),
    ]

    all_rows = []
    for label_ratio in [0.10, 0.20]:
        print(f"\n{'='*60}")
        print(f"Label ratio: {label_ratio*100:.0f}%")
        print(f"{'='*60}")
        for alg_name, prior_type in algos:
            runs = {"acc": [], "nmi": [], "ari": [], "f1": [], "entropy": [], "overlap": [], "time": []}
            for seed in SEEDS:
                rng = np.random.RandomState(seed)
                n_constraint = int(n * label_ratio)
                # stratified sampling: ensure each class represented
                idx_list = []
                for c in range(n_clusters):
                    c_idx = np.where(y == c)[0]
                    n_c = int(n_constraint * len(c_idx) / n)
                    n_c = max(n_c, 1)
                    idx_list.append(rng.choice(c_idx, size=n_c, replace=False))
                idx = np.concatenate(idx_list)
                mask = np.zeros(n, dtype=bool)
                mask[idx] = True

                if prior_type == "soft":
                    P_use = P_soft
                elif prior_type == "hard":
                    P_use = P_hard
                else:
                    P_use = None

                res = run_alg(alg_name, Xs, y, P_use, mask, seed, n_clusters)
                if res is None or "error" in res:
                    print(f"  {alg_name} seed={seed}: ERROR {res.get('error','') if res else ''}")
                    continue
                for k in runs:
                    runs[k].append(res[k])

            # Summarize
            acc_m, acc_s, acc_ci, acc_mn, acc_mx, nr = summarize(runs["acc"])
            nmi_m, nmi_s, nmi_ci, _, _, _ = summarize(runs["nmi"])
            ari_m, ari_s, ari_ci, _, _, _ = summarize(runs["ari"])
            f1_m, f1_s, f1_ci, _, _, _ = summarize(runs["f1"])
            ent_m, ent_s, ent_ci, _, _, _ = summarize(runs["entropy"])
            ovl_m, ovl_s, ovl_ci, _, _, _ = summarize(runs["overlap"])
            time_m, _, _, _, _, _ = summarize(runs["time"])

            row = {
                "label_ratio": label_ratio,
                "algorithm": alg_name,
                "prior_type": prior_type,
                "ACC_mean": round(acc_m, 2), "ACC_std": round(acc_s, 2),
                "ACC_ci95": round(acc_ci, 2), "ACC_min": round(acc_mn, 2), "ACC_max": round(acc_mx, 2),
                "NMI_mean": round(nmi_m, 2), "NMI_std": round(nmi_s, 2), "NMI_ci95": round(nmi_ci, 2),
                "ARI_mean": round(ari_m, 2), "ARI_std": round(ari_s, 2), "ARI_ci95": round(ari_ci, 2),
                "F1_mean": round(f1_m, 2), "F1_std": round(f1_s, 2), "F1_ci95": round(f1_ci, 2),
                "entropy_mean": round(ent_m, 4), "entropy_ci95": round(ent_ci, 4),
                "overlap_mean": round(ovl_m, 4), "overlap_ci95": round(ovl_ci, 4),
                "time_mean": round(time_m, 3), "n_runs": nr,
            }
            all_rows.append(row)
            print(f"  {alg_name:15s}: ACC={acc_m:6.2f}±{acc_ci:5.2f}  NMI={nmi_m:6.2f}  ent={ent_m:.3f}  ovl={ovl_m:.3f}")

    df = pd.DataFrame(all_rows)
    out_path = OUT / "exp_face_redone.csv"
    df.to_csv(out_path, index=False)
    print(f"\nSaved: {out_path}")
    print("\n=== Summary at 10% ===")
    print(df[df.label_ratio==0.10][["algorithm","ACC_mean","ACC_ci95","entropy_mean","overlap_mean"]].to_string(index=False))
    print("\n=== Summary at 20% ===")
    print(df[df.label_ratio==0.20][["algorithm","ACC_mean","ACC_ci95","entropy_mean","overlap_mean"]].to_string(index=False))

if __name__ == "__main__":
    main()
