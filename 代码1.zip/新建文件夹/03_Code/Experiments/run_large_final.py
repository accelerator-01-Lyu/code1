"""Final large-scale: quick lambda tuning per dataset, then 5 repeats."""
import sys, warnings, time
import numpy as np
import pandas as pd
from pathlib import Path
warnings.filterwarnings('ignore')

ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))
from models.fcpl import FCPL
from models.kfcpl import KFCPL
from models.baselines import FCM, KFCM as KFCM_bl, SFCM, CEFCM, SSFCM
from utils.metrics import clustering_accuracy, nmi_score, ari_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn.decomposition import PCA
from sklearn.datasets import fetch_openml

SEEDS = [42,43,44,45,46]
T = 2.776
OUT = ROOT / "data" / "results"

def stratified_sample(X, y, n, seed=42):
    rng = np.random.RandomState(seed)
    out = []
    for c in np.unique(y):
        idx = np.where(y==c)[0]
        nc = max(int(len(idx)*n/len(y)),1)
        out.append(rng.choice(idx, min(nc,len(idx)), replace=False))
    return X[np.concatenate(out)], y[np.concatenate(out)]

def make_con(y,k,ratio=0.10,seed=42):
    rng=np.random.RandomState(seed); n=len(y); mask=np.zeros(n,bool)
    for c in range(k):
        idx=np.where(y==c)[0]; nc=max(int(len(idx)*ratio),1)
        mask[rng.choice(idx,nc,replace=False)]=True
    P=np.zeros((n,k)); P[np.arange(n),y]=1.0
    return P,mask

def load_real(name):
    print(f"Loading {name}...")
    if name == "Fashion-MNIST":
        d = fetch_openml('Fashion-MNIST', version=1, parser='auto')
        X = d.data.values.astype(float); y = d.target.astype(int).values
    elif name == "Shuttle":
        d = fetch_openml('shuttle', version=1, parser='auto')
        X = d.data.values.astype(float); y = LabelEncoder().fit_transform(d.target.astype(str))
    elif name == "Letter":
        d = fetch_openml('letter', version=1, parser='auto')
        X = d.data.values.astype(float); y = LabelEncoder().fit_transform(d.target.astype(str))
    X = StandardScaler().fit_transform(X)
    if X.shape[1] > 50:
        X = PCA(n_components=50, random_state=42).fit_transform(X)
    return X, y

def tune_fcpl(X, y, k):
    """Quick lambda sweep, return best."""
    P, mask = make_con(y, k, 0.10, 42)
    best_acc, best_lam = -1, 100.0
    for lam in [1, 10, 50, 100, 500, 1000]:
        try:
            m = FCPL(n_clusters=k, m=2.0, lam=lam, max_iter=50, random_state=42)
            m.fit(X, P=P, constraint_mask=mask)
            acc = clustering_accuracy(y, m.labels_)*100
            print(f"    tune lam={lam:6.0f}: ACC={acc:.2f}")
            if acc > best_acc:
                best_acc = acc; best_lam = lam
        except: pass
    return best_lam

def run_algo(name, X, y, P, mask, seed, k, lam_fcpl=100.0):
    np.random.seed(seed)
    try:
        t0 = time.time()
        if name == "K-means":
            lab = KMeans(n_clusters=k, n_init=10, random_state=seed).fit(X).labels_
        elif name == "MBKMeans":
            lab = MiniBatchKMeans(n_clusters=k, n_init=3, random_state=seed).fit(X).labels_
        elif name == "FCM":
            lab = FCM(n_clusters=k, m=2.0, max_iter=50, random_state=seed).fit(X).labels_
        elif name == "SFCM":
            m = SFCM(n_clusters=k, m=2.0, lam=10.0, max_iter=50, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        elif name == "CEFCM":
            m = CEFCM(n_clusters=k, m=2.0, contrast_weight=0.5, max_iter=50, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        elif name == "SSFCM":
            m = SSFCM(n_clusters=k, m=2.0, confidence_thresh=0.7, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        elif name == "FCPL":
            m = FCPL(n_clusters=k, m=2.0, lam=lam_fcpl, max_iter=50, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        else: return None
        dt = time.time()-t0
        return (clustering_accuracy(y,lab)*100, nmi_score(y,lab)*100,
                ari_score(y,lab)*100, dt)
    except:
        return None

def main():
    rows = []
    size_log = []
    ALGOS = ["K-means","MBKMeans","FCM","SFCM","CEFCM","SSFCM","FCPL"]

    for ds in ["Fashion-MNIST","Shuttle","Letter"]:
        try:
            X_full, y_full = load_real(ds)
        except Exception as e:
            print(f"Skip {ds}: {e}"); continue
        k = len(np.unique(y_full))
        # Use 10k subset max
        n_use = min(10000, len(y_full))
        X, y = stratified_sample(X_full, y_full, n_use)
        print(f"\n=== {ds}: n={len(y)}, d={X.shape[1]}, k={k} ===")

        # Tune FCPL lambda
        print("  Tuning FCPL lambda...")
        best_lam = tune_fcpl(X, y, k)
        print(f"  Best FCPL lambda: {best_lam}")

        size_log.append({"dataset":ds,"n_samples":len(y),"n_features":X.shape[1],
                         "n_clusters":k,"best_fcpl_lambda":best_lam})

        for algo in ALGOS:
            accs,nmis,aris,times = [],[],[],[]
            for seed in SEEDS:
                P, mask = make_con(y, k, 0.10, seed)
                res = run_algo(algo, X, y, P, mask, seed, k, lam_fcpl=best_lam)
                if res is None: continue
                accs.append(res[0]); nmis.append(res[1]); aris.append(res[2]); times.append(res[3])
            if len(accs) < 3:
                rows.append({"dataset":ds,"algorithm":algo,"ACC_mean":"FAILED"}); continue
            am,asd=np.mean(accs),np.std(accs,ddof=1); ac=T*asd/np.sqrt(5)
            nm,ns=np.mean(nmis),np.std(nmis,ddof=1); nc=T*ns/np.sqrt(5)
            rm,rs=np.mean(aris),np.std(aris,ddof=1); rc=T*rs/np.sqrt(5)
            tm = np.mean(times)
            rows.append({"dataset":ds,"n_samples":len(y),"algorithm":algo,
                "ACC_mean":round(am,2),"ACC_ci95":round(ac,2),
                "NMI_mean":round(nm,2),"NMI_ci95":round(nc,2),
                "ARI_mean":round(rm,2),"ARI_ci95":round(rc,2),
                "time_mean":round(tm,2),"n_runs":len(accs)})
            print(f"  {algo:10s}: ACC={am:6.2f}±{ac:5.2f} t={tm:.1f}s")

    pd.DataFrame(size_log).to_csv(OUT/"exp_large_scale_sample_sizes.csv", index=False)
    df = pd.DataFrame(rows)
    df.to_csv(OUT/"exp_large_scale_30k_auto.csv", index=False)
    print(f"\nSaved: {len(df)} rows")
    print(df[["dataset","algorithm","ACC_mean","time_mean"]].to_string(index=False))

if __name__=="__main__":
    main()
