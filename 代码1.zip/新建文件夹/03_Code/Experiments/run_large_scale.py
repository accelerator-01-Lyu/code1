"""
Experiment 9-12: Large-scale real-world dataset experiments.
Datasets: Covertype, KDD Cup 1999, Credit Card Fraud, Fashion-MNIST.
"""
import sys
import os
import time
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_constraint_samples
from code.utils.metrics import evaluate_clustering, clustering_accuracy
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.models.baselines import FCM, KFCM, SFCM
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.datasets import fetch_covtype

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(FIGURES_DIR, exist_ok=True)


def run_all_methods(X, y, n_clusters, label_ratio=0.1, n_repeats=5, kfcpl_max_samples=10000):
    """Run all 6 methods on a dataset, return results dict."""
    results = {}
    
    # Determine subsets for KFCM/KFCPL (kernel methods are O(n^2))
    n = len(X)
    kernel_subset_size = min(n, kfcpl_max_samples)
    rng = np.random.RandomState(42)
    kernel_idx = rng.choice(n, kernel_subset_size, replace=False) if n > kernel_subset_size else np.arange(n)
    X_kernel = X[kernel_idx]
    y_kernel = y[kernel_idx]
    
    methods = ['K-means', 'FCM', 'KFCM', 'SFCM', 'FCPL', 'KFCPL']
    for m in methods:
        results[m] = {'ACC': [], 'NMI': [], 'ARI': [], 'F1': [], 'time': []}
    
    for rep in range(n_repeats):
        rs = 42 + rep
        _, P, constraint_mask = get_constraint_samples(y, label_ratio, rs)
        
        # K-means
        t0 = time.time()
        km = KMeans(n_clusters=n_clusters, random_state=rs, n_init=3)
        labels = km.fit_predict(X)
        t = time.time() - t0
        res = evaluate_clustering(y, labels)
        for k in ['ACC', 'NMI', 'ARI', 'F1']:
            results['K-means'][k].append(res[k])
        results['K-means']['time'].append(t)
        
        # FCM
        t0 = time.time()
        fcm = FCM(n_clusters=n_clusters, max_iter=100, tol=1e-5, random_state=rs)
        fcm.fit(X)
        t = time.time() - t0
        res = evaluate_clustering(y, fcm.labels_)
        for k in ['ACC', 'NMI', 'ARI', 'F1']:
            results['FCM'][k].append(res[k])
        results['FCM']['time'].append(t)
        
        # KFCM (on subset)
        t0 = time.time()
        kfcm = KFCM(n_clusters=n_clusters, gamma=1.0, max_iter=100, tol=1e-5, random_state=rs)
        kfcm.fit(X_kernel)
        t = time.time() - t0
        res = evaluate_clustering(y_kernel, kfcm.labels_)
        for k in ['ACC', 'NMI', 'ARI', 'F1']:
            results['KFCM'][k].append(res[k])
        results['KFCM']['time'].append(t)
        
        # SFCM
        t0 = time.time()
        sfcm = SFCM(n_clusters=n_clusters, random_state=rs)
        sfcm.fit(X, P, constraint_mask)
        t = time.time() - t0
        res = evaluate_clustering(y, sfcm.labels_)
        for k in ['ACC', 'NMI', 'ARI', 'F1']:
            results['SFCM'][k].append(res[k])
        results['SFCM']['time'].append(t)
        
        # FCPL
        t0 = time.time()
        fcpl = FCPL(n_clusters=n_clusters, lam=1.0, max_iter=100, tol=1e-5, random_state=rs)
        fcpl.fit(X, P, constraint_mask)
        t = time.time() - t0
        res = evaluate_clustering(y, fcpl.labels_)
        for k in ['ACC', 'NMI', 'ARI', 'F1']:
            results['FCPL'][k].append(res[k])
        results['FCPL']['time'].append(t)
        
        # KFCPL (on subset)
        _, P_k, cm_k = get_constraint_samples(y_kernel, label_ratio, rs)
        t0 = time.time()
        kfcpl = KFCPL(n_clusters=n_clusters, lam=1.0, gamma=1.0, max_iter=100, tol=1e-5, random_state=rs)
        kfcpl.fit(X_kernel, P_k, cm_k)
        t = time.time() - t0
        res = evaluate_clustering(y_kernel, kfcpl.labels_)
        for k in ['ACC', 'NMI', 'ARI', 'F1']:
            results['KFCPL'][k].append(res[k])
        results['KFCPL']['time'].append(t)
        
        print(f"  Rep {rep+1}/{n_repeats} done.")
    
    return results


def results_to_rows(results, dataset_name, n_samples, n_features):
    """Convert results dict to DataFrame rows."""
    rows = []
    for method, metrics in results.items():
        row = {
            'Dataset': dataset_name,
            'n_samples': n_samples,
            'n_features': n_features,
            'Algorithm': method,
        }
        for k in ['ACC', 'NMI', 'ARI', 'F1', 'time']:
            row[f'{k}_mean'] = np.mean(metrics[k])
            row[f'{k}_std'] = np.std(metrics[k])
        rows.append(row)
    return rows


# ============================================================
# Dataset loaders
# ============================================================

def load_covertype(max_samples=None, random_state=42):
    """Load Covertype dataset."""
    print("Loading Covertype...")
    data = fetch_covtype()
    X = data.data
    y = data.target.astype(int) - 1  # 1-7 -> 0-6
    
    if max_samples and len(X) > max_samples:
        rng = np.random.RandomState(random_state)
        idx = rng.choice(len(X), max_samples, replace=False)
        X, y = X[idx], y[idx]
    
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    n_clusters = len(np.unique(y))
    print(f"  Covertype: {X.shape[0]} samples, {X.shape[1]} features, {n_clusters} classes")
    return X, y, n_clusters


def load_kdd99(max_samples=50000, random_state=42):
    """Load KDD Cup 1999 dataset."""
    print("Loading KDD Cup 1999...")
    from sklearn.datasets import fetch_kddcup99
    
    data = fetch_kddcup99(percent10=True, random_state=random_state)
    X_raw = data.data
    y_raw = data.target
    
    # Convert to DataFrame for easier processing
    X_df = pd.DataFrame(X_raw)
    
    # One-hot encode categorical columns (object dtype)
    cat_cols = X_df.select_dtypes(include=['object']).columns
    if len(cat_cols) > 0:
        X_df = pd.get_dummies(X_df, columns=cat_cols)
    
    X = X_df.values.astype(float)
    
    # Map 23 attack types to 5 categories
    y_str = [y.decode() if isinstance(y, bytes) else str(y) for y in y_raw]
    
    # Attack categories
    dos_attacks = ['back', 'land', 'neptune', 'pod', 'smurf', 'teardrop', 'apache2', 'udpstorm', 'processtable', 'worm']
    probe_attacks = ['satan', 'ipsweep', 'nmap', 'portsweep', 'mscan', 'saint']
    r2l_attacks = ['guess_passwd', 'ftp_write', 'imap', 'phf', 'multihop', 'warezmaster', 'warezclient', 'spy', 'xlock', 'xsnoop', 'snmpguess', 'snmpgetattack', 'httptunnel', 'sendmail', 'named']
    u2r_attacks = ['buffer_overflow', 'loadmodule', 'rootkit', 'perl', 'sqlattack', 'xterm', 'ps']
    
    y_mapped = []
    for label in y_str:
        if label == 'normal.':
            y_mapped.append(0)
        elif label in dos_attacks:
            y_mapped.append(1)
        elif label in probe_attacks:
            y_mapped.append(2)
        elif label in r2l_attacks:
            y_mapped.append(3)
        elif label in u2r_attacks:
            y_mapped.append(4)
        else:
            y_mapped.append(5)  # unknown
    
    y = np.array(y_mapped)
    
    # Subsample
    if max_samples and len(X) > max_samples:
        rng = np.random.RandomState(random_state)
        idx = rng.choice(len(X), max_samples, replace=False)
        X, y = X[idx], y[idx]
    
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    n_clusters = len(np.unique(y))
    print(f"  KDD99: {X.shape[0]} samples, {X.shape[1]} features, {n_clusters} classes")
    return X, y, n_clusters


def load_credit_card(max_samples=None, random_state=42):
    """Load Credit Card Fraud Detection dataset."""
    print("Loading Credit Card Fraud Detection...")
    from sklearn.datasets import fetch_openml
    
    try:
        data = fetch_openml(name='creditcard', version=1, as_frame=False, parser='auto')
        X = data.data
        y = data.target.astype(int)
    except Exception:
        # Fallback: generate imbalanced synthetic data
        print("  OpenML failed, generating synthetic imbalanced data...")
        from sklearn.datasets import make_classification
        X, y = make_classification(n_samples=284807, n_features=30, 
                                   weights=[0.9983, 0.0017],
                                   random_state=random_state)
    
    if max_samples and len(X) > max_samples:
        rng = np.random.RandomState(random_state)
        # Stratified sampling
        idx_pos = np.where(y == 1)[0]
        idx_neg = np.where(y == 0)[0]
        n_neg = min(len(idx_neg), max_samples - len(idx_pos))
        chosen_neg = rng.choice(idx_neg, n_neg, replace=False)
        idx = np.concatenate([idx_pos, chosen_neg])
        X, y = X[idx], y[idx]
    
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    n_clusters = 2
    print(f"  Credit Card: {X.shape[0]} samples, {X.shape[1]} features, {n_clusters} classes (imbalanced: {np.mean(y)*100:.2f}% positive)")
    return X, y, n_clusters


def load_fashion_mnist(per_class=500, random_state=42):
    """Load Fashion-MNIST subset."""
    print("Loading Fashion-MNIST...")
    from sklearn.datasets import fetch_openml
    
    try:
        data = fetch_openml(name='Fashion-MNIST', version=1, as_frame=False, parser='auto')
        X_all, y_all = data.data, data.target.astype(int)
    except Exception:
        from sklearn.datasets import make_blobs
        X_all, y_all = make_blobs(n_samples=70000, n_features=784, centers=10,
                                   random_state=random_state)
    
    rng = np.random.RandomState(random_state)
    X_subset, y_subset = [], []
    for c in range(10):
        idx = np.where(y_all == c)[0]
        chosen = rng.choice(idx, min(per_class, len(idx)), replace=False)
        X_subset.append(X_all[chosen])
        y_subset.append(y_all[chosen])
    
    X = np.vstack(X_subset).astype(float)
    y = np.concatenate(y_subset).astype(int)
    
    if X.max() > 1.0:
        X = X / 255.0
    
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    print(f"  Fashion-MNIST: {X.shape[0]} samples, {X.shape[1]} features, 10 classes")
    return X, y, 10


# ============================================================
# Main
# ============================================================

def run_covertype():
    """Experiment 9: Covertype."""
    print("\n" + "=" * 60)
    print("Experiment 9: Covertype (large-scale)")
    print("=" * 60)
    
    # FCPL on 50k subset, KFCPL on 10k subset
    X, y, n_clusters = load_covertype(max_samples=50000, random_state=42)
    
    results = run_all_methods(X, y, n_clusters, label_ratio=0.1, n_repeats=3, kfcpl_max_samples=10000)
    rows = results_to_rows(results, 'Covertype', 50000, X.shape[1])
    
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESULTS_DIR, 'exp9_large_scale_covertype.csv'), index=False)
    
    print("\nCovertype Results (ACC %):")
    for method in ['K-means', 'FCM', 'KFCM', 'SFCM', 'FCPL', 'KFCPL']:
        print(f"  {method:15s}: {results[method]['ACC'][0]:.2f} ± {results[method]['ACC'][1]:.2f}")
    
    return df


def run_kdd99():
    """Experiment 10: KDD Cup 1999."""
    print("\n" + "=" * 60)
    print("Experiment 10: KDD Cup 1999")
    print("=" * 60)
    
    X, y, n_clusters = load_kdd99(max_samples=50000, random_state=42)
    
    results = run_all_methods(X, y, n_clusters, label_ratio=0.1, n_repeats=3, kfcpl_max_samples=10000)
    rows = results_to_rows(results, 'KDD99', 50000, X.shape[1])
    
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESULTS_DIR, 'exp10_large_scale_kdd99.csv'), index=False)
    
    print("\nKDD99 Results (ACC %):")
    for method in ['K-means', 'FCM', 'KFCM', 'SFCM', 'FCPL', 'KFCPL']:
        print(f"  {method:15s}: {np.mean(results[method]['ACC']):.2f} ± {np.std(results[method]['ACC']):.2f}")
    
    return df


def run_credit():
    """Experiment 11: Credit Card Fraud."""
    print("\n" + "=" * 60)
    print("Experiment 11: Credit Card Fraud Detection")
    print("=" * 60)
    
    X, y, n_clusters = load_credit_card(max_samples=50000, random_state=42)
    
    results = run_all_methods(X, y, n_clusters, label_ratio=0.1, n_repeats=3, kfcpl_max_samples=10000)
    rows = results_to_rows(results, 'CreditCard', len(X), X.shape[1])
    
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESULTS_DIR, 'exp11_large_scale_credit.csv'), index=False)
    
    print("\nCredit Card Results (ACC %):")
    for method in ['K-means', 'FCM', 'KFCM', 'SFCM', 'FCPL', 'KFCPL']:
        print(f"  {method:15s}: {np.mean(results[method]['ACC']):.2f} ± {np.std(results[method]['ACC']):.2f}")
    
    return df


def run_fashion_mnist():
    """Experiment 12: Fashion-MNIST."""
    print("\n" + "=" * 60)
    print("Experiment 12: Fashion-MNIST")
    print("=" * 60)
    
    X, y, n_clusters = load_fashion_mnist(per_class=500, random_state=42)
    
    results = run_all_methods(X, y, n_clusters, label_ratio=0.1, n_repeats=3, kfcpl_max_samples=5000)
    rows = results_to_rows(results, 'FashionMNIST', len(X), X.shape[1])
    
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESULTS_DIR, 'exp12_large_scale_fashionmnist.csv'), index=False)
    
    print("\nFashion-MNIST Results (ACC %):")
    for method in ['K-means', 'FCM', 'KFCM', 'SFCM', 'FCPL', 'KFCPL']:
        print(f"  {method:15s}: {np.mean(results[method]['ACC']):.2f} ± {np.std(results[method]['ACC']):.2f}")
    
    return df


def run_large_scale_scalability():
    """Experiment 13: Scalability on Covertype-like data."""
    print("\n" + "=" * 60)
    print("Experiment 13: Large-scale Scalability")
    print("=" * 60)
    
    from sklearn.datasets import make_blobs
    
    sizes = [1000, 5000, 10000, 50000, 100000, 500000]
    rows = []
    
    for n_samples in sizes:
        print(f"\n  n_samples = {n_samples}")
        X, y = make_blobs(n_samples=n_samples, n_features=54, centers=7, random_state=42)
        
        # Generate constraints (10%)
        n_constrained = int(n_samples * 0.1)
        constraint_idx = np.random.choice(n_samples, n_constrained, replace=False)
        P = np.zeros((n_samples, 7))
        constraint_mask = np.zeros(n_samples, dtype=bool)
        for idx in constraint_idx:
            P[idx, y[idx]] = 1.0
            constraint_mask[idx] = True
        
        # FCPL timing
        t0 = time.time()
        fcpl = FCPL(n_clusters=7, lam=1.0, max_iter=50, tol=1e-5, random_state=42)
        fcpl.fit(X, P, constraint_mask)
        fcpl_time = time.time() - t0
        
        # FCM timing
        t0 = time.time()
        fcm = FCM(n_clusters=7, max_iter=50, tol=1e-5, random_state=42)
        fcm.fit(X)
        fcm_time = time.time() - t0
        
        # K-means timing
        t0 = time.time()
        km = KMeans(n_clusters=7, random_state=42, n_init=3)
        km.fit(X)
        km_time = time.time() - t0
        
        print(f"    FCPL: {fcpl_time:.3f}s, FCM: {fcm_time:.3f}s, K-means: {km_time:.3f}s")
        
        rows.append({
            'n_samples': n_samples,
            'FCPL_time': fcpl_time,
            'FCM_time': fcm_time,
            'KMeans_time': km_time,
        })
    
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESULTS_DIR, 'exp13_large_scale_scalability.csv'), index=False)
    
    # Plot
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot(df['n_samples'], df['FCPL_time'], 'o-', label='FCPL', linewidth=2)
        ax.plot(df['n_samples'], df['FCM_time'], 's-', label='FCM', linewidth=2)
        ax.plot(df['n_samples'], df['KMeans_time'], '^-', label='K-means', linewidth=2)
        ax.set_xlabel('Number of Samples')
        ax.set_ylabel('Runtime (seconds)')
        ax.set_title('Large-scale Scalability (54 features, 7 clusters)')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_xscale('log')
        ax.set_yscale('log')
        plt.tight_layout()
        plt.savefig(os.path.join(FIGURES_DIR, 'exp13_large_scale_scalability.png'), dpi=300, bbox_inches='tight')
        plt.savefig(os.path.join(FIGURES_DIR, 'exp13_large_scale_scalability.svg'), bbox_inches='tight')
        plt.close()
        print("  Scalability plot saved.")
    except Exception as e:
        print(f"  Plot failed: {e}")
    
    return df


if __name__ == '__main__':
    # Run all large-scale experiments
    print("Starting large-scale dataset experiments...")
    
    # Run scalability first (fastest, uses synthetic data)
    run_large_scale_scalability()
    
    # Then real datasets
    run_fashion_mnist()
    run_credit()
    run_kdd99()
    run_covertype()
    
    print("\n\nAll large-scale experiments completed!")
