"""
Task 1: Face expression experiment with ALL 14 algorithms.
Uses the provided face_features.csv and face_membership.csv.
FCPL uses soft/fuzzy prior P; SFCM uses hard one-hot prior.
5 repetitions (seed=42..46), reports mean ± 95% CI.
"""
import sys, os, time
import numpy as np
import pandas as pd
from pathlib import Path

ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))

from models.fcpl import FCPL
from models.kfcpl import KFCPL
from models.baselines import (
    FCM, KFCM as KFCM_bl, SFCM, SimplifiedDeepSC, ContraClust, CDRSC,
    CEFCM, DKFCM, GRFCM, SSFCM, GK, PCM
)
from utils.metrics import clustering_accuracy as compute_acc, nmi_score as compute_nmi, ari_score as compute_ari, f1_score_clustering as compute_f1
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

T_CRIT = 2.776  # t_{0.975, 4}
RATIO = 0.10
SEEDS = [42, 43, 44, 45, 46]

FACE_DIR = Path(r"D:\FCPL_最终交付包_v2\03_数据集\人脸表情数据集")
OUT = ROOT / "data" / "results"

def load_face():
    X_df = pd.read_csv(FACE_DIR / "face_features.csv")
    M_df = pd.read_csv(FACE_DIR / "face_membership.csv")
    # 64 feature columns
    feat_cols = [c for c in X_df.columns if c.startswith("feat_")]
    X = X_df[feat_cols].values.astype(np.float64)
    y_hard = M_df["hard_label"].values.astype(int)
    memb_cols = [c for c in M_df.columns if c.startswith("membership_")]
    P_soft = M_df[memb_cols].values.astype(np.float64)
    # normalize rows to sum 1
    P_soft = P_soft / P_soft.sum(axis=1, keepdims=True)
    # one-hot hard prior
    P_hard = np.zeros_like(P_soft)
    P_hard[np.arange(len(y_hard)), y_hard] = 1.0
    return X, y_hard, P_soft, P_hard, len(memb_cols)

def membership_entropy(U, eps=1e-12):
    """Average membership entropy in nats (per sample)."""
    Uc = np.clip(U, eps, 1.0)
    return -np.mean(np.sum(Uc * np.log(Uc), axis=1))

def run_one_alg(alg_name, X, y_true, P_prior, constraint_mask, seed, n_clusters):
    """Run one algorithm, return dict of metrics."""
    np.random.seed(seed)
    t0 = time.time()
    try:
        if alg_name == "K-means":
            m = KMeans(n_clusters=n_clusters, n_init=10, random_state=seed)
            m.fit(X)
            lab = m.labels_
            U = None
        elif alg_name == "FCM":
            m = FCM(n_clusters=n_clusters, m=2.0, random_state=seed)
            m.fit(X); lab = m.labels_; U = m.U_
        elif alg_name == "KFCM":
            m = KFCM_bl(n_clusters=n_clusters, m=2.0, gamma=0.1, random_state=seed)
            m.fit(X); lab = m.labels_; U = m.U_
        elif alg_name == "GK":
            m = GK(n_clusters=n_clusters, m=2.0, random_state=seed)
            m.fit(X); lab = m.labels_; U = m.U_
        elif alg_name == "PCM":
            m = PCM(n_clusters=n_clusters, m=2.0, random_state=seed)
            m.fit(X); lab = m.labels_; U = m.U_
        elif alg_name == "SFCM":
            m = SFCM(n_clusters=n_clusters, m=2.0, lam=1.0, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        elif alg_name == "PCAKM":
            # PCA to min(50, n_features-1) then KMeans, constrained via P
            n_comp = min(50, X.shape[1] - 1)
            pca = PCA(n_components=n_comp, random_state=seed)
            Xp = pca.fit_transform(X)
            # For semi-supervised PCAKM: use constrained samples to set init centroids
            if P_prior is not None and constraint_mask is not None and constraint_mask.any():
                # Use prior labels to init centroids
                prior_idx = np.where(constraint_mask)[0]
                prior_lab = P_prior[prior_idx].argmax(axis=1)
                init_c = np.zeros((n_clusters, Xp.shape[1]))
                for k in range(n_clusters):
                    k_idx = prior_idx[prior_lab == k]
                    if len(k_idx) > 0:
                        init_c[k] = Xp[k_idx].mean(axis=0)
                    else:
                        init_c[k] = Xp[prior_idx[k % len(prior_idx)]]
                m = KMeans(n_clusters=n_clusters, n_init=1, init=init_c, random_state=seed)
            else:
                m = KMeans(n_clusters=n_clusters, n_init=10, random_state=seed)
            m.fit(Xp)
            lab = m.labels_; U = None
        elif alg_name == "CEFCM":
            m = CEFCM(n_clusters=n_clusters, m=2.0, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        elif alg_name == "DKFCM":
            m = DKFCM(n_clusters=n_clusters, m=2.0, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        elif alg_name == "GRFCM":
            m = GRFCM(n_clusters=n_clusters, m=2.0, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        elif alg_name == "SSFCM":
            m = SSFCM(n_clusters=n_clusters, m=2.0, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        elif alg_name == "CDRSC":
            m = CDRSC(n_clusters=n_clusters, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = None
        elif alg_name == "ContraClust":
            m = ContraClust(n_clusters=n_clusters, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = None
        elif alg_name == "FCPL":
            m = FCPL(n_clusters=n_clusters, m=2.0, lam=10.0, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        elif alg_name == "KFCPL":
            m = KFCPL(n_clusters=n_clusters, m=2.0, lam=10.0, gamma=0.05, random_state=seed)
            m.fit(X, P=P_prior, constraint_mask=constraint_mask)
            lab = m.labels_; U = m.U_
        else:
            return None
        elapsed = time.time() - t0
        ent = membership_entropy(U) if U is not None else np.nan
        return {
            "acc": compute_acc(y_true, lab),
            "nmi": compute_nmi(y_true, lab),
            "ari": compute_ari(y_true, lab),
            "f1": compute_f1(y_true, lab),
            "entropy": ent,
            "time": elapsed,
        }
    except Exception as e:
        elapsed = time.time() - t0
        return {"error": str(e), "time": elapsed}

def summarize(values):
    """values: list of floats. Return mean,std,ci,min,max."""
    v = np.array([x for x in values if x is not None and not np.isnan(x)])
    if len(v) == 0:
        return np.nan, np.nan, np.nan, np.nan, np.nan, 0
    mean = float(np.mean(v)); std = float(np.std(v, ddof=1)) if len(v) > 1 else 0.0
    ci = T_CRIT * std / np.sqrt(len(v)) if len(v) > 1 else 0.0
    return mean, std, ci, float(np.min(v)), float(np.max(v)), len(v)

def main():
    X, y_hard, P_soft, P_hard, n_clusters = load_face()
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    n = len(X)
    print(f"Face data: {n} samples, {Xs.shape[1]} features, {n_clusters} clusters")

    # Algorithms: which prior to use
    # FCPL/KFCPL use soft prior; SFCM and other semi-supervised use hard prior
    algos = [
        ("K-means", "none"),
        ("FCM", "none"),
        ("KFCM", "none"),
        ("GK", "none"),
        ("PCM", "none"),
        ("SFCM", "hard"),
        ("PCAKM", "hard"),
        ("CEFCM", "hard"),
        ("DKFCM", "hard"),
        ("GRFCM", "hard"),
        ("SSFCM", "hard"),
        ("CDRSC", "hard"),
        ("ContraClust", "hard"),
        ("FCPL", "soft"),
        ("KFCPL", "soft"),
    ]

    rows = []
    for alg_name, prior_type in algos:
        print(f"\n=== {alg_name} (prior={prior_type}) ===")
        runs = {"acc": [], "nmi": [], "ari": [], "f1": [], "entropy": [], "time": []}
        for seed in SEEDS:
            rng = np.random.RandomState(seed)
            idx = rng.choice(n, size=int(n * RATIO), replace=False)
            mask = np.zeros(n, dtype=bool)
            mask[idx] = True
            if prior_type == "soft":
                P_use = P_soft
            elif prior_type == "hard":
                P_use = P_hard
            else:
                P_use = None
            res = run_one_alg(alg_name, Xs, y_hard, P_use, mask, seed, n_clusters)
            if res is None or "error" in res:
                print(f"  seed={seed}: ERROR {res.get('error','') if res else 'None'}")
                continue
            for k in runs:
                runs[k].append(res[k])
            print(f"  seed={seed}: ACC={res['acc']:.3f} NMI={res['nmi']:.3f} time={res['time']:.2f}s")
        for metric in ["acc", "nmi", "ari", "f1", "entropy", "time"]:
            mean, std, ci, mn, mx, nruns = summarize(runs[metric])
            rows.append({
                "dataset": "face_fuzzy",
                "algorithm": alg_name,
                "metric": metric,
                "prior_type": prior_type,
                "mean": round(mean, 4) if not np.isnan(mean) else None,
                "std": round(std, 4) if not np.isnan(std) else None,
                "ci_95": round(ci, 4) if not np.isnan(ci) else None,
                "min": round(mn, 4) if not np.isnan(mn) else None,
                "max": round(mx, 4) if not np.isnan(mx) else None,
                "n_runs": nruns,
            })

    df = pd.DataFrame(rows)
    out_path = OUT / "exp_face_full_comparison.csv"
    df.to_csv(out_path, index=False)
    print(f"\nSaved: {out_path}")
    print(df.to_string())

if __name__ == "__main__":
    main()
