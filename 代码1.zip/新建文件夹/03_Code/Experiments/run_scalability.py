"""
Experiment 6: Scalability test.
Measure runtime and memory as dataset size grows.
"""
import sys
import os
import time
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from sklearn.datasets import make_blobs
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.models.baselines import FCM, SFCM

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(FIGURES_DIR, exist_ok=True)


def measure_memory_mb():
    """Estimate current memory usage in MB."""
    try:
        import psutil
        process = psutil.Process()
        return process.memory_info().rss / (1024 * 1024)
    except ImportError:
        return 0.0


def run_scalability_experiment():
    """Test scalability across different data sizes."""
    
    sizes = [1000, 5000, 10000, 50000, 100000]
    n_features = 20
    n_clusters = 5
    
    rows = []
    
    print("=" * 60)
    print("Experiment 6: Scalability Test")
    print("=" * 60)
    
    for n_samples in sizes:
        print(f"\n--- n_samples = {n_samples} ---")
        
        X, y = make_blobs(n_samples=n_samples, n_features=n_features, 
                          centers=n_clusters, random_state=42)
        
        # Generate constraints (10%)
        n_constrained = int(n_samples * 0.1)
        constraint_idx = np.random.choice(n_samples, n_constrained, replace=False)
        P = np.zeros((n_samples, n_clusters))
        constraint_mask = np.zeros(n_samples, dtype=bool)
        for idx in constraint_idx:
            P[idx, y[idx]] = 1.0
            constraint_mask[idx] = True
        
        # FCM
        t0 = time.time()
        fcm = FCM(n_clusters=n_clusters, max_iter=100, random_state=42)
        fcm.fit(X)
        fcm_time = time.time() - t0
        print(f"  FCM: {fcm_time:.3f}s")
        
        # SFCM
        t0 = time.time()
        sfcm = SFCM(n_clusters=n_clusters, random_state=42)
        sfcm.fit(X, P, constraint_mask)
        sfcm_time = time.time() - t0
        print(f"  SFCM: {sfcm_time:.3f}s")
        
        # FCPL
        t0 = time.time()
        fcpl = FCPL(n_clusters=n_clusters, lam=1.0, solver='mes', random_state=42)
        fcpl.fit(X, P, constraint_mask)
        fcpl_time = time.time() - t0
        print(f"  FCPL: {fcpl_time:.3f}s")
        
        # KFCPL (only for smaller sizes due to O(n^2) kernel)
        if n_samples <= 10000:
            t0 = time.time()
            kfcpl = KFCPL(n_clusters=n_clusters, lam=1.0, gamma=1.0, random_state=42)
            kfcpl.fit(X, P, constraint_mask)
            kfcpl_time = time.time() - t0
            print(f"  KFCPL: {kfcpl_time:.3f}s")
        else:
            kfcpl_time = np.nan
            print(f"  KFCPL: skipped (too large)")
        
        rows.append({
            'n_samples': n_samples,
            'FCM_time': fcm_time,
            'SFCM_time': sfcm_time,
            'FCPL_time': fcpl_time,
            'KFCPL_time': kfcpl_time,
        })
    
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESULTS_DIR, 'exp6_scalability.csv'), index=False)
    
    # Generate plot
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
        
        ax1.plot(df['n_samples'], df['FCM_time'], 'o-', label='FCM', linewidth=2)
        ax1.plot(df['n_samples'], df['SFCM_time'], 's-', label='SFCM', linewidth=2)
        ax1.plot(df['n_samples'], df['FCPL_time'], '^-', label='FCPL', linewidth=2)
        if not df['KFCPL_time'].isna().all():
            ax1.plot(df['n_samples'].dropna(), df['KFCPL_time'].dropna(), 'd-', label='KFCPL', linewidth=2)
        ax1.set_xlabel('Number of Samples')
        ax1.set_ylabel('Runtime (seconds)')
        ax1.set_title('Runtime vs. Dataset Size')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        ax1.set_xscale('log')
        ax1.set_yscale('log')
        
        # Relative speedup
        ax2.plot(df['n_samples'], df['FCPL_time'] / df['SFCM_time'], 'o-', label='FCPL/SFCM', linewidth=2)
        ax2.plot(df['n_samples'], df['FCPL_time'] / df['FCM_time'], 's-', label='FCPL/FCM', linewidth=2)
        ax2.set_xlabel('Number of Samples')
        ax2.set_ylabel('Time Ratio')
        ax2.set_title('Relative Computational Cost')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(os.path.join(FIGURES_DIR, 'exp6_scalability.png'), dpi=300, bbox_inches='tight')
        plt.savefig(os.path.join(FIGURES_DIR, 'exp6_scalability.svg'), bbox_inches='tight')
        plt.close()
        print("\nScalability plot saved.")
    except Exception as e:
        print(f"Plot generation failed: {e}")
    
    return df


if __name__ == '__main__':
    run_scalability_experiment()
