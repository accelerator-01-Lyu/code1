"""
Experiment 3: Statistical significance tests.
- Wilcoxon signed-rank test (pairwise)
- Friedman test
- Critical Difference (CD) diagram
"""
import sys
import os
import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_dataset, get_constraint_samples
from code.utils.metrics import clustering_accuracy
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.models.baselines import FCM, KFCM, SFCM, run_kmeans, run_pcakm

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(FIGURES_DIR, exist_ok=True)


def collect_acc_results(n_repeats=5):
    """Collect ACC results for all algorithms on all datasets."""
    
    datasets = ['iris', 'wine', 'breast_cancer', 'glass', 'seeds', 
                'balance', 'vehicle', 'segment']
    
    algorithms = ['K-means', 'PCAKM', 'FCM', 'KFCM', 'SFCM', 'FCPL', 'KFCPL']
    
    results = {alg: [] for alg in algorithms}
    dataset_names = []
    
    for ds_name in datasets:
        print(f"  Collecting: {ds_name}")
        X, y, n_clusters = get_dataset(ds_name, random_state=42)
        
        acc_per_ds = {alg: [] for alg in algorithms}
        
        for rep in range(n_repeats):
            rs = 42 + rep
            _, P, constraint_mask = get_constraint_samples(y, 0.1, rs)
            
            # K-means
            labels, _ = run_kmeans(X, n_clusters, rs)
            acc_per_ds['K-means'].append(clustering_accuracy(y, labels) * 100)
            
            # PCAKM
            labels = run_pcakm(X, n_clusters, rs)
            acc_per_ds['PCAKM'].append(clustering_accuracy(y, labels) * 100)
            
            # FCM
            fcm = FCM(n_clusters=n_clusters, random_state=rs)
            fcm.fit(X)
            acc_per_ds['FCM'].append(clustering_accuracy(y, fcm.labels_) * 100)
            
            # KFCM
            kfcm = KFCM(n_clusters=n_clusters, gamma=1.0, random_state=rs)
            kfcm.fit(X)
            acc_per_ds['KFCM'].append(clustering_accuracy(y, kfcm.labels_) * 100)
            
            # SFCM
            sfcm = SFCM(n_clusters=n_clusters, random_state=rs)
            sfcm.fit(X, P, constraint_mask)
            acc_per_ds['SFCM'].append(clustering_accuracy(y, sfcm.labels_) * 100)
            
            # FCPL
            fcpl = FCPL(n_clusters=n_clusters, lam=1.0, random_state=rs)
            fcpl.fit(X, P, constraint_mask)
            acc_per_ds['FCPL'].append(clustering_accuracy(y, fcpl.labels_) * 100)
            
            # KFCPL
            kfcpl = KFCPL(n_clusters=n_clusters, lam=1.0, gamma=1.0, random_state=rs)
            kfcpl.fit(X, P, constraint_mask)
            acc_per_ds['KFCPL'].append(clustering_accuracy(y, kfcpl.labels_) * 100)
        
        dataset_names.append(ds_name)
        for alg in algorithms:
            results[alg].append(np.mean(acc_per_ds[alg]))
    
    return results, dataset_names


def run_statistical_tests():
    """Run Wilcoxon and Friedman tests, generate CD diagram."""
    
    print("=" * 60)
    print("Experiment 3: Statistical Significance Tests")
    print("=" * 60)
    
    # Collect results
    results, dataset_names = collect_acc_results(n_repeats=5)
    
    algorithms = list(results.keys())
    n_alg = len(algorithms)
    n_ds = len(dataset_names)
    
    # Convert to DataFrame
    df = pd.DataFrame(results, index=dataset_names)
    print("\nACC Results (mean over 5 repeats):")
    print(df.round(2).to_string())
    
    # --- Wilcoxon signed-rank test (pairwise) ---
    print("\n--- Wilcoxon Signed-Rank Test (vs FCPL) ---")
    wilcoxon_results = []
    
    for alg in algorithms:
        if alg == 'FCPL':
            continue
        stat, p_value = stats.wilcoxon(df['FCPL'], df[alg])
        wilcoxon_results.append({
            'Comparison': f'FCPL vs {alg}',
            'Statistic': stat,
            'p_value': p_value,
            'Significant (0.05)': 'Yes' if p_value < 0.05 else 'No'
        })
        print(f"  FCPL vs {alg:12s}: p = {p_value:.4f} {'*' if p_value < 0.05 else 'ns'}")
    
    # Also KFCPL vs others
    print("\n--- Wilcoxon Signed-Rank Test (vs KFCPL) ---")
    for alg in algorithms:
        if alg == 'KFCPL':
            continue
        stat, p_value = stats.wilcoxon(df['KFCPL'], df[alg])
        wilcoxon_results.append({
            'Comparison': f'KFCPL vs {alg}',
            'Statistic': stat,
            'p_value': p_value,
            'Significant (0.05)': 'Yes' if p_value < 0.05 else 'No'
        })
        print(f"  KFCPL vs {alg:12s}: p = {p_value:.4f} {'*' if p_value < 0.05 else 'ns'}")
    
    # --- Friedman test ---
    print("\n--- Friedman Test ---")
    friedman_stat, friedman_p = stats.friedmanchisquare(*[df[alg].values for alg in algorithms])
    print(f"  Friedman statistic: {friedman_stat:.4f}")
    print(f"  p-value: {friedman_p:.6f}")
    print(f"  Significant: {'Yes' if friedman_p < 0.05 else 'No'}")
    
    # --- Compute ranks for CD diagram ---
    ranks = df.rank(axis=1, ascending=False)
    mean_ranks = ranks.mean(axis=0)
    print("\n--- Mean Ranks (lower is better) ---")
    for alg in algorithms:
        print(f"  {alg:15s}: {mean_ranks[alg]:.3f}")
    
    # Save results
    df_wilcoxon = pd.DataFrame(wilcoxon_results)
    df_wilcoxon.to_csv(os.path.join(RESULTS_DIR, 'exp3_wilcoxon_tests.csv'), index=False)
    
    mean_ranks.to_csv(os.path.join(RESULTS_DIR, 'exp3_mean_ranks.csv'), header=['mean_rank'])
    df.to_csv(os.path.join(RESULTS_DIR, 'exp3_acc_matrix.csv'))
    
    # --- Generate CD diagram ---
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        
        fig, ax = plt.subplots(figsize=(10, 3))
        
        sorted_algs = mean_ranks.sort_values()
        y_pos = np.arange(len(sorted_algs))
        
        ax.barh(y_pos, sorted_algs.values, color='steelblue', height=0.6)
        ax.set_yticks(y_pos)
        ax.set_yticklabels(sorted_algs.index)
        ax.set_xlabel('Average Rank (lower is better)')
        ax.set_title('Critical Difference Diagram - Mean Ranks')
        
        plt.tight_layout()
        plt.savefig(os.path.join(FIGURES_DIR, 'exp3_cd_diagram.png'), dpi=300, bbox_inches='tight')
        plt.savefig(os.path.join(FIGURES_DIR, 'exp3_cd_diagram.svg'), bbox_inches='tight')
        plt.close()
        print("\nCD diagram saved.")
    except Exception as e:
        print(f"CD diagram generation failed: {e}")
    
    return df, df_wilcoxon


if __name__ == '__main__':
    run_statistical_tests()
