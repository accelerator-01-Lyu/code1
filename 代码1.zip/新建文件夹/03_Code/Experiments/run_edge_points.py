"""
Task 2: Synthetic edge-point selection experiments on Compound & Aggregation.
Compares random vs edge-point constraint selection at 4 supervision ratios.
5 algorithms x 4 ratios x 2 selection strategies x 5 seeds.
"""
import sys, os, time
import numpy as np
import pandas as pd
from pathlib import Path

ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))

from models.fcpl import FCPL
from models.kfcpl import KFCPL
from models.baselines import FCM, SFCM
from utils.metrics import clustering_accuracy, nmi_score, ari_score
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.neighbors import NearestNeighbors

T_CRIT = 2.776
SEEDS = [42, 43, 44, 45, 46]
OUT = ROOT / "data" / "results"
DATA_DIR = ROOT / "data"

def summarize(values):
    v = np.array([x for x in values if x is not None and not np.isnan(x)])
    if len(v)==0: return np.nan, np.nan, np.nan, 0
    mean=float(np.mean(v)); std=float(np.std(v,ddof=1)) if len(v)>1 else 0.0
    ci=T_CRIT*std/np.sqrt(len(v)) if len(v)>1 else 0.0
    return mean,std,ci,len(v)

def load_synth(name):
    df = pd.read_csv(DATA_DIR / f"{name}.csv")
    X = df[["k1","k2"]].values.astype(np.float64)
    y = df["class"].values.astype(int) - 1  # 0-index
    return X, y

def select_edge_points(X, y, ratio, seed):
    """Select edge points: those near cluster boundaries (kNN with mixed neighbors)."""
    rng = np.random.RandomState(seed)
    n = len(y)
    n_constraint = int(n * ratio)
    k = len(np.unique(y))

    # Compute kNN impurity: fraction of neighbors with different label
    nn = NearestNeighbors(n_neighbors=min(10, n)).fit(X)
    _, indices = nn.kneighbors(X)
    impurity = np.zeros(n)
    for i in range(n):
        neighbor_labels = y[indices[i][1:]]  # exclude self
        impurity[i] = np.mean(neighbor_labels != y[i])

    # Edge points: top 50% by impurity, then randomly select n_constraint from edge region
    edge_threshold = np.median(impurity) + 0.5 * np.std(impurity)
    edge_candidates = np.where(impurity >= edge_threshold)[0]
    if len(edge_candidates) < n_constraint:
        # fallback: use all high-impurity + random
        remaining = n_constraint - len(edge_candidates)
        others = np.array([i for i in range(n) if i not in edge_candidates])
        extra = rng.choice(others, size=min(remaining, len(others)), replace=False)
        selected = np.concatenate([edge_candidates, extra])
    else:
        selected = rng.choice(edge_candidates, size=n_constraint, replace=False)

    mask = np.zeros(n, dtype=bool)
    mask[selected] = True
    P = np.zeros((n, k))
    P[np.arange(n), y] = 1.0
    return P, mask, selected

def select_random_points(y, ratio, seed):
    rng = np.random.RandomState(seed)
    n = len(y)
    k = len(np.unique(y))
    n_constraint = int(n * ratio)
    selected = rng.choice(n, size=n_constraint, replace=False)
    mask = np.zeros(n, dtype=bool)
    mask[selected] = True
    P = np.zeros((n, k))
    P[np.arange(n), y] = 1.0
    return P, mask, selected

def run_algo(name, X, y, P, mask, seed, k):
    np.random.seed(seed)
    try:
        if name == "K-means":
            m = KMeans(n_clusters=k, n_init=10, random_state=seed)
            m.fit(X); lab = m.labels_
        elif name == "FCM":
            m = FCM(n_clusters=k, m=2.0, random_state=seed)
            m.fit(X); lab = m.labels_
        elif name == "SFCM":
            m = SFCM(n_clusters=k, m=2.0, lam=1.0, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        elif name == "FCPL":
            m = FCPL(n_clusters=k, m=2.0, lam=10.0, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        elif name == "KFCPL":
            m = KFCPL(n_clusters=k, m=2.0, lam=10.0, gamma=1.0, random_state=seed)
            m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
        else:
            return None
        return {"acc": clustering_accuracy(y, lab)*100,
                "nmi": nmi_score(y, lab)*100,
                "ari": ari_score(y, lab)*100}
    except Exception as e:
        return {"error": str(e)}

def main():
    ratios = [0.10, 0.20, 0.30, 0.50]
    algos = ["K-means", "FCM", "SFCM", "FCPL", "KFCPL"]
    rows = []

    for ds_name in ["Compound", "Aggregation"]:
        X, y = load_synth(ds_name)
        scaler = StandardScaler()
        Xs = scaler.fit_transform(X)
        k = len(np.unique(y))
        n = len(y)
        print(f"\n{'='*50}\n{ds_name}: n={n}, k={k}\n{'='*50}")

        for ratio in ratios:
            for strategy in ["random", "edge"]:
                for algo in algos:
                    runs = {"acc":[], "nmi":[], "ari":[]}
                    for seed in SEEDS:
                        if strategy == "edge":
                            P, mask, sel = select_edge_points(Xs, y, ratio, seed)
                        else:
                            P, mask, sel = select_random_points(y, ratio, seed)
                        res = run_algo(algo, Xs, y, P, mask, seed, k)
                        if res is None or "error" in res:
                            continue
                        for kk in runs: runs[kk].append(res[kk])
                    am, asd, aci, an = summarize(runs["acc"])
                    nm, _, nci, _ = summarize(runs["nmi"])
                    rm, _, rci, _ = summarize(runs["ari"])
                    rows.append({
                        "dataset": ds_name, "ratio": ratio, "strategy": strategy,
                        "algorithm": algo,
                        "ACC_mean": round(am,2), "ACC_ci95": round(aci,2),
                        "NMI_mean": round(nm,2), "NMI_ci95": round(nci,2),
                        "ARI_mean": round(rm,2), "ARI_ci95": round(rci,2),
                        "n_runs": an})
                    print(f"  r={ratio:.0%} {strategy:6s} {algo:10s}: ACC={am:5.1f}±{aci:.1f}")

    df = pd.DataFrame(rows)
    out = OUT / "exp_synthetic_edge_points.csv"
    df.to_csv(out, index=False)
    print(f"\nSaved: {out}")
    print("\n=== Summary: FCPL comparison ===")
    fcp = df[df.algorithm=="FCPL"]
    print(fcp[["dataset","ratio","strategy","ACC_mean","ACC_ci95"]].to_string(index=False))

if __name__ == "__main__":
    main()
