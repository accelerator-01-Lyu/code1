"""
Experiment 8: Convergence verification.
Plot objective function vs. iterations, compare MES vs QP solver.
"""
import sys
import os
import time
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_dataset, get_constraint_samples
from code.models.fcpl import FCPL
from code.models.baselines import FCM

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(FIGURES_DIR, exist_ok=True)


def run_convergence_experiment():
    """Verify convergence of MES solver."""
    
    datasets = ['iris', 'wine', 'glass', 'seeds', 'balance']
    
    rows = []
    
    print("=" * 60)
    print("Experiment 8: Convergence Verification")
    print("=" * 60)
    
    all_histories = {}
    
    for ds_name in datasets:
        print(f"\n--- Dataset: {ds_name} ---")
        X, y, n_clusters = get_dataset(ds_name, random_state=42)
        _, P, constraint_mask = get_constraint_samples(y, 0.1, 42)
        
        # FCPL with MES
        fcpl_mes = FCPL(n_clusters=n_clusters, lam=1.0, solver='mes', 
                       max_iter=100, tol=1e-5, random_state=42)
        t0 = time.time()
        fcpl_mes.fit(X, P, constraint_mask)
        mes_time = time.time() - t0
        mes_iters = fcpl_mes.n_iter_
        mes_history = fcpl_mes.obj_history_
        
        # FCPL with QP
        fcpl_qp = FCPL(n_clusters=n_clusters, lam=1.0, solver='qp',
                      max_iter=100, tol=1e-5, random_state=42)
        t0 = time.time()
        fcpl_qp.fit(X, P, constraint_mask)
        qp_time = time.time() - t0
        qp_iters = fcpl_qp.n_iter_
        qp_history = fcpl_qp.obj_history_
        
        # FCM baseline
        fcm = FCM(n_clusters=n_clusters, max_iter=100, tol=1e-5, random_state=42)
        fcm.fit(X)
        fcm_iters = fcm.n_iter_
        fcm_history = fcm.obj_history_
        
        print(f"  MES: {mes_iters} iters, {mes_time:.3f}s")
        print(f"  QP:  {qp_iters} iters, {qp_time:.3f}s")
        print(f"  FCM: {fcm_iters} iters")
        
        # Check monotonicity
        if len(mes_history) > 1:
            diffs = np.diff(mes_history)
            monotonic = np.all(diffs <= 1e-10)
            print(f"  MES monotonic non-increasing: {monotonic}")
        
        rows.append({
            'Dataset': ds_name,
            'MES_iters': mes_iters,
            'MES_time': mes_time,
            'QP_iters': qp_iters,
            'QP_time': qp_time,
            'FCM_iters': fcm_iters,
            'MES_speedup': qp_time / mes_time if mes_time > 0 else 0,
        })
        
        all_histories[ds_name] = {
            'MES': mes_history,
            'QP': qp_history,
            'FCM': fcm_history,
        }
    
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESULTS_DIR, 'exp8_convergence.csv'), index=False)
    
    # Generate convergence plot
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        
        fig, axes = plt.subplots(1, len(datasets), figsize=(18, 4))
        if len(datasets) == 1:
            axes = [axes]
        
        for ax, ds_name in zip(axes, datasets):
            hist = all_histories[ds_name]
            
            # Normalize objective values
            mes_h = np.array(hist['MES'])
            qp_h = np.array(hist['QP'])
            fcm_h = np.array(hist['FCM'])
            
            ax.plot(range(1, len(mes_h)+1), mes_h, 'b-o', label='FCPL (MES)', 
                   markersize=3, linewidth=1.5)
            ax.plot(range(1, len(qp_h)+1), qp_h, 'r-s', label='FCPL (QP)',
                   markersize=3, linewidth=1.5)
            ax.plot(range(1, len(fcm_h)+1), fcm_h, 'g--^', label='FCM',
                   markersize=3, linewidth=1.5)
            
            ax.set_xlabel('Iteration')
            ax.set_ylabel('Objective Value')
            ax.set_title(ds_name)
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
        
        plt.suptitle('Convergence: Objective Function vs. Iterations', fontsize=14)
        plt.tight_layout()
        plt.savefig(os.path.join(FIGURES_DIR, 'exp8_convergence.png'), dpi=300, bbox_inches='tight')
        plt.savefig(os.path.join(FIGURES_DIR, 'exp8_convergence.svg'), bbox_inches='tight')
        plt.close()
        print("\nConvergence plot saved.")
    except Exception as e:
        print(f"Plot generation failed: {e}")
    
    return df, all_histories


if __name__ == '__main__':
    run_convergence_experiment()
