"""
Comprehensive tuning + final SOTA comparison with 95% CI.
Step 1: FCPL grid search (incremental save)
Step 2: KFCPL grid search (low-dim only)
Step 3: Final SOTA with best params, 5 repeats, 95% CI
"""
import sys, os, itertools, time, json
import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_dataset, get_constraint_samples
from code.utils.metrics import evaluate_clustering
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.models.baselines import FCM, KFCM, SFCM, GK, PCM, CEFCM, DKFCM, GRFCM, SSFCM, run_pcakm
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import fetch_openml, make_blobs

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')
os.makedirs(RESULTS_DIR, exist_ok=True)

T_975_4 = 2.776  # t_{0.975, n-1} for n=5


def ci95(values):
    """Compute mean, std, 95% CI, min, max."""
    values = np.array(values)
    n = len(values)
    m = np.mean(values)
    s = np.std(values, ddof=1) if n > 1 else 0.0
    ci = T_975_4 * s / np.sqrt(n) if n > 1 else 0.0
    return {'mean': m, 'std': s, 'ci_95': ci, 'min': np.min(values), 'max': np.max(values), 'runs': n}


def load_dataset(name):
    """Load any dataset (original + extra UCI)."""
    # Original datasets
    try:
        return get_dataset(name, random_state=42)
    except ValueError:
        pass
    
    # Extra UCI from OpenML
    openml_map = {
        'ionosphere': 'ionosphere', 'sonar': 'sonar', 'ecoli': 'ecoli',
        'yeast': 'yeast', 'diabetes': 'diabetes', 'heart': 'heart-statlog',
        'optdigits': 'optdigits', 'magic': 'magic.gamma.telescope'
    }
    
    if name in openml_map:
        data = fetch_openml(name=openml_map[name], version=1, as_frame=False, parser='auto')
        X = data.data
        y_raw = data.target
        unique = np.unique(y_raw)
        y = np.array([np.where(unique == l)[0][0] for l in y_raw])
        if np.any(np.isnan(X)):
            X = np.nan_to_num(X, nan=0.0)
        scaler = StandardScaler()
        X = scaler.fit_transform(X)
        if name == 'optdigits' and len(X) > 5000:
            rng = np.random.RandomState(42)
            idx = rng.choice(len(X), 5000, replace=False)
            X, y = X[idx], y[idx]
        return X, y, len(np.unique(y))
    
    raise ValueError(f"Unknown: {name}")


# ============================================================
# STEP 1: FCPL grid search
# ============================================================
def fcpl_grid():
    print("\n" + "=" * 60)
    print("STEP 1: FCPL Grid Search")
    print("=" * 60)
    
    LAMBDAS = [0.001, 0.01, 0.05, 0.1, 0.5, 1.0, 5.0, 10.0, 50.0, 100.0]
    MS = [1.5, 2.0, 2.5, 3.0]
    DATASETS = ['iris', 'wine', 'breast_cancer', 'glass', 'seeds', 'balance',
                'vehicle', 'segment', 'ionosphere', 'sonar', 'ecoli', 'yeast',
                'diabetes', 'heart', 'optdigits']
    
    all_rows = []
    best_params = {}
    best_csv = os.path.join(RESULTS_DIR, 'exp_best_params_fcpl.csv')
    
    for ds in DATASETS:
        # Skip if already done
        if os.path.exists(best_csv):
            existing = pd.read_csv(best_csv)
            if ds in existing['Dataset'].values:
                row = existing[existing['Dataset'] == ds].iloc[0]
                best_params[ds] = (row['Best_lambda'], row['Best_m'], row['Best_ACC'])
                print(f"  {ds}: already done, skip")
                continue
        
        print(f"  FCPL: {ds}...", end=" ", flush=True)
        X, y, nc = load_dataset(ds)
        
        best_acc = -1
        best_lam, best_m = 1.0, 2.0
        
        for lam, m in itertools.product(LAMBDAS, MS):
            accs = []
            for rep in range(3):
                rs = 42 + rep
                _, P, cm = get_constraint_samples(y, 0.1, rs)
                try:
                    model = FCPL(n_clusters=nc, m=m, lam=lam, max_iter=100, tol=1e-5, random_state=rs)
                    model.fit(X, P, cm)
                    res = evaluate_clustering(y, model.labels_)
                    accs.append(res['ACC'])
                except Exception:
                    accs.append(0)
            
            ma = np.mean(accs)
            all_rows.append({'Dataset': ds, 'lambda': lam, 'm': m, 'ACC_mean': ma})
            if ma > best_acc:
                best_acc = ma
                best_lam, best_m = lam, m
        
        best_params[ds] = (best_lam, best_m, best_acc)
        print(f"Best: λ={best_lam}, m={best_m}, ACC={best_acc:.2f}%")
        
        # Incremental save
        pd.DataFrame([
            {'Dataset': d, 'Best_lambda': v[0], 'Best_m': v[1], 'Best_ACC': v[2]}
            for d, v in best_params.items()
        ]).to_csv(best_csv, index=False)
    
    pd.DataFrame(all_rows).to_csv(os.path.join(RESULTS_DIR, 'exp_grid_search_fcpl_full.csv'), index=False)
    return best_params


# ============================================================
# STEP 2: KFCPL grid search
# ============================================================
def kfcpl_grid():
    print("\n" + "=" * 60)
    print("STEP 2: KFCPL Grid Search")
    print("=" * 60)
    
    LAMBDAS = [0.01, 0.1, 1.0, 10.0, 100.0]
    GAMMAS = [0.001, 0.01, 0.1, 1.0, 10.0, 100.0]
    DATASETS = ['iris', 'wine', 'seeds', 'balance', 'glass',
                'ionosphere', 'sonar', 'ecoli', 'diabetes', 'heart']
    
    best_params = {}
    best_csv = os.path.join(RESULTS_DIR, 'exp_best_params_kfcpl.csv')
    
    for ds in DATASETS:
        if os.path.exists(best_csv):
            existing = pd.read_csv(best_csv)
            if ds in existing['Dataset'].values:
                row = existing[existing['Dataset'] == ds].iloc[0]
                best_params[ds] = (row['Best_lambda'], 2.0, row['Best_gamma'], row['Best_ACC'])
                print(f"  {ds}: already done, skip")
                continue
        
        print(f"  KFCPL: {ds}...", end=" ", flush=True)
        X, y, nc = load_dataset(ds)
        if len(X) > 3000:
            rng = np.random.RandomState(42)
            idx = rng.choice(len(X), 3000, replace=False)
            X, y = X[idx], y[idx]
        
        best_acc = -1
        best_lam, best_gam = 1.0, 1.0
        
        for lam, gam in itertools.product(LAMBDAS, GAMMAS):
            accs = []
            for rep in range(3):
                rs = 42 + rep
                _, P, cm = get_constraint_samples(y, 0.1, rs)
                try:
                    model = KFCPL(n_clusters=nc, m=2.0, lam=lam, gamma=gam, max_iter=100, tol=1e-5, random_state=rs)
                    model.fit(X, P, cm)
                    res = evaluate_clustering(y, model.labels_)
                    accs.append(res['ACC'])
                except Exception:
                    accs.append(0)
            
            ma = np.mean(accs)
            if ma > best_acc:
                best_acc = ma
                best_lam, best_gam = lam, gam
        
        best_params[ds] = (best_lam, 2.0, best_gam, best_acc)
        print(f"Best: λ={best_lam}, γ={best_gam}, ACC={best_acc:.2f}%")
        
        pd.DataFrame([
            {'Dataset': d, 'Best_lambda': v[0], 'Best_m': v[1], 'Best_gamma': v[2], 'Best_ACC': v[3]}
            for d, v in best_params.items()
        ]).to_csv(best_csv, index=False)
    
    return best_params


# ============================================================
# STEP 3: Final SOTA with best params, 5 repeats, 95% CI
# ============================================================
def final_sota(fcpl_best, kfcpl_best):
    print("\n" + "=" * 60)
    print("STEP 3: Final SOTA (5 repeats, 95% CI)")
    print("=" * 60)
    
    DATASETS = ['iris', 'wine', 'breast_cancer', 'glass', 'seeds', 'balance',
                'vehicle', 'segment', 'ionosphere', 'sonar', 'ecoli', 'yeast',
                'diabetes', 'heart', 'optdigits']
    
    SEEDS = [42, 43, 44, 45, 46]
    all_rows = []
    
    for ds in DATASETS:
        print(f"\n  {ds}...", flush=True)
        try:
            X, y, nc = load_dataset(ds)
        except Exception as e:
            print(f"    Skip: {e}")
            continue
        
        # Best params for FCPL
        if ds in fcpl_best:
            bl, bm = fcpl_best[ds][0], fcpl_best[ds][1]
        else:
            bl, bm = 1.0, 2.0
        
        # Best params for KFCPL
        use_kfcpl = ds in kfcpl_best and X.shape[1] <= 15
        if use_kfcpl:
            bkl, bkg = kfcpl_best[ds][0], kfcpl_best[ds][2]
        
        # KFCPL subset
        k_idx = np.random.RandomState(42).choice(len(X), min(len(X), 3000), replace=False) if len(X) > 3000 else np.arange(len(X))
        X_k, y_k = X[k_idx], y[k_idx]
        
        for rep, rs in enumerate(SEEDS):
            _, P, cm = get_constraint_samples(y, 0.1, rs)
            _, P_k, cm_k = get_constraint_samples(y_k, 0.1, rs)
            
            # K-means
            km = KMeans(n_clusters=nc, random_state=rs, n_init=10)
            res = evaluate_clustering(y, km.fit_predict(X))
            all_rows.append({'Dataset': ds, 'Algorithm': 'K-means', 'Repeat': rep, **res})
            
            # PCAKM
            labels_pca = run_pcakm(X, nc, random_state=rs)
            res = evaluate_clustering(y, labels_pca)
            all_rows.append({'Dataset': ds, 'Algorithm': 'PCAKM', 'Repeat': rep, **res})
            
            # FCM
            fcm = FCM(n_clusters=nc, random_state=rs)
            fcm.fit(X)
            res = evaluate_clustering(y, fcm.labels_)
            all_rows.append({'Dataset': ds, 'Algorithm': 'FCM', 'Repeat': rep, **res})
            
            # KFCM
            kfcm = KFCM(n_clusters=nc, gamma=1.0, random_state=rs)
            kfcm.fit(X_k)
            res = evaluate_clustering(y_k, kfcm.labels_)
            all_rows.append({'Dataset': ds, 'Algorithm': 'KFCM', 'Repeat': rep, **res})
            
            # CEFCM
            cefcm = CEFCM(n_clusters=nc, random_state=rs)
            cefcm.fit(X)
            res = evaluate_clustering(y, cefcm.labels_)
            all_rows.append({'Dataset': ds, 'Algorithm': 'CEFCM', 'Repeat': rep, **res})
            
            # DKFCM
            dkfcm = DKFCM(n_clusters=nc, random_state=rs)
            dkfcm.fit(X)
            res = evaluate_clustering(y, dkfcm.labels_)
            all_rows.append({'Dataset': ds, 'Algorithm': 'DKFCM', 'Repeat': rep, **res})
            
            # GRFCM
            grfcm = GRFCM(n_clusters=nc, random_state=rs)
            grfcm.fit(X)
            res = evaluate_clustering(y, grfcm.labels_)
            all_rows.append({'Dataset': ds, 'Algorithm': 'GRFCM', 'Repeat': rep, **res})
            
            # SSFCM
            ssfcm = SSFCM(n_clusters=nc, random_state=rs)
            ssfcm.fit(X)
            res = evaluate_clustering(y, ssfcm.labels_)
            all_rows.append({'Dataset': ds, 'Algorithm': 'SSFCM', 'Repeat': rep, **res})
            
            # GK/PCM only for small, low-dim, few-cluster datasets
            if X.shape[1] <= 15 and nc <= 6 and len(X) <= 1000:
                gk = GK(n_clusters=nc, random_state=rs)
                gk.fit(X)
                res = evaluate_clustering(y, gk.labels_)
                all_rows.append({'Dataset': ds, 'Algorithm': 'GK', 'Repeat': rep, **res})
                
                pcm = PCM(n_clusters=nc, random_state=rs)
                pcm.fit(X)
                res = evaluate_clustering(y, pcm.labels_)
                all_rows.append({'Dataset': ds, 'Algorithm': 'PCM', 'Repeat': rep, **res})
            
            # SFCM
            sfcm = SFCM(n_clusters=nc, random_state=rs)
            sfcm.fit(X, P, cm)
            res = evaluate_clustering(y, sfcm.labels_)
            all_rows.append({'Dataset': ds, 'Algorithm': 'SFCM', 'Repeat': rep, **res})
            
            # FCPL (with BEST params)
            fcpl = FCPL(n_clusters=nc, m=bm, lam=bl, max_iter=100, tol=1e-5, random_state=rs)
            fcpl.fit(X, P, cm)
            res = evaluate_clustering(y, fcpl.labels_)
            all_rows.append({'Dataset': ds, 'Algorithm': 'FCPL', 'Repeat': rep, **res})
            
            # KFCPL (with BEST params)
            if use_kfcpl:
                kfcpl = KFCPL(n_clusters=nc, m=2.0, lam=bkl, gamma=bkg, max_iter=100, tol=1e-5, random_state=rs)
                kfcpl.fit(X_k, P_k, cm_k)
                res = evaluate_clustering(y_k, kfcpl.labels_)
                all_rows.append({'Dataset': ds, 'Algorithm': 'KFCPL', 'Repeat': rep, **res})
        
        # Quick summary + incremental save
        print(f"    Done. ({len(all_rows)} rows total)")
        pd.DataFrame(all_rows).to_csv(os.path.join(RESULTS_DIR, 'exp_sota_final_raw.csv'), index=False)
    
    # Save raw
    df_raw = pd.DataFrame(all_rows)
    df_raw.to_csv(os.path.join(RESULTS_DIR, 'exp_sota_final_raw.csv'), index=False)
    
    # Summary with 95% CI
    summary_rows = []
    for (ds, alg), grp in df_raw.groupby(['Dataset', 'Algorithm']):
        row = {'Dataset': ds, 'Algorithm': alg}
        for metric in ['ACC', 'NMI', 'ARI', 'F1']:
            vals = grp[metric].values
            stats_ci = ci95(vals)
            row[f'{metric}_mean'] = stats_ci['mean']
            row[f'{metric}_std'] = stats_ci['std']
            row[f'{metric}_ci95'] = stats_ci['ci_95']
            row[f'{metric}_min'] = stats_ci['min']
            row[f'{metric}_max'] = stats_ci['max']
            row[f'{metric}_runs'] = stats_ci['runs']
        summary_rows.append(row)
    
    df_summary = pd.DataFrame(summary_rows)
    df_summary.to_csv(os.path.join(RESULTS_DIR, 'exp_sota_final.csv'), index=False)
    
    # Print table
    print("\n" + "=" * 80)
    print("FINAL SOTA: ACC% (mean ± 95% CI)")
    print("=" * 80)
    pivot = df_summary.pivot(index='Dataset', columns='Algorithm', values='ACC_mean')
    print(pivot.round(2).to_string())
    
    return df_summary


if __name__ == '__main__':
    t0 = time.time()
    fcpl_best = fcpl_grid()
    kfcpl_best = kfcpl_grid()
    df_final = final_sota(fcpl_best, kfcpl_best)
    print(f"\nTotal: {time.time()-t0:.1f}s")
