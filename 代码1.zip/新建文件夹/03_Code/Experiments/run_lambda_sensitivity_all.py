"""
Unified lambda tuning + sensitivity curves for ALL semi-supervised algorithms.
Each algo's equivalent constraint-weight parameter is scanned across log-spaced values.
"""
import sys, warnings
import numpy as np
import pandas as pd
from pathlib import Path
warnings.filterwarnings('ignore')

ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))
from models.fcpl import FCPL
from models.kfcpl import KFCPL
from models.baselines import SFCM, CEFCM, DKFCM, GRFCM, SSFCM
from utils.data_loader import load_uci_dataset
from utils.metrics import clustering_accuracy, nmi_score, ari_score
from sklearn.preprocessing import StandardScaler

SEEDS = [42,43,44,45,46]
T = 2.776
OUT = ROOT / "data" / "results"

def make_con(y,k,ratio=0.10,seed=42):
    rng=np.random.RandomState(seed); n=len(y); mask=np.zeros(n,bool)
    for c in range(k):
        idx=np.where(y==c)[0]; nc=max(int(len(idx)*ratio),1)
        mask[rng.choice(idx,nc,replace=False)]=True
    P=np.zeros((n,k)); P[np.arange(n),y]=1.0
    return P,mask

# Each algo: (param_name, values_list)
LAMBDA_SCAN = {
    "SFCM":   ("lam",             [0.01,0.05,0.1,0.5,1,2,5,10,50,100]),
    "SSFCM":  ("pseudo_weight",   [0.01,0.05,0.1,0.5,1,2,5,10]),
    "CEFCM":  ("contrast_weight", [0.01,0.05,0.1,0.5,1,2,5,10]),
    "DKFCM":  ("gamma",           [0.001,0.01,0.1,0.5,1,2,5,10,50,100]),
    "GRFCM":  ("graph_weight",    [0.01,0.05,0.1,0.5,1,2,5,10]),
    "FCPL":   ("lam",             [0.01,0.05,0.1,0.5,1,2,5,10,50,100]),
    "KFCPL":  ("lam",             [0.01,0.05,0.1,0.5,1,2,5,10,50,100]),
}

DATASETS = ["iris","wine","seeds","balance","glass"]  # representative 5

def run_algo(algo, param_name, param_val, X, y, P, mask, seed, k):
    np.random.seed(seed)
    try:
        kw = {"m":2.0, "max_iter":100, "random_state":seed}
        kw[param_name] = param_val
        if algo == "SFCM":
            m = SFCM(n_clusters=k, **kw); m.fit(X,P=P,constraint_mask=mask)
        elif algo == "SSFCM":
            m = SSFCM(n_clusters=k, confidence_thresh=0.7, **{param_name:param_val},
                      random_state=seed); m.fit(X,P=P,constraint_mask=mask)
        elif algo == "CEFCM":
            m = CEFCM(n_clusters=k, **kw); m.fit(X,P=P,constraint_mask=mask)
        elif algo == "DKFCM":
            m = DKFCM(n_clusters=k, n_layers=2, **{param_name:param_val},
                      random_state=seed); m.fit(X,P=P,constraint_mask=mask)
        elif algo == "GRFCM":
            m = GRFCM(n_clusters=k, n_neighbors=7, **{param_name:param_val},
                      random_state=seed); m.fit(X,P=P,constraint_mask=mask)
        elif algo == "FCPL":
            m = FCPL(n_clusters=k, **kw); m.fit(X,P=P,constraint_mask=mask)
        elif algo == "KFCPL":
            m = KFCPL(n_clusters=k, gamma=1.0, **{param_name:param_val},
                      random_state=seed); m.fit(X,P=P,constraint_mask=mask)
        else:
            return None
        lab = m.labels_
        return (clustering_accuracy(y,lab)*100, nmi_score(y,lab)*100, ari_score(y,lab)*100)
    except:
        return None

def main():
    rows = []
    for ds in DATASETS:
        X_raw, y, _ = load_uci_dataset(ds)
        Xs = StandardScaler().fit_transform(X_raw)
        k = len(np.unique(y))
        print(f"\n=== {ds} (k={k}) ===")
        for algo, (pname, pvals) in LAMBDA_SCAN.items():
            for pv in pvals:
                accs,nmis,aris = [],[],[]
                for seed in SEEDS:
                    P, mask = make_con(y, k, 0.10, seed)
                    res = run_algo(algo, pname, pv, Xs, y, P, mask, seed, k)
                    if res is None: continue
                    accs.append(res[0]); nmis.append(res[1]); aris.append(res[2])
                if len(accs) < 3:
                    rows.append({"dataset":ds,"algorithm":algo,"param":pname,"param_value":pv,
                        "ACC_mean":np.nan,"NMI_mean":np.nan,"ARI_mean":np.nan})
                    continue
                am,asd=np.mean(accs),np.std(accs,ddof=1); ac=T*asd/np.sqrt(5)
                nm,ns=np.mean(nmis),np.std(nmis,ddof=1); nc=T*ns/np.sqrt(5)
                rm,rs=np.mean(aris),np.std(aris,ddof=1); rc=T*rs/np.sqrt(5)
                rows.append({"dataset":ds,"algorithm":algo,"param":pname,"param_value":pv,
                    "ACC_mean":round(am,2),"ACC_ci95":round(ac,2),
                    "NMI_mean":round(nm,2),"NMI_ci95":round(nc,2),
                    "ARI_mean":round(rm,2),"ARI_ci95":round(rc,2)})
                print(f"  {algo:8s} {pname}={pv:7.3f}: ACC={am:6.2f}±{ac:5.2f}")
    df = pd.DataFrame(rows)
    df.to_csv(OUT / "exp_param_sensitivity_all_semisupervised.csv", index=False)
    print(f"\nSaved: {len(df)} rows")

if __name__=="__main__":
    main()
