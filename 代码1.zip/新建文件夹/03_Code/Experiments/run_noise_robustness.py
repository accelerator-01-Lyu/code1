"""
Experiment 5: Noise robustness.
Inject different levels of noise into constraint labels and measure performance degradation.
"""
import sys
import os
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

from code.utils.data_loader import get_dataset, get_constraint_samples, inject_noise_into_constraints
from code.utils.metrics import evaluate_clustering
from code.models.fcpl import FCPL
from code.models.kfcpl import KFCPL
from code.models.baselines import SFCM

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data', 'results')
FIGURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures')
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(FIGURES_DIR, exist_ok=True)


def run_noise_experiment(n_repeats=5):
    """Test robustness to noisy constraints."""
    
    datasets = ['iris', 'wine', 'glass', 'seeds', 'balance']
    noise_levels = [0.0, 0.10, 0.20, 0.30, 0.40]
    
    rows = []
    
    print("=" * 60)
    print("Experiment 5: Noise Robustness")
    print("=" * 60)
    
    for ds_name in datasets:
        print(f"\n--- Dataset: {ds_name} ---")
        X, y, n_clusters = get_dataset(ds_name, random_state=42)
        
        for noise in noise_levels:
            accs_fcpl, accs_kfcpl, accs_sfcm = [], [], []
            
            for rep in range(n_repeats):
                rs = 42 + rep
                _, P, constraint_mask = get_constraint_samples(y, 0.1, rs)
                
                # Inject noise
                P_noisy = inject_noise_into_constraints(P, constraint_mask, noise, rs)
                
                # FCPL with noisy constraints
                fcpl = FCPL(n_clusters=n_clusters, lam=1.0, random_state=rs)
                fcpl.fit(X, P_noisy, constraint_mask)
                res = evaluate_clustering(y, fcpl.labels_)
                accs_fcpl.append(res['ACC'])
                
                # KFCPL with noisy constraints
                kfcpl = KFCPL(n_clusters=n_clusters, lam=1.0, gamma=1.0, random_state=rs)
                kfcpl.fit(X, P_noisy, constraint_mask)
                res = evaluate_clustering(y, kfcpl.labels_)
                accs_kfcpl.append(res['ACC'])
                
                # SFCM with noisy constraints
                sfcm = SFCM(n_clusters=n_clusters, random_state=rs)
                sfcm.fit(X, P_noisy, constraint_mask)
                res = evaluate_clustering(y, sfcm.labels_)
                accs_sfcm.append(res['ACC'])
            
            rows.append({
                'Dataset': ds_name, 'NoiseLevel': noise,
                'FCPL_ACC_mean': np.mean(accs_fcpl), 'FCPL_ACC_std': np.std(accs_fcpl),
                'KFCPL_ACC_mean': np.mean(accs_kfcpl), 'KFCPL_ACC_std': np.std(accs_kfcpl),
                'SFCM_ACC_mean': np.mean(accs_sfcm), 'SFCM_ACC_std': np.std(accs_sfcm),
            })
            
            print(f"  Noise {noise:.0%}: FCPL={np.mean(accs_fcpl):.2f}%, KFCPL={np.mean(accs_kfcpl):.2f}%, SFCM={np.mean(accs_sfcm):.2f}%")
    
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RESULTS_DIR, 'exp5_noise_robustness.csv'), index=False)
    
    # Generate plot
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        
        fig, axes = plt.subplots(1, len(datasets), figsize=(15, 4), sharey=True)
        if len(datasets) == 1:
            axes = [axes]
        
        for ax, ds_name in zip(axes, datasets):
            ds_df = df[df['Dataset'] == ds_name]
            ax.errorbar(ds_df['NoiseLevel']*100, ds_df['FCPL_ACC_mean'],
                       yerr=ds_df['FCPL_ACC_std'], marker='o', label='FCPL', linewidth=2)
            ax.errorbar(ds_df['NoiseLevel']*100, ds_df['KFCPL_ACC_mean'],
                       yerr=ds_df['KFCPL_ACC_std'], marker='s', label='KFCPL', linewidth=2)
            ax.errorbar(ds_df['NoiseLevel']*100, ds_df['SFCM_ACC_mean'],
                       yerr=ds_df['SFCM_ACC_std'], marker='^', label='SFCM', linewidth=2)
            ax.set_xlabel('Noise Level (%)')
            ax.set_title(ds_name)
            ax.grid(True, alpha=0.3)
        
        axes[0].set_ylabel('ACC (%)')
        axes[0].legend()
        plt.suptitle('Noise Robustness: ACC vs. Constraint Noise Level', fontsize=14)
        plt.tight_layout()
        plt.savefig(os.path.join(FIGURES_DIR, 'exp5_noise_robustness.png'), dpi=300, bbox_inches='tight')
        plt.savefig(os.path.join(FIGURES_DIR, 'exp5_noise_robustness.svg'), bbox_inches='tight')
        plt.close()
        print("\nNoise robustness plot saved.")
    except Exception as e:
        print(f"Plot generation failed: {e}")
    
    return df


if __name__ == '__main__':
    run_noise_experiment()
