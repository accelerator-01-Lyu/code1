"""
Fair SOTA comparison: all algorithms use paper-recommended fixed params.
No per-dataset tuning. FCPL uses fixed lam=5.0, m=2.0.
"""
import sys, warnings
import numpy as np
import pandas as pd
from pathlib import Path
warnings.filterwarnings('ignore')

ROOT = Path(r"C:\Users\FJZ\Doubao\chats\2026-09-16\new-chat")
sys.path.insert(0, str(ROOT / "code"))
from models.fcpl import FCPL
from models.kfcpl import KFCPL
from models.baselines import FCM, KFCM as KFCM_bl, SFCM, CEFCM, DKFCM, GRFCM, SSFCM, GK, PCM
from utils.data_loader import load_uci_dataset
from utils.metrics import clustering_accuracy, nmi_score, ari_score
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

SEEDS = [42,43,44,45,46]
T = 2.776
OUT = ROOT / "data" / "results"

def make_con(y,k,ratio=0.10,seed=42):
    rng=np.random.RandomState(seed); n=len(y); mask=np.zeros(n,bool)
    for c in range(k):
        idx=np.where(y==c)[0]; nc=max(int(len(idx)*ratio),1)
        mask[rng.choice(idx,nc,replace=False)]=True
    P=np.zeros((n,k)); P[np.arange(n),y]=1.0
    return P,mask

# Paper-recommended fixed params
ALGOS = {
    # name: (constructor kwargs, semi_supervised_bool)
    "K-means":  ({"n_init":10}, False),
    "FCM":      ({"m":2.0, "max_iter":100}, False),
    "KFCM":     ({"m":2.0, "gamma":1.0, "max_iter":100}, False),
    "GK":       ({"m":2.0}, False),
    "PCM":      ({"m":2.0, "eta":1.0}, False),
    "SFCM":     ({"m":2.0, "lam":1.0, "max_iter":100}, True),
    "SSFCM":    ({"m":2.0, "confidence_thresh":0.7}, True),
    "CEFCM":    ({"m":2.0, "contrast_weight":0.5, "max_iter":100}, True),
    "DKFCM":    ({"m":2.0, "gamma":1.0, "n_layers":2}, True),
    "GRFCM":    ({"m":2.0, "graph_weight":0.1, "n_neighbors":7, "max_iter":100}, True),
    "FCPL":     ({"m":2.0, "lam":5.0, "max_iter":100}, True),
    "KFCPL":    ({"m":2.0, "lam":5.0, "gamma":1.0, "max_iter":100}, True),
}

DATASETS = ["iris","wine","seeds","balance","glass","breast_cancer","ecoli","yeast",
            "diabetes","heart","ionosphere","sonar","optdigits","segment","vehicle"]

def run_one(algo, X, y, P, mask, seed, k):
    np.random.seed(seed)
    try:
        if algo == "K-means":
            m = KMeans(n_clusters=k, n_init=10, random_state=seed)
            m.fit(X); lab = m.labels_
        elif algo == "PCAKM":
            n_comp = min(k-1, X.shape[1], X.shape[0])
            pca = PCA(n_components=n_comp, random_state=seed)
            Xp = pca.fit_transform(X)
            m = KMeans(n_clusters=k, n_init=10, random_state=seed)
            m.fit(Xp); lab = m.labels_
        else:
            kwargs, is_semi = ALGOS[algo]
            if algo == "FCM":
                m = FCM(n_clusters=k, **kwargs, random_state=seed); m.fit(X); lab = m.labels_
            elif algo == "KFCM":
                m = KFCM_bl(n_clusters=k, **kwargs, random_state=seed); m.fit(X); lab = m.labels_
            elif algo == "GK":
                m = GK(n_clusters=k, **kwargs, random_state=seed); m.fit(X); lab = m.labels_
            elif algo == "PCM":
                m = PCM(n_clusters=k, **kwargs, random_state=seed); m.fit(X); lab = m.labels_
            elif algo in ("SFCM","CEFCM","DKFCM","GRFCM","SSFCM"):
                cls = {"SFCM":SFCM,"CEFCM":CEFCM,"DKFCM":DKFCM,"GRFCM":GRFCM,"SSFCM":SSFCM}[algo]
                m = cls(n_clusters=k, **kwargs, random_state=seed)
                m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
            elif algo == "FCPL":
                m = FCPL(n_clusters=k, **kwargs, random_state=seed)
                m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
            elif algo == "KFCPL":
                m = KFCPL(n_clusters=k, **kwargs, random_state=seed)
                m.fit(X, P=P, constraint_mask=mask); lab = m.labels_
            else:
                return None
        return (clustering_accuracy(y,lab)*100, nmi_score(y,lab)*100, ari_score(y,lab)*100)
    except Exception as e:
        return None

def main():
    rows = []
    for ds in DATASETS:
        try:
            X_raw, y, _ = load_uci_dataset(ds)
        except Exception as e:
            print(f"Skip {ds}: {e}"); continue
        Xs = StandardScaler().fit_transform(X_raw)
        k = len(np.unique(y))
        print(f"\n=== {ds}: n={len(y)}, d={Xs.shape[1]}, k={k} ===")
        for algo in list(ALGOS.keys()) + ["PCAKM"]:
            accs,nmis,aris = [],[],[]
            for seed in SEEDS:
                P, mask = make_con(y, k, 0.10, seed)
                res = run_one(algo, Xs, y, P, mask, seed, k)
                if res is None: continue
                accs.append(res[0]); nmis.append(res[1]); aris.append(res[2])
            if len(accs) < 3:
                rows.append({"dataset":ds,"algorithm":algo,"ACC_mean":"OOM","ACC_ci95":"OOM",
                    "NMI_mean":"OOM","NMI_ci95":"OOM","ARI_mean":"OOM","ARI_ci95":"OOM","n_runs":0})
                print(f"  {algo:10s}: FAILED")
                continue
            am,asd=np.mean(accs),np.std(accs,ddof=1); ac=T*asd/np.sqrt(5)
            nm,ns=np.mean(nmis),np.std(nmis,ddof=1); nc=T*ns/np.sqrt(5)
            rm,rs=np.mean(aris),np.std(aris,ddof=1); rc=T*rs/np.sqrt(5)
            rows.append({"dataset":ds,"algorithm":algo,
                "ACC_mean":round(am,2),"ACC_ci95":round(ac,2),
                "NMI_mean":round(nm,2),"NMI_ci95":round(nc,2),
                "ARI_mean":round(rm,2),"ARI_ci95":round(rc,2),"n_runs":len(accs)})
            print(f"  {algo:10s}: ACC={am:6.2f}±{ac:5.2f}")

    df = pd.DataFrame(rows)
    out = OUT / "exp_sota_fair_comparison.csv"
    df.to_csv(out, index=False)
    print(f"\nSaved: {out} ({len(df)} rows)")
    pv = df.pivot_table(index="dataset", columns="algorithm", values="ACC_mean")
    print("\n=== ACC pivot (all fixed params) ===")
    print(pv.round(1).to_string())

if __name__=="__main__":
    main()
