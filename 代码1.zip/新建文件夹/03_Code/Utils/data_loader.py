"""
Dataset loading utilities for semi-supervised fuzzy clustering experiments.
Supports UCI datasets, image datasets (MNIST, Fashion-MNIST), and synthetic data.
"""
import numpy as np
from sklearn.datasets import (
    load_iris, load_wine, load_breast_cancer,
    fetch_openml, make_blobs, make_moons, make_circles
)
from sklearn.preprocessing import StandardScaler
import os


DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data')


def load_uci_dataset(name, random_state=42):
    """
    Load UCI benchmark datasets.
    
    Args:
        name: dataset name (iris, wine, breast_cancer, glass, seeds, balance, vehicle, segment)
        random_state: random seed
    
    Returns:
        X: feature matrix (n_samples, n_features)
        y: ground truth labels (n_samples,)
        n_clusters: number of clusters
    """
    np.random.seed(random_state)
    
    if name == 'iris':
        data = load_iris()
        X, y = data.data, data.target
        n_clusters = 3
    elif name == 'wine':
        data = load_wine()
        X, y = data.data, data.target
        n_clusters = 3
    elif name == 'breast_cancer':
        data = load_breast_cancer()
        X, y = data.data, data.target
        n_clusters = 2
    elif name == 'glass':
        # Load from OpenML
        data = fetch_openml(name='glass', version=1, as_frame=False, parser='auto')
        X = data.data
        y_raw = data.target
        # Convert string labels to int
        unique_labels = np.unique(y_raw)
        label_map = {l: i for i, l in enumerate(unique_labels)}
        y = np.array([label_map[l] for l in y_raw])
        n_clusters = len(unique_labels)
    elif name == 'seeds':
        data = fetch_openml(name='seeds', version=1, as_frame=False, parser='auto')
        X = data.data
        y_raw = data.target
        unique_labels = np.unique(y_raw)
        label_map = {l: i for i, l in enumerate(unique_labels)}
        y = np.array([label_map[l] for l in y_raw])
        n_clusters = 3
    elif name == 'balance':
        data = fetch_openml(name='balance-scale', version=1, as_frame=False, parser='auto')
        X, y = data.data, data.target
        # Convert string labels to int
        unique_labels = np.unique(y)
        label_map = {l: i for i, l in enumerate(unique_labels)}
        y = np.array([label_map[l] for l in y])
        n_clusters = len(unique_labels)
    elif name == 'vehicle':
        data = fetch_openml(name='vehicle', version=1, as_frame=False, parser='auto')
        X, y = data.data, data.target
        unique_labels = np.unique(y)
        label_map = {l: i for i, l in enumerate(unique_labels)}
        y = np.array([label_map[l] for l in y])
        n_clusters = len(unique_labels)
    elif name == 'segment':
        data = fetch_openml(name='segment', version=1, as_frame=False, parser='auto')
        X, y = data.data, data.target
        unique_labels = np.unique(y)
        label_map = {l: i for i, l in enumerate(unique_labels)}
        y = np.array([label_map[l] for l in y])
        n_clusters = len(unique_labels)
    elif name == 'vowel':
        data = fetch_openml(name='vowel', version=1, as_frame=False, parser='auto')
        X, y = data.data, data.target
        unique_labels = np.unique(y)
        label_map = {l: i for i, l in enumerate(unique_labels)}
        y = np.array([label_map[l] for l in y])
        n_clusters = len(unique_labels)
    elif name == 'pendigits':
        data = fetch_openml(name='pendigits', version=1, as_frame=False, parser='auto')
        X, y = data.data, data.target.astype(int)
        n_clusters = 10
    elif name == 'letter':
        data = fetch_openml(name='letter', version=1, as_frame=False, parser='auto')
        X, y = data.data, data.target
        # Use subset: first 5000 samples
        idx = np.random.RandomState(random_state).choice(len(X), 5000, replace=False)
        X, y = X[idx], y[idx]
        unique_labels = np.unique(y)
        label_map = {l: i for i, l in enumerate(unique_labels)}
        y = np.array([label_map[l] for l in y])
        n_clusters = len(unique_labels)
    else:
        raise ValueError(f"Unknown dataset: {name}")
    
    # Handle NaN values
    if np.any(np.isnan(X)):
        X = np.nan_to_num(X, nan=0.0)
    
    # Standardize
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    
    return X, y, n_clusters


def load_mnist_subset(per_class=500, random_state=42):
    """
    Load MNIST subset (per_class samples per digit).
    
    Args:
        per_class: number of samples per class
        random_state: random seed
    
    Returns:
        X, y, n_clusters
    """
    try:
        from sklearn.datasets import fetch_openml
        mnist = fetch_openml('mnist_784', version=1, as_frame=False, parser='auto')
        X_all, y_all = mnist.data, mnist.target.astype(int)
    except Exception:
        # Fallback: generate synthetic MNIST-like data
        X_all, y_all = make_blobs(n_samples=70000, n_features=784, centers=10,
                                   random_state=random_state)
    
    rng = np.random.RandomState(random_state)
    X_subset, y_subset = [], []
    for c in range(10):
        idx = np.where(y_all == c)[0]
        chosen = rng.choice(idx, min(per_class, len(idx)), replace=False)
        X_subset.append(X_all[chosen])
        y_subset.append(y_all[chosen])
    
    X = np.vstack(X_subset)
    y = np.concatenate(y_subset).astype(int)
    
    # Normalize to [0, 1] and flatten
    if X.max() > 1.0:
        X = X / 255.0
    
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    
    return X, y, 10


def load_fashion_mnist_subset(per_class=500, random_state=42):
    """
    Load Fashion-MNIST subset.
    """
    try:
        fm = fetch_openml(name='Fashion-MNIST', version=1, as_frame=False, parser='auto')
        X_all, y_all = fm.data, fm.target.astype(int)
    except Exception:
        X_all, y_all = make_blobs(n_samples=70000, n_features=784, centers=10,
                                   random_state=random_state)
    
    rng = np.random.RandomState(random_state)
    X_subset, y_subset = [], []
    for c in range(10):
        idx = np.where(y_all == c)[0]
        chosen = rng.choice(idx, min(per_class, len(idx)), replace=False)
        X_subset.append(X_all[chosen])
        y_subset.append(y_all[chosen])
    
    X = np.vstack(X_subset)
    y = np.concatenate(y_subset).astype(int)
    
    if X.max() > 1.0:
        X = X / 255.0
    
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    
    return X, y, 10


def load_synthetic_dataset(name, n_samples=1000, random_state=42):
    """
    Load synthetic structural datasets.
    
    Args:
        name: 'aggregation', 'compound', 'moons', 'circles', 'blobs'
    """
    rng = np.random.RandomState(random_state)
    
    if name == 'moons':
        X, y = make_moons(n_samples=n_samples, noise=0.05, random_state=random_state)
        n_clusters = 2
    elif name == 'circles':
        X, y = make_circles(n_samples=n_samples, noise=0.05, factor=0.5, random_state=random_state)
        n_clusters = 2
    elif name == 'blobs':
        X, y = make_blobs(n_samples=n_samples, centers=6, n_features=2,
                          random_state=random_state, cluster_std=0.8)
        n_clusters = 6
    elif name == 'aggregation':
        # Generate synthetic aggregation-like data
        centers = np.array([
            [0.0, 0.0], [1.5, 0.5], [3.0, 0.0],
            [0.5, 2.0], [2.0, 2.5], [3.5, 2.0], [1.5, 4.0]
        ])
        n_per = n_samples // 7
        X_list, y_list = [], []
        for i, c in enumerate(centers):
            pts = c + rng.randn(n_per, 2) * 0.3
            X_list.append(pts)
            y_list.append(np.full(n_per, i))
        X = np.vstack(X_list)
        y = np.concatenate(y_list)
        n_clusters = 7
    elif name == 'compound':
        # Generate synthetic compound-like data with nested rings
        X_list, y_list = [], []
        # Outer ring
        theta = np.linspace(0, 2*np.pi, 200)
        ring_x = 3 * np.cos(theta) + rng.randn(200) * 0.1
        ring_y = 3 * np.sin(theta) + rng.randn(200) * 0.1
        X_list.append(np.column_stack([ring_x, ring_y]))
        y_list.append(np.zeros(200))
        # Inner cluster
        c1 = rng.randn(150, 2) * 0.5 + np.array([0, 0])
        X_list.append(c1)
        y_list.append(np.ones(150))
        # Three outer clusters
        c2 = rng.randn(100, 2) * 0.4 + np.array([5, 2])
        c3 = rng.randn(100, 2) * 0.4 + np.array([-4, 3])
        c4 = rng.randn(100, 2) * 0.4 + np.array([2, -4])
        X_list.extend([c2, c3, c4])
        y_list.extend([np.full(100, 2), np.full(100, 3), np.full(100, 4)])
        X = np.vstack(X_list)
        y = np.concatenate(y_list).astype(int)
        n_clusters = 5
    else:
        raise ValueError(f"Unknown synthetic dataset: {name}")
    
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    return X, y, n_clusters


def get_constraint_samples(y, label_ratio=0.1, random_state=42):
    """
    Select constraint samples and generate prior membership matrix P.
    
    Args:
        y: ground truth labels
        label_ratio: fraction of samples to use as constraints
        random_state: random seed
    
    Returns:
        constraint_indices: indices of constrained samples
        P: prior membership matrix (n_samples, n_clusters), one-hot for constrained samples
        constraint_mask: boolean mask indicating which samples are constrained
    """
    rng = np.random.RandomState(random_state)
    n = len(y)
    n_clusters = len(np.unique(y))
    
    n_constrained = max(int(n * label_ratio), n_clusters)
    
    # Stratified sampling to ensure each cluster has at least one labeled sample
    constraint_indices = []
    for c in range(n_clusters):
        idx_c = np.where(y == c)[0]
        n_c = max(1, int(n_constrained / n_clusters))
        chosen = rng.choice(idx_c, min(n_c, len(idx_c)), replace=False)
        constraint_indices.extend(chosen)
    
    constraint_indices = np.array(constraint_indices)
    
    # Build prior membership matrix (one-hot encoding)
    P = np.zeros((n, n_clusters))
    for idx in constraint_indices:
        P[idx, y[idx]] = 1.0
    
    constraint_mask = np.zeros(n, dtype=bool)
    constraint_mask[constraint_indices] = True
    
    return constraint_indices, P, constraint_mask


def inject_noise_into_constraints(P, constraint_mask, noise_ratio=0.1, random_state=42):
    """
    Inject noise into prior membership matrix by randomly flipping labels.
    
    Args:
        P: prior membership matrix
        constraint_mask: boolean mask of constrained samples
        noise_ratio: fraction of constrained samples to corrupt
        random_state: random seed
    
    Returns:
        P_noisy: noisy prior membership matrix
    """
    rng = np.random.RandomState(random_state)
    P_noisy = P.copy()
    n_clusters = P.shape[1]
    
    constrained_idx = np.where(constraint_mask)[0]
    n_noisy = int(len(constrained_idx) * noise_ratio)
    
    if n_noisy > 0:
        noisy_idx = rng.choice(constrained_idx, n_noisy, replace=False)
        for idx in noisy_idx:
            # Flip to a random different cluster
            true_c = np.argmax(P_noisy[idx])
            other_c = rng.choice([c for c in range(n_clusters) if c != true_c])
            P_noisy[idx, true_c] = 0.0
            P_noisy[idx, other_c] = 1.0
    
    return P_noisy


def get_dataset(name, random_state=42, **kwargs):
    """
    Universal dataset loader.
    
    Returns:
        X, y, n_clusters
    """
    uci_names = ['iris', 'wine', 'breast_cancer', 'glass', 'seeds', 
                 'balance', 'vehicle', 'segment', 'vowel', 'pendigits', 'letter']
    
    if name in uci_names:
        return load_uci_dataset(name, random_state)
    elif name == 'mnist':
        return load_mnist_subset(random_state=random_state, **kwargs)
    elif name == 'fashion_mnist':
        return load_fashion_mnist_subset(random_state=random_state, **kwargs)
    elif name in ['moons', 'circles', 'blobs', 'aggregation', 'compound']:
        return load_synthetic_dataset(name, random_state=random_state, **kwargs)
    else:
        raise ValueError(f"Unknown dataset: {name}")
