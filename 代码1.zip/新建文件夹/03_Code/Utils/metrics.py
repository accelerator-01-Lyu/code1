"""
Clustering evaluation metrics: ACC, NMI, ARI, F1-score.
All metrics return values in [0, 1] or [0, 100] depending on scale parameter.
"""
import numpy as np
from scipy.optimize import linear_sum_assignment
from sklearn.metrics import normalized_mutual_info_score, adjusted_rand_score, f1_score


def clustering_accuracy(y_true, y_pred):
    """
    Calculate clustering accuracy (ACC) using Hungarian matching.
    
    Args:
        y_true: ground truth labels, shape (n_samples,)
        y_pred: predicted cluster labels, shape (n_samples,)
    
    Returns:
        acc: accuracy in [0, 1]
    """
    y_true = y_true.astype(np.int64)
    y_pred = y_pred.astype(np.int64)
    assert y_pred.size == y_true.size
    
    # Build contingency matrix
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    
    # Hungarian algorithm (maximize)
    row_ind, col_ind = linear_sum_assignment(w.max() - w)
    acc = w[row_ind, col_ind].sum() / y_pred.size
    return acc


def nmi_score(y_true, y_pred):
    """Normalized Mutual Information."""
    return normalized_mutual_info_score(y_true, y_pred)


def ari_score(y_true, y_pred):
    """Adjusted Rand Index."""
    return adjusted_rand_score(y_true, y_pred)


def f1_score_clustering(y_true, y_pred):
    """
    Calculate F1-score for clustering using best matching.
    Uses macro F1 after Hungarian matching.
    """
    y_true = y_true.astype(np.int64)
    y_pred = y_pred.astype(np.int64)
    
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    
    row_ind, col_ind = linear_sum_assignment(w.max() - w)
    # Map predicted labels to true labels
    mapping = {}
    for r, c in zip(row_ind, col_ind):
        mapping[r] = c
    
    y_pred_mapped = np.array([mapping.get(p, p) for p in y_pred])
    return f1_score(y_true, y_pred_mapped, average='macro', zero_division=0)


def evaluate_clustering(y_true, y_pred, scale=100):
    """
    Compute all clustering metrics.
    
    Args:
        y_true: ground truth labels
        y_pred: predicted cluster labels
        scale: multiply results by this (100 for percentage)
    
    Returns:
        dict with ACC, NMI, ARI, F1
    """
    return {
        'ACC': clustering_accuracy(y_true, y_pred) * scale,
        'NMI': nmi_score(y_true, y_pred) * scale,
        'ARI': ari_score(y_true, y_pred) * scale,
        'F1': f1_score_clustering(y_true, y_pred) * scale,
    }
