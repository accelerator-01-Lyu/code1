"""
MES (Matrix-based Efficient Solver) implementation.
Solves the constrained membership update subproblem.

For m=2, the constrained subproblem is:
    min  sum_k u_k^2 * d_k + lambda * sum_k (u_k - p_k)^2
    s.t. sum_k u_k = 1, u_k >= 0

KKT conditions (m=2):
    2*u_k*d_k + 2*lambda*(u_k - p_k) + nu = 0
    => u_k = (lambda*p_k - nu/2) / (d_k + lambda)

This gives a 1D equation in nu:
    sum_k (lambda*p_k - nu/2) / (d_k + lambda) = 1

With active-set method for non-negativity.
"""
import numpy as np
from scipy.optimize import brentq


def mes_solve_single(d_vec, p_vec, lam):
    """
    Solve membership update for a single constrained sample (m=2 exact solution).
    
    Minimize:  sum_k u_k^2 * d_k + lambda * sum_k (u_k - p_k)^2
    Subject to: sum_k u_k = 1, u_k >= 0
    
    KKT gives: u_k = (lambda*p_k - nu/2) / (d_k + lambda)
    Solve for nu such that sum u_k = 1.
    
    Args:
        d_vec: squared distance vector, shape (k,)
        p_vec: prior membership vector, shape (k,)
        lam: constraint strength lambda
    
    Returns:
        u_opt: optimal membership vector, shape (k,)
    """
    k = len(d_vec)
    
    # Active set iteration
    active_mask = np.ones(k, dtype=bool)
    
    for _ in range(k + 1):
        active_idx = np.where(active_mask)[0]
        k_active = len(active_idx)
        
        if k_active == 0:
            u = np.ones(k) / k
            break
        
        d_a = d_vec[active_idx]
        p_a = p_vec[active_idx]
        
        # Solve: sum_{k in active} (lambda*p_k - nu/2) / (d_k + lambda) = 1
        # Let a_k = lambda / (d_k + lambda), b_k = 1 / (2*(d_k + lambda))
        # Then: sum (a_k * p_k) - nu * sum(b_k) = 1
        # => nu = (sum(a_k * p_k) - 1) / sum(b_k)
        
        a = lam / (d_a + lam)
        b = 1.0 / (2.0 * (d_a + lam))
        
        numerator = np.sum(a * p_a) - 1.0
        denominator = np.sum(b)
        
        if abs(denominator) < 1e-15:
            nu = 0.0
        else:
            nu = numerator / denominator
        
        # Compute u on active set
        u_active = (lam * p_a - nu / 2.0) / (d_a + lam)
        
        # Check for negative components
        if np.any(u_active < -1e-10):
            # Remove the most negative component
            min_local_idx = np.argmin(u_active)
            active_mask[active_idx[min_local_idx]] = False
        else:
            # Solution found
            u = np.zeros(k)
            u[active_idx] = np.maximum(u_active, 0.0)
            break
    else:
        u = np.ones(k) / k
    
    # Normalize
    u_sum = u.sum()
    if u_sum > 1e-10:
        u = u / u_sum
    else:
        u = np.ones(k) / k
    
    return u


def mes_solve_batch(d_matrix, P, constraint_mask, lam):
    """
    Batch solve membership updates.
    
    Args:
        d_matrix: distance matrix (n, k)
        P: prior membership (n, k)
        constraint_mask: boolean (n,)
        lam: constraint strength
    
    Returns:
        U: membership matrix (n, k)
    """
    n, k = d_matrix.shape
    U = np.zeros((n, k))
    
    for i in range(n):
        if constraint_mask[i]:
            U[i] = mes_solve_single(d_matrix[i], P[i], lam)
        else:
            # Standard FCM update (m=2)
            d = d_matrix[i]
            d = np.maximum(d, 1e-10)
            inv_d = 1.0 / d
            U[i] = inv_d / inv_d.sum()
    
    return U


def qp_solve_single(d_vec, p_vec, lam):
    """
    Standard QP solver using scipy.optimize for comparison.
    """
    from scipy.optimize import minimize
    
    k = len(d_vec)
    
    def objective(u):
        return np.sum(u**2 * d_vec) + lam * np.sum((u - p_vec)**2)
    
    def constraint_sum(u):
        return np.sum(u) - 1.0
    
    bounds = [(0, 1)] * k
    cons = {'type': 'eq', 'fun': constraint_sum}
    x0 = p_vec.copy()
    
    try:
        res = minimize(objective, x0, method='SLSQP', bounds=bounds,
                      constraints=cons, options={'ftol': 1e-10, 'maxiter': 200})
        u = res.x
        u = np.maximum(u, 0.0)
        u_sum = u.sum()
        if u_sum > 0:
            u = u / u_sum
        else:
            u = np.ones(k) / k
    except Exception:
        u = np.ones(k) / k
    
    return u


def qp_solve_batch(d_matrix, P, constraint_mask, lam):
    """Batch QP solve for comparison with MES."""
    n, k = d_matrix.shape
    U = np.zeros((n, k))
    
    for i in range(n):
        if constraint_mask[i]:
            U[i] = qp_solve_single(d_matrix[i], P[i], lam)
        else:
            d = d_matrix[i]
            d = np.maximum(d, 1e-10)
            inv_d = 1.0 / d
            U[i] = inv_d / inv_d.sum()
    
    return U
