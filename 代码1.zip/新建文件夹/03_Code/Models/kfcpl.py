"""
KFCPL: Kernelized Semi-supervised Fuzzy Clustering with Partition-level Constraints.

Extends FCPL to RKHS using Gaussian kernel.
Kernelized distance (Eq. 37 in paper):
    ||phi(x_i) - phi(c_k)||^2 = K(x_i,x_i) - 2 * sum_j u_jk^m * K(x_i,x_j) / sum_j u_jk^m
                                + sum_{j,l} u_jk^m * u_lk^m * K(x_j,x_l) / (sum_j u_jk^m)^2

Paper reference: Section 3.4
"""
import numpy as np
import time
from .mes import mes_solve_single


class KFCPL:
    """
    Kernelized FCPL with Gaussian kernel.
    
    Parameters:
        n_clusters: number of clusters
        m: fuzzification coefficient (default: 2)
        lam: constraint strength lambda (default: 1.0)
        gamma: Gaussian kernel bandwidth (default: 1.0)
        max_iter: maximum iterations (default: 100)
        tol: convergence threshold (default: 1e-5)
        random_state: random seed
    """
    
    def __init__(self, n_clusters, m=2.0, lam=1.0, gamma=1.0, 
                 max_iter=100, tol=1e-5, random_state=42):
        self.n_clusters = n_clusters
        self.m = m
        self.lam = lam
        self.gamma = gamma
        self.max_iter = max_iter
        self.tol = tol
        self.random_state = random_state
        
        self.U_ = None
        self.X_ = None       # training data (needed for kernel)
        self.labels_ = None
        self.obj_history_ = []
        self.n_iter_ = 0
        self.time_ = 0.0
    
    def _gaussian_kernel(self, X1, X2):
        """
        Compute Gaussian kernel matrix.
        K(x, y) = exp(-gamma * ||x - y||^2)
        """
        # ||x - y||^2 = ||x||^2 + ||y||^2 - 2 x^T y
        X1_sq = np.sum(X1 ** 2, axis=1, keepdims=True)  # (n1, 1)
        X2_sq = np.sum(X2 ** 2, axis=1, keepdims=True).T  # (1, n2)
        dist_sq = X1_sq + X2_sq - 2.0 * X1 @ X2.T
        dist_sq = np.maximum(dist_sq, 0.0)
        return np.exp(-self.gamma * dist_sq)
    
    def _compute_kernel_distances(self, X, U, K=None):
        """
        Compute kernelized distances between samples and cluster centers.
        
        ||phi(x_i) - phi(c_k)||^2 = 
            K(x_i,x_i) - 2 * sum_j u_jk^m * K(x_i,x_j) / sum_j u_jk^m
            + sum_{j,l} u_jk^m * u_lk^m * K(x_j,x_l) / (sum_j u_jk^m)^2
        
        Args:
            X: data matrix (n, d)
            U: membership matrix (n, k)
            K: precomputed kernel matrix (n, n), or None to compute
        
        Returns:
            D: kernelized distance matrix (n, k)
        """
        n = X.shape[0]
        k = self.n_clusters
        
        if K is None:
            K = self._gaussian_kernel(X, X)
        
        um = U ** self.m  # (n, k)
        
        # Sum of memberships per cluster: S_k = sum_j u_jk^m
        S = um.sum(axis=0)  # (k,)
        S = np.maximum(S, 1e-10)
        
        # K(x_i, x_i) = 1 for Gaussian kernel
        diag_K = np.ones(n)  # (n,)
        
        # Second term: -2 * sum_j u_jk^m * K(x_i,x_j) / S_k
        # weighted_K: (n, k)
        weighted_K = K @ um  # (n, k)
        term2 = -2.0 * weighted_K / S[np.newaxis, :]  # (n, k)
        
        # Third term: sum_{j,l} u_jk^m * u_lk^m * K(x_j,x_l) / S_k^2
        # For each cluster k:
        #   numerator_k = u_k^T K u_k (where u_k is the k-th column of um)
        # This is the "center term"
        term3 = np.zeros(k)
        for kk in range(k):
            uk = um[:, kk:kk+1]  # (n, 1)
            # uk^T K uk = sum_{j,l} u_jk^m u_lk^m K(x_j, x_l)
            center_term = (uk.T @ K @ uk)[0, 0]
            term3[kk] = center_term / (S[kk] ** 2)
        
        # Final distance: D[i,k] = diag_K[i] + term2[i,k] + term3[k]
        D = diag_K[:, np.newaxis] + term2 + term3[np.newaxis, :]
        D = np.maximum(D, 1e-10)
        
        return D
    
    def fit(self, X, P=None, constraint_mask=None):
        """
        Run KFCPL clustering.
        
        Args:
            X: feature matrix (n_samples, n_features)
            P: prior membership matrix (n_samples, n_clusters)
            constraint_mask: boolean array (n_samples,)
        """
        start_time = time.time()
        n, d = X.shape
        k = self.n_clusters
        
        if P is None:
            P = np.zeros((n, k))
            constraint_mask = np.zeros(n, dtype=bool)
        
        self.X_ = X.copy()
        
        # Precompute kernel matrix
        K = self._gaussian_kernel(X, X)
        
        # Initialize membership
        rng = np.random.RandomState(self.random_state)
        U = rng.rand(n, k)
        U = U / U.sum(axis=1, keepdims=True)
        
        if P is not None and constraint_mask is not None:
            for i in range(n):
                if constraint_mask[i]:
                    U[i] = 0.5 * P[i] + 0.5 * U[i]
                    U[i] = U[i] / U[i].sum()
        
        self.obj_history_ = []
        
        for iteration in range(self.max_iter):
            # Compute kernelized distances
            D = self._compute_kernel_distances(X, U, K)
            
            # Update membership
            U_new = np.zeros_like(U)
            
            for i in range(n):
                if constraint_mask[i]:
                    g = self.m * (U[i] ** (self.m - 1)) * D[i]
                    U_new[i] = mes_solve_single(g, P[i], self.lam)
                else:
                    d = D[i]
                    d = np.maximum(d, 1e-10)
                    inv_d_pow = (1.0 / d) ** (1.0 / (self.m - 1))
                    U_new[i] = inv_d_pow / inv_d_pow.sum()
            
            # Compute objective
            um_new = U_new ** self.m
            # FCM term in kernel space
            fcm_term = 0.0
            for kk in range(k):
                uk = um_new[:, kk:kk+1]
                center_term = (uk.T @ K @ uk)[0, 0] / (uk.sum() ** 2)
                diag_term = np.sum(um_new[:, kk] * np.diag(K))
                cross_term = -2.0 * (uk.flatten() @ K @ uk.flatten()) / uk.sum()
                # Actually simpler: compute sum_i u_ik^m * D[i,k]
                fcm_term += np.sum(um_new[:, kk] * D[:, kk])
            
            # Constraint term
            if np.any(constraint_mask):
                diff = U_new[constraint_mask] - P[constraint_mask]
                constraint_term = self.lam * np.sum(diff ** 2)
            else:
                constraint_term = 0.0
            
            obj = fcm_term + constraint_term
            self.obj_history_.append(obj)
            
            # Check convergence
            if iteration > 0:
                obj_change = abs(self.obj_history_[-2] - self.obj_history_[-1])
                if obj_change < self.tol:
                    U = U_new
                    self.n_iter_ = iteration + 1
                    break
            
            U = U_new
            self.n_iter_ = iteration + 1
        
        self.U_ = U
        self.labels_ = np.argmax(U, axis=1)
        self.time_ = time.time() - start_time
        
        return self
