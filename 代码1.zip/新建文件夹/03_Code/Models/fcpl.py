"""
FCPL: Semi-supervised Fuzzy Clustering with Partition-level Constraints.

Objective function (Eq. 7 in paper):
    J = sum_i sum_k u_ik^m ||x_i - c_k||^2 + lambda * sum_{i in S} sum_k (u_ik - p_ik)^2

Subject to: sum_k u_ik = 1, u_ik >= 0

Solving with MES (Matrix-based Efficient Solver):
- Unconstrained samples: standard FCM update
- Constrained samples: solve subproblem via KKT/block matrix inversion

The subproblem for constrained samples i (fixed C):
    min  sum_k d_ik * u_ik + lambda * sum_k (u_ik - p_ik)^2
    s.t. sum_k u_ik = 1, u_ik >= 0

Note: The FCM term is linearized in the subproblem (first-order Taylor expansion
of u^m around the current U). The fuzzification coefficient m enters through the
cluster center update.

Paper reference: Section 3.2 - 3.3
"""
import numpy as np
import time
from .mes import mes_solve_single, qp_solve_single


class FCPL:
    """
    Semi-supervised Fuzzy Clustering with Partition-level Constraints.
    
    Parameters:
        n_clusters: number of clusters (c)
        m: fuzzification coefficient (default: 2)
        lam: constraint strength lambda (default: 1.0)
        max_iter: maximum number of iterations (default: 100)
        tol: convergence threshold (default: 1e-5)
        solver: 'mes' or 'qp' (default: 'mes')
        random_state: random seed (default: 42)
    """
    
    def __init__(self, n_clusters, m=2.0, lam=1.0, max_iter=100,
                 tol=1e-5, solver='mes', random_state=42):
        self.n_clusters = n_clusters
        self.m = m
        self.lam = lam
        self.max_iter = max_iter
        self.tol = tol
        self.solver = solver
        self.random_state = random_state
        
        self.U_ = None
        self.C_ = None
        self.labels_ = None
        self.obj_history_ = []
        self.n_iter_ = 0
        self.time_ = 0.0
    
    def _init_membership(self, X, P=None, constraint_mask=None):
        """Initialize membership matrix U."""
        n = X.shape[0]
        rng = np.random.RandomState(self.random_state)
        
        U = rng.rand(n, self.n_clusters)
        U = U / U.sum(axis=1, keepdims=True)
        
        if P is not None and constraint_mask is not None:
            for i in range(n):
                if constraint_mask[i]:
                    U[i] = P[i].copy()
                    U[i] = U[i] / U[i].sum()
        
        return U
    
    def _update_centers(self, X, U):
        """
        Update cluster centers (M-step).
        c_k = sum_i u_ik^m * x_i / sum_i u_ik^m
        """
        um = U ** self.m
        numerator = um.T @ X
        denominator = um.sum(axis=0, keepdims=True).T
        C = numerator / np.maximum(denominator, 1e-10)
        return C
    
    def _compute_distances(self, X, C):
        """Compute squared Euclidean distances D[i,k] = ||x_i - c_k||^2"""
        D = np.sum((X[:, np.newaxis, :] - C[np.newaxis, :, :]) ** 2, axis=2)
        return np.maximum(D, 1e-10)
    
    def _compute_objective(self, X, U, C, P, constraint_mask, D=None):
        """Compute the objective function value."""
        if D is None:
            D = self._compute_distances(X, C)
        
        um = U ** self.m
        fcm_term = np.sum(um * D)
        
        if constraint_mask is not None and np.any(constraint_mask):
            diff = U[constraint_mask] - P[constraint_mask]
            constraint_term = self.lam * np.sum(diff ** 2)
        else:
            constraint_term = 0.0
        
        return fcm_term + constraint_term
    
    def fit(self, X, P=None, constraint_mask=None):
        """
        Run FCPL clustering.
        
        Args:
            X: feature matrix, shape (n_samples, n_features)
            P: prior membership matrix, shape (n_samples, n_clusters)
            constraint_mask: boolean array, shape (n_samples,)
        """
        start_time = time.time()
        n, d = X.shape
        k = self.n_clusters
        
        if P is None:
            P = np.zeros((n, k))
            constraint_mask = np.zeros(n, dtype=bool)
        
        U = self._init_membership(X, P, constraint_mask)
        
        self.obj_history_ = []
        
        for iteration in range(self.max_iter):
            # M-step: update cluster centers
            C = self._update_centers(X, U)
            
            # Compute distances
            D = self._compute_distances(X, C)
            
            # E-step: update membership
            U_new = np.zeros_like(U)
            
            for i in range(n):
                if constraint_mask[i]:
                    # Constrained sample: solve exact m=2 subproblem via MES
                    # min sum_k u_k^2 * d_ik + lambda * sum_k (u_k - p_k)^2
                    # The MES solver uses the exact KKT solution for m=2
                    if self.solver == 'mes':
                        U_new[i] = mes_solve_single(D[i], P[i], self.lam)
                    else:
                        U_new[i] = qp_solve_single(D[i], P[i], self.lam)
                else:
                    # Unconstrained sample: standard FCM update
                    d_i = D[i]
                    d_i = np.maximum(d_i, 1e-10)
                    inv_d_pow = (1.0 / d_i) ** (1.0 / (self.m - 1))
                    U_new[i] = inv_d_pow / inv_d_pow.sum()
            
            # Compute objective
            C_new = self._update_centers(X, U_new)
            D_new = self._compute_distances(X, C_new)
            obj = self._compute_objective(X, U_new, C_new, P, constraint_mask, D_new)
            self.obj_history_.append(obj)
            
            # Check convergence
            if iteration > 0:
                obj_change = abs(self.obj_history_[-2] - self.obj_history_[-1])
                if obj_change < self.tol:
                    U = U_new
                    C = C_new
                    self.n_iter_ = iteration + 1
                    break
            
            U = U_new
            self.n_iter_ = iteration + 1
        
        if not hasattr(self, 'n_iter_') or self.n_iter_ == 0:
            C = self._update_centers(X, U)
        
        self.U_ = U
        self.C_ = C
        self.labels_ = np.argmax(U, axis=1)
        self.time_ = time.time() - start_time
        
        return self
    
    def predict(self, X):
        """Predict cluster labels for new samples."""
        D = self._compute_distances(X, self.C_)
        d = np.maximum(D, 1e-10)
        inv_d_pow = (1.0 / d) ** (1.0 / (self.m - 1))
        U = inv_d_pow / inv_d_pow.sum(axis=1, keepdims=True)
        return np.argmax(U, axis=1)
