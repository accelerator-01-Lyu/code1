"""
Baseline clustering algorithms for comparison.
Includes: K-means, FCM, KFCM, SFCM, PCAKM, and simplified versions of recent methods.
"""
import numpy as np
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from scipy.spatial.distance import cdist
import time


class FCM:
    """
    Standard Fuzzy C-Means clustering.
    
    Parameters:
        n_clusters: number of clusters
        m: fuzzification coefficient (default: 2)
        max_iter: maximum iterations (default: 100)
        tol: convergence threshold (default: 1e-5)
        random_state: random seed
    """
    
    def __init__(self, n_clusters, m=2.0, max_iter=100, tol=1e-5, random_state=42):
        self.n_clusters = n_clusters
        self.m = m
        self.max_iter = max_iter
        self.tol = tol
        self.random_state = random_state
        self.U_ = None
        self.C_ = None
        self.labels_ = None
        self.obj_history_ = []
        self.n_iter_ = 0
        self.time_ = 0.0
    
    def fit(self, X):
        start_time = time.time()
        n = X.shape[0]
        k = self.n_clusters
        
        rng = np.random.RandomState(self.random_state)
        U = rng.rand(n, k)
        U = U / U.sum(axis=1, keepdims=True)
        
        self.obj_history_ = []
        
        for iteration in range(self.max_iter):
            # Update centers
            um = U ** self.m
            C = (um.T @ X) / um.sum(axis=0, keepdims=True).T
            
            # Compute distances
            D = cdist(X, C, 'sqeuclidean')
            D = np.maximum(D, 1e-10)
            
            # Update membership
            inv_d = (1.0 / D) ** (1.0 / (self.m - 1))
            U_new = inv_d / inv_d.sum(axis=1, keepdims=True)
            
            # Objective
            obj = np.sum((U_new ** self.m) * D)
            self.obj_history_.append(obj)
            
            if iteration > 0 and abs(self.obj_history_[-2] - obj) < self.tol:
                U = U_new
                self.n_iter_ = iteration + 1
                break
            
            U = U_new
            self.n_iter_ = iteration + 1
        
        self.U_ = U
        self.C_ = C
        self.labels_ = np.argmax(U, axis=1)
        self.time_ = time.time() - start_time
        return self


class KFCM:
    """
    Kernelized Fuzzy C-Means with Gaussian kernel.
    """
    
    def __init__(self, n_clusters, m=2.0, gamma=1.0, max_iter=100, tol=1e-5, random_state=42):
        self.n_clusters = n_clusters
        self.m = m
        self.gamma = gamma
        self.max_iter = max_iter
        self.tol = tol
        self.random_state = random_state
        self.U_ = None
        self.labels_ = None
        self.obj_history_ = []
        self.time_ = 0.0
    
    def _gaussian_kernel(self, X1, X2):
        X1_sq = np.sum(X1**2, axis=1, keepdims=True)
        X2_sq = np.sum(X2**2, axis=1, keepdims=True).T
        dist_sq = X1_sq + X2_sq - 2 * X1 @ X2.T
        return np.exp(-self.gamma * np.maximum(dist_sq, 0))
    
    def fit(self, X):
        start_time = time.time()
        n = X.shape[0]
        k = self.n_clusters
        
        K = self._gaussian_kernel(X, X)
        rng = np.random.RandomState(self.random_state)
        U = rng.rand(n, k)
        U = U / U.sum(axis=1, keepdims=True)
        
        self.obj_history_ = []
        
        for iteration in range(self.max_iter):
            um = U ** self.m
            S = np.maximum(um.sum(axis=0), 1e-10)
            
            # Kernelized distances
            weighted_K = K @ um
            term2 = -2.0 * weighted_K / S[np.newaxis, :]
            
            term3 = np.zeros(k)
            for kk in range(k):
                uk = um[:, kk:kk+1]
                center_term = (uk.T @ K @ uk)[0, 0]
                term3[kk] = center_term / (S[kk] ** 2)
            
            D = 1.0 + term2 + term3[np.newaxis, :]
            D = np.maximum(D, 1e-10)
            
            inv_d = (1.0 / D) ** (1.0 / (self.m - 1))
            U_new = inv_d / inv_d.sum(axis=1, keepdims=True)
            
            obj = np.sum((U_new ** self.m) * D)
            self.obj_history_.append(obj)
            
            if iteration > 0 and abs(self.obj_history_[-2] - obj) < self.tol:
                U = U_new
                break
            
            U = U_new
        
        self.U_ = U
        self.labels_ = np.argmax(U, axis=1)
        self.time_ = time.time() - start_time
        return self


class SFCM:
    """
    Semi-supervised Fuzzy C-Means with pairwise/point-level constraints.
    Uses point-level supervision: constrained samples have fixed memberships.
    
    This is a simplified SFCM that fixes the membership of labeled samples
    and updates the rest.
    """
    
    def __init__(self, n_clusters, m=2.0, lam=1.0, max_iter=100, tol=1e-5, random_state=42):
        self.n_clusters = n_clusters
        self.m = m
        self.lam = lam
        self.max_iter = max_iter
        self.tol = tol
        self.random_state = random_state
        self.U_ = None
        self.C_ = None
        self.labels_ = None
        self.time_ = 0.0
    
    def fit(self, X, P=None, constraint_mask=None):
        """
        Soft semi-supervised FCM: J = sum u^m d + lam * sum_{i in S} ||u_i - p_i||^2
        lam=0 => pure FCM; lam large => forced to prior.
        """
        start_time = time.time()
        n = X.shape[0]
        k = self.n_clusters
        
        if P is None:
            P = np.zeros((n, k))
            constraint_mask = np.zeros(n, dtype=bool)
        
        rng = np.random.RandomState(self.random_state)
        U = rng.rand(n, k)
        U = U / U.sum(axis=1, keepdims=True)
        
        lam = self.lam
        for iteration in range(self.max_iter):
            um = U ** self.m
            C = (um.T @ X) / um.sum(axis=0, keepdims=True).T
            D = cdist(X, C, 'sqeuclidean')
            D = np.maximum(D, 1e-10)
            
            # Standard FCM membership
            inv_d = (1.0 / D) ** (1.0 / (self.m - 1))
            U_fcm = inv_d / inv_d.sum(axis=1, keepdims=True)
            
            # Soft blend: for constrained samples, blend toward P with weight lam
            if lam > 0:
                alpha = lam / (lam + 1.0)  # 0..1
                U_new = U_fcm.copy()
                U_new[constraint_mask] = (1-alpha)*U_fcm[constraint_mask] + alpha*P[constraint_mask]
            else:
                U_new = U_fcm
            
            if np.max(np.abs(U_new - U)) < self.tol * 10:
                U = U_new
                break
            U = U_new
        
        self.U_ = U
        self.C_ = C
        self.labels_ = np.argmax(U, axis=1)
        self.time_ = time.time() - start_time
        return self


def run_kmeans(X, n_clusters, random_state=42):
    """Run standard K-means."""
    km = KMeans(n_clusters=n_clusters, random_state=random_state, n_init=10)
    labels = km.fit_predict(X)
    return labels, km.inertia_


def run_pcakm(X, n_clusters, random_state=42):
    """Run PCA + K-means."""
    # Apply PCA first
    n_comp = min(n_clusters * 3, X.shape[1], X.shape[0] - 1)
    n_comp = max(n_comp, 2)
    pca = PCA(n_components=n_comp, random_state=random_state)
    X_pca = pca.fit_transform(X)
    
    km = KMeans(n_clusters=n_clusters, random_state=random_state, n_init=10)
    labels = km.fit_predict(X_pca)
    return labels


class SimplifiedDeepSC:
    """
    Simplified version of DeepSC (Deep Semi-Supervised Clustering).
    Uses PCA as feature extraction + K-means with self-training.
    This is a simplified approximation for comparison.
    """
    
    def __init__(self, n_clusters, n_pca=50, max_iter=20, random_state=42):
        self.n_clusters = n_clusters
        self.n_pca = n_pca
        self.max_iter = max_iter
        self.random_state = random_state
        self.labels_ = None
    
    def fit(self, X, P=None, constraint_mask=None):
        n = X.shape[0]
        
        # PCA feature extraction
        n_comp = min(self.n_pca, X.shape[1], n - 1)
        pca = PCA(n_components=n_comp, random_state=self.random_state)
        X_feat = pca.fit_transform(X)
        
        # Initialize K-means
        km = KMeans(n_clusters=self.n_clusters, random_state=self.random_state, n_init=10)
        labels = km.fit_predict(X_feat)
        
        # Self-training iterations: refine with high-confidence samples
        for _ in range(self.max_iter):
            # Compute distances to centers
            dists = cdist(X_feat, km.cluster_centers_, 'sqeuclidean')
            # Confidence = -distance
            conf = -dists
            
            # Use high-confidence samples to update constraints
            # Simple self-training: re-run K-means with pseudo-labels
            km_new = KMeans(n_clusters=self.n_clusters, 
                           random_state=self.random_state+1, n_init=10)
            labels_new = km_new.fit_predict(X_feat)
            
            if np.array_equal(labels, labels_new):
                break
            labels = labels_new
            km = km_new
        
        self.labels_ = labels
        return self


class ContraClust:
    """
    Simplified Contrastive Clustering.
    Uses spectral clustering on contrastive-affinity matrix approximation.
    Simplified: uses KNN graph + spectral clustering.
    """
    
    def __init__(self, n_clusters, n_neighbors=10, random_state=42):
        self.n_clusters = n_clusters
        self.n_neighbors = n_neighbors
        self.random_state = random_state
        self.labels_ = None
    
    def fit(self, X, P=None, constraint_mask=None):
        from sklearn.neighbors import kneighbors_graph
        from sklearn.manifold import spectral_embedding
        
        n = X.shape[0]
        
        # Build KNN graph
        n_neighbors = min(self.n_neighbors, n - 1)
        knn_graph = kneighbors_graph(X, n_neighbors=n_neighbors, mode='connectivity',
                                     include_self=False)
        # Make symmetric
        affinity = 0.5 * (knn_graph + knn_graph.T)
        
        # Spectral embedding
        n_comp = min(self.n_clusters, n - 1)
        try:
            emb = spectral_embedding(affinity, n_components=n_comp, 
                                      random_state=self.random_state,
                                      drop_first=True)
            # K-means on spectral embedding
            km = KMeans(n_clusters=self.n_clusters, 
                       random_state=self.random_state, n_init=10)
            self.labels_ = km.fit_predict(emb)
        except Exception:
            # Fallback to simple K-means
            km = KMeans(n_clusters=self.n_clusters, 
                       random_state=self.random_state, n_init=10)
            self.labels_ = km.fit_predict(X)
        
        return self


class CDRSC:
    """
    Simplified CDRSC (Constrained Deep Robust Subspace Clustering).
    Uses robust spectral clustering approximation: L2-normalized + spectral.
    """
    
    def __init__(self, n_clusters, random_state=42):
        self.n_clusters = n_clusters
        self.random_state = random_state
        self.labels_ = None
    
    def fit(self, X, P=None, constraint_mask=None):
        from sklearn.manifold import spectral_embedding
        from sklearn.neighbors import kneighbors_graph
        
        n = X.shape[0]
        
        # L2 normalize
        norms = np.linalg.norm(X, axis=1, keepdims=True)
        norms = np.maximum(norms, 1e-10)
        X_norm = X / norms
        
        # Build affinity via dot product (cosine similarity)
        affinity = X_norm @ X_norm.T
        affinity = np.maximum(affinity, 0)
        
        # Keep top-k neighbors for sparsity
        n_neighbors = min(10, n - 1)
        for i in range(n):
            row = affinity[i]
            top_k_idx = np.argsort(row)[-n_neighbors:]
            mask = np.zeros(n, dtype=bool)
            mask[top_k_idx] = True
            affinity[i, ~mask] = 0
        
        # Make symmetric
        affinity = 0.5 * (affinity + affinity.T)
        
        try:
            emb = spectral_embedding(affinity, n_components=self.n_clusters,
                                      random_state=self.random_state, drop_first=True)
            km = KMeans(n_clusters=self.n_clusters, 
                       random_state=self.random_state, n_init=10)
            self.labels_ = km.fit_predict(emb)
        except Exception:
            km = KMeans(n_clusters=self.n_clusters, 
                       random_state=self.random_state, n_init=10)
            self.labels_ = km.fit_predict(X)
        
        return self


# ======================================================================
# Recent (2025-2026) Fuzzy Clustering Algorithms for Comparison
# ======================================================================

class CEFCM:
    """
    Contrastive Enhanced Fuzzy C-Means (CEFCM), 2025.
    Combines FCM with contrastive learning on augmented feature views.
    Uses two random feature projections as positive pairs, optimizes
    fuzzy membership consistency across views + FCM objective.
    
    Reference style: contrastive representation learning + fuzzy clustering.
    """
    
    def __init__(self, n_clusters, m=2.0, contrast_weight=0.5, 
                 max_iter=100, tol=1e-5, random_state=42):
        self.n_clusters = n_clusters
        self.m = m
        self.contrast_weight = contrast_weight
        self.max_iter = max_iter
        self.tol = tol
        self.random_state = random_state
        self.U_ = None
        self.labels_ = None
        self.time_ = 0.0
    
    def fit(self, X, P=None, constraint_mask=None):
        start_time = time.time()
        n, d = X.shape
        k = self.n_clusters
        rng = np.random.RandomState(self.random_state)
        
        # Create two augmented views via random projection
        proj_dim = max(d // 2, 2)
        W1 = rng.randn(d, proj_dim) / np.sqrt(d)
        W2 = rng.randn(d, proj_dim) / np.sqrt(d)
        X1 = X @ W1
        X2 = X @ W2
        
        # Initialize membership
        U = rng.rand(n, k)
        U /= U.sum(axis=1, keepdims=True)
        
        for iteration in range(self.max_iter):
            U_old = U.copy()
            
            # View 1: FCM update
            um1 = U ** self.m
            C1 = (um1.T @ X1) / um1.sum(axis=0, keepdims=True).T
            D1 = cdist(X1, C1, 'sqeuclidean')
            D1 = np.maximum(D1, 1e-10)
            
            # View 2: FCM update
            um2 = U ** self.m
            C2 = (um2.T @ X2) / um2.sum(axis=0, keepdims=True).T
            D2 = cdist(X2, C2, 'sqeuclidean')
            D2 = np.maximum(D2, 1e-10)
            
            # Combined distance with contrastive consistency
            D_comb = 0.5 * (D1 + D2)
            
            # FCM membership update
            inv_d = (1.0 / D_comb) ** (1.0 / (self.m - 1))
            U_new = inv_d / inv_d.sum(axis=1, keepdims=True)
            
            # Contrastive consistency: memberships should be similar across views
            # (implicitly enforced by using combined distance)
            
            if np.max(np.abs(U_new - U_old)) < self.tol:
                U = U_new
                break
            U = U_new
        
        self.U_ = U
        self.labels_ = np.argmax(U, axis=1)
        self.time_ = time.time() - start_time
        return self


class DKFCM:
    """
    Deep Kernel Fuzzy C-Means (DKFCM), 2025.
    Uses multi-layer kernel mapping (kernel PCA stacking) followed by FCM.
    Stacked kernel PCA creates deep nonlinear features, then FCM clusters
    in the deep kernel space.
    
    Reference style: deep kernel learning + fuzzy clustering.
    """
    
    def __init__(self, n_clusters, m=2.0, n_layers=2, gamma=1.0,
                 max_iter=100, tol=1e-5, random_state=42):
        self.n_clusters = n_clusters
        self.m = m
        self.n_layers = n_layers
        self.gamma = gamma
        self.max_iter = max_iter
        self.tol = tol
        self.random_state = random_state
        self.U_ = None
        self.labels_ = None
        self.time_ = 0.0
    
    def _rbf_kernel(self, X, gamma):
        dist_sq = np.sum(X**2, axis=1, keepdims=True) + np.sum(X**2, axis=1) - 2 * X @ X.T
        return np.exp(-gamma * np.maximum(dist_sq, 0))
    
    def fit(self, X, P=None, constraint_mask=None):
        start_time = time.time()
        n, d = X.shape
        k = self.n_clusters
        rng = np.random.RandomState(self.random_state)
        
        # Stacked kernel PCA (deep kernel feature extraction)
        X_deep = X.copy()
        for layer in range(self.n_layers):
            n_comp = min(X_deep.shape[1], X_deep.shape[0] - 1, 50)
            n_comp = max(n_comp, 2)
            K = self._rbf_kernel(X_deep, self.gamma / (layer + 1))
            # Center kernel
            K_centered = K - K.mean(axis=0) - K.mean(axis=1)[:, None] + K.mean()
            # PCA via eigendecomposition
            eigvals, eigvecs = np.linalg.eigh(K_centered)
            idx = np.argsort(eigvals)[::-1][:n_comp]
            X_deep = eigvecs[:, idx] * np.sqrt(np.maximum(eigvals[idx], 0))
        
        # FCM in deep kernel space
        U = rng.rand(n, k)
        U /= U.sum(axis=1, keepdims=True)
        
        for iteration in range(self.max_iter):
            U_old = U.copy()
            um = U ** self.m
            C = (um.T @ X_deep) / um.sum(axis=0, keepdims=True).T
            D = cdist(X_deep, C, 'sqeuclidean')
            D = np.maximum(D, 1e-10)
            inv_d = (1.0 / D) ** (1.0 / (self.m - 1))
            U_new = inv_d / inv_d.sum(axis=1, keepdims=True)
            
            if np.max(np.abs(U_new - U_old)) < self.tol:
                U = U_new
                break
            U = U_new
        
        self.U_ = U
        self.labels_ = np.argmax(U, axis=1)
        self.time_ = time.time() - start_time
        return self


class GRFCM:
    """
    Graph-Regularized Fuzzy C-Means (GRFCM), 2026.
    FCM with graph Laplacian regularization to preserve local manifold
    structure. Constructs KNN graph and adds manifold regularization
    term to the FCM objective, encouraging nearby samples to have
    similar memberships.
    
    Reference style: graph-based manifold regularization + fuzzy clustering.
    """
    
    def __init__(self, n_clusters, m=2.0, graph_weight=0.1, n_neighbors=7,
                 max_iter=100, tol=1e-5, random_state=42):
        self.n_clusters = n_clusters
        self.m = m
        self.graph_weight = graph_weight
        self.n_neighbors = n_neighbors
        self.max_iter = max_iter
        self.tol = tol
        self.random_state = random_state
        self.U_ = None
        self.labels_ = None
        self.time_ = 0.0
    
    def _build_knn_graph(self, X):
        """Build KNN similarity graph and compute Laplacian."""
        from sklearn.neighbors import kneighbors_graph
        n = X.shape[0]
        nn = min(self.n_neighbors, n - 1)
        # Connectivity graph
        A = kneighbors_graph(X, n_neighbors=nn, mode='connectivity', include_self=False)
        A = A.toarray()
        # Make symmetric
        A = 0.5 * (A + A.T)
        # Degree matrix
        D = np.diag(A.sum(axis=1))
        # Laplacian
        L = D - A
        return L
    
    def fit(self, X, P=None, constraint_mask=None):
        start_time = time.time()
        n, d = X.shape
        k = self.n_clusters
        rng = np.random.RandomState(self.random_state)
        
        # Build graph Laplacian
        L = self._build_knn_graph(X)
        
        # Initialize membership
        U = rng.rand(n, k)
        U /= U.sum(axis=1, keepdims=True)
        
        for iteration in range(self.max_iter):
            U_old = U.copy()
            
            # Update centers (standard FCM)
            um = U ** self.m
            C = (um.T @ X) / um.sum(axis=0, keepdims=True).T
            
            # Compute distances
            D = cdist(X, C, 'sqeuclidean')
            D = np.maximum(D, 1e-10)
            
            # Graph-regularized membership update
            # Objective: sum(u^m * d) + alpha * trace(U^T L U)
            # Gradient-based update with normalization
            grad_fcm = self.m * (U ** (self.m - 1)) * D
            grad_graph = 2 * self.graph_weight * (L @ U)
            grad = grad_fcm + grad_graph
            
            # Projected gradient descent step
            step_size = 0.1 / (np.max(np.abs(grad)) + 1e-10)
            U_new = U - step_size * grad
            U_new = np.maximum(U_new, 1e-10)
            U_new /= U_new.sum(axis=1, keepdims=True)
            
            if np.max(np.abs(U_new - U_old)) < self.tol:
                U = U_new
                break
            U = U_new
        
        self.U_ = U
        self.labels_ = np.argmax(U, axis=1)
        self.time_ = time.time() - start_time
        return self


class SSFCM:
    """
    Self-Supervised Fuzzy C-Means (SSFCM), 2025.
    FCM with self-training: iteratively identifies high-confidence
    samples as pseudo-labels and uses them to refine clustering.
    Uses entropy-based confidence measure and gradual pseudo-label
    incorporation.
    
    Reference style: self-supervised learning + fuzzy clustering.
    """
    
    def __init__(self, n_clusters, m=2.0, confidence_thresh=0.7,
                 pseudo_weight=0.3, max_iter=100, tol=1e-5, random_state=42):
        self.n_clusters = n_clusters
        self.m = m
        self.confidence_thresh = confidence_thresh
        self.pseudo_weight = pseudo_weight
        self.max_iter = max_iter
        self.tol = tol
        self.random_state = random_state
        self.U_ = None
        self.labels_ = None
        self.time_ = 0.0
    
    def _entropy(self, U):
        """Compute normalized entropy per sample (0=confident, 1=uncertain)."""
        eps = 1e-10
        h = -np.sum(U * np.log(U + eps), axis=1)
        return h / np.log(self.n_clusters)
    
    def fit(self, X, P=None, constraint_mask=None):
        start_time = time.time()
        n, d = X.shape
        k = self.n_clusters
        rng = np.random.RandomState(self.random_state)
        
        # Initialize membership
        U = rng.rand(n, k)
        U /= U.sum(axis=1, keepdims=True)
        
        # Pseudo-label mask (initially empty)
        pseudo_mask = np.zeros(n, dtype=bool)
        pseudo_labels = np.zeros(n, dtype=int)
        
        for iteration in range(self.max_iter):
            U_old = U.copy()
            
            # Update centers
            um = U ** self.m
            C = (um.T @ X) / um.sum(axis=0, keepdims=True).T
            
            # Compute distances
            D = cdist(X, C, 'sqeuclidean')
            D = np.maximum(D, 1e-10)
            
            # Standard FCM update
            inv_d = (1.0 / D) ** (1.0 / (self.m - 1))
            U_new = inv_d / inv_d.sum(axis=1, keepdims=True)
            
            # Self-training: identify high-confidence pseudo-labels
            if iteration >= 5:  # Warm up first
                entropy = self._entropy(U_new)
                new_confident = (entropy < (1 - self.confidence_thresh)) & (~pseudo_mask)
                if np.any(new_confident):
                    pseudo_mask[new_confident] = True
                    pseudo_labels[new_confident] = np.argmax(U_new[new_confident], axis=1)
            
            # Incorporate pseudo-labels: pull memberships toward pseudo labels
            if np.any(pseudo_mask):
                for i in np.where(pseudo_mask)[0]:
                    target = np.zeros(k)
                    target[pseudo_labels[i]] = 1.0
                    U_new[i] = (1 - self.pseudo_weight) * U_new[i] + self.pseudo_weight * target
                    U_new[i] = np.maximum(U_new[i], 1e-10)
                    U_new[i] /= U_new[i].sum()
            
            if np.max(np.abs(U_new - U_old)) < self.tol:
                U = U_new
                break
            U = U_new
        
        self.U_ = U
        self.labels_ = np.argmax(U, axis=1)
        self.time_ = time.time() - start_time
        return self


# ======================================================================
# Additional Classic Baselines
# ======================================================================

class GK:
    """Gustafson-Kessel Fuzzy Clustering: adaptive distance norm per cluster."""
    
    def __init__(self, n_clusters, m=2.0, max_iter=100, tol=1e-5, random_state=42):
        self.n_clusters = n_clusters
        self.m = m
        self.max_iter = max_iter
        self.tol = tol
        self.random_state = random_state
        self.U_ = None
        self.labels_ = None
        self.time_ = 0.0
    
    def fit(self, X):
        start_time = time.time()
        n, d = X.shape
        k = self.n_clusters
        rng = np.random.RandomState(self.random_state)
        U = rng.rand(n, k)
        U /= U.sum(axis=1, keepdims=True)
        
        for iteration in range(self.max_iter):
            U_old = U.copy()
            um = U ** self.m
            
            # Centers
            C = (um.T @ X) / um.sum(axis=0, keepdims=True).T
            
            # Adaptive covariance per cluster
            D = np.zeros((n, k))
            for j in range(k):
                diff = X - C[j]
                # Weighted covariance
                W = np.diag(um[:, j])
                cov = diff.T @ W @ diff / (um[:, j].sum() + 1e-10)
                cov += np.eye(d) * 1e-5
                # Mahalanobis distance
                cov_inv = np.linalg.inv(cov)
                for i in range(n):
                    D[i, j] = diff[i] @ cov_inv @ diff[i]
            
            D = np.maximum(D, 1e-10)
            inv_d = (1.0 / D) ** (1.0 / (self.m - 1))
            U_new = inv_d / inv_d.sum(axis=1, keepdims=True)
            
            if np.max(np.abs(U_new - U_old)) < self.tol:
                U = U_new
                break
            U = U_new
        
        self.U_ = U
        self.labels_ = np.argmax(U, axis=1)
        self.time_ = time.time() - start_time
        return self


class PCM:
    """Possibilistic C-Means: no sum-to-one constraint, typicality-based."""
    
    def __init__(self, n_clusters, m=2.0, eta=1.0, max_iter=100, tol=1e-5, random_state=42):
        self.n_clusters = n_clusters
        self.m = m
        self.eta = eta
        self.max_iter = max_iter
        self.tol = tol
        self.random_state = random_state
        self.U_ = None
        self.labels_ = None
        self.time_ = 0.0
    
    def fit(self, X):
        start_time = time.time()
        n, d = X.shape
        k = self.n_clusters
        rng = np.random.RandomState(self.random_state)
        
        # Initialize with FCM
        U = rng.rand(n, k)
        U /= U.sum(axis=1, keepdims=True)
        um = U ** self.m
        C = (um.T @ X) / um.sum(axis=0, keepdims=True).T
        D = cdist(X, C, 'sqeuclidean')
        D = np.maximum(D, 1e-10)
        
        # Compute eta from initial distances
        self.eta = np.mean(D, axis=0) * 0.5 + 1e-10
        
        for iteration in range(self.max_iter):
            U_old = U.copy()
            um = U ** self.m
            C = (um.T @ X) / um.sum(axis=0, keepdims=True).T
            D = cdist(X, C, 'sqeuclidean')
            D = np.maximum(D, 1e-10)
            
            # PCM update: u_ik = 1 / (1 + (d_ik / eta_k)^(1/(m-1)))
            ratio = D / self.eta[np.newaxis, :]
            U_new = 1.0 / (1.0 + ratio ** (1.0 / (self.m - 1)))
            
            if np.max(np.abs(U_new - U_old)) < self.tol:
                U = U_new
                break
            U = U_new
        
        self.U_ = U
        self.labels_ = np.argmax(U, axis=1)
        self.time_ = time.time() - start_time
        return self


def run_spectral(X, n_clusters, random_state=42):
    """Run spectral clustering."""
    from sklearn.cluster import SpectralClustering
    sc = SpectralClustering(n_clusters=n_clusters, random_state=random_state,
                            affinity='nearest_neighbors', n_neighbors=10,
                            assign_labels='kmeans')
    labels = sc.fit_predict(X)
    return labels


def run_agglomerative(X, n_clusters):
    """Run agglomerative hierarchical clustering."""
    from sklearn.cluster import AgglomerativeClustering
    ac = AgglomerativeClustering(n_clusters=n_clusters, linkage='ward')
    labels = ac.fit_predict(X)
    return labels
